package com.example

import com.example.core.model.PlatformCommissionConfig
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun adminCommission_calculationIsCorrect() {
    val config = PlatformCommissionConfig()
    assertEquals(0.5, config.percentageCommission, 0.001)

    val totalBookingAmount = 9000.0
    val adminCharge = totalBookingAmount * 0.005
    val remainingAmount = totalBookingAmount - adminCharge

    assertEquals(45.0, adminCharge, 0.001)
    assertEquals(8955.0, remainingAmount, 0.001)
  }
}
