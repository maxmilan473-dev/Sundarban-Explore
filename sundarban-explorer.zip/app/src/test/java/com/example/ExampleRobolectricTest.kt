package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.localization.AppLanguage
import com.example.core.localization.LanguageManager
import com.example.core.model.Booking
import com.example.core.model.BookingStatus
import com.example.core.model.EmergencyContact
import com.example.core.model.OperatorStatus
import com.example.core.model.PaymentMethod
import com.example.core.model.PaymentStatus
import com.example.core.model.TourPackage
import com.example.core.model.UserRole
import com.example.core.security.SecurityManager
import com.example.data.database.AppDatabase
import com.example.data.repositories.AuthRepositoryImpl
import com.example.data.repositories.AuthResult
import com.example.data.repositories.ContentRepositoryImpl
import com.example.data.repositories.TourRepositoryImpl
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var authRepository: AuthRepositoryImpl
    private lateinit var tourRepository: TourRepositoryImpl
    private lateinit var contentRepository: ContentRepositoryImpl
    private lateinit var languageManager: LanguageManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        val database = AppDatabase.getDatabase(context)
        authRepository = AuthRepositoryImpl(context, database)
        tourRepository = TourRepositoryImpl(authRepository)
        contentRepository = ContentRepositoryImpl()
        languageManager = LanguageManager.getInstance(context)
    }

    @Test
    fun `verify app name resource`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Sundarban Explorer", appName)
    }

    @Test
    fun `test security manager validation utilities`() {
        // Email Validation
        assertTrue(SecurityManager.isValidEmail("tourist@example.com"))
        assertTrue(SecurityManager.isValidEmail("admin@sundarbanexplorer.gov.in"))
        assertFalse(SecurityManager.isValidEmail("invalid-email"))
        assertFalse(SecurityManager.isValidEmail("missing@domain"))

        // Phone Validation (Indian mobile format)
        assertTrue(SecurityManager.isValidPhoneNumber("+91 9830012345"))
        assertTrue(SecurityManager.isValidPhoneNumber("9830012345"))
        assertFalse(SecurityManager.isValidPhoneNumber("12345"))

        // Password Strength Validation
        val strongPass = SecurityManager.validatePassword("Sundarban@2026")
        assertTrue(strongPass.isValid)

        val weakPass = SecurityManager.validatePassword("12345")
        assertFalse(weakPass.isValid)
    }

    @Test
    fun `test tourist sign in and role enforcement`() = runBlocking {
        val touristLogin = authRepository.signIn(
            email = "tourist@example.com",
            password = "Tourist@1234",
            role = UserRole.CUSTOMER
        )
        assertTrue(touristLogin is AuthResult.Success)
        val user = (touristLogin as AuthResult.Success).data
        assertEquals("Priya Sharma", user.fullName)
        assertEquals(UserRole.CUSTOMER, user.role)
    }

    @Test
    fun `test operator verification workflow by admin`() = runBlocking {
        // Debashis Roy is seeded as REQUIRES_ADMIN_REVIEW
        val users = authRepository.getAllUsersForAdmin().first()
        val pendingOperator = users.firstOrNull { it.email == "delta_safari@sundarban.com" }
        assertNotNull(pendingOperator)
        assertEquals(OperatorStatus.REQUIRES_ADMIN_REVIEW, pendingOperator?.operatorDetails?.verificationStatus)

        // Admin approves operator
        val approvalResult = authRepository.updateOperatorVerificationStatus(
            operatorId = pendingOperator!!.id,
            status = OperatorStatus.VERIFIED
        )
        assertTrue(approvalResult is AuthResult.Success)

        // Check that operator is now verified
        val updatedUsers = authRepository.getAllUsersForAdmin().first()
        val verifiedOperator = updatedUsers.first { it.id == pendingOperator.id }
        assertEquals(OperatorStatus.VERIFIED, verifiedOperator.operatorDetails?.verificationStatus)
        assertTrue(verifiedOperator.isVerified)
    }

    @Test
    fun `test tour package booking and payment creation`() = runBlocking {
        val packages = tourRepository.getPublicVerifiedPackages().first()
        assertTrue(packages.isNotEmpty())
        val selectedPackage = packages.first()

        val booking = Booking(
            id = "test_booking_001",
            customerId = "cust_tourist_001",
            customerName = "Priya Sharma",
            customerPhone = "+91 9820011223",
            operatorId = selectedPackage.operatorId,
            operatorName = selectedPackage.operatorName,
            packageId = selectedPackage.id,
            packageTitle = selectedPackage.title,
            travelDate = "2026-10-15",
            numberOfTourists = 2,
            totalAmount = selectedPackage.pricePerPerson * 2,
            paymentMethod = PaymentMethod.ONLINE_UPI_CARD,
            paymentStatus = PaymentStatus.PAID,
            bookingStatus = BookingStatus.CONFIRMED
        )

        tourRepository.createBooking(booking)

        val customerBookings = tourRepository.getBookingsForCustomer("cust_tourist_001").first()
        assertTrue(customerBookings.any { it.id == "test_booking_001" })
    }

    @Test
    fun `test localized strings across English, Bengali, and Hindi`() = runBlocking {
        languageManager.setLanguage(AppLanguage.ENGLISH)
        assertEquals("Sundarban Explorer", languageManager.currentStrings.value.appName)
        assertEquals("Sign In", languageManager.currentStrings.value.login)

        languageManager.setLanguage(AppLanguage.BENGALI)
        assertEquals("সুন্দরবন এক্সপ্লোরার", languageManager.currentStrings.value.appName)
        assertEquals("লগইন করুন", languageManager.currentStrings.value.login)

        languageManager.setLanguage(AppLanguage.HINDI)
        assertEquals("सुंदरबन एक्सप्लोरर", languageManager.currentStrings.value.appName)
        assertEquals("साइन इन करें", languageManager.currentStrings.value.login)
    }
}
