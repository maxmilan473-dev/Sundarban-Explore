package com.example.features.booking

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.model.*
import com.example.core.util.CancellationTimeHelper
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun RequestCancellationDialog(
    booking: Booking,
    currentUser: UserProfile?,
    onDismiss: () -> Unit,
    onSubmit: (reason: String, detailedExplanation: String?) -> Unit
) {
    var reason by remember { mutableStateOf("") }
    var detailedExplanation by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }

    val hoursRemaining = remember(booking) {
        CancellationTimeHelper.calculateHoursRemaining(booking.travelDate, booking.tourStartTime)
    }
    val isEmergency = hoursRemaining <= 5.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isEmergency) Icons.Default.WarningAmber else Icons.Default.Cancel,
                    contentDescription = null,
                    tint = if (isEmergency) MaterialTheme.colorScheme.error else TigerAmber,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isEmergency) "Emergency Cancellation" else "Request Cancellation",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Time context banner
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isEmergency) MaterialTheme.colorScheme.errorContainer else TigerAmber.copy(alpha = 0.12f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (isEmergency) MaterialTheme.colorScheme.onErrorContainer else TigerAmber
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = CancellationTimeHelper.formatHoursRemaining(hoursRemaining),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isEmergency) MaterialTheme.colorScheme.onErrorContainer else TigerAmber
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isEmergency) {
                                "⚠️ Less than 5 hours remain before safari start. This request will be submitted directly to Sundarban Forest Directorate Admin Review. Booking will not cancel automatically."
                            } else {
                                "ℹ️ More than 5 hours remain. Both parties must agree to cancel this booking. The other party will receive this request to accept or reject."
                            },
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = if (isEmergency) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Text(
                    text = "Booking #${booking.id} • ${booking.packageTitle}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = {
                        reason = it
                        if (it.isNotBlank()) showError = false
                    },
                    label = { Text("Cancellation Reason *") },
                    placeholder = {
                        Text(if (isEmergency) "e.g., Medical emergency, sudden boat mechanical issue" else "e.g., Change of travel plans, unexpected delay")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cancellation_reason_input"),
                    isError = showError,
                    supportingText = if (showError) {
                        { Text("Reason is required", color = MaterialTheme.colorScheme.error) }
                    } else null,
                    minLines = 2,
                    maxLines = 4
                )

                OutlinedTextField(
                    value = detailedExplanation,
                    onValueChange = { detailedExplanation = it },
                    label = { Text("Detailed Explanation (Optional)") },
                    placeholder = { Text("Provide any additional context or proof for the review") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cancellation_explanation_input"),
                    minLines = 2,
                    maxLines = 4
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (reason.isBlank()) {
                        showError = true
                    } else {
                        onSubmit(reason.trim(), detailedExplanation.trim().ifBlank { null })
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isEmergency) MaterialTheme.colorScheme.error else TigerAmber
                ),
                modifier = Modifier.testTag("submit_cancellation_btn")
            ) {
                Text(if (isEmergency) "Submit Emergency Request" else "Submit Cancel Request")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun CancellationDiscussionDialog(
    booking: Booking,
    currentUser: UserProfile?,
    onDismiss: () -> Unit,
    onSendMessage: (String) -> Unit,
    onAcceptCancellation: () -> Unit,
    onRejectCancellation: (rejectionReason: String) -> Unit
) {
    val activeReq = booking.activeCancellationRequest
    var replyText by remember { mutableStateOf("") }
    var showRejectConfirm by remember { mutableStateOf(false) }
    var rejectReasonText by remember { mutableStateOf("") }

    val isInitiator = currentUser?.id == activeReq?.initiatedByUid
    val isResponder = currentUser != null && !isInitiator && (currentUser.id == booking.customerId || currentUser.id == booking.operatorId)
    val canTakeDecision = isResponder && activeReq != null && !activeReq.isEmergency && activeReq.status == CancellationRequestStatus.PENDING_OTHER_PARTY

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (activeReq?.isEmergency == true) "Emergency Review Dossier" else "Cancellation Discussion",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Text(
                            text = "Booking #${booking.id}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Request Summary Card
                activeReq?.let { req ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (req.isEmergency) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Initiated by ${req.initiatedByName} (${req.initiatedByRole.displayName})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (req.isEmergency) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = req.status.displayName,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (req.isEmergency) MaterialTheme.colorScheme.error else MangrovePrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Reason: ${req.reason}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (!req.detailedExplanation.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Details: ${req.detailedExplanation}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date(req.requestedAt))
                            Text(
                                text = "Submitted: $dateStr • ${String.format(Locale.US, "%.1f", req.hoursRemainingAtRequest)}h to tour",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Mutual Agreement Actions (Only shown to responder when in normal cancellation flow)
                if (canTakeDecision) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MangrovePrimary.copy(alpha = 0.08f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MangrovePrimary.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Mutual Agreement Required",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MangrovePrimary
                            )
                            Text(
                                text = "You can accept to cancel the booking & initiate refund, or reject to keep it confirmed.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onAcceptCancellation,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("accept_cancellation_btn")
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Accept & Cancel", fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = { showRejectConfirm = true },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("reject_cancellation_btn")
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reject Request", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Discussion Thread
                Text(
                    text = "Discussion & Messages (${activeReq?.discussionMessages?.size ?: 0})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val msgs = activeReq?.discussionMessages ?: emptyList()
                    if (msgs.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No messages yet. Send a message to discuss options.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        items(msgs) { msg ->
                            val isMe = msg.senderUid == currentUser?.id
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(
                                        topStart = 12.dp,
                                        topEnd = 12.dp,
                                        bottomStart = if (isMe) 12.dp else 2.dp,
                                        bottomEnd = if (isMe) 2.dp else 12.dp
                                    ),
                                    color = if (isMe) MangrovePrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.widthIn(max = 280.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = if (isMe) "You" else "${msg.senderName} (${msg.senderRole.displayName})",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = MangrovePrimary
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = msg.message,
                                            fontSize = 12.sp
                                        )
                                        val timeStr = SimpleDateFormat("hh:mm a", Locale.US).format(Date(msg.timestamp))
                                        Text(
                                            text = timeStr,
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.align(Alignment.End)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Message input
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        placeholder = { Text("Write message...", fontSize = 12.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("discussion_message_input"),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            if (replyText.isNotBlank()) {
                                onSendMessage(replyText.trim())
                                replyText = ""
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MangrovePrimary)
                            .testTag("send_discussion_msg_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    // Rejection reason prompt dialog
    if (showRejectConfirm) {
        AlertDialog(
            onDismissRequest = { showRejectConfirm = false },
            title = { Text("Reject Cancellation", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "The booking will remain CONFIRMED. Please provide a reason for declining:",
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = rejectReasonText,
                        onValueChange = { rejectReasonText = it },
                        label = { Text("Rejection Note") },
                        placeholder = { Text("e.g., Boat passes already reserved and non-refundable") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRejectConfirm = false
                        onRejectCancellation(rejectReasonText.trim().ifBlank { "Declined by other party" })
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Confirm Rejection")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRejectConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminEmergencyDecisionDialog(
    booking: Booking,
    adminUser: UserProfile?,
    allOperators: List<UserProfile>,
    onDismiss: () -> Unit,
    onSubmitDecision: (
        decisionType: AdminDecisionType,
        refundDecision: AdminRefundDecision,
        refundAmount: Double,
        rescheduledDate: String?,
        newOperatorId: String?,
        reason: String
    ) -> Unit
) {
    val activeReq = booking.activeCancellationRequest
    var selectedDecisionType by remember { mutableStateOf(AdminDecisionType.APPROVE_CANCELLATION) }
    var selectedRefundDecision by remember { mutableStateOf(AdminRefundDecision.FULL_REFUND) }
    var partialRefundAmount by remember { mutableStateOf((booking.paidAmount * 0.5).toInt().toString()) }
    var rescheduledDate by remember { mutableStateOf(booking.travelDate) }
    var selectedOperatorId by remember { mutableStateOf(booking.operatorId) }
    var adminReason by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Gavel,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Emergency Directorate Review",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Booking #${booking.id}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Dossier Summary
                    item {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "🚨 Emergency Case Details",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Package: ${booking.packageTitle}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Departure: ${booking.travelDate} at ${booking.tourStartTime}",
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Tourist: ${booking.customerName} (${booking.customerPhone})",
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Operator: ${booking.operatorName} (${booking.operatorPhone})",
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Financials: Total ₹${booking.totalAmount.toInt()} | Paid ₹${booking.paidAmount.toInt()}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                activeReq?.let { req ->
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Initiated by: ${req.initiatedByName} (${req.initiatedByRole.displayName})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Reason: ${req.reason}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                    if (!req.detailedExplanation.isNullOrBlank()) {
                                        Text(
                                            text = "Explanation: ${req.detailedExplanation}",
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Decision Types
                    item {
                        Text(
                            text = "Select Directorate Adjudication Action *",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            AdminDecisionType.values().forEach { type ->
                                val isSelected = selectedDecisionType == type
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) MangrovePrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, MangrovePrimary) else null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedDecisionType = type }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { selectedDecisionType = type }
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = type.displayName,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Sub-options based on decision
                    item {
                        when (selectedDecisionType) {
                            AdminDecisionType.APPROVE_CANCELLATION -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                        .padding(10.dp)
                                ) {
                                    Text(
                                        text = "Refund Adjudication Policy",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))

                                    AdminRefundDecision.values().filter { it != AdminRefundDecision.NO_REFUND }.forEach { rDec ->
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { selectedRefundDecision = rDec }
                                        ) {
                                            RadioButton(
                                                selected = selectedRefundDecision == rDec,
                                                onClick = { selectedRefundDecision = rDec }
                                            )
                                            Text(rDec.displayName, fontSize = 12.sp)
                                        }
                                    }

                                    if (selectedRefundDecision == AdminRefundDecision.PARTIAL_REFUND) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        OutlinedTextField(
                                            value = partialRefundAmount,
                                            onValueChange = { partialRefundAmount = it },
                                            label = { Text("Partial Refund Amount (₹)") },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }

                            AdminDecisionType.RESCHEDULE_TOUR -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                        .padding(10.dp)
                                ) {
                                    Text("Reschedule Tour Date", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    OutlinedTextField(
                                        value = rescheduledDate,
                                        onValueChange = { rescheduledDate = it },
                                        label = { Text("New Tour Date (YYYY-MM-DD)") },
                                        placeholder = { Text("2026-09-25") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }

                            AdminDecisionType.REASSIGN_OPERATOR -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                        .padding(10.dp)
                                ) {
                                    Text("Reassign to Verified Operator", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    val operators = allOperators.filter { it.role == UserRole.OPERATOR }
                                    operators.forEach { op ->
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { selectedOperatorId = op.id }
                                        ) {
                                            RadioButton(
                                                selected = selectedOperatorId == op.id,
                                                onClick = { selectedOperatorId = op.id }
                                            )
                                            Text(op.fullName, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            AdminDecisionType.REQUEST_INFO -> {
                                Text(
                                    text = "ℹ️ Status will remain in EMERGENCY REVIEW while you request additional information from tourist/operator.",
                                    fontSize = 11.sp,
                                    color = MangrovePrimary
                                )
                            }

                            AdminDecisionType.REJECT_CANCELLATION -> {
                                Text(
                                    text = "ℹ️ Request will be declined and booking status will revert to CONFIRMED.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Admin Reason & Justification
                    item {
                        OutlinedTextField(
                            value = adminReason,
                            onValueChange = {
                                adminReason = it
                                if (it.isNotBlank()) showError = false
                            },
                            label = { Text("Official Admin Rationale / Reason *") },
                            placeholder = { Text("Mandatory explanation recorded in audit log and sent to both parties") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_decision_reason_input"),
                            isError = showError,
                            supportingText = if (showError) {
                                { Text("Official justification reason is mandatory", color = MaterialTheme.colorScheme.error) }
                            } else null,
                            minLines = 2,
                            maxLines = 4
                        )
                    }
                }

                // Submit Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            if (adminReason.isBlank()) {
                                showError = true
                            } else {
                                val refundAmt = partialRefundAmount.toDoubleOrNull() ?: (booking.paidAmount * 0.5)
                                onSubmitDecision(
                                    selectedDecisionType,
                                    selectedRefundDecision,
                                    refundAmt,
                                    if (selectedDecisionType == AdminDecisionType.RESCHEDULE_TOUR) rescheduledDate else null,
                                    if (selectedDecisionType == AdminDecisionType.REASSIGN_OPERATOR) selectedOperatorId else null,
                                    adminReason.trim()
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedDecisionType == AdminDecisionType.APPROVE_CANCELLATION) MaterialTheme.colorScheme.error else MangrovePrimary
                        ),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("submit_admin_decision_btn")
                    ) {
                        Text("Issue Directorate Ruling")
                    }
                }
            }
        }
    }
}
