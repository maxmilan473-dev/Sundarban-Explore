package com.example.features.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun AdminAnalyticsView(
    users: List<UserProfile>,
    bookings: List<Booking>,
    transactions: List<PaymentTransaction>,
    complaints: List<Complaint>,
    disputes: List<DisputeRecord>,
    refunds: List<RefundRecord>,
    packages: List<TourPackage>,
    modifier: Modifier = Modifier
) {
    var timeframeFilter by remember { mutableStateOf("Monthly") }

    val customers = users.filter { it.role == UserRole.CUSTOMER }
    val operators = users.filter { it.role == UserRole.OPERATOR }

    val totalRevenue = transactions.filter { it.status == TransactionStatus.SUCCESS }.sumOf { it.amount }
    val platformCommission = transactions.filter { it.status == TransactionStatus.SUCCESS }.sumOf { it.platformCommission }
    val operatorEarnings = transactions.filter { it.status == TransactionStatus.SUCCESS }.sumOf { it.operatorNetEarnings }

    val completedTrips = bookings.count { it.bookingStatus == BookingStatus.COMPLETED }
    val cancelledBookings = bookings.count { it.bookingStatus == BookingStatus.CANCELLED }
    val totalBookings = bookings.size.coerceAtLeast(1)

    val cancellationRate = (cancelledBookings.toDouble() / totalBookings) * 100.0
    val refundRate = (refunds.size.toDouble() / totalBookings) * 100.0
    val complaintRate = (complaints.size.toDouble() / totalBookings) * 100.0

    val currencyFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("admin_analytics_view"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Timeframe Selector & Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Executive Platform Analytics",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "Live telemetry on bookings, revenues, take-rates & safety",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Daily", "Weekly", "Monthly", "All-Time").forEach { tf ->
                    FilterChip(
                        selected = timeframeFilter == tf,
                        onClick = { timeframeFilter = tf },
                        label = { Text(tf, fontSize = 12.sp) }
                    )
                }
            }
        }

        // Financial KPIs Grid
        item {
            Text(
                text = "Financial & Monetization Overview",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall,
                color = ForestDarkest
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AnalyticsKpiCard(
                    title = "Gross GMV",
                    value = currencyFormat.format(totalRevenue),
                    icon = Icons.Default.CurrencyRupee,
                    color = MangrovePrimary,
                    modifier = Modifier.weight(1f)
                )
                AnalyticsKpiCard(
                    title = "Admin Charge (0.5%)",
                    value = currencyFormat.format(platformCommission),
                    icon = Icons.Default.AccountBalance,
                    color = StatusAdmin,
                    modifier = Modifier.weight(1f)
                )
                AnalyticsKpiCard(
                    title = "Operator Payouts",
                    value = currencyFormat.format(operatorEarnings),
                    icon = Icons.Default.Payments,
                    color = TigerAmber,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Operational Rates & Trust Metrics
        item {
            Text(
                text = "Operational Health & Trust Ratios",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall,
                color = ForestDarkest
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AnalyticsMetricCard(
                    title = "Completed Trips",
                    value = "$completedTrips",
                    subtitle = "Safe delta journeys",
                    icon = Icons.Default.CheckCircle,
                    color = StatusVerified,
                    modifier = Modifier.weight(1f)
                )
                AnalyticsMetricCard(
                    title = "Cancel Rate",
                    value = String.format(Locale.getDefault(), "%.1f%%", cancellationRate),
                    subtitle = "$cancelledBookings cancellations",
                    icon = Icons.Default.Cancel,
                    color = if (cancellationRate > 15) StatusRejected else TigerAmber,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AnalyticsMetricCard(
                    title = "Refund Rate",
                    value = String.format(Locale.getDefault(), "%.1f%%", refundRate),
                    subtitle = "${refunds.size} claims recorded",
                    icon = Icons.Default.CurrencyExchange,
                    color = TigerAmber,
                    modifier = Modifier.weight(1f)
                )
                AnalyticsMetricCard(
                    title = "Complaint Rate",
                    value = String.format(Locale.getDefault(), "%.1f%%", complaintRate),
                    subtitle = "${complaints.size} directorate files",
                    icon = Icons.Default.ReportProblem,
                    color = if (complaintRate > 5) StatusRejected else StatusVerified,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Booking Trends Bar Chart
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Booking Volume Trend ($timeframeFilter)",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val trendBars = when (timeframeFilter) {
                        "Daily" -> listOf("Mon" to 14, "Tue" to 19, "Wed" to 22, "Thu" to 28, "Fri" to 42, "Sat" to 58, "Sun" to 49)
                        "Weekly" -> listOf("W1" to 68, "W2" to 82, "W3" to 105, "W4" to 124)
                        "Monthly" -> listOf("May" to 180, "Jun" to 140, "Jul" to 95, "Aug" to 210, "Sep" to 340, "Oct" to 490)
                        else -> listOf("2024" to 1200, "2025" to 2400, "2026" to 3800)
                    }

                    val maxVal = trendBars.maxOf { it.second }.coerceAtLeast(1)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        trendBars.forEach { (label, count) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "$count",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MangrovePrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .width(20.dp)
                                        .height((100 * (count.toFloat() / maxVal)).dp)
                                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                        .background(MangrovePrimary)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Community Growth Stats
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "User Community & Ecosystem Growth",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Total Registered Customers", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "${customers.size}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = ForestDarkest)
                        }
                        Column {
                            Text(text = "Registered Tour Operators", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "${operators.size}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = TigerAmber)
                        }
                        Column {
                            Text(text = "Active Packages", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "${packages.size}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MangrovePrimary)
                        }
                    }
                }
            }
        }

        // Popular Packages Table
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Popular Tour Packages",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val topPackages = packages.take(5)
                    if (topPackages.isEmpty()) {
                        Text(text = "No packages published yet.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        topPackages.forEachIndexed { index, pkg ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "#${index + 1}",
                                        fontWeight = FontWeight.Bold,
                                        color = MangrovePrimary,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(text = pkg.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                        Text(text = "By ${pkg.operatorName} • ₹${pkg.price.toInt()}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = TigerGold, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(text = "${pkg.rating}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            if (index < topPackages.size - 1) {
                                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                            }
                        }
                    }
                }
            }
        }

        // Popular Destinations Ranking
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Popular Sundarban Destinations",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val topDestinations = listOf(
                        "Sajnekhali Bird Sanctuary & Watchtower" to 92,
                        "Sudhanyakhali Tiger Watchtower" to 88,
                        "Dobanki Mangrove Canopy Walk" to 79,
                        "Netidhopani 400-Yr Temple Ruins" to 64,
                        "Burirdabri Mudwalk & Raymongal Confluence" to 53,
                        "Bonnie Camp Deep Delta Watchtower" to 47,
                        "Kalash Island & Olive Ridley Beach" to 38
                    )

                    topDestinations.forEach { (name, popularity) ->
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                Text(text = "$popularity% Interest", style = MaterialTheme.typography.labelSmall, color = MangrovePrimary, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { popularity / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = MangrovePrimary,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalyticsKpiCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = color)
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AnalyticsMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = color.copy(alpha = 0.12f),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(text = title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall)
                Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp)
            }
        }
    }
}
