package com.example.features.authentication.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.UserProfile
import com.example.core.model.UserRole
import com.example.core.security.SecurityManager
import com.example.data.repositories.AuthRepository
import com.example.data.repositories.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val email: String = "",
    val emailError: String? = null,
    val password: String = "",
    val passwordError: String? = null,
    val selectedRole: UserRole = UserRole.CUSTOMER,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val loggedInUser: UserProfile? = null
)

class LoginViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun onEmailChanged(email: String) {
        _uiState.update { it.copy(email = email, emailError = null, errorMessage = null) }
    }

    fun onPasswordChanged(password: String) {
        _uiState.update { it.copy(password = password, passwordError = null, errorMessage = null) }
    }

    fun onRoleChanged(role: UserRole) {
        _uiState.update { it.copy(selectedRole = role, errorMessage = null) }
    }

    fun quickFillDemo(role: UserRole) {
        when (role) {
            UserRole.CUSTOMER -> {
                _uiState.update {
                    it.copy(
                        selectedRole = UserRole.CUSTOMER,
                        email = "tourist@example.com",
                        password = "Tourist@1234",
                        emailError = null,
                        passwordError = null,
                        errorMessage = null
                    )
                }
            }
            UserRole.OPERATOR -> {
                _uiState.update {
                    it.copy(
                        selectedRole = UserRole.OPERATOR,
                        email = "tiger_trails@sundarban.com",
                        password = "Operator@1234",
                        emailError = null,
                        passwordError = null,
                        errorMessage = null
                    )
                }
            }
            UserRole.ADMIN -> {
                quickFillSuperAdmin()
            }
        }
    }

    fun quickFillSuperAdmin() {
        _uiState.update {
            it.copy(
                selectedRole = UserRole.ADMIN,
                email = "admin@sundarbanexplorer.gov.in",
                password = "Admin@1234",
                emailError = null,
                passwordError = null,
                errorMessage = null
            )
        }
    }

    fun quickFillStandardAdmin() {
        _uiState.update {
            it.copy(
                selectedRole = UserRole.ADMIN,
                email = "officer.roy@sundarbanexplorer.gov.in",
                password = "Admin@1234",
                emailError = null,
                passwordError = null,
                errorMessage = null
            )
        }
    }

    fun login(onSuccess: (UserProfile) -> Unit) {
        val currentState = _uiState.value
        val cleanEmail = currentState.email.trim()
        val cleanPassword = currentState.password.trim()

        var hasError = false
        var emailErr: String? = null
        var passErr: String? = null

        if (cleanEmail.isEmpty()) {
            emailErr = "Email or mobile number is required"
            hasError = true
        } else if (cleanEmail.contains("@")) {
            if (!SecurityManager.isValidEmail(cleanEmail)) {
                emailErr = "Enter a valid email address"
                hasError = true
            }
        } else {
            if (!SecurityManager.isValidPhoneNumber(cleanEmail)) {
                emailErr = "Enter a valid 10-digit mobile number or email"
                hasError = true
            }
        }

        if (cleanPassword.isEmpty()) {
            passErr = "Password is required"
            hasError = true
        }

        if (hasError) {
            _uiState.update { it.copy(emailError = emailErr, passwordError = passErr) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepository.signIn(cleanEmail, cleanPassword, currentState.selectedRole)) {
                is AuthResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, loggedInUser = result.data) }
                    onSuccess(result.data)
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {
                    _uiState.update { it.copy(isLoading = true) }
                }
            }
        }
    }
}
