package com.example.features.booking

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Booking
import com.example.core.model.EmergencyContact
import com.example.core.model.PaymentMethod
import com.example.core.model.UserProfile
import com.example.data.repositories.TourRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateBookingScreen(
    packageId: String,
    currentUser: UserProfile?,
    tourRepository: TourRepository,
    onNavigateBack: () -> Unit,
    onBookingSuccess: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val pkg = remember(packageId) {
        tourRepository.getPackageById(packageId)
    }

    if (pkg == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Book Safari") },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Tour package not found.")
            }
        }
        return
    }

    var selectedDate by remember { mutableStateOf(pkg.availableDates.firstOrNull() ?: "2026-09-15") }
    var numberOfTourists by remember { mutableStateOf(2) }
    var pickupLocation by remember { mutableStateOf(pkg.startingLocation) }
    var specialRequirements by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    // Emergency Contact defaults from user profile
    var emergencyName by remember { mutableStateOf(currentUser?.emergencyContact?.name ?: "") }
    var emergencyPhone by remember { mutableStateOf(currentUser?.emergencyContact?.phoneNumber ?: "") }
    var emergencyRelation by remember { mutableStateOf(currentUser?.emergencyContact?.relationship ?: "Family") }

    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.ONLINE_UPI_CARD) }
    var isSubmitting by remember { mutableStateOf(false) }
    var safetyError by remember { mutableStateOf<String?>(null) }

    val totalAmount = remember(numberOfTourists, pkg.pricePerPerson) {
        numberOfTourists * pkg.pricePerPerson
    }

    // Auto-calculate Return Date based on durationDays
    val returnDate = remember(selectedDate, pkg.durationDays) {
        try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = sdf.parse(selectedDate)
            if (date != null) {
                val cal = Calendar.getInstance()
                cal.time = date
                cal.add(Calendar.DAY_OF_YEAR, (pkg.durationDays - 1).coerceAtLeast(0))
                sdf.format(cal.time)
            } else selectedDate
        } catch (e: Exception) {
            selectedDate
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Confirm Safari Booking", fontWeight = FontWeight.Bold)
                        Text(
                            text = pkg.title,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("booking_back_btn")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Total ($numberOfTourists Tourist${if (numberOfTourists > 1) "s" else ""})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "₹${totalAmount.toInt()}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        val adminCharge = totalAmount * 0.005
                        val adminChargeFormatted = if (adminCharge % 1.0 == 0.0) String.format("%,.0f", adminCharge) else String.format("%,.2f", adminCharge)
                        Text(
                            text = "Incl. 0.5% Admin Charge: ₹$adminChargeFormatted",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = {
                            if (currentUser == null) {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Please sign in to confirm booking")
                                }
                                return@Button
                            }

                            if (emergencyPhone.isBlank()) {
                                safetyError = "Emergency contact phone is mandatory for forest safety."
                                return@Button
                            }

                            safetyError = null
                            isSubmitting = true

                            coroutineScope.launch {
                                val bookingRequest = Booking(
                                    packageId = pkg.id,
                                    packageTitle = pkg.title,
                                    operatorId = pkg.operatorId,
                                    operatorName = pkg.operatorName,
                                    operatorPhone = pkg.operatorPhone,
                                    customerId = currentUser.id,
                                    customerName = currentUser.fullName,
                                    customerPhone = currentUser.phoneNumber,
                                    customerEmail = currentUser.email,
                                    numberOfTourists = numberOfTourists,
                                    travelDate = selectedDate,
                                    returnDate = returnDate,
                                    pickupLocation = pickupLocation.trim(),
                                    specialRequirements = specialRequirements.trim(),
                                    notes = notes.trim(),
                                    emergencyContact = EmergencyContact(
                                        name = emergencyName.trim(),
                                        phoneNumber = emergencyPhone.trim(),
                                        relationship = emergencyRelation.trim()
                                    ),
                                    paymentMethod = selectedPaymentMethod
                                )

                                val result = tourRepository.validateAndCreateBooking(bookingRequest, currentUser)
                                isSubmitting = false

                                result.onSuccess { createdBooking ->
                                    onBookingSuccess(createdBooking.id)
                                }.onFailure { error ->
                                    safetyError = error.message ?: "Booking validation failed"
                                    snackbarHostState.showSnackbar(safetyError ?: "Validation error")
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("submit_booking_btn"),
                        enabled = !isSubmitting
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onPrimary)
                        } else {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Confirm Booking Request")
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Safety Error Banner (if validation triggered)
            if (safetyError != null) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = safetyError ?: "",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = pkg.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = pkg.durationText,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Operator: ${pkg.operatorName} • Route: ${pkg.route}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Step 1: Date & Guests
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("1. Travel Date & Number of Tourists", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        Text("Select Departure Date:", style = MaterialTheme.typography.labelMedium)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(pkg.availableDates) { dt ->
                                FilterChip(
                                    selected = selectedDate == dt,
                                    onClick = { selectedDate = dt },
                                    label = { Text(dt) },
                                    leadingIcon = if (selectedDate == dt) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Number of Tourists", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text("Max capacity: ${pkg.maxTourists} guests", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { if (numberOfTourists > 1) numberOfTourists-- },
                                    enabled = numberOfTourists > 1
                                ) {
                                    Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease")
                                }

                                Text(
                                    text = "$numberOfTourists",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )

                                IconButton(
                                    onClick = { if (numberOfTourists < pkg.maxTourists) numberOfTourists++ },
                                    enabled = numberOfTourists < pkg.maxTourists
                                ) {
                                    Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase")
                                }
                            }
                        }

                        Text(
                            text = "Estimated Return Date: $returnDate",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Step 2: Pickup & Special Requirements
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("2. Pickup & Special Preferences", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        OutlinedTextField(
                            value = pickupLocation,
                            onValueChange = { pickupLocation = it },
                            label = { Text("Pickup Location *") },
                            modifier = Modifier.fillMaxWidth().testTag("booking_pickup_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = specialRequirements,
                            onValueChange = { specialRequirements = it },
                            label = { Text("Special Requirements (Meals / Mobility)") },
                            placeholder = { Text("e.g. Pure Vegetarian meals, small child life jacket needed...") },
                            modifier = Modifier.fillMaxWidth().testTag("booking_special_req_input"),
                            minLines = 2
                        )

                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Additional Notes for Boat Captain") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Step 3: Mandatory Emergency Contact (Forest Safety)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ContactPhone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("3. Emergency Contact (Mandatory)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }

                        OutlinedTextField(
                            value = emergencyName,
                            onValueChange = { emergencyName = it },
                            label = { Text("Contact Name *") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = emergencyPhone,
                                onValueChange = { emergencyPhone = it },
                                label = { Text("Phone Number *") },
                                modifier = Modifier.weight(1.2f).testTag("booking_emergency_phone_input")
                            )

                            OutlinedTextField(
                                value = emergencyRelation,
                                onValueChange = { emergencyRelation = it },
                                label = { Text("Relation") },
                                modifier = Modifier.weight(0.8f)
                            )
                        }
                    }
                }
            }

            // Step 4: Payment Method Preference
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("4. Payment Preference", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedPaymentMethod = PaymentMethod.ONLINE_UPI_CARD }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedPaymentMethod == PaymentMethod.ONLINE_UPI_CARD,
                                onClick = { selectedPaymentMethod = PaymentMethod.ONLINE_UPI_CARD }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Online Payment (Instant UPI / QR / NetBanking)", fontWeight = FontWeight.SemiBold)
                                Text("Zero transaction fees. Instant confirmation.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedPaymentMethod = PaymentMethod.CASH_ON_ARRIVAL }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedPaymentMethod == PaymentMethod.CASH_ON_ARRIVAL,
                                onClick = { selectedPaymentMethod = PaymentMethod.CASH_ON_ARRIVAL }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Pay on Arrival (Godkhali Ferry Ghat)", fontWeight = FontWeight.SemiBold)
                                Text("Pay operator directly upon arrival at the jetty.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            // Forest Directorate Compliance Badge
            item {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Booking is safeguarded by Sundarban Explorer anti-fraud policies. Status transitions are logged in real-time.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }
    }
}
