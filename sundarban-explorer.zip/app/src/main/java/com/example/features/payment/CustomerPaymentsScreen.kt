package com.example.features.payment

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Booking
import com.example.core.model.BookingFinancialTimeline
import com.example.core.model.BookingStatus
import com.example.core.model.PaymentGatewayMethod
import com.example.core.model.PaymentStatus
import com.example.core.model.PaymentTransaction
import com.example.core.model.TransactionStatus
import com.example.core.model.TransactionType
import com.example.core.model.UserProfile
import com.example.data.repositories.TourRepository
import com.example.features.disputes.OpenDisputeDialog
import com.example.ui.theme.ForestDarkest
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.TigerAmber
import com.example.ui.theme.TigerGold
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerPaymentsScreen(
    currentUser: UserProfile,
    tourRepository: TourRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val allTransactions by tourRepository.getTransactionsForCustomer(currentUser.id).collectAsState(initial = emptyList())
    val customerBookings by tourRepository.getBookingsForCustomer(currentUser.id).collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf(0) } // 0: Financial Timelines, 1: All Transaction Ledger
    var filterType by remember { mutableStateOf<String>("ALL") } // ALL, SUCCESS, PENDING, REFUNDED, FAILED, CANCELLED, ONLINE, CASH

    // Active bottom sheet / dialog states
    var payingBooking by remember { mutableStateOf<Booking?>(null) }
    var viewingReceiptBooking by remember { mutableStateOf<Booking?>(null) }
    var viewingReceiptTxn by remember { mutableStateOf<PaymentTransaction?>(null) }
    var requestingRefundBooking by remember { mutableStateOf<Booking?>(null) }
    var bookingForDispute by remember { mutableStateOf<Booking?>(null) }
    var refundAmountText by remember { mutableStateOf("") }
    var refundReasonText by remember { mutableStateOf("") }

    // Summary calculations
    val totalPaidAll = allTransactions.filter { it.status == TransactionStatus.SUCCESS || it.status == TransactionStatus.CASH_RECORDED }.sumOf { it.amount }
    val totalRefundedAll = allTransactions.filter { it.type == TransactionType.REFUND_PAYOUT }.sumOf { it.amount }
    val totalRemainingDue = customerBookings.sumOf { (it.totalAmount - it.paidAmount).coerceAtLeast(0.0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("My Payments & Invoices", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Secure Escrow Ledger & Safari Permits", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Summary Metric Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Total Paid",
                        amount = "₹${String.format("%,.0f", totalPaidAll)}",
                        icon = Icons.Default.CheckCircle,
                        iconColor = StatusVerified,
                        containerColor = Color(0xFFE8F5E9),
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Balance Due",
                        amount = "₹${String.format("%,.0f", totalRemainingDue)}",
                        icon = Icons.Default.AccountBalanceWallet,
                        iconColor = if (totalRemainingDue > 0) TigerAmber else StatusVerified,
                        containerColor = if (totalRemainingDue > 0) Color(0xFFFFF8E1) else Color(0xFFF1F8E9),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                // Tab Selection: Timelines vs Transactions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(4.dp)
                ) {
                    val isTimeline = selectedTab == 0
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isTimeline) MaterialTheme.colorScheme.surface else Color.Transparent)
                            .clickable { selectedTab = 0 }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timeline,
                                contentDescription = null,
                                tint = if (isTimeline) MangrovePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Booking Financials (${customerBookings.size})",
                                fontSize = 13.sp,
                                fontWeight = if (isTimeline) FontWeight.Bold else FontWeight.Medium,
                                color = if (isTimeline) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    val isTxn = selectedTab == 1
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isTxn) MaterialTheme.colorScheme.surface else Color.Transparent)
                            .clickable { selectedTab = 1 }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = null,
                                tint = if (isTxn) MangrovePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "All Transactions (${allTransactions.size})",
                                fontSize = 13.sp,
                                fontWeight = if (isTxn) FontWeight.Bold else FontWeight.Medium,
                                color = if (isTxn) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            if (selectedTab == 0) {
                // Booking-Wise Financial Timelines
                if (customerBookings.isEmpty()) {
                    item {
                        EmptyStateCard(message = "No safari bookings found. Explore verified packages to book your tour.")
                    }
                } else {
                    items(customerBookings) { booking ->
                        BookingFinancialCard(
                            booking = booking,
                            tourRepository = tourRepository,
                            onPayOnline = { payingBooking = booking },
                            onViewReceipt = { viewingReceiptBooking = booking },
                            onOpenDispute = { bookingForDispute = booking },
                            onRequestRefund = {
                                requestingRefundBooking = booking
                                refundAmountText = booking.paidAmount.toInt().toString()
                                refundReasonText = ""
                            }
                        )
                    }
                }
            } else {
                // Transaction Ledger
                item {
                    // Filter Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val filters = listOf(
                            "ALL" to "All Records",
                            "SUCCESS" to "Successful",
                            "PENDING" to "Pending",
                            "REFUNDED" to "Refunded",
                            "FAILED" to "Failed",
                            "CANCELLED" to "Cancelled",
                            "ONLINE" to "Online UPI / Bank",
                            "CASH" to "Cash at Ghat"
                        )
                        items(filters) { (key, label) ->
                            FilterChip(
                                selected = filterType == key,
                                onClick = { filterType = key },
                                label = { Text(label, fontSize = 12.sp) }
                            )
                        }
                    }
                }

                val filteredTxns = allTransactions.filter { txn ->
                    when (filterType) {
                        "SUCCESS" -> txn.status == TransactionStatus.SUCCESS || txn.status == TransactionStatus.CASH_RECORDED
                        "PENDING" -> txn.status == TransactionStatus.PENDING || txn.status == TransactionStatus.INITIATED
                        "REFUNDED" -> txn.status == TransactionStatus.REFUNDED || txn.status == TransactionStatus.PARTIALLY_REFUNDED || txn.type == TransactionType.REFUND_PAYOUT
                        "FAILED" -> txn.status == TransactionStatus.FAILED
                        "CANCELLED" -> txn.status == TransactionStatus.CANCELLED
                        "ONLINE" -> txn.type == TransactionType.ONLINE_GATEWAY
                        "CASH" -> txn.type == TransactionType.OFFLINE_CASH || txn.type == TransactionType.CASH_ADJUSTMENT
                        else -> true
                    }
                }

                if (filteredTxns.isEmpty()) {
                    item {
                        EmptyStateCard(message = "No transaction records found matching this filter.")
                    }
                } else {
                    items(filteredTxns) { txn ->
                        CustomerTransactionCard(
                            txn = txn,
                            onClick = {
                                val bk = customerBookings.firstOrNull { it.id == txn.bookingId }
                                if (bk != null) {
                                    viewingReceiptBooking = bk
                                    viewingReceiptTxn = txn
                                }
                            }
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // Payment Gateway Bottom Sheet
    if (payingBooking != null) {
        val bk = payingBooking!!
        val remainingToPay = (bk.totalAmount - bk.paidAmount).coerceAtLeast(0.0)
        PaymentGatewayBottomSheet(
            booking = bk,
            amountToPay = if (remainingToPay > 0) remainingToPay else bk.totalAmount,
            currentUser = currentUser,
            tourRepository = tourRepository,
            onDismiss = { payingBooking = null },
            onPaymentCompleted = {
                payingBooking = null
                Toast.makeText(context, "Payment successful! Safari permit updated.", Toast.LENGTH_LONG).show()
            }
        )
    }

    // Official Receipt Dialog
    if (viewingReceiptBooking != null) {
        val bk = viewingReceiptBooking!!
        val timeline by tourRepository.getBookingFinancialTimeline(bk.id).collectAsState(initial = null)
        PaymentReceiptDialog(
            booking = bk,
            timeline = timeline,
            transaction = viewingReceiptTxn,
            onDismiss = {
                viewingReceiptBooking = null
                viewingReceiptTxn = null
            }
        )
    }

    // Refund Request Dialog
    if (requestingRefundBooking != null) {
        val bk = requestingRefundBooking!!
        AlertDialog(
            onDismissRequest = { requestingRefundBooking = null },
            title = {
                Text("Request Booking Refund", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            },
            text = {
                Column {
                    Text(
                        text = "Booking: ${bk.packageTitle} (${bk.id})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Total Paid: ₹${String.format("%,.0f", bk.paidAmount)}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = refundAmountText,
                        onValueChange = { refundAmountText = it },
                        label = { Text("Refund Amount (INR)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = refundReasonText,
                        onValueChange = { refundReasonText = it },
                        label = { Text("Reason for Refund") },
                        placeholder = { Text("e.g. Schedule change, emergency, or operator cancellation") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Sundarban Directorate Escrow Rule: Refunds are processed back to the original payment source within 24-48 hours upon verification.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = refundAmountText.toDoubleOrNull() ?: 0.0
                        if (amount <= 0 || amount > bk.paidAmount) {
                            Toast.makeText(context, "Invalid refund amount", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        scope.launch {
                            val result = tourRepository.requestRefund(
                                bookingId = bk.id,
                                transactionId = bk.id,
                                amount = amount,
                                reason = refundReasonText,
                                requester = currentUser
                            )
                            if (result.isSuccess) {
                                Toast.makeText(context, "Refund request submitted to Admin", Toast.LENGTH_LONG).show()
                                requestingRefundBooking = null
                            } else {
                                Toast.makeText(context, result.exceptionOrNull()?.message ?: "Failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary)
                ) {
                    Text("Submit Request")
                }
            },
            dismissButton = {
                TextButton(onClick = { requestingRefundBooking = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Open Formal Dispute Dialog for payment issues
    if (bookingForDispute != null) {
        val target = bookingForDispute!!
        OpenDisputeDialog(
            booking = target,
            currentUser = currentUser,
            onDismiss = { bookingForDispute = null },
            onConfirmOpenDispute = { reason, evidenceUrl ->
                scope.launch {
                    val evidenceList = if (!evidenceUrl.isNullOrBlank()) listOf(evidenceUrl) else emptyList()
                    val result = tourRepository.openFormalDispute(
                        bookingId = target.id,
                        complaintId = null,
                        reason = reason,
                        evidenceUrls = evidenceList,
                        requester = currentUser
                    )
                    bookingForDispute = null
                    if (result.isSuccess) {
                        Toast.makeText(context, "Dispute ${result.getOrNull()?.disputeId} submitted to Admin Review.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "Failed: ${result.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }
}

@Composable
fun BookingFinancialCard(
    booking: Booking,
    tourRepository: TourRepository,
    onPayOnline: () -> Unit,
    onViewReceipt: () -> Unit,
    onOpenDispute: () -> Unit = {},
    onRequestRefund: () -> Unit
) {
    val timeline by tourRepository.getBookingFinancialTimeline(booking.id).collectAsState(initial = null)

    val totalPaid = timeline?.totalPaid ?: booking.paidAmount
    val remaining = timeline?.remainingAmount ?: (booking.totalAmount - booking.paidAmount).coerceAtLeast(0.0)
    val refunded = timeline?.refundedAmount ?: 0.0

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = booking.id,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = booking.packageTitle,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = when (booking.paymentStatus) {
                        PaymentStatus.PAID -> Color(0xFFE8F5E9)
                        PaymentStatus.PARTIALLY_PAID -> Color(0xFFFFF8E1)
                        PaymentStatus.REFUNDED -> Color(0xFFFFEBEE)
                        else -> Color(0xFFEDE7F6)
                    }
                ) {
                    Text(
                        text = booking.paymentStatus.displayName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (booking.paymentStatus) {
                            PaymentStatus.PAID -> Color(0xFF2E7D32)
                            PaymentStatus.PARTIALLY_PAID -> TigerAmber
                            PaymentStatus.REFUNDED -> Color(0xFFC62828)
                            else -> MangrovePrimary
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Financial Timeline Metrics Grid
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Price", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("₹${String.format("%,.0f", booking.totalAmount)}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Online Paid", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("₹${String.format("%,.0f", timeline?.onlinePaid ?: 0.0)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1565C0))
                        }
                        Column {
                            Text("Cash at Ghat", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("₹${String.format("%,.0f", timeline?.cashPaid ?: 0.0)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Balance Due", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "₹${String.format("%,.0f", remaining)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (remaining > 0) Color(0xFFC62828) else StatusVerified
                            )
                        }
                    }

                    val adminCharge = booking.totalAmount * 0.005
                    val adminChargeFormatted = if (adminCharge % 1.0 == 0.0) String.format("%,.0f", adminCharge) else String.format("%,.2f", adminCharge)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• Incl. Admin Charge (0.5%): ₹$adminChargeFormatted (Total × 0.005)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (refunded > 0) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "• Refund Disbursed: ₹${String.format("%,.0f", refunded)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFC62828)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onViewReceipt,
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Receipt", fontSize = 12.sp)
                }

                if (totalPaid > 0) {
                    OutlinedButton(
                        onClick = onOpenDispute,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Dispute", fontSize = 12.sp, color = TigerAmber)
                    }
                }

                if (remaining > 0) {
                    Button(
                        onClick = onPayOnline,
                        modifier = Modifier
                            .weight(1.3f)
                            .height(42.dp)
                            .testTag("pay_balance_online_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pay ₹${String.format("%,.0f", remaining)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (totalPaid > 0 && refunded < totalPaid) {
                    OutlinedButton(
                        onClick = onRequestRefund,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Refund", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerTransactionCard(
    txn: PaymentTransaction,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val (icon, bgColor, tintColor) = when (txn.type) {
                TransactionType.ONLINE_GATEWAY -> Triple(Icons.Default.CreditCard, Color(0xFFE3F2FD), Color(0xFF1565C0))
                TransactionType.OFFLINE_CASH -> Triple(Icons.Default.Payments, Color(0xFFE8F5E9), Color(0xFF2E7D32))
                TransactionType.CASH_ADJUSTMENT -> Triple(Icons.Default.History, Color(0xFFFFF3E0), TigerAmber)
                TransactionType.REFUND_PAYOUT -> Triple(Icons.Default.ReceiptLong, Color(0xFFFFEBEE), Color(0xFFC62828))
                else -> Triple(Icons.Default.Payment, Color(0xFFEDE7F6), MangrovePrimary)
            }

            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(bgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = tintColor, modifier = Modifier.size(22.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = txn.notes.ifBlank { txn.packageTitle },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${txn.method.displayName} • ${txn.formattedDate} ${txn.formattedTime}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Ref: ${txn.transactionId}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                val isNegative = txn.type == TransactionType.REFUND_PAYOUT || txn.amount < 0
                Text(
                    text = "${if (isNegative) "-" else "+"}₹${String.format("%,.0f", Math.abs(txn.amount))}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isNegative) Color(0xFFC62828) else Color(0xFF2E7D32)
                )
                Text(
                    text = txn.status.displayName,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = when (txn.status) {
                        TransactionStatus.SUCCESS, TransactionStatus.CASH_RECORDED -> StatusVerified
                        TransactionStatus.REFUNDED -> Color(0xFFC62828)
                        else -> TigerAmber
                    }
                )
                val commFormatted = if (txn.platformCommission % 1.0 == 0.0) String.format("%,.0f", txn.platformCommission) else String.format("%,.2f", txn.platformCommission)
                Text(
                    text = "Admin: ₹$commFormatted (0.5%)",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    amount: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF37474F))
                Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = amount, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ForestDarkest)
        }
    }
}

@Composable
private fun EmptyStateCard(message: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = message, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}
