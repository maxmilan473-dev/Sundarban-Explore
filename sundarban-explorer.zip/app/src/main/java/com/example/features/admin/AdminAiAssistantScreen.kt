package com.example.features.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.ai.AdminAiAssistantService
import com.example.core.ai.AssistantResponse
import com.example.core.model.*
import com.example.data.repositories.AuthRepository
import com.example.data.repositories.TourRepository
import com.example.ui.theme.*
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // "Admin" or "Sundarban AI"
    val isUser: Boolean,
    val text: String,
    val structuredResponse: AssistantResponse? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAiAssistantDialog(
    tourRepository: TourRepository,
    authRepository: AuthRepository,
    currentAdmin: UserProfile,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage(
                    sender = "Sundarban AI",
                    isUser = false,
                    text = "Hello Administrator. I am the Sundarban AI Platform Assistant. I assist in verifying operator credentials, summarizing dispute dossiers, analyzing fraud risks, and searching audit logs.\n\n⚠️ **Safety Notice**: All insights are strictly advisory. I cannot autonomously ban users, issue refunds, or modify ledger records.",
                    structuredResponse = null
                )
            )
        )
    }

    var inputPrompt by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val quickPrompts = listOf(
        "Investigate operator credentials and permit compliance",
        "Summarize active customer complaints and safety alerts",
        "Evaluate financial risk indicators and cash adjustments",
        "Analyze dispute dossier between tourists and operators",
        "Audit log query: Recent administrative verifications"
    )

    fun sendQuery(queryText: String) {
        if (queryText.isBlank() || isLoading) return
        val userMsg = ChatMessage(
            sender = currentAdmin.fullName,
            isUser = true,
            text = queryText.trim()
        )
        messages = messages + userMsg
        inputPrompt = ""
        isLoading = true

        scope.launch {
            // Gather live platform telemetry
            val users = authRepository.getAllUsersForAdmin().firstOrNull() ?: emptyList()
            val bookings = tourRepository.getAllBookingsForAdmin().firstOrNull() ?: emptyList()
            val transactions = tourRepository.getAllTransactionsForAdmin().firstOrNull() ?: emptyList()
            val complaints = tourRepository.getComplaints().firstOrNull() ?: emptyList()
            val disputes = tourRepository.getDisputes().firstOrNull() ?: emptyList()
            val refunds = tourRepository.getRefundRecords().firstOrNull() ?: emptyList()
            val auditLogs = tourRepository.getAuditLogs().firstOrNull() ?: emptyList()
            val riskCases = tourRepository.getFlaggedRiskCases().firstOrNull() ?: emptyList()

            val response = AdminAiAssistantService.processAdminQuery(
                query = queryText,
                adminUser = currentAdmin,
                allUsers = users,
                allBookings = bookings,
                allTransactions = transactions,
                allComplaints = complaints,
                allDisputes = disputes,
                allRefunds = refunds,
                allRiskCases = riskCases,
                auditLogs = auditLogs
            )

            val aiMsg = ChatMessage(
                sender = "Sundarban AI",
                isUser = false,
                text = response.fact,
                structuredResponse = response
            )
            messages = messages + aiMsg
            isLoading = false
            listState.animateScrollToItem((messages.size - 1).coerceAtLeast(0))
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.SmartToy, contentDescription = null, tint = MangrovePrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Admin AI Intelligence Assistant", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(480.dp)
            ) {
                // Safety Banner
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TigerLight,
                    border = BorderStroke(1.dp, TigerAmber.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = TigerAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AI Guardrails Active: Advisory Only (Cannot autonomously ban or refund)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = TigerAmber
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Prompt Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickPrompts.forEach { prompt ->
                        SuggestionChip(
                            onClick = { sendQuery(prompt) },
                            label = { Text(prompt.take(32) + "...", fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Messages Stream
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { msg ->
                        if (msg.isUser) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MangrovePrimary,
                                    modifier = Modifier.widthIn(max = 280.dp)
                                ) {
                                    Text(
                                        text = msg.text,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // AI Message Bubble
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = MangrovePrimary, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(text = "Sundarban AI Platform Core", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = MangrovePrimary)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = msg.text, style = MaterialTheme.typography.bodySmall)
                                    }
                                }

                                // Structured FACT / RISK / RECOMMENDATION Cards if available
                                val struct = msg.structuredResponse
                                if (struct != null) {
                                    if (struct.fact.isNotBlank()) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = StatusVerifiedBg,
                                            border = BorderStroke(1.dp, StatusVerified.copy(alpha = 0.3f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(8.dp)) {
                                                Text(text = "📋 FACT (Verified System Data):", fontWeight = FontWeight.Bold, color = StatusVerified, style = MaterialTheme.typography.labelSmall)
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(text = struct.fact, style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }

                                    if (struct.possibleRisk.isNotBlank()) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = TigerLight,
                                            border = BorderStroke(1.dp, TigerAmber.copy(alpha = 0.3f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(8.dp)) {
                                                Text(text = "⚠️ POSSIBLE RISK (Anomaly Analysis):", fontWeight = FontWeight.Bold, color = TigerAmber, style = MaterialTheme.typography.labelSmall)
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(text = struct.possibleRisk, style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }

                                    if (struct.recommendation.isNotBlank()) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                            border = BorderStroke(1.dp, MangrovePrimary.copy(alpha = 0.3f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(8.dp)) {
                                                Text(text = "💡 RECOMMENDATION (Advisory Only):", fontWeight = FontWeight.Bold, color = MangrovePrimary, style = MaterialTheme.typography.labelSmall)
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(text = struct.recommendation, style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (isLoading) {
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MangrovePrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Analyzing platform telemetry with Gemini...", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputPrompt,
                        onValueChange = { inputPrompt = it },
                        placeholder = { Text("Ask AI Assistant (e.g. 'Investigate operator Subhasis' or 'Summarize complaints')...", fontSize = 12.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("admin_ai_input")
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = { sendQuery(inputPrompt) },
                        enabled = inputPrompt.isNotBlank() && !isLoading,
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = MangrovePrimary),
                        modifier = Modifier.testTag("admin_ai_send_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close Assistant")
            }
        }
    )
}
