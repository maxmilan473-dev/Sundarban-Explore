package com.example.features.operator.packages

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.PackageStatus
import com.example.core.model.TourPackage
import com.example.core.model.UserProfile
import com.example.data.repositories.TourRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperatorPackagesScreen(
    currentUser: UserProfile?,
    tourRepository: TourRepository,
    onNavigateBack: () -> Unit,
    onCreatePackage: () -> Unit,
    onViewPackageDetail: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var selectedTab by remember { mutableStateOf(0) }
    var packageToDelete by remember { mutableStateOf<TourPackage?>(null) }
    val operatorId = currentUser?.id ?: "op_verified_001"

    val allPackages by tourRepository.getPackagesForOperator(operatorId).collectAsState(initial = emptyList())

    val filteredPackages = remember(allPackages, selectedTab) {
        when (selectedTab) {
            0 -> allPackages // All
            1 -> allPackages.filter { it.status == PackageStatus.PUBLISHED || it.status == PackageStatus.AUTO_VERIFIED }
            2 -> allPackages.filter { it.status == PackageStatus.PENDING_APPROVAL || it.status == PackageStatus.REQUIRES_ADMIN_REVIEW }
            3 -> allPackages.filter { it.status == PackageStatus.DRAFT }
            4 -> allPackages.filter { it.status == PackageStatus.REJECTED }
            else -> allPackages.filter { it.status == PackageStatus.HIDDEN || it.status == PackageStatus.ARCHIVED }
        }
    }

    // Confirmation Dialog for Deleting a Package
    if (packageToDelete != null) {
        val targetPkg = packageToDelete!!
        AlertDialog(
            onDismissRequest = { packageToDelete = null },
            icon = {
                Icon(
                    Icons.Default.DeleteOutline,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text("Delete Tour Package?", fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        text = "Are you sure you want to permanently delete \"${targetPkg.title}\"?",
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Policy Reminder:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Editing existing packages is not permitted. To modify information in an existing package, you must delete this package and create a new one.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pkgToDelete = targetPkg
                        packageToDelete = null
                        coroutineScope.launch {
                            val res = tourRepository.deletePackage(pkgToDelete.id, operatorId)
                            if (res.isSuccess) {
                                snackbarHostState.showSnackbar("Package \"${pkgToDelete.title}\" was successfully deleted.")
                            } else {
                                snackbarHostState.showSnackbar(res.exceptionOrNull()?.message ?: "Failed to delete package")
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_pkg_btn")
                ) {
                    Text("Delete Package")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { packageToDelete = null },
                    modifier = Modifier.testTag("cancel_delete_pkg_btn")
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("My Tour Packages", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("op_packages_back_btn")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreatePackage,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New Package") },
                modifier = Modifier.testTag("create_new_package_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Policy Notice Banner
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Package Editing Is Not Allowed",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "To preserve booking integrity, packages cannot be edited after publishing. If you need to change details, delete this package and add a new package.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            // Filter Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("All (${allPackages.size})") })
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Published (${allPackages.count { it.status == PackageStatus.PUBLISHED }})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Pending (${allPackages.count { it.status == PackageStatus.PENDING_APPROVAL }})") }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Drafts (${allPackages.count { it.status == PackageStatus.DRAFT }})") }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("Rejected (${allPackages.count { it.status == PackageStatus.REJECTED }})") }
                )
                Tab(
                    selected = selectedTab == 5,
                    onClick = { selectedTab = 5 },
                    text = { Text("Archived / Hidden") }
                )
            }

            if (filteredPackages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Outlined.Tour,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No packages in this category",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Create customized Sundarban packages with boat, food, and guide details.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = onCreatePackage) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Create Package Now")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filteredPackages, key = { it.id }) { pkg ->
                        OperatorPackageItemCard(
                            pkg = pkg,
                            isOwner = pkg.operatorId == operatorId,
                            onViewDetail = { onViewPackageDetail(pkg.id) },
                            onDeletePackage = { packageToDelete = pkg },
                            onToggleVisibility = {
                                val nextStatus = if (pkg.status == PackageStatus.PUBLISHED) PackageStatus.HIDDEN else PackageStatus.PUBLISHED
                                coroutineScope.launch {
                                    tourRepository.moderatePackageStatus(pkg.id, nextStatus)
                                }
                            },
                            onArchive = {
                                coroutineScope.launch {
                                    tourRepository.moderatePackageStatus(pkg.id, PackageStatus.ARCHIVED)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun OperatorPackageItemCard(
    pkg: TourPackage,
    isOwner: Boolean,
    onViewDetail: () -> Unit,
    onDeletePackage: () -> Unit,
    onToggleVisibility: () -> Unit,
    onArchive: () -> Unit
) {
    val statusColor = when (pkg.status) {
        PackageStatus.PUBLISHED, PackageStatus.AUTO_VERIFIED -> Color(0xFF2E7D32)
        PackageStatus.PENDING_APPROVAL -> Color(0xFFEF6C00)
        PackageStatus.REQUIRES_ADMIN_REVIEW -> Color(0xFFD32F2F)
        PackageStatus.DRAFT -> Color(0xFF616161)
        PackageStatus.REJECTED -> Color(0xFFC62828)
        PackageStatus.HIDDEN -> Color(0xFF757575)
        PackageStatus.ARCHIVED -> Color(0xFF455A64)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Status Badge & Price
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = pkg.status.displayName.uppercase(),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                }

                Text(
                    text = "₹${pkg.pricePerPerson.toInt()} / person",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = pkg.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${pkg.durationText} • Max ${pkg.maxTourists} Tourists • ${pkg.availableDates.size} Available Dates",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Route: ${pkg.route}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                        RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Icon(
                    Icons.Default.Lock,
                    contentDescription = null,
                    modifier = Modifier.size(13.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Package locked (No edit allowed • Delete & re-create to change)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (pkg.rejectionReason != null && pkg.status == PackageStatus.REJECTED) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Admin Note: ${pkg.rejectionReason}",
                        modifier = Modifier.padding(8.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons: Delete Package (Owner only) and View Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Delete Package button for package owner
                if (isOwner) {
                    OutlinedButton(
                        onClick = onDeletePackage,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("delete_pkg_btn_${pkg.id}")
                    ) {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = "Delete Package",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delete Package", fontSize = 13.sp)
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (pkg.status == PackageStatus.PUBLISHED || pkg.status == PackageStatus.HIDDEN) {
                        TextButton(onClick = onToggleVisibility) {
                            Icon(
                                if (pkg.status == PackageStatus.PUBLISHED) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (pkg.status == PackageStatus.PUBLISHED) "Hide" else "Publish", fontSize = 13.sp)
                        }
                    }

                    if (pkg.status != PackageStatus.ARCHIVED) {
                        TextButton(onClick = onArchive) {
                            Icon(Icons.Default.Archive, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Archive", fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    FilledTonalButton(
                        onClick = onViewDetail,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("View / Book", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
