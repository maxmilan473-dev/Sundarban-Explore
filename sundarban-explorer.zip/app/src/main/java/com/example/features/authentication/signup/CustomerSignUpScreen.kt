package com.example.features.authentication.signup

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContactEmergency
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.localization.LocalAppStrings
import com.example.core.model.UserProfile
import com.example.core.ui.components.SundarbanButton
import com.example.core.ui.components.SundarbanTextField
import com.example.ui.theme.MangroveMedium
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusAdmin
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedBg
import com.example.ui.theme.TigerAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerSignUpScreen(
    viewModel: SignUpViewModel,
    onSignUpSuccess: (UserProfile) -> Unit,
    onNavigateBackToLogin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val state by viewModel.customerState.collectAsState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("customer_signup_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Tourist Registration",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBackToLogin,
                        modifier = Modifier.testTag("customer_signup_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MangrovePrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            // Header Info & Public Signup Policy Badge
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MangrovePrimary.copy(alpha = 0.08f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MangrovePrimary
                        ) {
                            Text(
                                text = "Public Signup: Customer ID ✅",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Create your tourist account to discover verified Sundarban cruises, safe bookings, and local wildlife guides. Note: Admin IDs cannot be registered publicly (❌) and are provisioned by Super Admin only (✅).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MangrovePrimary,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Error Banner
            if (state.errorMessage != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp)
                        .testTag("customer_signup_error"),
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = state.errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            // Section 1: Basic Information
            Text(
                text = "1. Personal Information",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MangrovePrimary
            )
            Spacer(modifier = Modifier.height(10.dp))

            SundarbanTextField(
                value = state.fullName,
                onValueChange = { viewModel.onCustomerNameChanged(it) },
                label = strings.fullName,
                placeholder = "e.g. Priya Sharma",
                leadingIcon = Icons.Default.Person,
                errorMessage = state.nameError,
                testTag = "customer_signup_name"
            )

            Spacer(modifier = Modifier.height(12.dp))

            SundarbanTextField(
                value = state.mobileNumber,
                onValueChange = { viewModel.onCustomerPhoneChanged(it) },
                label = strings.phoneNumber,
                placeholder = "+91 9876543210",
                leadingIcon = Icons.Default.Phone,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                errorMessage = state.phoneError,
                testTag = "customer_signup_phone"
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Mobile OTP Verification Box (MANDATORY REQUIREMENT)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("customer_phone_otp_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (state.isPhoneVerified) StatusVerifiedBg else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = BorderStroke(
                    1.dp,
                    if (state.isPhoneVerified) StatusVerified.copy(alpha = 0.5f) else Color.LightGray.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (state.isPhoneVerified) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified",
                                tint = StatusVerified,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Mobile Verified (OTP Confirmed)",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium,
                                color = StatusVerified
                            )
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Mobile Number Verification",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "SMS OTP verification is required to create your account",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            SundarbanButton(
                                text = if (state.phoneOtpCountdown > 0) "Resend (${state.phoneOtpCountdown}s)" else if (state.isPhoneOtpSent) "Resend OTP" else "Send OTP",
                                onClick = { viewModel.requestCustomerPhoneOtp() },
                                isLoading = state.isLoading,
                                isSecondary = true,
                                enabled = state.phoneOtpCountdown == 0 && !state.isLoading,
                                modifier = Modifier.height(40.dp),
                                testTag = "customer_send_phone_otp_btn"
                            )
                        }

                        if (state.isPhoneOtpSent) {
                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(10.dp))

                            // Demo OTP reminder
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MangrovePrimary.copy(alpha = 0.12f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "SMS OTP: ${state.simulatedPhoneOtp.ifBlank { "123456" }} (Code expires in 5 mins)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MangrovePrimary,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                SundarbanTextField(
                                    value = state.phoneOtpInput,
                                    onValueChange = { viewModel.onCustomerPhoneOtpInputChanged(it) },
                                    label = "Enter 6-digit OTP",
                                    placeholder = "e.g. ${state.simulatedPhoneOtp.ifBlank { "123456" }}",
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    testTag = "customer_phone_otp_input"
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                SundarbanButton(
                                    text = "Verify",
                                    onClick = { viewModel.verifyCustomerPhoneOtp() },
                                    isLoading = state.isLoading,
                                    isSecondary = false,
                                    modifier = Modifier.height(52.dp),
                                    testTag = "customer_confirm_phone_otp_btn"
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SundarbanTextField(
                value = state.email,
                onValueChange = { viewModel.onCustomerEmailChanged(it) },
                label = strings.email,
                placeholder = "priya@example.com",
                leadingIcon = Icons.Default.Email,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                errorMessage = state.emailError,
                testTag = "customer_signup_email"
            )

            Spacer(modifier = Modifier.height(12.dp))

            SundarbanTextField(
                value = state.address,
                onValueChange = { viewModel.onCustomerAddressChanged(it) },
                label = strings.address,
                placeholder = "City / District, State",
                leadingIcon = Icons.Default.Home,
                testTag = "customer_signup_address"
            )

            Spacer(modifier = Modifier.height(12.dp))

            SundarbanTextField(
                value = state.profilePhotoUrl,
                onValueChange = { viewModel.onCustomerPhotoChanged(it) },
                label = "Profile Photo (Optional URL)",
                placeholder = "https://example.com/avatar.jpg",
                leadingIcon = Icons.Default.Image,
                testTag = "customer_signup_photo"
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Section 2: Account Security
            Text(
                text = "2. Account Security",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MangrovePrimary
            )
            Spacer(modifier = Modifier.height(10.dp))

            SundarbanTextField(
                value = state.password,
                onValueChange = { viewModel.onCustomerPasswordChanged(it) },
                label = strings.password,
                placeholder = "Min 6 chars with letters & numbers",
                leadingIcon = Icons.Default.Lock,
                isPassword = true,
                errorMessage = state.passwordError,
                testTag = "customer_signup_password"
            )

            Spacer(modifier = Modifier.height(12.dp))

            SundarbanTextField(
                value = state.confirmPassword,
                onValueChange = { viewModel.onCustomerConfirmPasswordChanged(it) },
                label = strings.confirmPassword,
                leadingIcon = Icons.Default.Lock,
                isPassword = true,
                errorMessage = state.confirmPasswordError,
                testTag = "customer_signup_confirm_password"
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Section 3: Emergency Contact (Strictly enforced for tourist safety)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ContactEmergency,
                            contentDescription = null,
                            tint = TigerAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "3. Emergency Contact (Mandatory)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TigerAmber
                        )
                    }
                    Text(
                        text = "Used by tour boat captains & forest officers in case of medical or weather emergencies in deep delta areas.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    SundarbanTextField(
                        value = state.emergencyContactName,
                        onValueChange = { viewModel.onCustomerEmergencyNameChanged(it) },
                        label = strings.emergencyContactName,
                        placeholder = "e.g. Ramesh Sharma",
                        errorMessage = state.emergencyNameError,
                        testTag = "customer_signup_emergency_name"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    SundarbanTextField(
                        value = state.emergencyContactPhone,
                        onValueChange = { viewModel.onCustomerEmergencyPhoneChanged(it) },
                        label = strings.emergencyContactPhone,
                        placeholder = "+91 9876500000",
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        errorMessage = state.emergencyPhoneError,
                        testTag = "customer_signup_emergency_phone"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    SundarbanTextField(
                        value = state.emergencyContactRelation,
                        onValueChange = { viewModel.onCustomerEmergencyRelationChanged(it) },
                        label = strings.emergencyContactRelation,
                        placeholder = "e.g. Spouse / Parent / Sibling",
                        testTag = "customer_signup_emergency_relation"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Submit Button
            SundarbanButton(
                text = strings.signup,
                onClick = { viewModel.registerCustomer(onSignUpSuccess) },
                isLoading = state.isLoading,
                testTag = "customer_signup_submit_button"
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                TextButton(
                    onClick = onNavigateBackToLogin,
                    modifier = Modifier.testTag("customer_signup_to_login_button")
                ) {
                    Text(
                        text = strings.alreadyHaveAccount,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MangrovePrimary
                    )
                }
            }
        }
    }
}
