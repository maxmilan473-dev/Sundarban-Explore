package com.example.features.booking

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.data.repositories.TourRepository
import com.example.features.complaints.FileComplaintDialog
import com.example.features.disputes.OpenDisputeDialog
import com.example.features.payment.PaymentGatewayBottomSheet
import com.example.features.reviews.AddReviewDialog
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerBookingsScreen(
    currentUser: UserProfile?,
    tourRepository: TourRepository,
    onNavigateBack: () -> Unit,
    onExplorePackages: () -> Unit,
    onNavigateToPayments: () -> Unit = {}
) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val customerId = currentUser?.id ?: "cust_tourist_001"

    val bookings by tourRepository.getBookingsForCustomer(customerId).collectAsState(initial = emptyList())
    val allReviews by tourRepository.getAllReviewsForAdmin().collectAsState(initial = emptyList())
    var selectedTab by remember { mutableStateOf(0) } // 0: Upcoming/Active, 1: Completed, 2: Cancelled

    var bookingForCancellationRequest by remember { mutableStateOf<Booking?>(null) }
    var bookingForDiscussion by remember { mutableStateOf<Booking?>(null) }

    var bookingForReview by remember { mutableStateOf<Booking?>(null) }
    var bookingForDispute by remember { mutableStateOf<Booking?>(null) }
    var bookingForComplaint by remember { mutableStateOf<Booking?>(null) }
    var bookingForPayment by remember { mutableStateOf<Booking?>(null) }

    val filteredBookings = remember(bookings, selectedTab) {
        when (selectedTab) {
            0 -> bookings.filter {
                it.bookingStatus == BookingStatus.PENDING ||
                        it.bookingStatus == BookingStatus.ACCEPTED ||
                        it.bookingStatus == BookingStatus.CONFIRMED ||
                        it.bookingStatus == BookingStatus.PAID ||
                        it.bookingStatus == BookingStatus.PARTIALLY_PAID ||
                        it.bookingStatus == BookingStatus.IN_PROGRESS ||
                        it.bookingStatus == BookingStatus.UPCOMING ||
                        it.bookingStatus == BookingStatus.PROCESSING ||
                        it.bookingStatus == BookingStatus.CANCEL_REQUESTED ||
                        it.bookingStatus == BookingStatus.EMERGENCY_REVIEW ||
                        it.bookingStatus == BookingStatus.RESCHEDULE_REQUESTED ||
                        it.bookingStatus == BookingStatus.RESCHEDULED
            }
            1 -> bookings.filter { it.bookingStatus == BookingStatus.COMPLETED }
            else -> bookings.filter {
                it.bookingStatus == BookingStatus.CANCELLED ||
                        it.bookingStatus == BookingStatus.REJECTED ||
                        it.bookingStatus == BookingStatus.DISPUTED
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("My Safari Bookings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("cust_bookings_back_btn")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToPayments, modifier = Modifier.testTag("cust_bookings_payments_btn")) {
                        Icon(Icons.Default.Payments, contentDescription = "Payment History & Invoices")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tabs
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            "Upcoming / Active (${bookings.count {
                                it.bookingStatus == BookingStatus.PENDING ||
                                        it.bookingStatus == BookingStatus.ACCEPTED ||
                                        it.bookingStatus == BookingStatus.CONFIRMED ||
                                        it.bookingStatus == BookingStatus.PAID ||
                                        it.bookingStatus == BookingStatus.IN_PROGRESS
                            }})"
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Completed (${bookings.count { it.bookingStatus == BookingStatus.COMPLETED }})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text(
                            "Cancelled (${bookings.count {
                                it.bookingStatus == BookingStatus.CANCELLED ||
                                        it.bookingStatus == BookingStatus.REJECTED ||
                                        it.bookingStatus == BookingStatus.DISPUTED
                            }})"
                        )
                    }
                )
            }

            if (filteredBookings.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Outlined.Luggage,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No bookings in this tab",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Explore verified safari packages to plan your next Sundarban adventure.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = onExplorePackages) {
                            Text("Browse Tour Packages")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filteredBookings, key = { it.id }) { booking ->
                        val hasReview = allReviews.any { it.bookingId == booking.id }
                        CustomerBookingCard(
                            booking = booking,
                            hasReview = hasReview,
                            onPayOnlineClick = {
                                bookingForPayment = booking
                            },
                            onCancelClick = {
                                bookingForCancellationRequest = booking
                            },
                            onDiscussionClick = {
                                bookingForDiscussion = booking
                            },
                            onReviewClick = {
                                bookingForReview = booking
                            },
                            onDisputeClick = {
                                bookingForDispute = booking
                            },
                            onComplaintClick = {
                                bookingForComplaint = booking
                            }
                        )
                    }
                }
            }
        }
    }

    // Payment Gateway Bottom Sheet for Tourist
    if (bookingForPayment != null && currentUser != null) {
        val target = bookingForPayment!!
        val remaining = (target.totalAmount - target.paidAmount).coerceAtLeast(0.0)
        PaymentGatewayBottomSheet(
            booking = target,
            amountToPay = if (remaining > 0) remaining else target.totalAmount,
            currentUser = currentUser,
            tourRepository = tourRepository,
            onDismiss = { bookingForPayment = null },
            onPaymentCompleted = {
                bookingForPayment = null
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Payment successful! Safari booking ${target.id} updated.")
                }
            }
        )
    }

    // Cancellation Request Dialog (Rules: >5h normal mutual agreement, <=5h emergency review)
    if (bookingForCancellationRequest != null) {
        val target = bookingForCancellationRequest!!
        RequestCancellationDialog(
            booking = target,
            currentUser = currentUser,
            onDismiss = { bookingForCancellationRequest = null },
            onSubmit = { reason, detailedExplanation ->
                if (currentUser == null) return@RequestCancellationDialog
                coroutineScope.launch {
                    val result = tourRepository.requestBookingCancellation(
                        bookingId = target.id,
                        initiator = currentUser,
                        reason = reason,
                        detailedExplanation = detailedExplanation
                    )
                    bookingForCancellationRequest = null
                    result.onSuccess { req ->
                        val msg = if (req.isEmergency) {
                            "🚨 Emergency cancellation submitted. Escalated to Directorate Admin Review (< 5h to safari)."
                        } else {
                            "Cancellation requested (> 5h remaining). Awaiting operator mutual agreement."
                        }
                        snackbarHostState.showSnackbar(msg)
                    }.onFailure { err ->
                        snackbarHostState.showSnackbar("Error: ${err.message}")
                    }
                }
            }
        )
    }

    // Cancellation Discussion & Dossier Dialog
    if (bookingForDiscussion != null) {
        val target = bookingForDiscussion!!
        CancellationDiscussionDialog(
            booking = target,
            currentUser = currentUser,
            onDismiss = { bookingForDiscussion = null },
            onSendMessage = { msg ->
                if (currentUser == null) return@CancellationDiscussionDialog
                coroutineScope.launch {
                    tourRepository.addCancellationDiscussionMessage(target.id, currentUser, msg)
                }
            },
            onAcceptCancellation = {
                if (currentUser == null) return@CancellationDiscussionDialog
                coroutineScope.launch {
                    val result = tourRepository.respondToCancellationRequest(
                        bookingId = target.id,
                        responder = currentUser,
                        accept = true,
                        responseNotes = "Cancellation mutually agreed by tourist."
                    )
                    bookingForDiscussion = null
                    result.onSuccess {
                        snackbarHostState.showSnackbar("Cancellation accepted. Booking cancelled and refund initiated.")
                    }.onFailure { err ->
                        snackbarHostState.showSnackbar("Error: ${err.message}")
                    }
                }
            },
            onRejectCancellation = { note ->
                if (currentUser == null) return@CancellationDiscussionDialog
                coroutineScope.launch {
                    val result = tourRepository.respondToCancellationRequest(
                        bookingId = target.id,
                        responder = currentUser,
                        accept = false,
                        responseNotes = note
                    )
                    bookingForDiscussion = null
                    result.onSuccess {
                        snackbarHostState.showSnackbar("Cancellation request rejected. Booking remains confirmed.")
                    }.onFailure { err ->
                        snackbarHostState.showSnackbar("Error: ${err.message}")
                    }
                }
            }
        )
    }

    // Add Review Dialog (Only for COMPLETED bookings, Prevents Duplicates)
    if (bookingForReview != null && currentUser != null) {
        val target = bookingForReview!!
        AddReviewDialog(
            booking = target,
            currentUser = currentUser,
            onDismiss = { bookingForReview = null },
            onSubmitReview = { rating, comment, photoUrl ->
                coroutineScope.launch {
                    val review = Review(
                        id = "rev_${UUID.randomUUID().toString().take(8)}",
                        bookingId = target.id,
                        packageId = target.packageId,
                        packageTitle = target.packageTitle,
                        operatorId = target.operatorId,
                        customerId = currentUser.id,
                        customerName = currentUser.fullName,
                        rating = rating,
                        comment = comment,
                        photoUrl = photoUrl,
                        createdAt = System.currentTimeMillis()
                    )
                    val result = tourRepository.addReview(review, currentUser)
                    bookingForReview = null
                    if (result.isSuccess) {
                        snackbarHostState.showSnackbar("Review submitted successfully! Thank you for helping the community.")
                    } else {
                        snackbarHostState.showSnackbar("Error: ${result.exceptionOrNull()?.message ?: "Unable to submit review"}")
                    }
                }
            }
        )
    }

    // Open Dispute Dialog
    if (bookingForDispute != null && currentUser != null) {
        val target = bookingForDispute!!
        OpenDisputeDialog(
            booking = target,
            currentUser = currentUser,
            onDismiss = { bookingForDispute = null },
            onConfirmOpenDispute = { reason, evidenceUrl ->
                coroutineScope.launch {
                    val evidenceList = if (!evidenceUrl.isNullOrBlank()) listOf(evidenceUrl) else emptyList()
                    val result = tourRepository.openFormalDispute(
                        bookingId = target.id,
                        complaintId = null,
                        reason = reason,
                        evidenceUrls = evidenceList,
                        requester = currentUser
                    )
                    bookingForDispute = null
                    if (result.isSuccess) {
                        snackbarHostState.showSnackbar("Dispute ${result.getOrNull()?.disputeId} submitted to Admin Governance.")
                    } else {
                        snackbarHostState.showSnackbar("Error: ${result.exceptionOrNull()?.message ?: "Failed to open dispute"}")
                    }
                }
            }
        )
    }

    // File Complaint Dialog
    if (bookingForComplaint != null && currentUser != null) {
        val target = bookingForComplaint!!
        FileComplaintDialog(
            currentUser = currentUser,
            linkedBookings = bookings,
            initialBookingId = target.id,
            onDismiss = { bookingForComplaint = null },
            onSubmitComplaint = { complaint ->
                coroutineScope.launch {
                    val result = tourRepository.fileComplaint(complaint, currentUser)
                    bookingForComplaint = null
                    if (result.isSuccess) {
                        snackbarHostState.showSnackbar("Complaint ${result.getOrNull()?.complaintId} registered for Admin investigation.")
                    } else {
                        snackbarHostState.showSnackbar("Error: ${result.exceptionOrNull()?.message ?: "Failed to file complaint"}")
                    }
                }
            }
        )
    }
}

@Composable
fun CustomerBookingCard(
    booking: Booking,
    hasReview: Boolean = false,
    onPayOnlineClick: () -> Unit = {},
    onCancelClick: () -> Unit,
    onDiscussionClick: () -> Unit = {},
    onReviewClick: () -> Unit = {},
    onDisputeClick: () -> Unit = {},
    onComplaintClick: () -> Unit = {}
) {
    val context = LocalContext.current
    var isTimelineExpanded by remember { mutableStateOf(false) }

    val statusColor = when (booking.bookingStatus) {
        BookingStatus.PROCESSING -> Color(0xFFE65100)
        BookingStatus.PENDING -> Color(0xFFE65100)
        BookingStatus.ACCEPTED -> Color(0xFF1565C0)
        BookingStatus.CONFIRMED -> Color(0xFF2E7D32)
        BookingStatus.UPCOMING -> Color(0xFF1565C0)
        BookingStatus.PARTIALLY_PAID -> Color(0xFFE65100)
        BookingStatus.PAID -> Color(0xFF2E7D32)
        BookingStatus.IN_PROGRESS -> Color(0xFF6A1B9A)
        BookingStatus.TOUR_IN_PROGRESS -> Color(0xFF6A1B9A)
        BookingStatus.COMPLETED -> Color(0xFF00695C)
        BookingStatus.CANCEL_REQUESTED -> TigerAmber
        BookingStatus.CANCELLED -> Color(0xFFC62828)
        BookingStatus.RESCHEDULE_REQUESTED -> Color(0xFF1565C0)
        BookingStatus.RESCHEDULED -> Color(0xFF00897B)
        BookingStatus.EMERGENCY_REVIEW -> Color(0xFFC62828)
        BookingStatus.REJECTED -> Color(0xFFB71C1C)
        BookingStatus.DISPUTED -> Color(0xFFAD1457)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("booking_card_${booking.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Unique Booking ID & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.ConfirmationNumber,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = booking.id,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    booking.refundResolutionStatus?.let { refStatus ->
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = refStatus,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    Surface(
                        color = statusColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = booking.bookingStatus.displayName.uppercase(),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Specialized Cancellation / Emergency Banners
            if (booking.bookingStatus == BookingStatus.CANCEL_REQUESTED) {
                Surface(
                    color = TigerAmber.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Cancellation Requested (> 5h before tour)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = TigerAmber
                            )
                            booking.activeCancellationRequest?.reason?.let { r ->
                                Text("Reason: $r", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        TextButton(onClick = onDiscussionClick) {
                            Text("Discuss", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            } else if (booking.bookingStatus == BookingStatus.EMERGENCY_REVIEW) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🚨 Emergency Review in Progress (≤ 5h to safari)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                            Text(
                                text = "Directorate Admin is reviewing this case. You will be notified of the decision.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        TextButton(onClick = onDiscussionClick) {
                            Text("View Dossier", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            } else if (booking.bookingStatus == BookingStatus.RESCHEDULED) {
                Surface(
                    color = Color(0xFF00897B).copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "🗓️ Rescheduled Safari Date: ${booking.travelDate}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFF00897B)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Package Title & Operator
            Text(
                text = booking.packageTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Operator: ${booking.operatorName}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Dates & Guests Row
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Departure", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(booking.travelDate, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }

                    Column {
                        Text("Return", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(booking.returnDate.ifBlank { booking.travelDate }, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }

                    Column {
                        Text("Tourists", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${booking.numberOfTourists} Guests", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Pickup & Total Amount
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Pickup: ${booking.pickupLocation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                    Text(
                        text = "Payment: ${booking.paymentMethod.displayName} • ${booking.paymentStatus.name}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "₹${booking.totalAmount.toInt()}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    val adminCharge = booking.totalAmount * 0.005
                    val adminChargeFormatted = if (adminCharge % 1.0 == 0.0) String.format("%,.0f", adminCharge) else String.format("%,.2f", adminCharge)
                    Text(
                        text = "Incl. 0.5% Admin Charge (₹$adminChargeFormatted)",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Expandable Booking Status Timeline
            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isTimelineExpanded = !isTimelineExpanded }
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.History,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Status Timeline & Audit History (${booking.statusTimeline.size} steps)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Icon(
                    if (isTimelineExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
            }

            AnimatedVisibility(visible = isTimelineExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    booking.statusTimeline.forEachIndexed { index, history ->
                        TimelineItemView(history = history, isLatest = index == booking.statusTimeline.size - 1)
                    }
                }
            }

            // Action Buttons for Active Bookings
            val remainingDue = (booking.totalAmount - booking.paidAmount).coerceAtLeast(0.0)
            if (booking.bookingStatus == BookingStatus.PENDING ||
                booking.bookingStatus == BookingStatus.ACCEPTED ||
                booking.bookingStatus == BookingStatus.CONFIRMED ||
                booking.bookingStatus == BookingStatus.UPCOMING ||
                booking.bookingStatus == BookingStatus.PROCESSING ||
                booking.bookingStatus == BookingStatus.PARTIALLY_PAID ||
                booking.bookingStatus == BookingStatus.PAID
            ) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (remainingDue > 0) {
                        Button(
                            onClick = onPayOnlineClick,
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("pay_booking_online_btn_${booking.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pay ₹${String.format("%,.0f", remainingDue)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (booking.paidAmount > 0) {
                        OutlinedButton(
                            onClick = onDisputeClick,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusAdmin),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Dispute", fontSize = 11.sp)
                        }
                    }

                    if (booking.operatorPhone.isNotBlank()) {
                        TextButton(onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${booking.operatorPhone}"))
                            context.startActivity(intent)
                        }) {
                            Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("Call", fontSize = 12.sp)
                        }
                    }

                    OutlinedButton(
                        onClick = onCancelClick,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Cancel", fontSize = 12.sp)
                    }
                }
            } else if (booking.bookingStatus == BookingStatus.CANCEL_REQUESTED || booking.bookingStatus == BookingStatus.EMERGENCY_REVIEW) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onDiscussionClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (booking.bookingStatus == BookingStatus.EMERGENCY_REVIEW) MaterialTheme.colorScheme.error else TigerAmber
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            if (booking.bookingStatus == BookingStatus.EMERGENCY_REVIEW) Icons.Default.Gavel else Icons.Default.Chat,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (booking.bookingStatus == BookingStatus.EMERGENCY_REVIEW) "Open Directorate Review Dossier" else "Open Cancellation Discussion",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            } else if (booking.bookingStatus == BookingStatus.COMPLETED) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!hasReview) {
                        Button(
                            onClick = onReviewClick,
                            colors = ButtonDefaults.buttonColors(containerColor = TigerAmber),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Write Review", fontSize = 12.sp)
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = StatusVerifiedBg,
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusVerified, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reviewed", color = StatusVerified, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = onDisputeClick,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusAdmin),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Dispute", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onComplaintClick,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejected),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ReportProblem, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Complaint", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun TimelineItemView(history: BookingStatusHistory, isLatest: Boolean) {
    val dateStr = remember(history.timestamp) {
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(history.timestamp))
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .padding(top = 4.dp)
                .size(10.dp)
                .clip(CircleShape)
                .background(if (isLatest) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
        )

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = history.newStatus.displayName,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isLatest) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = "By ${history.changedByName} (${history.changedByRole.name})",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (history.reason.isNotBlank()) {
                Text(
                    text = history.reason,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
