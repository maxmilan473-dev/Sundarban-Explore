package com.example.features.library

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Water
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.localization.AppLanguage
import com.example.core.localization.LanguageManager
import com.example.core.model.BookChapter
import com.example.core.model.BookResource
import com.example.core.model.SundarbanArticle
import com.example.core.model.VideoResource
import com.example.data.repositories.ContentRepository
import com.example.ui.theme.ForestDarkest
import com.example.ui.theme.MangroveContainer
import com.example.ui.theme.MangroveDark
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.RiverTeal
import com.example.ui.theme.TigerAmber
import com.example.ui.theme.TigerGold
import com.example.ui.theme.TigerLight
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EcoLibraryViewModel(
    private val contentRepository: ContentRepository,
    private val languageManager: LanguageManager
) : ViewModel() {
    val currentLanguage: StateFlow<AppLanguage> = languageManager.currentLanguage

    val articles = contentRepository.getArticles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val videos = contentRepository.getVideos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val books = contentRepository.getBooks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setLanguage(language: AppLanguage) {
        languageManager.setLanguage(language)
    }

    fun cycleNextLanguage() {
        val next = when (currentLanguage.value) {
            AppLanguage.ENGLISH -> AppLanguage.BENGALI
            AppLanguage.BENGALI -> AppLanguage.HINDI
            AppLanguage.HINDI -> AppLanguage.ENGLISH
        }
        languageManager.setLanguage(next)
    }

    fun updateReadingProgress(bookId: String, progressPercent: Int) {
        viewModelScope.launch {
            contentRepository.updateReadingProgress(bookId, progressPercent)
        }
    }

    fun toggleBookmark(bookId: String, pageOrChapter: Int) {
        viewModelScope.launch {
            contentRepository.toggleBookmark(bookId, pageOrChapter)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EcoLibraryScreen(
    viewModel: EcoLibraryViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val articles by viewModel.articles.collectAsState()
    val videos by viewModel.videos.collectAsState()
    val books by viewModel.books.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("All") }

    var selectedArticleForRead by remember { mutableStateOf<SundarbanArticle?>(null) }
    var selectedVideoForPlay by remember { mutableStateOf<VideoResource?>(null) }
    var isVideoPlaying by remember { mutableStateOf(false) }
    var selectedBookForRead by remember { mutableStateOf<BookResource?>(null) }
    var currentChapterIndex by remember { mutableIntStateOf(0) }

    val categories = listOf(
        "All", "About Sundarbans", "History", "Geography", "Mangrove Forest",
        "Rivers", "Islands", "Royal Bengal Tiger", "Wildlife", "Birds",
        "Fish", "Reptiles", "Plants", "Tourist Destinations", "Best Time to Visit",
        "Travel Preparation", "Safety", "Forest Rules", "Tourist Responsibilities", "FAQs"
    )

    val tabs = listOf("Articles & Wildlife", "Video Library", "Digital Field Books", "Tides & Safety")

    // ARTICLE READER FULL SCREEN
    if (selectedArticleForRead != null) {
        val art = selectedArticleForRead!!
        val title = when (currentLang) {
            AppLanguage.BENGALI -> art.titleBn.ifBlank { art.titleEn }
            AppLanguage.HINDI -> art.titleHi.ifBlank { art.titleEn }
            else -> art.titleEn
        }
        val summary = when (currentLang) {
            AppLanguage.BENGALI -> art.summaryBn.ifBlank { art.summaryEn }
            AppLanguage.HINDI -> art.summaryHi.ifBlank { art.summaryEn }
            else -> art.summaryEn
        }
        val content = when (currentLang) {
            AppLanguage.BENGALI -> art.contentBn.ifBlank { art.contentEn }
            AppLanguage.HINDI -> art.contentHi.ifBlank { art.contentEn }
            else -> art.contentEn
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(text = title, maxLines = 1, fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { selectedArticleForRead = null }, modifier = Modifier.testTag("article_reader_back")) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.cycleNextLanguage() }) {
                            Icon(imageVector = Icons.Default.Translate, contentDescription = "Language", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MangrovePrimary, titleContentColor = Color.White)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TigerAmber.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = art.category.uppercase(),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = TigerAmber,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MangroveDark
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "${art.readTimeMinutes} min read • Verified Sundarban Knowledge • Lang: ${currentLang.nativeName}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

                Text(
                    text = summary,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MangrovePrimary,
                    lineHeight = 24.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 26.sp
                )
            }
        }
        return
    }

    // DIGITAL BOOK READER FULL SCREEN
    if (selectedBookForRead != null) {
        val bk = selectedBookForRead!!
        val chapter = bk.chapters.getOrNull(currentChapterIndex) ?: BookChapter("ch_0", 1, bk.titleEn, bk.descriptionEn)
        val isBookmarked = bk.bookmarks.contains(chapter.chapterNumber)

        val bookTitle = when (currentLang) {
            AppLanguage.BENGALI -> bk.titleBn.ifBlank { bk.titleEn }
            AppLanguage.HINDI -> bk.titleHi.ifBlank { bk.titleEn }
            else -> bk.titleEn
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(text = bookTitle, maxLines = 1, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(text = "Chapter ${chapter.chapterNumber} of ${bk.chapters.size.coerceAtLeast(1)}", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { selectedBookForRead = null }, modifier = Modifier.testTag("book_reader_back")) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.toggleBookmark(bk.id, chapter.chapterNumber) }) {
                            Icon(
                                imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                contentDescription = "Bookmark",
                                tint = if (isBookmarked) TigerGold else Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = ForestDarkest, titleContentColor = Color.White)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp)
            ) {
                // Reading progress
                Column(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Reading Progress", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text(text = "${bk.readingProgressPercent}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MangrovePrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { bk.readingProgressPercent / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = MangrovePrimary,
                        trackColor = Color.LightGray.copy(alpha = 0.3f)
                    )
                }

                Card(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp)
                    ) {
                        Text(
                            text = chapter.title,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = ForestDarkest
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Author: ${bk.author} • Format: ${bk.format}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF64748B)
                        )
                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        Text(
                            text = chapter.content,
                            style = MaterialTheme.typography.bodyLarge,
                            lineHeight = 28.sp,
                            color = Color(0xFF1E293B)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Chapter Navigation Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (currentChapterIndex > 0) {
                                currentChapterIndex--
                                val newPercent = (((currentChapterIndex + 1).toFloat() / bk.chapters.size) * 100).toInt()
                                viewModel.updateReadingProgress(bk.id, newPercent)
                            }
                        },
                        enabled = currentChapterIndex > 0
                    ) {
                        Text(text = "← Prev", fontWeight = FontWeight.Bold, color = if (currentChapterIndex > 0) MangrovePrimary else Color.Gray)
                    }

                    Text(text = "${currentChapterIndex + 1} / ${bk.chapters.size.coerceAtLeast(1)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)

                    IconButton(
                        onClick = {
                            if (currentChapterIndex < bk.chapters.size - 1) {
                                currentChapterIndex++
                                val newPercent = (((currentChapterIndex + 1).toFloat() / bk.chapters.size) * 100).toInt()
                                viewModel.updateReadingProgress(bk.id, newPercent)
                            }
                        },
                        enabled = currentChapterIndex < bk.chapters.size - 1
                    ) {
                        Text(text = "Next →", fontWeight = FontWeight.Bold, color = if (currentChapterIndex < bk.chapters.size - 1) MangrovePrimary else Color.Gray)
                    }
                }
            }
        }
        return
    }

    // MAIN ECO-LIBRARY SCREEN
    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("eco_library_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Sundarban Information & Eco-Library", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("Authentic Knowledge, Wildlife & Digital Reading", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("eco_library_back_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.cycleNextLanguage() }) {
                        Icon(imageVector = Icons.Default.Translate, contentDescription = "Language", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MangrovePrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Bar & Language Chip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search Sundarbans articles, videos...", fontSize = 13.sp) },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MangrovePrimary) },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = TigerAmber.copy(alpha = 0.15f),
                    modifier = Modifier.clickable { viewModel.cycleNextLanguage() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = TigerAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = currentLang.code.uppercase(), fontWeight = FontWeight.Bold, color = TigerAmber, fontSize = 12.sp)
                    }
                }
            }

            // Scrollable Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.White,
                contentColor = MangrovePrimary,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = MangrovePrimary
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedTabIndex == index) MangrovePrimary else Color(0xFF64748B)
                            )
                        }
                    )
                }
            }

            when (selectedTabIndex) {
                0 -> {
                    // ARTICLES (SUNDARBAN INFORMATION SYSTEM - 19 CATEGORIES)
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Category Pills Filter
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(categories) { cat ->
                                FilterChip(
                                    selected = selectedCategoryFilter == cat,
                                    onClick = { selectedCategoryFilter = cat },
                                    label = { Text(cat, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MangrovePrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        val filteredArticles = articles.filter { art ->
                            val matchesCategory = selectedCategoryFilter == "All" || art.category.equals(selectedCategoryFilter, ignoreCase = true)
                            val title = when(currentLang) {
                                AppLanguage.BENGALI -> art.titleBn.ifBlank { art.titleEn }
                                AppLanguage.HINDI -> art.titleHi.ifBlank { art.titleEn }
                                else -> art.titleEn
                            }
                            val matchesSearch = searchQuery.isBlank() || title.contains(searchQuery, ignoreCase = true) || art.summaryEn.contains(searchQuery, ignoreCase = true)
                            matchesCategory && matchesSearch
                        }

                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filteredArticles) { art ->
                                val title = when(currentLang) {
                                    AppLanguage.BENGALI -> art.titleBn.ifBlank { art.titleEn }
                                    AppLanguage.HINDI -> art.titleHi.ifBlank { art.titleEn }
                                    else -> art.titleEn
                                }
                                val summary = when(currentLang) {
                                    AppLanguage.BENGALI -> art.summaryBn.ifBlank { art.summaryEn }
                                    AppLanguage.HINDI -> art.summaryHi.ifBlank { art.summaryEn }
                                    else -> art.summaryEn
                                }

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedArticleForRead = art }
                                        .testTag("article_item_${art.id}"),
                                    shape = RoundedCornerShape(18.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                                    elevation = CardDefaults.cardElevation(2.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = TigerLight
                                            ) {
                                                Text(
                                                    text = art.category.uppercase(),
                                                    color = TigerAmber,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 9.sp,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }

                                            Text(
                                                text = "${art.readTimeMinutes} min",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color.Gray
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ForestDarkest)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = summary, style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B), maxLines = 2)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(text = "Read Full Knowledge Guide →", color = MangrovePrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // VIDEO LIBRARY WITH INTERACTIVE PLAYER SIMULATION
                    val filteredVideos = videos.filter { vid ->
                        val title = when (currentLang) {
                            AppLanguage.BENGALI -> vid.titleBn.ifBlank { vid.titleEn }
                            AppLanguage.HINDI -> vid.titleHi.ifBlank { vid.titleEn }
                            else -> vid.titleEn
                        }
                        searchQuery.isBlank() || title.contains(searchQuery, ignoreCase = true) || vid.category.contains(searchQuery, ignoreCase = true)
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Video Player Screen if active
                        if (selectedVideoForPlay != null) {
                            val activeVid = selectedVideoForPlay!!
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = ForestDarkest)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(180.dp)
                                                .background(Color.Black, RoundedCornerShape(12.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                IconButton(
                                                    onClick = { isVideoPlaying = !isVideoPlaying },
                                                    modifier = Modifier.size(64.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (isVideoPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                                        contentDescription = "Play/Pause",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(56.dp)
                                                    )
                                                }
                                                Text(
                                                    text = if (isVideoPlaying) "Streaming HD Nature Video..." else "Tap to Play Video",
                                                    color = Color.White.copy(alpha = 0.8f),
                                                    style = MaterialTheme.typography.bodySmall
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(text = activeVid.titleEn, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text(text = "${activeVid.category} • ${activeVid.durationText} • ${activeVid.channel}", color = TigerGold, style = MaterialTheme.typography.labelSmall)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = activeVid.descriptionEn, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }

                        items(filteredVideos) { vid ->
                            val title = when (currentLang) {
                                AppLanguage.BENGALI -> vid.titleBn.ifBlank { vid.titleEn }
                                AppLanguage.HINDI -> vid.titleHi.ifBlank { vid.titleEn }
                                else -> vid.titleEn
                            }
                            val desc = when (currentLang) {
                                AppLanguage.BENGALI -> vid.descriptionBn.ifBlank { vid.descriptionEn }
                                AppLanguage.HINDI -> vid.descriptionHi.ifBlank { vid.descriptionEn }
                                else -> vid.descriptionEn
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedVideoForPlay = vid
                                        isVideoPlaying = true
                                    },
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                                elevation = CardDefaults.cardElevation(2.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        modifier = Modifier.size(56.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        color = TigerLight
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(imageVector = Icons.Default.PlayCircleOutline, contentDescription = null, tint = TigerAmber, modifier = Modifier.size(32.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = MangroveContainer
                                        ) {
                                            Text(
                                                text = vid.category.uppercase(),
                                                color = MangrovePrimary,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ForestDarkest)
                                        Text(text = desc, style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B), maxLines = 2)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = "${vid.durationText} • ${vid.channel}", style = MaterialTheme.typography.labelSmall, color = MangrovePrimary, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // DIGITAL FIELD BOOKS & COMPANIONS
                    val filteredBooks = books.filter { bk ->
                        val title = when (currentLang) {
                            AppLanguage.BENGALI -> bk.titleBn.ifBlank { bk.titleEn }
                            AppLanguage.HINDI -> bk.titleHi.ifBlank { bk.titleEn }
                            else -> bk.titleEn
                        }
                        searchQuery.isBlank() || title.contains(searchQuery, ignoreCase = true) || bk.author.contains(searchQuery, ignoreCase = true)
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filteredBooks) { bk ->
                            val title = when (currentLang) {
                                AppLanguage.BENGALI -> bk.titleBn.ifBlank { bk.titleEn }
                                AppLanguage.HINDI -> bk.titleHi.ifBlank { bk.titleEn }
                                else -> bk.titleEn
                            }
                            val desc = when (currentLang) {
                                AppLanguage.BENGALI -> bk.descriptionBn.ifBlank { bk.descriptionEn }
                                AppLanguage.HINDI -> bk.descriptionHi.ifBlank { bk.descriptionEn }
                                else -> bk.descriptionEn
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedBookForRead = bk
                                        currentChapterIndex = 0
                                    }
                                    .testTag("book_item_${bk.id}"),
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                                elevation = CardDefaults.cardElevation(2.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            modifier = Modifier.size(52.dp),
                                            shape = RoundedCornerShape(16.dp),
                                            color = MangroveContainer
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(imageVector = Icons.Default.AutoStories, contentDescription = null, tint = MangrovePrimary, modifier = Modifier.size(28.dp))
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ForestDarkest)
                                            Text(text = "By ${bk.author}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF64748B))
                                            Text(text = "${bk.chapters.size} Chapters • ${bk.format} • ${bk.language}", style = MaterialTheme.typography.labelSmall, color = MangrovePrimary, fontWeight = FontWeight.SemiBold)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(text = desc, style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569))

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Progress bar
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        LinearProgressIndicator(
                                            progress = { bk.readingProgressPercent / 100f },
                                            modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)),
                                            color = MangrovePrimary,
                                            trackColor = Color.LightGray.copy(alpha = 0.3f)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(text = "${bk.readingProgressPercent}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MangrovePrimary)
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(text = "Open Reader & Field Companion →", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MangrovePrimary)
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // TIDES & RIVER SAFETY PROTOCOLS
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                            elevation = CardDefaults.cardElevation(2.dp)
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        modifier = Modifier.size(42.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        color = RiverTeal.copy(alpha = 0.1f)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(imageVector = Icons.Default.Water, contentDescription = null, tint = RiverTeal)
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(text = "Tidal Dynamics & Navigation Hours", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ForestDarkest)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Sundarban operates strictly on semi-diurnal tides with high tide (Jowar/Bhora Kotal) and low tide (Bhata/Mora Kotal) alternating every 6 hours. High tides allow boats to access narrow creeks like Pirkhali and Sudhanyakhali, while low tides reveal muddy banks where crocodiles and mudskippers bask.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF475569),
                                    lineHeight = 20.sp
                                )
                            }
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                            elevation = CardDefaults.cardElevation(2.dp)
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        modifier = Modifier.size(42.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        color = MangroveContainer
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = MangrovePrimary)
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(text = "Official Forest Directorate Rules", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ForestDarkest)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                listOf(
                                    "1. Entry into core forest zones without armed guard is strictly prohibited.",
                                    "2. No boat navigation is permitted in forest rivers between sunset and sunrise (6 PM to 6 AM).",
                                    "3. Single-use plastic is strictly banned in the biosphere reserve.",
                                    "4. Wearing safety life jackets on boat decks is mandatory by maritime law.",
                                    "5. Avoid playing loud music or throwing food to wild animals."
                                ).forEach { rule ->
                                    Text(text = rule, style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569), modifier = Modifier.padding(vertical = 3.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
