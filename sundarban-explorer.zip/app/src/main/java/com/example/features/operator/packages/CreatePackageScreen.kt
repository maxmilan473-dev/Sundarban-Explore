package com.example.features.operator.packages

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.PackageStatus
import com.example.core.model.TourPackage
import com.example.core.model.UserProfile
import com.example.data.repositories.TourRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePackageScreen(
    currentUser: UserProfile?,
    tourRepository: TourRepository,
    onNavigateBack: () -> Unit,
    onPackageCreated: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var packageName by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var startingLocation by remember { mutableStateOf("Godkhali Ferry Ghat, Canning") }
    var route by remember { mutableStateOf("Godkhali -> Gosaba -> Sajnekhali -> Sudhanyakhali -> Dobanki -> Godkhali") }
    var destination by remember { mutableStateOf("Sundarban Tiger Reserve & Core Delta") }
    var durationDays by remember { mutableStateOf(2) }
    var durationNights by remember { mutableStateOf(1) }
    var maxTourists by remember { mutableStateOf(12) }
    var pricePerPerson by remember { mutableStateOf(4500.0) }
    var boatDetails by remember { mutableStateOf("M.B. Sundarban Pride - Deluxe 42ft Twin-Diesel Motor Boat with upper viewing deck & western toilet") }
    var foodDetails by remember { mutableStateOf("Breakfast (Luchi, Cholar Dal), Lunch (Bhetki Macher Jhol, Dal, Bhaja, Rice), Dinner (Chicken Curry, Roti/Rice)") }
    var accommodationDetails by remember { mutableStateOf("Eco-Cottage at Pakhiralay / Dayapur with attached bath, 24/7 solar power & mosquito nets") }
    var guideDetails by remember { mutableStateOf("Certified West Bengal Forest Ecotourism Naturalist and experienced Sundarban boat pilot") }
    var permitInfo by remember { mutableStateOf("Mandatory Forest Department National Park entry permits, biometric pass and boat clearance included") }
    var pickupInfo by remember { mutableStateOf("Godkhali Ghat Meeting Point (08:30 AM). Optional Canning Station pickup (+Rs 200/person)") }
    var cancellationPolicy by remember { mutableStateOf("100% refund up to 72 hours before departure. 50% refund between 24-72 hours. Non-refundable within 24 hours.") }
    var importantInstructions by remember { mutableStateOf("1. Carry original Govt ID (mandatory at checkpost).\n2. Single-use plastic is strictly prohibited.\n3. High-decibel audio is prohibited.") }

    var newIncludedService by remember { mutableStateOf("") }
    var includedServices by remember {
        mutableStateOf(
            listOf(
                "Govt Forest Entry Permits",
                "Certified Naturalist Guide",
                "Traditional Bengali Meals on Boat",
                "Life Jackets & Safety Gear",
                "Twin-sharing Eco-Resort Stay"
            )
        )
    }

    var newExcludedService by remember { mutableStateOf("") }
    var excludedServices by remember {
        mutableStateOf(
            listOf(
                "Personal snacks & mineral water",
                "Camera/Video charges at forest counter",
                "Transport to Godkhali Ghat"
            )
        )
    }

    var newDate by remember { mutableStateOf("") }
    var availableDates by remember {
        mutableStateOf(listOf("2026-09-15", "2026-09-20", "2026-09-25", "2026-10-02", "2026-10-10"))
    }

    var isSubmitting by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Create Tour Package", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("create_pkg_back_btn")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Package Lifecycle Policy Banner
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Important Policy: No Editing Once Published",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "To protect booking integrity, operators cannot edit a package after publication. If you need to make changes in the future, delete the existing package and create a new one.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            // General Info Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("1. Basic Tour Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        OutlinedTextField(
                            value = packageName,
                            onValueChange = { packageName = it },
                            label = { Text("Package Name *") },
                            placeholder = { Text("e.g. Royal Tiger & Sajnekhali 2D/1N River Safari") },
                            modifier = Modifier.fillMaxWidth().testTag("pkg_name_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Description *") },
                            placeholder = { Text("Describe the safari experience, wildlife spots, and boat route...") },
                            modifier = Modifier.fillMaxWidth().testTag("pkg_desc_input"),
                            minLines = 3
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = durationDays.toString(),
                                onValueChange = { durationDays = it.toIntOrNull() ?: 1 },
                                label = { Text("Days") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = durationNights.toString(),
                                onValueChange = { durationNights = it.toIntOrNull() ?: 0 },
                                label = { Text("Nights") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = maxTourists.toString(),
                                onValueChange = { maxTourists = it.toIntOrNull() ?: 10 },
                                label = { Text("Max Tourists") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = pricePerPerson.toString(),
                            onValueChange = { pricePerPerson = it.toDoubleOrNull() ?: 0.0 },
                            label = { Text("Price Per Person (₹) *") },
                            modifier = Modifier.fillMaxWidth().testTag("pkg_price_input")
                        )
                    }
                }
            }

            // Route & Destinations Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("2. Location & Route", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        OutlinedTextField(
                            value = startingLocation,
                            onValueChange = { startingLocation = it },
                            label = { Text("Starting Location / Jetty *") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = route,
                            onValueChange = { route = it },
                            label = { Text("Safari Route Map *") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = destination,
                            onValueChange = { destination = it },
                            label = { Text("Primary Destination *") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Boat, Food & Stay Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("3. Logistics & Facilities", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        OutlinedTextField(
                            value = boatDetails,
                            onValueChange = { boatDetails = it },
                            label = { Text("Boat & Vessel Details *") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )

                        OutlinedTextField(
                            value = foodDetails,
                            onValueChange = { foodDetails = it },
                            label = { Text("Food & Catering Menu *") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )

                        OutlinedTextField(
                            value = accommodationDetails,
                            onValueChange = { accommodationDetails = it },
                            label = { Text("Accommodation Details") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )

                        OutlinedTextField(
                            value = guideDetails,
                            onValueChange = { guideDetails = it },
                            label = { Text("Guide & Naturalist Information") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Inclusions & Exclusions Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("4. Services Included & Excluded", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        Text("Included Services:", style = MaterialTheme.typography.labelMedium)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newIncludedService,
                                onValueChange = { newIncludedService = it },
                                placeholder = { Text("Add included item...") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            Button(onClick = {
                                if (newIncludedService.isNotBlank()) {
                                    includedServices = includedServices + newIncludedService.trim()
                                    newIncludedService = ""
                                }
                            }) {
                                Text("Add")
                            }
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(includedServices) { item ->
                                InputChip(
                                    selected = true,
                                    onClick = { includedServices = includedServices - item },
                                    label = { Text("✓ $item") },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = "Remove", modifier = Modifier.size(14.dp)) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Excluded Services:", style = MaterialTheme.typography.labelMedium)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newExcludedService,
                                onValueChange = { newExcludedService = it },
                                placeholder = { Text("Add excluded item...") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            Button(onClick = {
                                if (newExcludedService.isNotBlank()) {
                                    excludedServices = excludedServices + newExcludedService.trim()
                                    newExcludedService = ""
                                }
                            }) {
                                Text("Add")
                            }
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(excludedServices) { item ->
                                InputChip(
                                    selected = false,
                                    onClick = { excludedServices = excludedServices - item },
                                    label = { Text("✕ $item") },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = "Remove", modifier = Modifier.size(14.dp)) }
                                )
                            }
                        }
                    }
                }
            }

            // Available Dates & Policies Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("5. Available Safari Dates & Policies", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newDate,
                                onValueChange = { newDate = it },
                                placeholder = { Text("YYYY-MM-DD (e.g. 2026-10-15)") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            Button(onClick = {
                                if (newDate.isNotBlank()) {
                                    availableDates = (availableDates + newDate.trim()).sorted()
                                    newDate = ""
                                }
                            }) {
                                Text("Add Date")
                            }
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(availableDates) { dt ->
                                InputChip(
                                    selected = true,
                                    onClick = { availableDates = availableDates - dt },
                                    label = { Text(dt) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = "Remove", modifier = Modifier.size(14.dp)) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = permitInfo,
                            onValueChange = { permitInfo = it },
                            label = { Text("Forest Permit & Entry Info") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = pickupInfo,
                            onValueChange = { pickupInfo = it },
                            label = { Text("Pickup Information") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = cancellationPolicy,
                            onValueChange = { cancellationPolicy = it },
                            label = { Text("Cancellation Policy") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )

                        OutlinedTextField(
                            value = importantInstructions,
                            onValueChange = { importantInstructions = it },
                            label = { Text("Important Tourist Instructions") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                    }
                }
            }

            // Action Buttons (Save Draft & Submit)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            if (packageName.isBlank()) {
                                coroutineScope.launch { snackbarHostState.showSnackbar("Please enter a package name") }
                                return@OutlinedButton
                            }
                            coroutineScope.launch {
                                isSubmitting = true
                                val draft = TourPackage(
                                    operatorId = currentUser?.id ?: "op_verified_001",
                                    operatorName = currentUser?.fullName ?: "Verified Operator",
                                    operatorPhone = currentUser?.phoneNumber ?: "",
                                    isOperatorVerified = currentUser?.isPublicVerifiedOperator ?: true,
                                    title = packageName.trim(),
                                    description = description.trim(),
                                    durationDays = durationDays,
                                    durationNights = durationNights,
                                    durationText = "$durationDays Days / $durationNights Nights",
                                    startingLocation = startingLocation.trim(),
                                    route = route.trim(),
                                    destination = destination.trim(),
                                    maxTourists = maxTourists,
                                    price = pricePerPerson,
                                    pricePerPerson = pricePerPerson,
                                    includedServices = includedServices,
                                    excludedServices = excludedServices,
                                    boatDetails = boatDetails,
                                    foodDetails = foodDetails,
                                    accommodationDetails = accommodationDetails,
                                    guideDetails = guideDetails,
                                    permitInfo = permitInfo,
                                    pickupInfo = pickupInfo,
                                    cancellationPolicy = cancellationPolicy,
                                    availableDates = availableDates,
                                    importantInstructions = importantInstructions,
                                    status = PackageStatus.DRAFT
                                )
                                tourRepository.createPackage(draft)
                                isSubmitting = false
                                onPackageCreated()
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("save_draft_btn")
                    ) {
                        Text("Save Draft")
                    }

                    Button(
                        onClick = {
                            if (packageName.isBlank() || description.isBlank()) {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Package name and description are required")
                                }
                                return@Button
                            }
                            coroutineScope.launch {
                                isSubmitting = true
                                val newPkg = TourPackage(
                                    operatorId = currentUser?.id ?: "op_verified_001",
                                    operatorName = currentUser?.fullName ?: "Verified Operator",
                                    operatorPhone = currentUser?.phoneNumber ?: "",
                                    isOperatorVerified = currentUser?.isPublicVerifiedOperator ?: true,
                                    title = packageName.trim(),
                                    description = description.trim(),
                                    durationDays = durationDays,
                                    durationNights = durationNights,
                                    durationText = "$durationDays Days / $durationNights Nights",
                                    startingLocation = startingLocation.trim(),
                                    route = route.trim(),
                                    destination = destination.trim(),
                                    maxTourists = maxTourists,
                                    price = pricePerPerson,
                                    pricePerPerson = pricePerPerson,
                                    includedServices = includedServices,
                                    excludedServices = excludedServices,
                                    boatDetails = boatDetails,
                                    foodDetails = foodDetails,
                                    accommodationDetails = accommodationDetails,
                                    guideDetails = guideDetails,
                                    permitInfo = permitInfo,
                                    pickupInfo = pickupInfo,
                                    cancellationPolicy = cancellationPolicy,
                                    availableDates = availableDates,
                                    importantInstructions = importantInstructions,
                                    status = PackageStatus.PENDING_APPROVAL
                                )
                                tourRepository.createPackage(newPkg)
                                isSubmitting = false
                                onPackageCreated()
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("submit_pkg_btn"),
                        enabled = !isSubmitting
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onPrimary)
                        } else {
                            Text("Submit & Auto-Publish")
                        }
                    }
                }
            }
        }
    }
}
