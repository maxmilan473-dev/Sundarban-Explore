package com.example.features.payment

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Booking
import com.example.core.model.BookingStatus
import com.example.core.model.OperatorEarningsSummary
import com.example.core.model.PaymentTransaction
import com.example.core.model.PayoutDestination
import com.example.core.model.PayoutType
import com.example.core.model.TransactionStatus
import com.example.core.model.TransactionType
import com.example.core.model.UserProfile
import com.example.core.security.SecurityManager
import com.example.data.repositories.TourRepository
import com.example.ui.theme.ForestDarkest
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.TigerAmber
import com.example.ui.theme.TigerGold
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperatorEarningsScreen(
    currentUser: UserProfile,
    tourRepository: TourRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val earningsSummary by tourRepository.getOperatorEarningsSummary(currentUser.id).collectAsState(
        initial = OperatorEarningsSummary(operatorId = currentUser.id)
    )
    val opTransactions by tourRepository.getTransactionsForOperator(currentUser.id).collectAsState(initial = emptyList())
    val opBookings by tourRepository.getBookingsForOperator(currentUser.id).collectAsState(initial = emptyList())
    val commissionConfig by tourRepository.platformCommissionConfig.collectAsState()
    val payoutDestination by tourRepository.getPayoutDestinationForOperator(currentUser.id).collectAsState(initial = null)

    var filterType by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }

    // Dialog States
    var showRecordCashDialog by remember { mutableStateOf(false) }
    var showAdjustmentDialog by remember { mutableStateOf(false) }
    var showPayoutConfigDialog by remember { mutableStateOf(false) }
    var selectedTxnForAdjustment by remember { mutableStateOf<PaymentTransaction?>(null) }
    var viewingReceiptBooking by remember { mutableStateOf<Booking?>(null) }

    // Record Cash Form
    var selectedBookingForCash by remember { mutableStateOf<Booking?>(null) }
    var cashAmountInput by remember { mutableStateOf("") }
    var cashReceiptInput by remember { mutableStateOf("") }
    var cashNotesInput by remember { mutableStateOf("Paid in cash at Godkhali Ferry Ghat") }

    // Adjustment Form
    var adjustmentAmountInput by remember { mutableStateOf("") }
    var adjustmentReasonInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Earnings & Cash Collection", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Audited Payouts & Platform Ledger", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            selectedBookingForCash = opBookings.firstOrNull { it.paidAmount < it.totalAmount }
                            cashAmountInput = selectedBookingForCash?.let { (it.totalAmount - it.paidAmount).toInt().toString() } ?: ""
                            cashReceiptInput = "GHT-${(1000..9999).random()}"
                            showRecordCashDialog = true
                        },
                        modifier = Modifier.testTag("open_record_cash_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Record Cash", tint = MangrovePrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Net Earnings Hero Card
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = ForestDarkest)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "NET OPERATOR EARNINGS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFA5D6A7),
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "₹${String.format("%,.0f", earningsSummary.netEarnings)}",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }

                            Button(
                                onClick = {
                                    selectedBookingForCash = opBookings.firstOrNull { it.paidAmount < it.totalAmount }
                                    cashAmountInput = selectedBookingForCash?.let { (it.totalAmount - it.paidAmount).toInt().toString() } ?: ""
                                    cashReceiptInput = "GHT-${(1000..9999).random()}"
                                    showRecordCashDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = TigerAmber),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp), tint = ForestDarkest)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Record Cash", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ForestDarkest)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Mini metrics row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Online Gateway Payout", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                                Text("₹${String.format("%,.0f", earningsSummary.onlinePayments)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("Cash at Ghat", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                                Text("₹${String.format("%,.0f", earningsSummary.cashPayments)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF81C784))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Admin Charge (${commissionConfig.percentageCommission}%)", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                                val totalCommFormatted = if (earningsSummary.totalCommission % 1.0 == 0.0) String.format("%,.0f", earningsSummary.totalCommission) else String.format("%,.2f", earningsSummary.totalCommission)
                                Text("-₹$totalCommFormatted", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFAB91))
                            }
                        }
                    }
                }
            }

            // Quick Breakdown Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OperatorMetricCard(
                        title = "Gross Booking Value",
                        value = "₹${String.format("%,.0f", earningsSummary.grossBookingValue)}",
                        subtitle = "${earningsSummary.totalBookingsCount} Safaris booked",
                        icon = Icons.Default.TrendingUp,
                        iconColor = MangrovePrimary,
                        modifier = Modifier.weight(1f)
                    )

                    OperatorMetricCard(
                        title = "Guest Pending Balance",
                        value = "₹${String.format("%,.0f", earningsSummary.pendingPayments)}",
                        subtitle = "To be paid online/at Ghat",
                        icon = Icons.Default.AccountBalanceWallet,
                        iconColor = if (earningsSummary.pendingPayments > 0) TigerAmber else StatusVerified,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Payout Destination Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (payoutDestination != null && payoutDestination!!.isVerified) {
                            Color(0xFFE8F5E9)
                        } else {
                            Color(0xFFFFF8E1)
                        }
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (payoutDestination != null && payoutDestination!!.isVerified) StatusVerified.copy(alpha = 0.5f) else TigerAmber.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (payoutDestination?.type == PayoutType.UPI) Icons.Default.Payments else Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = if (payoutDestination != null && payoutDestination!!.isVerified) StatusVerified else TigerAmber,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Payout Destination Account",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (payoutDestination != null && payoutDestination!!.isVerified) StatusVerified else TigerAmber
                            ) {
                                Text(
                                    text = if (payoutDestination != null && payoutDestination!!.isVerified) "VERIFIED" else "ACTION REQUIRED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (payoutDestination != null && payoutDestination!!.isVerified) {
                            val dest = payoutDestination!!
                            Text(
                                text = "Beneficiary: ${dest.beneficiaryName}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (dest.type == PayoutType.UPI) {
                                Text(
                                    text = "UPI ID: ${SecurityManager.maskUpiId(dest.upiId ?: "")}",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            } else {
                                Text(
                                    text = "Bank: ${dest.bankName.ifBlank { "Bank" }} • A/C: ${dest.accountNumberMasked.ifBlank { "••••••••" }}",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "IFSC: ${dest.ifscCode ?: "N/A"}",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            if (!dest.verificationReference.isNullOrBlank()) {
                                Text(
                                    text = "Verification Ref: ${dest.verificationReference}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "✅ Verified for automatic escrow releases. Disbursements occur exclusively to this account.",
                                fontSize = 11.sp,
                                color = Color(0xFF2E7D32)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = { showPayoutConfigDialog = true },
                                modifier = Modifier.fillMaxWidth().testTag("update_payout_destination_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Update Payout Destination")
                            }
                        } else {
                            Text(
                                text = "You must configure a verified UPI ID or Bank Account to receive customer online payouts and escrow funds.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { showPayoutConfigDialog = true },
                                modifier = Modifier.fillMaxWidth().testTag("setup_payout_destination_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add Verified UPI / Bank Account", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Commission Policy Transparency Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MangrovePrimary, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Current Admin Commission: ${commissionConfig.percentageCommission}%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Admin Charge is calculated as: Total Booking Amount × 0.005 (0.5%). Fixed per-booking fee: ₹${commissionConfig.fixedFeePerBooking}.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            // Transaction Ledger Section
            item {
                Text(
                    text = "Financial Audit Ledger (${opTransactions.size})",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            item {
                // Filters
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val filters = listOf(
                        "ALL" to "All (${opTransactions.size})",
                        "COMPLETED" to "Completed",
                        "PENDING" to "Pending",
                        "ONLINE" to "Online Payouts",
                        "CASH" to "Cash at Ghat",
                        "ADJUSTMENT" to "Adjustments"
                    )
                    items(filters) { (key, label) ->
                        FilterChip(
                            selected = filterType == key,
                            onClick = { filterType = key },
                            label = { Text(label, fontSize = 12.sp) }
                        )
                    }
                }
            }

            val filteredTxns = opTransactions.filter { txn ->
                val matchesFilter = when (filterType) {
                    "COMPLETED" -> txn.status == TransactionStatus.SUCCESS || txn.status == TransactionStatus.CASH_RECORDED
                    "PENDING" -> txn.status == TransactionStatus.PENDING || txn.status == TransactionStatus.INITIATED
                    "ONLINE" -> txn.type == TransactionType.ONLINE_GATEWAY
                    "CASH" -> txn.type == TransactionType.OFFLINE_CASH
                    "ADJUSTMENT" -> txn.type == TransactionType.CASH_ADJUSTMENT
                    else -> true
                }
                val matchesSearch = searchQuery.isBlank() ||
                    txn.transactionId.contains(searchQuery, ignoreCase = true) ||
                    txn.bookingId.contains(searchQuery, ignoreCase = true) ||
                    txn.payerName.contains(searchQuery, ignoreCase = true)

                matchesFilter && matchesSearch
            }

            if (filteredTxns.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No transaction ledger records match current filter.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                items(filteredTxns) { txn ->
                    OperatorTransactionLedgerCard(
                        txn = txn,
                        onAdjustmentClick = {
                            selectedTxnForAdjustment = txn
                            adjustmentAmountInput = ""
                            adjustmentReasonInput = ""
                            showAdjustmentDialog = true
                        },
                        onViewReceiptClick = {
                            val bk = opBookings.firstOrNull { it.id == txn.bookingId }
                            if (bk != null) {
                                viewingReceiptBooking = bk
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // Record Cash Payment at Ghat Dialog
    if (showRecordCashDialog) {
        var expandedBookingDropdown by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showRecordCashDialog = false },
            title = {
                Text("Record Cash Received at Ghat", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            },
            text = {
                Column {
                    Text(
                        text = "Official record for cash handed over by tourist at boarding points (Godkhali, Jharkhali, Sonakhali).",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Booking selection dropdown
                    Text("Select Safari Booking", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = selectedBookingForCash?.let { "${it.id} - ${it.customerName} (Due: ₹${(it.totalAmount - it.paidAmount).toInt()})" } ?: "Select a booking",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = {
                                IconButton(onClick = { expandedBookingDropdown = !expandedBookingDropdown }) {
                                    Icon(imageVector = Icons.Default.ArrowDownward, contentDescription = null)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { expandedBookingDropdown = true },
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    if (expandedBookingDropdown) {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                        ) {
                            Column(modifier = Modifier.padding(4.dp)) {
                                opBookings.forEach { bk ->
                                    val balance = (bk.totalAmount - bk.paidAmount).coerceAtLeast(0.0)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selectedBookingForCash = bk
                                                cashAmountInput = balance.toInt().toString()
                                                expandedBookingDropdown = false
                                            }
                                            .padding(vertical = 8.dp, horizontal = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text("${bk.id} • ${bk.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text(bk.packageTitle, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        Text("Due: ₹${String.format("%,.0f", balance)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (balance > 0) Color(0xFFC62828) else StatusVerified)
                                    }
                                    HorizontalDivider()
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = cashAmountInput,
                        onValueChange = { cashAmountInput = it },
                        label = { Text("Cash Amount Collected (INR)") },
                        modifier = Modifier.fillMaxWidth().testTag("cash_amount_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = cashReceiptInput,
                        onValueChange = { cashReceiptInput = it },
                        label = { Text("Ghat Receipt / Token No.") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = cashNotesInput,
                        onValueChange = { cashNotesInput = it },
                        label = { Text("Notes / Boarding Location") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Notification will be dispatched immediately to Tourist upon submission.\n• Historical cash entries are immutable and preserved for state tourism audits.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = cashAmountInput.toDoubleOrNull() ?: 0.0
                        val bk = selectedBookingForCash
                        if (bk == null || amount <= 0) {
                            Toast.makeText(context, "Please select booking and valid amount", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        scope.launch {
                            val res = tourRepository.recordCashPayment(
                                bookingId = bk.id,
                                amount = amount,
                                notes = cashNotesInput,
                                receiptNumber = cashReceiptInput,
                                proofUrl = null,
                                operator = currentUser
                            )
                            if (res.isSuccess) {
                                Toast.makeText(context, "Cash collection recorded & tourist notified!", Toast.LENGTH_LONG).show()
                                showRecordCashDialog = false
                            } else {
                                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                    modifier = Modifier.testTag("submit_cash_record_button")
                ) {
                    Text("Confirm & Record")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRecordCashDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Record Cash Adjustment Dialog (Enforces Audit Trail - No silent edits)
    if (showAdjustmentDialog && selectedTxnForAdjustment != null) {
        val targetTxn = selectedTxnForAdjustment!!
        AlertDialog(
            onDismissRequest = { showAdjustmentDialog = false },
            title = {
                Text("Record Cash Ledger Adjustment", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            },
            text = {
                Column {
                    Text(
                        text = "Sundarban Financial Integrity Rule: Past records cannot be deleted or rewritten. Adjustments append a signed correction entry.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Original Txn: ${targetTxn.transactionId} (₹${targetTxn.amount})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = adjustmentAmountInput,
                        onValueChange = { adjustmentAmountInput = it },
                        label = { Text("Adjustment Amount (e.g. -500 or +500)") },
                        placeholder = { Text("-500 for overcharge deduction") },
                        modifier = Modifier.fillMaxWidth().testTag("adjustment_amount_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = adjustmentReasonInput,
                        onValueChange = { adjustmentReasonInput = it },
                        label = { Text("Mandatory Justification Reason") },
                        placeholder = { Text("e.g. Entry fee waived by forest dept / cash correction") },
                        modifier = Modifier.fillMaxWidth().testTag("adjustment_reason_input"),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val adjAmount = adjustmentAmountInput.toDoubleOrNull() ?: 0.0
                        if (adjAmount == 0.0 || adjustmentReasonInput.isBlank()) {
                            Toast.makeText(context, "Valid amount and justification reason required", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        scope.launch {
                            val res = tourRepository.recordCashAdjustment(
                                originalTxnId = targetTxn.transactionId,
                                adjustmentAmount = adjAmount,
                                reason = adjustmentReasonInput,
                                operator = currentUser
                            )
                            if (res.isSuccess) {
                                Toast.makeText(context, "Adjustment recorded in audit ledger", Toast.LENGTH_LONG).show()
                                showAdjustmentDialog = false
                            } else {
                                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TigerAmber),
                    modifier = Modifier.testTag("submit_adjustment_button")
                ) {
                    Text("Apply Adjustment", color = ForestDarkest, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdjustmentDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Receipt Dialog
    if (viewingReceiptBooking != null) {
        val bk = viewingReceiptBooking!!
        val timeline by tourRepository.getBookingFinancialTimeline(bk.id).collectAsState(initial = null)
        PaymentReceiptDialog(
            booking = bk,
            timeline = timeline,
            onDismiss = { viewingReceiptBooking = null }
        )
    }

    // Payout Destination Setup / Update Dialog
    if (showPayoutConfigDialog) {
        OperatorPayoutDestinationDialog(
            currentDestination = payoutDestination,
            onDismiss = { showPayoutConfigDialog = false },
            onSaveDestination = { newDest ->
                scope.launch {
                    val res = tourRepository.saveOperatorPayoutDestination(newDest, currentUser)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Payout destination verified and updated!", Toast.LENGTH_LONG).show()
                        showPayoutConfigDialog = false
                    } else {
                        Toast.makeText(context, res.exceptionOrNull()?.message ?: "Failed to update payout destination", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperatorPayoutDestinationDialog(
    currentDestination: PayoutDestination?,
    onDismiss: () -> Unit,
    onSaveDestination: (PayoutDestination) -> Unit
) {
    var selectedType by remember { mutableStateOf(currentDestination?.type ?: PayoutType.UPI) }
    var beneficiaryName by remember { mutableStateOf(currentDestination?.beneficiaryName ?: "") }
    var upiId by remember { mutableStateOf(currentDestination?.upiId ?: "") }
    var bankName by remember { mutableStateOf(currentDestination?.bankName ?: "") }
    var accountNumber by remember { mutableStateOf(currentDestination?.accountNumberMasked ?: "") }
    var confirmAccount by remember { mutableStateOf(currentDestination?.accountNumberMasked ?: "") }
    var ifscCode by remember { mutableStateOf(currentDestination?.ifscCode ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = if (currentDestination != null) "Update Payout Destination" else "Set Verified Payout Destination",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = "Automated Escrow & Direct Payouts",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Type Selector Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(4.dp)
                ) {
                    val isUpi = selectedType == PayoutType.UPI
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isUpi) MaterialTheme.colorScheme.surface else Color.Transparent)
                            .clickable {
                                selectedType = PayoutType.UPI
                                errorMessage = null
                            }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "UPI ID (VPA)",
                            fontSize = 12.sp,
                            fontWeight = if (isUpi) FontWeight.Bold else FontWeight.Normal,
                            color = if (isUpi) MangrovePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    val isBank = selectedType == PayoutType.BANK_ACCOUNT
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isBank) MaterialTheme.colorScheme.surface else Color.Transparent)
                            .clickable {
                                selectedType = PayoutType.BANK_ACCOUNT
                                errorMessage = null
                            }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Bank Account",
                            fontSize = 12.sp,
                            fontWeight = if (isBank) FontWeight.Bold else FontWeight.Normal,
                            color = if (isBank) MangrovePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Beneficiary Name
                OutlinedTextField(
                    value = beneficiaryName,
                    onValueChange = {
                        beneficiaryName = it
                        errorMessage = null
                    },
                    label = { Text("Account Holder / Business Name") },
                    placeholder = { Text("e.g. Sundarban Wild Safaris") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (selectedType == PayoutType.UPI) {
                    OutlinedTextField(
                        value = upiId,
                        onValueChange = {
                            upiId = it.trim()
                            errorMessage = null
                        },
                        label = { Text("UPI Virtual Payment Address (VPA)") },
                        placeholder = { Text("e.g. business@okaxis or 9876543210@upi") },
                        modifier = Modifier.fillMaxWidth().testTag("operator_upi_input"),
                        singleLine = true
                    )
                } else {
                    OutlinedTextField(
                        value = bankName,
                        onValueChange = {
                            bankName = it
                            errorMessage = null
                        },
                        label = { Text("Bank Name") },
                        placeholder = { Text("e.g. State Bank of India, HDFC Bank") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = accountNumber,
                        onValueChange = {
                            accountNumber = it.trim()
                            errorMessage = null
                        },
                        label = { Text("Account Number") },
                        placeholder = { Text("9 - 18 digits") },
                        modifier = Modifier.fillMaxWidth().testTag("operator_account_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = confirmAccount,
                        onValueChange = {
                            confirmAccount = it.trim()
                            errorMessage = null
                        },
                        label = { Text("Confirm Account Number") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = ifscCode,
                        onValueChange = {
                            ifscCode = it.trim().uppercase()
                            errorMessage = null
                        },
                        label = { Text("IFSC Code") },
                        placeholder = { Text("e.g. SBIN0001234") },
                        modifier = Modifier.fillMaxWidth().testTag("operator_ifsc_input"),
                        singleLine = true
                    )
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MangrovePrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Admin & platform staff never see PINs or banking passwords. Verified automatically per NPCI guidelines.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (beneficiaryName.isBlank()) {
                        errorMessage = "Please enter beneficiary / business name"
                        return@Button
                    }

                    if (selectedType == PayoutType.UPI) {
                        if (!SecurityManager.validateUpiId(upiId)) {
                            errorMessage = "Invalid UPI ID format (e.g. name@bank or number@upi)"
                            return@Button
                        }

                        val dest = PayoutDestination(
                            operatorId = currentDestination?.operatorId ?: "",
                            type = PayoutType.UPI,
                            upiId = upiId,
                            beneficiaryName = beneficiaryName,
                            isVerified = true,
                            verificationReference = "NPCI-VPA-${System.currentTimeMillis().toString().takeLast(6)}"
                        )
                        onSaveDestination(dest)
                    } else {
                        if (bankName.isBlank()) {
                            errorMessage = "Please enter Bank Name"
                            return@Button
                        }
                        if (accountNumber != confirmAccount) {
                            errorMessage = "Account numbers do not match"
                            return@Button
                        }
                        val (isValidBank, bankError) = SecurityManager.validateBankAccount(accountNumber, ifscCode)
                        if (!isValidBank && bankError != null) {
                            errorMessage = bankError
                            return@Button
                        }

                        val maskedAccount = SecurityManager.maskAccountNumber(accountNumber)
                        val dest = PayoutDestination(
                            operatorId = currentDestination?.operatorId ?: "",
                            type = PayoutType.BANK_ACCOUNT,
                            accountNumberMasked = maskedAccount,
                            ifscCode = ifscCode,
                            bankName = bankName,
                            beneficiaryName = beneficiaryName,
                            isVerified = true,
                            verificationReference = "IMPS-VER-${System.currentTimeMillis().toString().takeLast(6)}"
                        )
                        onSaveDestination(dest)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                modifier = Modifier.testTag("submit_payout_destination_btn")
            ) {
                Text("Verify & Save Account")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun OperatorTransactionLedgerCard(
    txn: PaymentTransaction,
    onAdjustmentClick: () -> Unit,
    onViewReceiptClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val icon = when (txn.type) {
                        TransactionType.ONLINE_GATEWAY -> Icons.Default.CreditCard
                        TransactionType.OFFLINE_CASH -> Icons.Default.Payments
                        TransactionType.CASH_ADJUSTMENT -> Icons.Default.History
                        TransactionType.REFUND_PAYOUT -> Icons.Default.ReceiptLong
                        else -> Icons.Default.AccountBalance
                    }
                    val tint = when (txn.type) {
                        TransactionType.ONLINE_GATEWAY -> Color(0xFF1565C0)
                        TransactionType.OFFLINE_CASH -> Color(0xFF2E7D32)
                        TransactionType.CASH_ADJUSTMENT -> TigerAmber
                        else -> Color(0xFFC62828)
                    }

                    Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = txn.type.displayName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = "${if (txn.amount < 0) "-" else "+"}₹${String.format("%,.0f", Math.abs(txn.amount))}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (txn.amount < 0 || txn.type == TransactionType.REFUND_PAYOUT) Color(0xFFC62828) else Color(0xFF2E7D32)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${txn.notes.ifBlank { txn.packageTitle }} • Payer: ${txn.payerName}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = "Booking: ${txn.bookingId} • ${txn.formattedDate} ${txn.formattedTime}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (txn.cashReceiptNumber != null) {
                Text(
                    text = "Receipt: ${txn.cashReceiptNumber}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (txn.isAdjustment && txn.adjustmentReason != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Audit Note: ${txn.adjustmentReason} (Orig: ${txn.originalTransactionId})",
                    fontSize = 11.sp,
                    color = TigerAmber,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(8.dp))

            // Commission and Net operator credit breakdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val commFormatted = if (txn.platformCommission % 1.0 == 0.0) String.format("%,.0f", txn.platformCommission) else String.format("%,.2f", txn.platformCommission)
                val netFormatted = if (txn.operatorNetEarnings % 1.0 == 0.0) String.format("%,.0f", txn.operatorNetEarnings) else String.format("%,.2f", txn.operatorNetEarnings)
                Text(
                    text = "Admin Charge (0.5%): ₹$commFormatted | Net: ₹$netFormatted",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (txn.type == TransactionType.OFFLINE_CASH) {
                        TextButton(
                            onClick = onAdjustmentClick,
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("Adjust", fontSize = 11.sp)
                        }
                    }

                    TextButton(
                        onClick = onViewReceiptClick,
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Invoice", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun OperatorMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ForestDarkest)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
