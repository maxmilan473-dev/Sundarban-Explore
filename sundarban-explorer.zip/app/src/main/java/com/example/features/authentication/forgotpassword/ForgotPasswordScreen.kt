package com.example.features.authentication.forgotpassword

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.localization.LocalAppStrings
import com.example.core.model.UserRole
import com.example.core.security.SecurityManager
import com.example.core.ui.components.SundarbanButton
import com.example.core.ui.components.SundarbanTextField
import com.example.data.repositories.AuthRepository
import com.example.data.repositories.AuthResult
import com.example.ui.theme.MangroveMedium
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedBg
import com.example.ui.theme.TigerAmber
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class RecoveryStep {
    ENTER_IDENTIFIER,
    VERIFY_OTP,
    SET_NEW_PASSWORD,
    SUCCESS
}

data class ForgotPasswordState(
    val step: RecoveryStep = RecoveryStep.ENTER_IDENTIFIER,
    val identifier: String = "",
    val detectedType: String = "",
    val maskedDestination: String = "",
    val otpInput: String = "",
    val simulatedOtp: String = "",
    val countdownSeconds: Int = 0,
    val newPassword: String = "",
    val confirmPassword: String = "",
    val identifierError: String? = null,
    val otpError: String? = null,
    val newPasswordError: String? = null,
    val confirmPasswordError: String? = null,
    val errorMessage: String? = null,
    val isLoading: Boolean = false,
    val matchedRole: UserRole? = null
)

class ForgotPasswordViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _state = MutableStateFlow(ForgotPasswordState())
    val state: StateFlow<ForgotPasswordState> = _state.asStateFlow()

    private var countdownJob: Job? = null

    fun onIdentifierChanged(value: String) {
        val clean = value.trim()
        val detected = when {
            clean.contains("@") -> "Email"
            clean.any { it.isDigit() } -> "Mobile"
            else -> ""
        }
        _state.update {
            it.copy(
                identifier = value,
                detectedType = detected,
                identifierError = null,
                errorMessage = null
            )
        }
    }

    fun onOtpInputChanged(value: String) {
        _state.update { it.copy(otpInput = value, otpError = null, errorMessage = null) }
    }

    fun onNewPasswordChanged(value: String) {
        _state.update { it.copy(newPassword = value, newPasswordError = null, errorMessage = null) }
    }

    fun onConfirmPasswordChanged(value: String) {
        _state.update { it.copy(confirmPassword = value, confirmPasswordError = null, errorMessage = null) }
    }

    fun checkAccountAndSendOtp() {
        val input = _state.value.identifier.trim()
        if (input.isBlank()) {
            _state.update { it.copy(identifierError = "Please enter your registered email or mobile number") }
            return
        }

        val isEmail = input.contains("@")
        if (isEmail && !SecurityManager.isValidEmail(input)) {
            _state.update { it.copy(identifierError = "Please enter a valid email address") }
            return
        }
        if (!isEmail && !SecurityManager.isValidPhoneNumber(input)) {
            _state.update { it.copy(identifierError = "Please enter a valid 10-digit mobile number") }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, errorMessage = null, identifierError = null) }

            // Step 1: Validate account exists before sending OTP
            when (val accountCheck = authRepository.checkAccountExistsForRecovery(input)) {
                is AuthResult.Error -> {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = accountCheck.message,
                            identifierError = accountCheck.message
                        )
                    }
                    return@launch
                }
                is AuthResult.Success -> {
                    val role = accountCheck.data
                    // Step 2: Account exists, send OTP to verified channel
                    when (val otpResult = authRepository.sendPasswordResetOtp(input)) {
                        is AuthResult.Success -> {
                            val masked = if (isEmail) {
                                SecurityManager.maskEmail(input)
                            } else {
                                SecurityManager.maskPhoneNumber(input)
                            }
                            _state.update {
                                it.copy(
                                    isLoading = false,
                                    step = RecoveryStep.VERIFY_OTP,
                                    matchedRole = role,
                                    maskedDestination = masked,
                                    simulatedOtp = otpResult.data,
                                    otpInput = otpResult.data, // For ease of testing in emulator
                                    errorMessage = null
                                )
                            }
                            startCooldownTimer()
                        }
                        is AuthResult.Error -> {
                            _state.update { it.copy(isLoading = false, errorMessage = otpResult.message) }
                        }
                        is AuthResult.Loading -> {}
                    }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun resendOtp() {
        if (_state.value.countdownSeconds > 0) return
        val input = _state.value.identifier.trim()
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, errorMessage = null) }
            when (val otpResult = authRepository.sendPasswordResetOtp(input)) {
                is AuthResult.Success -> {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            simulatedOtp = otpResult.data,
                            otpInput = otpResult.data,
                            errorMessage = null
                        )
                    }
                    startCooldownTimer()
                }
                is AuthResult.Error -> {
                    _state.update { it.copy(isLoading = false, errorMessage = otpResult.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    private fun startCooldownTimer() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            for (sec in SecurityManager.OTP_COOLDOWN_SECONDS downTo 0) {
                _state.update { it.copy(countdownSeconds = sec) }
                delay(1000L)
            }
        }
    }

    fun verifyOtp() {
        val input = _state.value.identifier.trim()
        val code = _state.value.otpInput.trim()
        if (code.isBlank()) {
            _state.update { it.copy(otpError = "Please enter the 6-digit OTP") }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, errorMessage = null, otpError = null) }
            when (val result = authRepository.verifyPasswordResetOtp(input, code)) {
                is AuthResult.Success -> {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            step = RecoveryStep.SET_NEW_PASSWORD,
                            errorMessage = null
                        )
                    }
                }
                is AuthResult.Error -> {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = result.message,
                            otpError = result.message
                        )
                    }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun submitNewPassword() {
        val input = _state.value.identifier.trim()
        val code = _state.value.otpInput.trim()
        val newPass = _state.value.newPassword.trim()
        val confirmPass = _state.value.confirmPassword.trim()

        val passVal = SecurityManager.validatePassword(newPass)
        if (!passVal.isValid) {
            _state.update { it.copy(newPasswordError = passVal.errorMessage) }
            return
        }
        if (newPass != confirmPass) {
            _state.update { it.copy(confirmPasswordError = "Passwords do not match") }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = authRepository.resetPasswordWithOtp(input, code, newPass)) {
                is AuthResult.Success -> {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            step = RecoveryStep.SUCCESS,
                            errorMessage = null
                        )
                    }
                }
                is AuthResult.Error -> {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = res.message
                        )
                    }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun backToIdentifierStep() {
        countdownJob?.cancel()
        _state.update {
            it.copy(
                step = RecoveryStep.ENTER_IDENTIFIER,
                otpInput = "",
                simulatedOtp = "",
                errorMessage = null,
                otpError = null
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForgotPasswordScreen(
    viewModel: ForgotPasswordViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val state by viewModel.state.collectAsState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("forgot_password_screen"),
        topBar = {
            TopAppBar(
                title = { Text(strings.forgotPassword, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("forgot_password_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MangrovePrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Step Progress Indicator
            RecoveryStepIndicator(currentStep = state.step)

            Spacer(modifier = Modifier.height(20.dp))

            // Error Banner
            if (state.errorMessage != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .testTag("forgot_password_error"),
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = state.errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            when (state.step) {
                RecoveryStep.ENTER_IDENTIFIER -> {
                    EnterIdentifierContent(
                        state = state,
                        onIdentifierChanged = { viewModel.onIdentifierChanged(it) },
                        onSubmit = { viewModel.checkAccountAndSendOtp() },
                        onNavigateBack = onNavigateBack
                    )
                }
                RecoveryStep.VERIFY_OTP -> {
                    VerifyOtpContent(
                        state = state,
                        onOtpChanged = { viewModel.onOtpInputChanged(it) },
                        onVerify = { viewModel.verifyOtp() },
                        onResend = { viewModel.resendOtp() },
                        onChangeIdentifier = { viewModel.backToIdentifierStep() }
                    )
                }
                RecoveryStep.SET_NEW_PASSWORD -> {
                    SetNewPasswordContent(
                        state = state,
                        onNewPasswordChanged = { viewModel.onNewPasswordChanged(it) },
                        onConfirmPasswordChanged = { viewModel.onConfirmPasswordChanged(it) },
                        onSubmit = { viewModel.submitNewPassword() }
                    )
                }
                RecoveryStep.SUCCESS -> {
                    RecoverySuccessContent(onBackToLogin = onNavigateBack)
                }
            }
        }
    }
}

@Composable
private fun RecoveryStepIndicator(currentStep: RecoveryStep) {
    val steps = listOf("Find Account", "Verify OTP", "New Password")
    val activeIndex = when (currentStep) {
        RecoveryStep.ENTER_IDENTIFIER -> 0
        RecoveryStep.VERIFY_OTP -> 1
        RecoveryStep.SET_NEW_PASSWORD -> 2
        RecoveryStep.SUCCESS -> 3
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, label ->
            val isCurrent = index == activeIndex
            val isDone = index < activeIndex

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    modifier = Modifier.size(32.dp),
                    shape = CircleShape,
                    color = when {
                        isDone -> StatusVerified
                        isCurrent -> MangrovePrimary
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isDone) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Done",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        } else {
                            Text(
                                text = "${index + 1}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 11.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    color = if (isCurrent) MangrovePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (index < steps.size - 1) {
                Box(
                    modifier = Modifier
                        .height(2.dp)
                        .weight(1f)
                        .padding(horizontal = 6.dp)
                        .background(
                            if (index < activeIndex) StatusVerified else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }
    }
}

@Composable
private fun EnterIdentifierContent(
    state: ForgotPasswordState,
    onIdentifierChanged: (String) -> Unit,
    onSubmit: () -> Unit,
    onNavigateBack: () -> Unit
) {
    Surface(
        modifier = Modifier.size(68.dp),
        shape = CircleShape,
        color = MangrovePrimary.copy(alpha = 0.1f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Default.LockReset,
                contentDescription = null,
                tint = MangrovePrimary,
                modifier = Modifier.size(34.dp)
            )
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
        text = "Recover Your Account",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
        text = "Enter your registered Email Address or 10-digit Mobile Number. We'll verify your account exists before sending a secure OTP.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        lineHeight = 20.sp
    )

    Spacer(modifier = Modifier.height(24.dp))

    SundarbanTextField(
        value = state.identifier,
        onValueChange = onIdentifierChanged,
        label = "Registered Email or Mobile Number",
        placeholder = "e.g. priya@example.com or 9820011223",
        leadingIcon = if (state.detectedType == "Mobile") Icons.Default.Phone else Icons.Default.Email,
        errorMessage = state.identifierError,
        testTag = "recovery_identifier_input"
    )

    Spacer(modifier = Modifier.height(20.dp))

    SundarbanButton(
        text = "Find Account & Send OTP",
        onClick = onSubmit,
        isLoading = state.isLoading,
        testTag = "recovery_find_account_btn"
    )

    Spacer(modifier = Modifier.height(16.dp))

    TextButton(
        onClick = onNavigateBack,
        modifier = Modifier.testTag("recovery_cancel_btn")
    ) {
        Text("Back to Login", color = MangroveMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun VerifyOtpContent(
    state: ForgotPasswordState,
    onOtpChanged: (String) -> Unit,
    onVerify: () -> Unit,
    onResend: () -> Unit,
    onChangeIdentifier: () -> Unit
) {
    Surface(
        modifier = Modifier.size(68.dp),
        shape = CircleShape,
        color = TigerAmber.copy(alpha = 0.12f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Default.Pin,
                contentDescription = null,
                tint = TigerAmber,
                modifier = Modifier.size(34.dp)
            )
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
        text = "Enter Verification Code",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
        text = "A 6-digit OTP has been sent to your verified destination:",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(4.dp))

    Text(
        text = state.maskedDestination,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MangrovePrimary
    )

    Spacer(modifier = Modifier.height(14.dp))

    // Demo/Simulator Notice
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MangrovePrimary.copy(alpha = 0.08f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = MangrovePrimary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "SMS / Email OTP: ${state.simulatedOtp.ifBlank { "123456" }}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MangrovePrimary
                )
                Text(
                    text = "Code valid for 5 minutes. Master bypass: 123456",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    Spacer(modifier = Modifier.height(18.dp))

    SundarbanTextField(
        value = state.otpInput,
        onValueChange = onOtpChanged,
        label = "Enter 6-Digit OTP",
        placeholder = "e.g. ${state.simulatedOtp.ifBlank { "123456" }}",
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        errorMessage = state.otpError,
        testTag = "recovery_otp_input"
    )

    Spacer(modifier = Modifier.height(16.dp))

    SundarbanButton(
        text = "Verify OTP & Continue",
        onClick = onVerify,
        isLoading = state.isLoading,
        testTag = "recovery_verify_otp_btn"
    )

    Spacer(modifier = Modifier.height(12.dp))

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onChangeIdentifier,
            modifier = Modifier.testTag("recovery_change_destination_btn")
        ) {
            Text("Change Email / Mobile", style = MaterialTheme.typography.bodySmall, color = MangroveMedium)
        }

        TextButton(
            onClick = onResend,
            enabled = state.countdownSeconds == 0 && !state.isLoading,
            modifier = Modifier.testTag("recovery_resend_otp_btn")
        ) {
            Text(
                text = if (state.countdownSeconds > 0) "Resend in ${state.countdownSeconds}s" else "Resend OTP",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = if (state.countdownSeconds > 0) Color.Gray else TigerAmber
            )
        }
    }
}

@Composable
private fun SetNewPasswordContent(
    state: ForgotPasswordState,
    onNewPasswordChanged: (String) -> Unit,
    onConfirmPasswordChanged: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Surface(
        modifier = Modifier.size(68.dp),
        shape = CircleShape,
        color = StatusVerified.copy(alpha = 0.12f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Default.Key,
                contentDescription = null,
                tint = StatusVerified,
                modifier = Modifier.size(34.dp)
            )
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
        text = "Set New Password",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
        text = "Create a secure password with at least 6 characters including letters and numbers.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(20.dp))

    SundarbanTextField(
        value = state.newPassword,
        onValueChange = onNewPasswordChanged,
        label = "New Password",
        leadingIcon = Icons.Default.Lock,
        isPassword = true,
        errorMessage = state.newPasswordError,
        testTag = "recovery_new_password_input"
    )

    Spacer(modifier = Modifier.height(14.dp))

    SundarbanTextField(
        value = state.confirmPassword,
        onValueChange = onConfirmPasswordChanged,
        label = "Confirm New Password",
        leadingIcon = Icons.Default.Lock,
        isPassword = true,
        errorMessage = state.confirmPasswordError,
        testTag = "recovery_confirm_password_input"
    )

    Spacer(modifier = Modifier.height(20.dp))

    SundarbanButton(
        text = "Save New Password",
        onClick = onSubmit,
        isLoading = state.isLoading,
        testTag = "recovery_save_password_btn"
    )
}

@Composable
private fun RecoverySuccessContent(onBackToLogin: () -> Unit) {
    Surface(
        modifier = Modifier.size(80.dp),
        shape = CircleShape,
        color = StatusVerifiedBg
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = StatusVerified,
                modifier = Modifier.size(48.dp)
            )
        }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
        text = "Password Reset Successful!",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = StatusVerified,
        textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(10.dp))

    Text(
        text = "Your password has been securely updated and all temporary verification codes have been invalidated. You can now sign in with your new credentials.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        lineHeight = 22.sp
    )

    Spacer(modifier = Modifier.height(28.dp))

    SundarbanButton(
        text = "Log In With New Password",
        onClick = onBackToLogin,
        testTag = "recovery_success_login_btn"
    )
}
