package com.example.features.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.*
import com.example.core.ui.components.SundarbanTextField
import com.example.core.ui.components.VerificationStatusBadge
import com.example.data.repositories.AuthRepository
import com.example.data.repositories.ContentRepository
import com.example.data.repositories.TourRepository
import com.example.features.booking.AdminEmergencyDecisionDialog
import com.example.features.booking.CancellationDiscussionDialog
import com.example.core.util.CancellationTimeHelper
import com.example.features.complaints.ComplaintDetailDialog
import com.example.features.disputes.DisputeDetailDialog
import com.example.features.reviews.ReviewItemCard
import com.example.ui.theme.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AdminViewModel(
    val authRepository: AuthRepository,
    val tourRepository: TourRepository,
    private val contentRepository: ContentRepository
) : ViewModel() {

    val currentUser = authRepository.currentUser
    val allUsers: StateFlow<List<UserProfile>> = authRepository.getAllUsersForAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBookings: StateFlow<List<Booking>> = tourRepository.getAllBookingsForAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val complaints: StateFlow<List<Complaint>> = tourRepository.getComplaints()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val disputes: StateFlow<List<DisputeRecord>> = tourRepository.getDisputes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val riskCases: StateFlow<List<FlaggedRiskCase>> = tourRepository.getFlaggedRiskCases()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminAlerts: StateFlow<List<AdminAlert>> = tourRepository.getAdminAlerts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntry>> = tourRepository.getAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReviews: StateFlow<List<Review>> = tourRepository.getAllReviewsForAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val articles: StateFlow<List<SundarbanArticle>> = contentRepository.getArticles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val videos: StateFlow<List<VideoResource>> = contentRepository.getVideos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val books: StateFlow<List<BookResource>> = contentRepository.getBooks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<PaymentTransaction>> = tourRepository.getAllTransactionsForAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val refunds: StateFlow<List<RefundRecord>> = tourRepository.getRefundRecords()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val packages: StateFlow<List<TourPackage>> = tourRepository.getAllPackagesForAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun moderatePackageStatus(packageId: String, status: PackageStatus, rejectionReason: String? = null) {
        viewModelScope.launch {
            tourRepository.moderatePackageStatus(packageId, status, rejectionReason)
        }
    }

    fun updateOperatorStatus(operatorUid: String, status: OperatorStatus) {
        viewModelScope.launch {
            authRepository.updateOperatorVerificationStatus(operatorUid, status)
        }
    }

    // Account Moderation (Part 5)
    fun warnUser(userId: String, reason: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            authRepository.warnUser(userId, reason, admin)
        }
    }

    fun restrictUser(userId: String, reason: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            authRepository.restrictUser(userId, reason, admin)
        }
    }

    fun suspendUser(userId: String, durationDays: Int, reason: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            authRepository.suspendUser(userId, durationDays, reason, admin)
        }
    }

    fun banUser(userId: String, reason: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            authRepository.banUser(userId, reason, admin)
        }
    }

    fun unbanUser(userId: String, reason: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            authRepository.unbanUser(userId, reason, admin)
        }
    }

    // Complaint actions
    fun investigateComplaint(complaintId: String, notes: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.investigateComplaint(complaintId, notes, admin)
        }
    }

    fun requestComplaintEvidence(complaintId: String, instructions: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.requestComplaintEvidence(complaintId, instructions, admin)
        }
    }

    fun resolveComplaint(complaintId: String, resolution: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.resolveComplaint(complaintId, resolution, admin)
        }
    }

    fun rejectComplaint(complaintId: String, rejectionReason: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.rejectComplaint(complaintId, rejectionReason, admin)
        }
    }

    // Dispute actions
    fun sendDisputeMessage(disputeId: String, message: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.addDisputeMessage(disputeId, message, null, admin)
        }
    }

    fun requestDisputeEvidence(disputeId: String, instructions: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.requestDisputeEvidence(disputeId, instructions, admin)
        }
    }

    fun adjudicateDispute(
        disputeId: String,
        decision: DisputeStatus,
        refundType: RefundDecisionType,
        amount: Double,
        summary: String
    ) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.adjudicateDispute(disputeId, decision, refundType, amount, summary, admin)
        }
    }

    // Risk actions
    fun reviewRiskCase(caseId: String, notes: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.reviewRiskCase(caseId, notes, admin)
        }
    }

    fun acknowledgeAlert(alertId: String) {
        viewModelScope.launch {
            tourRepository.acknowledgeAlert(alertId)
        }
    }

    // Review moderation
    fun moderateReview(reviewId: String, isModerated: Boolean, reason: String?) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.moderateReview(reviewId, isModerated, reason, admin)
        }
    }

    // Article actions
    fun addArticle(article: SundarbanArticle) {
        viewModelScope.launch {
            contentRepository.addArticle(article)
        }
    }

    fun toggleArticlePublish(articleId: String) {
        viewModelScope.launch {
            contentRepository.toggleArticlePublish(articleId)
        }
    }

    fun archiveArticle(articleId: String) {
        viewModelScope.launch {
            contentRepository.archiveArticle(articleId)
        }
    }

    fun deleteArticle(articleId: String) {
        viewModelScope.launch {
            contentRepository.deleteArticle(articleId)
        }
    }

    // Video actions
    fun addVideo(video: VideoResource) {
        viewModelScope.launch {
            contentRepository.addVideo(video)
        }
    }

    fun toggleVideoPublish(videoId: String) {
        viewModelScope.launch {
            contentRepository.toggleVideoPublish(videoId)
        }
    }

    fun deleteVideo(videoId: String) {
        viewModelScope.launch {
            contentRepository.deleteVideo(videoId)
        }
    }

    // Book actions
    fun addBook(book: BookResource) {
        viewModelScope.launch {
            contentRepository.addBook(book)
        }
    }

    fun deleteBook(bookId: String) {
        viewModelScope.launch {
            contentRepository.deleteBook(bookId)
        }
    }

    // Admin Creation (Super Admin Only)
    fun createAdmin(
        fullName: String,
        email: String,
        phoneNumber: String,
        password: String,
        designation: String,
        isSuperAdmin: Boolean,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val current = currentUser.value
            if (current == null || current.role != UserRole.ADMIN || !current.isSuperAdmin) {
                onResult(false, "Permission Denied: Admin creation is Super Admin Only (✅).")
                return@launch
            }

            val result = authRepository.createAdminUser(
                creatorUser = current,
                fullName = fullName,
                email = email,
                phoneNumber = phoneNumber,
                password = password,
                designation = designation,
                isSuperAdmin = isSuperAdmin
            )

            when (result) {
                is com.example.data.repositories.AuthResult.Success -> {
                    tourRepository.recordAuditLog(
                        AuditLogEntry(
                            id = "AUD_" + UUID.randomUUID().toString().take(8).uppercase(),
                            adminId = current.id,
                            adminName = current.fullName,
                            action = AuditAction.ADMIN_PROVISIONED,
                            targetId = result.data.id,
                            targetType = "ADMIN_USER",
                            previousValue = "NONE",
                            newValue = "${result.data.fullName} (${result.data.email}, ${if (isSuperAdmin) "Super Admin" else "Admin"})",
                            reason = "Super Admin internal provisioning with designation: $designation",
                            ipOrDevice = "Secure Terminal • Super Admin Console",
                            timestamp = System.currentTimeMillis()
                        )
                    )
                    onResult(true, "New Admin account (${result.data.fullName}) provisioned successfully!")
                }
                is com.example.data.repositories.AuthResult.Error -> {
                    onResult(false, result.message)
                }
                com.example.data.repositories.AuthResult.Loading -> Unit
            }
        }
    }

    // Emergency Cancellation & Directorate Adjudication
    fun adminResolveEmergencyCancellation(
        bookingId: String,
        decisionType: AdminDecisionType,
        refundDecision: AdminRefundDecision,
        refundAmount: Double = 0.0,
        rescheduledDate: String? = null,
        newOperatorId: String? = null,
        reason: String,
        onComplete: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            val admin = currentUser.value
            if (admin == null || admin.role != UserRole.ADMIN) {
                onComplete(false, "Permission Denied: Must be authenticated as Admin.")
                return@launch
            }
            val result = tourRepository.adminResolveEmergencyCancellation(
                bookingId = bookingId,
                admin = admin,
                decisionType = decisionType,
                refundDecision = refundDecision,
                refundAmount = refundAmount,
                rescheduledDate = rescheduledDate,
                newOperatorId = newOperatorId,
                reason = reason
            )
            result.fold(
                onSuccess = { onComplete(true, "Directorate decision issued successfully.") },
                onFailure = { onComplete(false, it.message ?: "Failed to process emergency ruling.") }
            )
        }
    }

    fun sendCancellationDiscussionMessage(bookingId: String, message: String) {
        viewModelScope.launch {
            val admin = currentUser.value ?: return@launch
            tourRepository.addCancellationDiscussionMessage(bookingId, admin, message)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: AdminViewModel,
    onNavigateToProfile: () -> Unit,
    onNavigateToTransactions: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val currentAdmin by viewModel.currentUser.collectAsState()
    val users by viewModel.allUsers.collectAsState()
    val bookings by viewModel.allBookings.collectAsState()
    val complaints by viewModel.complaints.collectAsState()
    val disputes by viewModel.disputes.collectAsState()
    val riskCases by viewModel.riskCases.collectAsState()
    val adminAlerts by viewModel.adminAlerts.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val reviews by viewModel.allReviews.collectAsState()
    val articles by viewModel.articles.collectAsState()
    val videos by viewModel.videos.collectAsState()
    val books by viewModel.books.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val refunds by viewModel.refunds.collectAsState()
    val packages by viewModel.packages.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    var operatorStatusFilter by remember { mutableStateOf("All") }

    // Dialog state holders
    var selectedOperatorForReview by remember { mutableStateOf<UserProfile?>(null) }
    var operatorModerationTarget by remember { mutableStateOf<UserProfile?>(null) }
    var unmaskedDocsOperator by remember { mutableStateOf<UserProfile?>(null) }

    var selectedComplaintDetail by remember { mutableStateOf<Complaint?>(null) }
    var selectedDisputeDetail by remember { mutableStateOf<DisputeRecord?>(null) }

    var selectedPackageForReview by remember { mutableStateOf<TourPackage?>(null) }
    var smartVerificationSubTab by remember { mutableIntStateOf(0) } // 0 = Operators, 1 = Packages
    var packageStatusFilter by remember { mutableStateOf("Review Required") }

    var showAiAssistantDialog by remember { mutableStateOf(false) }
    var showAddArticleDialog by remember { mutableStateOf(false) }
    var showAddVideoDialog by remember { mutableStateOf(false) }
    var showAddBookDialog by remember { mutableStateOf(false) }
    var showProvisionAdminDialog by remember { mutableStateOf(false) }
    var adminProvisionFeedback by remember { mutableStateOf<String?>(null) }
    var selectedBookingForAdminEmergencyReview by remember { mutableStateOf<Booking?>(null) }
    var selectedBookingForAdminDiscussion by remember { mutableStateOf<Booking?>(null) }
    var bookingStatusFilter by remember { mutableStateOf("All") }

    val adminUsers = remember(users) { users.filter { it.role == UserRole.ADMIN } }
    val operators = users.filter { it.role == UserRole.OPERATOR }
    val problematicOperators = operators.filter {
        val s = it.operatorDetails?.verificationStatus
        s == OperatorStatus.REQUIRES_ADMIN_REVIEW || (s == OperatorStatus.PENDING_REVIEW && !it.isVerified) || (s == OperatorStatus.PENDING_VERIFICATION && !it.isVerified)
    }
    val problematicPackages = packages.filter {
        it.status == PackageStatus.REQUIRES_ADMIN_REVIEW || (it.status == PackageStatus.PENDING_APPROVAL && !it.isAutoVerified)
    }
    val reviewRequiredCount = problematicOperators.size + problematicPackages.size
    val autoVerifiedCount = operators.count { it.operatorDetails?.verificationStatus == OperatorStatus.AUTOMATICALLY_VERIFIED }
    val openComplaintsCount = complaints.count { it.status == ComplaintStatus.OPEN || it.status == ComplaintStatus.UNDER_REVIEW }
    val activeDisputesCount = disputes.count { it.status == DisputeStatus.OPEN || it.status == DisputeStatus.UNDER_REVIEW || it.status == DisputeStatus.EVIDENCE_REQUESTED }

    // Provision Admin Dialog (Super Admin Only)
    if (showProvisionAdminDialog) {
        ProvisionAdminDialog(
            currentAdmin = currentAdmin,
            viewModel = viewModel,
            onDismiss = { showProvisionAdminDialog = false },
            onSuccess = { msg ->
                adminProvisionFeedback = msg
                selectedTab = 11 // Navigate to Admins & Governance tab
            }
        )
    }

    // AI Assistant Dialog
    if (showAiAssistantDialog && currentAdmin != null) {
        AdminAiAssistantDialog(
            tourRepository = viewModel.tourRepository,
            authRepository = viewModel.authRepository,
            currentAdmin = currentAdmin!!,
            onDismiss = { showAiAssistantDialog = false }
        )
    }

    // Emergency Directorate Review & Decision Dialog
    if (selectedBookingForAdminEmergencyReview != null && currentAdmin != null) {
        AdminEmergencyDecisionDialog(
            booking = selectedBookingForAdminEmergencyReview!!,
            adminUser = currentAdmin!!,
            allOperators = operators,
            onDismiss = { selectedBookingForAdminEmergencyReview = null },
            onSubmitDecision = { decisionType, refundDecision, refundAmount, rescheduledDate, newOperatorId, reason ->
                val targetId = selectedBookingForAdminEmergencyReview!!.id
                viewModel.adminResolveEmergencyCancellation(
                    bookingId = targetId,
                    decisionType = decisionType,
                    refundDecision = refundDecision,
                    refundAmount = refundAmount,
                    rescheduledDate = rescheduledDate,
                    newOperatorId = newOperatorId,
                    reason = reason
                ) { _, _ ->
                    selectedBookingForAdminEmergencyReview = null
                }
            }
        )
    }

    // Cancellation Discussion Dialog for Admin Mediation
    if (selectedBookingForAdminDiscussion != null && currentAdmin != null) {
        val target = selectedBookingForAdminDiscussion!!
        CancellationDiscussionDialog(
            booking = target,
            currentUser = currentAdmin!!,
            onDismiss = { selectedBookingForAdminDiscussion = null },
            onSendMessage = { msg ->
                viewModel.sendCancellationDiscussionMessage(target.id, msg)
            },
            onAcceptCancellation = {
                // Admin can open emergency decision dialog for ruling
                selectedBookingForAdminEmergencyReview = target
                selectedBookingForAdminDiscussion = null
            },
            onRejectCancellation = { note ->
                viewModel.adminResolveEmergencyCancellation(
                    bookingId = target.id,
                    decisionType = AdminDecisionType.REJECT_CANCELLATION,
                    refundDecision = AdminRefundDecision.NO_REFUND,
                    reason = note
                ) { _, _ ->
                    selectedBookingForAdminDiscussion = null
                }
            }
        )
    }

    // Flagged Package Verification & Moderation Dialog
    if (selectedPackageForReview != null) {
        val pkg = selectedPackageForReview!!
        var pkgRejectionReason by remember { mutableStateOf("") }
        var showPkgRejectionInput by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { selectedPackageForReview = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.DirectionsBoat, contentDescription = null, tint = TigerAmber)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Package Moderation Decision", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(text = pkg.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text(text = "Operator: ${pkg.operatorName} • Phone: ${pkg.operatorPhone}", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Status: ${pkg.status.displayName}", fontWeight = FontWeight.Bold, color = TigerAmber, style = MaterialTheme.typography.labelMedium)
                            Text(text = "Automated Risk Score: ${pkg.riskScore} / 100", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            if (pkg.riskSignals.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "Detected Problem Signals:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                pkg.riskSignals.forEach { signal ->
                                    Text(text = "• $signal", style = MaterialTheme.typography.labelSmall, color = StatusRejected)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Price Per Person: ₹${pkg.pricePerPerson.toInt()} • Max Guests: ${pkg.maxTourists}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Starting Location: ${pkg.startingLocation}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Route / Itinerary: ${pkg.route}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Permits & Safety: ${pkg.permitInfo} | ${pkg.boatDetails}", style = MaterialTheme.typography.bodySmall)

                    if (showPkgRejectionInput) {
                        Spacer(modifier = Modifier.height(10.dp))
                        SundarbanTextField(
                            value = pkgRejectionReason,
                            onValueChange = { pkgRejectionReason = it },
                            label = "Rejection / Correction Reason",
                            placeholder = "e.g. Invalid price or missing Forest Directorate permit"
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.moderatePackageStatus(pkg.id, PackageStatus.PUBLISHED)
                        selectedPackageForReview = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusVerified),
                    modifier = Modifier.testTag("admin_approve_pkg_btn")
                ) {
                    Text("Approve & Publish")
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!showPkgRejectionInput) {
                        OutlinedButton(
                            onClick = { showPkgRejectionInput = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejected)
                        ) {
                            Text("Reject")
                        }
                    } else {
                        Button(
                            onClick = {
                                viewModel.moderatePackageStatus(pkg.id, PackageStatus.REJECTED, pkgRejectionReason.ifBlank { "Policy violation / safety issue" })
                                selectedPackageForReview = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusRejected)
                        ) {
                            Text("Confirm Reject")
                        }
                    }
                    TextButton(onClick = { selectedPackageForReview = null }) {
                        Text("Close")
                    }
                }
            }
        )
    }

    // Operator Verification Review & Decision Dialog
    if (selectedOperatorForReview != null) {
        val op = selectedOperatorForReview!!
        val details = op.operatorDetails
        var rejectionReason by remember { mutableStateOf("") }
        var showRejectionInput by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { selectedOperatorForReview = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = StatusAdmin)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Operator Verification Decision", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(text = "Agency / Lead: ${op.fullName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text(text = "Email: ${op.email} • Phone: ${op.phoneNumber}", style = MaterialTheme.typography.bodySmall)

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Status: ${details?.verificationStatus?.displayName ?: "Pending"}", fontWeight = FontWeight.Bold, color = TigerAmber, style = MaterialTheme.typography.labelMedium)
                            Text(text = "Account Status: ${op.accountStatus.displayName}", fontWeight = FontWeight.Bold, color = if (op.accountStatus == AccountStatus.ACTIVE) StatusVerified else StatusRejected, style = MaterialTheme.typography.labelSmall)
                            Text(text = "Automated Risk Score: ${details?.riskScore ?: 0} / 100", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            if (!details?.riskSignals.isNullOrEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "Risk Signals:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                details?.riskSignals?.forEach { signal ->
                                    Text(text = "• $signal", style = MaterialTheme.typography.labelSmall, color = StatusRejected)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Operating Area: ${details?.operatingArea.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Masked Gov ID: ${details?.govIdNumber.orEmpty()}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                    Text(text = "Tourism Trade License: ${details?.licenseNumber.orEmpty()}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                    Text(text = "Marine Boat Reg: ${details?.boatRegistrationNumber.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Bank / UPI ID: ${details?.bankUpiId.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Experience: ${details?.yearsOfExperience ?: 1} years", style = MaterialTheme.typography.bodySmall)

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { unmaskedDocsOperator = op },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View Unmasked Sensitive Documents (Audit Logged)")
                    }

                    if (showRejectionInput) {
                        Spacer(modifier = Modifier.height(10.dp))
                        SundarbanTextField(
                            value = rejectionReason,
                            onValueChange = { rejectionReason = it },
                            label = "Reason for Rejection / Info Request",
                            placeholder = "e.g. Invalid trade license or boat certificate unreadable"
                        )
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            viewModel.updateOperatorStatus(op.uid, OperatorStatus.VERIFIED)
                            selectedOperatorForReview = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusVerified),
                        modifier = Modifier.testTag("admin_approve_operator_btn")
                    ) {
                        Text("Approve / Verify")
                    }

                    Button(
                        onClick = {
                            viewModel.updateOperatorStatus(op.uid, OperatorStatus.INFORMATION_REQUIRED)
                            selectedOperatorForReview = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TigerAmber)
                    ) {
                        Text("Request Info")
                    }
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!showRejectionInput) {
                        OutlinedButton(
                            onClick = { showRejectionInput = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejected)
                        ) {
                            Text("Reject / Action")
                        }
                    } else {
                        Button(
                            onClick = {
                                viewModel.updateOperatorStatus(op.uid, OperatorStatus.REJECTED)
                                selectedOperatorForReview = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusRejected)
                        ) {
                            Text("Confirm Reject")
                        }
                    }

                    TextButton(onClick = { selectedOperatorForReview = null }) {
                        Text("Close")
                    }
                }
            }
        )
    }

    // Unmasked Sensitive Documents Viewer Dialog (Admin Only)
    if (unmaskedDocsOperator != null && currentAdmin != null) {
        val op = unmaskedDocsOperator!!
        val details = op.operatorDetails

        AlertDialog(
            onDismissRequest = { unmaskedDocsOperator = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = StatusAdmin)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Unmasked Verification Dossier", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusAdmin.copy(alpha = 0.1f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "🔒 Highly Confidential: Access to unmasked documents is recorded in the immutable audit log.",
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusAdmin,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Operator: ${op.fullName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Unmasked Gov ID (${details?.govIdType ?: "Gov ID"}): ${details?.govIdNumber.orEmpty().ifBlank { "Not Set" }}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    Text(text = "Trade License Number: ${details?.licenseNumber.orEmpty().ifBlank { "Not Set" }}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    Text(text = "Marine Boat Reg: ${details?.boatRegistrationNumber.orEmpty().ifBlank { "Not Set" }}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    Text(text = "Financial Settlement Account / UPI: ${details?.bankUpiId.orEmpty().ifBlank { "Not Set" }}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    
                    if (!details?.documents.isNullOrEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "Attached Documents (${details!!.documents.size}):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        details.documents.forEach { doc ->
                            Text(text = "• ${doc.docType}: ${doc.rawDocumentNumber.ifBlank { doc.documentNumberMasked }} (${doc.title})", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { unmaskedDocsOperator = null }) {
                    Text("Close Dossier")
                }
            }
        )
    }

    // Account Moderation Dialog (Warn, Restrict, Suspend, Ban, Unban)
    if (operatorModerationTarget != null) {
        val target = operatorModerationTarget!!
        var moderationAction by remember { mutableStateOf("WARN") }
        var reasonText by remember { mutableStateOf("") }
        var suspendDurationDays by remember { mutableStateOf("7") }

        AlertDialog(
            onDismissRequest = { operatorModerationTarget = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = StatusRejected)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Account Moderation: ${target.fullName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = "Current Status: ${target.accountStatus.displayName} (Warnings: ${target.warningCount})", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)

                    // Action Selector
                    listOf(
                        "WARN" to "Issue Formal Warning",
                        "RESTRICT" to "Restrict Account (Limits Package Publishing)",
                        "SUSPEND" to "Suspend Account (Temporary Hold)",
                        "BAN" to "Permanent Ban (Prohibits all operations)",
                        "UNBAN" to "Restore / Lift Restrictions"
                    ).forEach { (key, label) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = moderationAction == key, onClick = { moderationAction = key })
                            Text(text = label, style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    if (moderationAction == "SUSPEND") {
                        SundarbanTextField(
                            value = suspendDurationDays,
                            onValueChange = { suspendDurationDays = it },
                            label = "Suspension Duration (Days)",
                            placeholder = "7"
                        )
                    }

                    SundarbanTextField(
                        value = reasonText,
                        onValueChange = { reasonText = it },
                        label = "Official Reason & Audit Ground",
                        placeholder = "State the safety violation, payment dispute, or compliance issue..."
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val reason = reasonText.ifBlank { "Administrative policy enforcement." }
                        when (moderationAction) {
                            "WARN" -> viewModel.warnUser(target.id, reason)
                            "RESTRICT" -> viewModel.restrictUser(target.id, reason)
                            "SUSPEND" -> viewModel.suspendUser(target.id, suspendDurationDays.toIntOrNull() ?: 7, reason)
                            "BAN" -> viewModel.banUser(target.id, reason)
                            "UNBAN" -> viewModel.unbanUser(target.id, reason)
                        }
                        operatorModerationTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (moderationAction == "UNBAN") StatusVerified else StatusRejected
                    )
                ) {
                    Text("Apply Moderation Action")
                }
            },
            dismissButton = {
                TextButton(onClick = { operatorModerationTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Complaint Detail Dialog
    if (selectedComplaintDetail != null && currentAdmin != null) {
        ComplaintDetailDialog(
            complaint = selectedComplaintDetail!!,
            currentUser = currentAdmin!!,
            onDismiss = { selectedComplaintDetail = null },
            onInvestigate = { notes ->
                viewModel.investigateComplaint(selectedComplaintDetail!!.id, notes)
            },
            onRequestEvidence = { instructions ->
                viewModel.requestComplaintEvidence(selectedComplaintDetail!!.id, instructions)
            },
            onResolve = { resolution ->
                viewModel.resolveComplaint(selectedComplaintDetail!!.id, resolution)
            },
            onReject = { reason ->
                viewModel.rejectComplaint(selectedComplaintDetail!!.id, reason)
            }
        )
    }

    // Dispute Detail Dialog
    if (selectedDisputeDetail != null && currentAdmin != null) {
        DisputeDetailDialog(
            dispute = selectedDisputeDetail!!,
            currentUser = currentAdmin!!,
            onDismiss = { selectedDisputeDetail = null },
            onSendMessage = { msg ->
                viewModel.sendDisputeMessage(selectedDisputeDetail!!.disputeId, msg)
            },
            onRequestEvidence = { instructions ->
                viewModel.requestDisputeEvidence(selectedDisputeDetail!!.disputeId, instructions)
            },
            onAdjudicate = { ruling, refundType, amt, summary ->
                viewModel.adjudicateDispute(selectedDisputeDetail!!.disputeId, ruling, refundType, amt, summary)
            }
        )
    }

    // Add Article Dialog
    if (showAddArticleDialog) {
        var titleEn by remember { mutableStateOf("") }
        var titleBn by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("About Sundarbans") }
        var summaryEn by remember { mutableStateOf("") }
        var contentEn by remember { mutableStateOf("") }
        var readTime by remember { mutableStateOf("5") }

        AlertDialog(
            onDismissRequest = { showAddArticleDialog = false },
            title = { Text("Add Sundarban Knowledge Article", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    SundarbanTextField(value = titleEn, onValueChange = { titleEn = it }, label = "Article Title (English)")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = titleBn, onValueChange = { titleBn = it }, label = "Article Title (Bengali)")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = category, onValueChange = { category = it }, label = "Category (e.g. Wildlife, Safety)")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = summaryEn, onValueChange = { summaryEn = it }, label = "Summary", minLines = 2)
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = contentEn, onValueChange = { contentEn = it }, label = "Full Content", minLines = 4)
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = readTime, onValueChange = { readTime = it }, label = "Read Time (minutes)")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (titleEn.isNotBlank() && contentEn.isNotBlank()) {
                            viewModel.addArticle(
                                SundarbanArticle(
                                    id = "art_" + UUID.randomUUID().toString().take(6),
                                    titleEn = titleEn.trim(),
                                    titleBn = titleBn.trim(),
                                    category = category.trim(),
                                    summaryEn = summaryEn.trim(),
                                    contentEn = contentEn.trim(),
                                    readTimeMinutes = readTime.toIntOrNull() ?: 5,
                                    isPublished = true
                                )
                            )
                            showAddArticleDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary)
                ) {
                    Text("Publish Article")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddArticleDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add Video Dialog
    if (showAddVideoDialog) {
        var vTitle by remember { mutableStateOf("") }
        var vCategory by remember { mutableStateOf("Travel Guide") }
        var vDesc by remember { mutableStateOf("") }
        var vUrl by remember { mutableStateOf("") }
        var vDuration by remember { mutableStateOf("10:00") }

        AlertDialog(
            onDismissRequest = { showAddVideoDialog = false },
            title = { Text("Add Educational Video Resource", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    SundarbanTextField(value = vTitle, onValueChange = { vTitle = it }, label = "Video Title")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = vCategory, onValueChange = { vCategory = it }, label = "Category")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = vUrl, onValueChange = { vUrl = it }, label = "Video URL / ID")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = vDuration, onValueChange = { vDuration = it }, label = "Duration (e.g. 12:30)")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = vDesc, onValueChange = { vDesc = it }, label = "Description", minLines = 3)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (vTitle.isNotBlank()) {
                            viewModel.addVideo(
                                VideoResource(
                                    id = "vid_" + UUID.randomUUID().toString().take(6),
                                    titleEn = vTitle.trim(),
                                    category = vCategory.trim(),
                                    descriptionEn = vDesc.trim(),
                                    videoUrl = vUrl.trim(),
                                    durationText = vDuration.trim(),
                                    isPublished = true
                                )
                            )
                            showAddVideoDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TigerAmber)
                ) {
                    Text("Add Video")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddVideoDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add Book Dialog
    if (showAddBookDialog) {
        var bTitle by remember { mutableStateOf("") }
        var bAuthor by remember { mutableStateOf("Sundarban Forest Directorate") }
        var bCategory by remember { mutableStateOf("Field Guide") }
        var bDesc by remember { mutableStateOf("") }
        var bPages by remember { mutableStateOf("120") }

        AlertDialog(
            onDismissRequest = { showAddBookDialog = false },
            title = { Text("Add Digital Field Guide", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    SundarbanTextField(value = bTitle, onValueChange = { bTitle = it }, label = "Book / Guide Title")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = bAuthor, onValueChange = { bAuthor = it }, label = "Author / Organization")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = bCategory, onValueChange = { bCategory = it }, label = "Category")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = bDesc, onValueChange = { bDesc = it }, label = "Description", minLines = 2)
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = bPages, onValueChange = { bPages = it }, label = "Page Count")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (bTitle.isNotBlank()) {
                            viewModel.addBook(
                                BookResource(
                                    id = "bk_" + UUID.randomUUID().toString().take(6),
                                    titleEn = bTitle.trim(),
                                    author = bAuthor.trim(),
                                    category = bCategory.trim(),
                                    descriptionEn = bDesc.trim(),
                                    pageCount = bPages.toIntOrNull() ?: 100,
                                    chapters = listOf(
                                        BookChapter("ch_1", 1, "Chapter 1: Field Guide Foundations", bDesc.trim())
                                    )
                                )
                            )
                            showAddBookDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestDarkest)
                ) {
                    Text("Add Book")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddBookDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("admin_dashboard_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "Admin Governance Console", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text(text = "Sundarban Explorer Anti-Fraud & Trust Hub", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            if (currentAdmin?.isSuperAdmin == true) {
                                showProvisionAdminDialog = true
                            } else {
                                selectedTab = 11
                            }
                        },
                        modifier = Modifier.testTag("admin_provision_nav_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin Provisioning",
                            tint = if (currentAdmin?.isSuperAdmin == true) TigerGold else Color.White
                        )
                    }
                    IconButton(
                        onClick = { showAiAssistantDialog = true },
                        modifier = Modifier.testTag("admin_ai_assistant_btn")
                    ) {
                        Icon(imageVector = Icons.Default.SmartToy, contentDescription = "AI Intelligence Assistant", tint = TigerGold)
                    }
                    IconButton(onClick = onNavigateToTransactions, modifier = Modifier.testTag("admin_transactions_button")) {
                        Icon(imageVector = Icons.Default.AccountBalance, contentDescription = "Platform Transactions & Commission Hub", tint = Color.White)
                    }
                    IconButton(onClick = onNavigateToProfile, modifier = Modifier.testTag("admin_profile_button")) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = "Profile", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = StatusAdmin,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            when (selectedTab) {
                5 -> {
                    FloatingActionButton(
                        onClick = { showAddArticleDialog = true },
                        containerColor = MangrovePrimary,
                        contentColor = Color.White
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Article")
                    }
                }
                6 -> {
                    FloatingActionButton(
                        onClick = { showAddVideoDialog = true },
                        containerColor = TigerAmber,
                        contentColor = Color.White
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Video")
                    }
                }
                7 -> {
                    FloatingActionButton(
                        onClick = { showAddBookDialog = true },
                        containerColor = ForestDarkest,
                        contentColor = Color.White
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Book")
                    }
                }
                11 -> {
                    if (currentAdmin?.isSuperAdmin == true) {
                        ExtendedFloatingActionButton(
                            onClick = { showProvisionAdminDialog = true },
                            containerColor = Color(0xFF673AB7),
                            contentColor = Color.White,
                            icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                            text = { Text("Provision Admin ID", fontWeight = FontWeight.Bold) },
                            modifier = Modifier.testTag("admin_fab_provision")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Admin Provisioning Feedback Banner
            if (adminProvisionFeedback != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFE8F5E9),
                    border = BorderStroke(1.dp, Color(0xFF81C784))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = MangrovePrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = adminProvisionFeedback ?: "", style = MaterialTheme.typography.bodySmall, color = Color(0xFF1B5E20), fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { adminProvisionFeedback = null }, modifier = Modifier.size(24.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Dismiss", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Stats Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AdminStatCard(title = "Review Req", value = "$reviewRequiredCount", icon = Icons.Default.HourglassTop, color = TigerAmber, modifier = Modifier.weight(1f))
                AdminStatCard(title = "Complaints", value = "$openComplaintsCount", icon = Icons.Default.ReportProblem, color = StatusRejected, modifier = Modifier.weight(1f))
                AdminStatCard(title = "Disputes", value = "$activeDisputesCount", icon = Icons.Default.Gavel, color = StatusAdmin, modifier = Modifier.weight(1f))
                AdminStatCard(title = "Bookings", value = "${bookings.size}", icon = Icons.Default.DirectionsBoat, color = MangrovePrimary, modifier = Modifier.weight(1f))
            }

            // Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = StatusAdmin
                    )
                }
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Smart Verification (${operators.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Complaints (${complaints.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Disputes (${disputes.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Risk & Alerts (${riskCases.size + adminAlerts.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("Audit Ledger (${auditLogs.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 5, onClick = { selectedTab = 5 }, text = { Text("Articles (${articles.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 6, onClick = { selectedTab = 6 }, text = { Text("Videos (${videos.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 7, onClick = { selectedTab = 7 }, text = { Text("Books (${books.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 8, onClick = { selectedTab = 8 }, text = { Text("Bookings (${bookings.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 9, onClick = { selectedTab = 9 }, text = { Text("Reviews (${reviews.size})", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 10, onClick = { selectedTab = 10 }, text = { Text("Analytics & KPIs", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 11, onClick = { selectedTab = 11 }, text = { Text("Admins & Governance (${adminUsers.size})", fontWeight = FontWeight.Bold) }, modifier = Modifier.testTag("admin_tab_governance"))
            }

            when (selectedTab) {
                0 -> {
                    // Smart Operator & Package Verification Queue & Moderation
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Sub-Tab Switcher between Operators & Tour Packages
                        PrimaryTabRow(
                            selectedTabIndex = smartVerificationSubTab,
                            containerColor = MaterialTheme.colorScheme.surface,
                            divider = {}
                        ) {
                            Tab(
                                selected = smartVerificationSubTab == 0,
                                onClick = { smartVerificationSubTab = 0 },
                                text = {
                                    Text(
                                        text = "Operators (${problematicOperators.size} Req / ${operators.size})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            )
                            Tab(
                                selected = smartVerificationSubTab == 1,
                                onClick = { smartVerificationSubTab = 1 },
                                text = {
                                    Text(
                                        text = "Packages (${problematicPackages.size} Req / ${packages.size})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            )
                        }

                        // Auto-Verification Engine status notice
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = StatusAdmin.copy(alpha = 0.08f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = StatusAdmin,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Auto-Verification: Compliant submissions publish automatically. Only flagged issues appear in Review Required.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusAdmin
                                )
                            }
                        }

                        if (smartVerificationSubTab == 0) {
                            // OPERATORS SUB-TAB
                            val statusOptions = listOf(
                                "Review Required (${problematicOperators.size})",
                                "Auto-Verified (${autoVerifiedCount})",
                                "All (${operators.size})",
                                "Verified",
                                "Info Required",
                                "Rejected",
                                "Suspended"
                            )
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(statusOptions) { opt ->
                                    val isSelected = operatorStatusFilter == opt || (operatorStatusFilter == "Review Required" && opt.startsWith("Review Required")) || (operatorStatusFilter == "Auto-Verified" && opt.startsWith("Auto-Verified")) || (operatorStatusFilter == "All" && opt.startsWith("All"))
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            operatorStatusFilter = when {
                                                opt.startsWith("Review Required") -> "Review Required"
                                                opt.startsWith("Auto-Verified") -> "Auto-Verified"
                                                opt.startsWith("All") -> "All"
                                                else -> opt
                                            }
                                        },
                                        label = { Text(opt, fontSize = 12.sp) }
                                    )
                                }
                            }

                            val filteredOperators = operators.filter { op ->
                                val status = op.operatorDetails?.verificationStatus
                                when (operatorStatusFilter) {
                                    "All" -> true
                                    "Review Required" -> status == OperatorStatus.REQUIRES_ADMIN_REVIEW || (status == OperatorStatus.PENDING_REVIEW && !op.isVerified) || (status == OperatorStatus.PENDING_VERIFICATION && !op.isVerified)
                                    "Auto-Verified" -> status == OperatorStatus.AUTOMATICALLY_VERIFIED
                                    "Verified" -> status == OperatorStatus.VERIFIED || status == OperatorStatus.AUTOMATICALLY_VERIFIED
                                    "Info Required" -> status == OperatorStatus.INFORMATION_REQUIRED
                                    "Rejected" -> status == OperatorStatus.REJECTED
                                    "Suspended" -> status == OperatorStatus.SUSPENDED || op.accountStatus == AccountStatus.SUSPENDED || op.accountStatus == AccountStatus.BANNED
                                    else -> true
                                }
                            }

                            if (filteredOperators.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = StatusVerified,
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "No operators requiring review in this category.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Verified and clean submissions are published automatically.",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(filteredOperators) { op ->
                                        val status = op.operatorDetails?.verificationStatus ?: OperatorStatus.PENDING_VERIFICATION
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("admin_op_card_${op.uid}"),
                                            shape = RoundedCornerShape(14.dp),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                        ) {
                                            Column(modifier = Modifier.padding(16.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(text = op.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                                    VerificationStatusBadge(status = status)
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(text = "Area: ${op.operatorDetails?.operatingArea.orEmpty()} • License: ${op.operatorDetails?.licenseNumber.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                                                Text(text = "Email: ${op.email} • Phone: ${op.phoneNumber}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = if (op.accountStatus == AccountStatus.ACTIVE) StatusVerifiedBg else StatusRejectedBg
                                                    ) {
                                                        Text(
                                                            text = "Account: ${op.accountStatus.displayName}",
                                                            color = if (op.accountStatus == AccountStatus.ACTIVE) StatusVerified else StatusRejected,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                    if (op.warningCount > 0) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(text = "Warnings: ${op.warningCount}", color = TigerAmber, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                                    }
                                                }

                                                if (op.operatorDetails?.riskSignals?.isNotEmpty() == true) {
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = "Risk Signal: ${op.operatorDetails?.riskSignals?.firstOrNull()}",
                                                        color = StatusRejected,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(10.dp))
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Button(
                                                        onClick = { selectedOperatorForReview = op },
                                                        colors = ButtonDefaults.buttonColors(containerColor = StatusAdmin),
                                                        shape = RoundedCornerShape(8.dp),
                                                        modifier = Modifier.testTag("review_op_btn_${op.uid}")
                                                    ) {
                                                        Text(text = "Inspect & Decision", style = MaterialTheme.typography.labelSmall)
                                                    }

                                                    OutlinedButton(
                                                        onClick = { operatorModerationTarget = op },
                                                        shape = RoundedCornerShape(8.dp),
                                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejected)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(text = "Moderate Account", style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            // PACKAGES SUB-TAB
                            val pkgFilterOptions = listOf(
                                "Review Required (${problematicPackages.size})",
                                "Published / Auto-Verified",
                                "All (${packages.size})",
                                "Drafts"
                            )
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(pkgFilterOptions) { opt ->
                                    val isSelected = packageStatusFilter == opt || (packageStatusFilter == "Review Required" && opt.startsWith("Review Required")) || (packageStatusFilter == "All" && opt.startsWith("All"))
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            packageStatusFilter = when {
                                                opt.startsWith("Review Required") -> "Review Required"
                                                opt.startsWith("All") -> "All"
                                                else -> opt
                                            }
                                        },
                                        label = { Text(opt, fontSize = 12.sp) }
                                    )
                                }
                            }

                            val filteredPackages = packages.filter { pkg ->
                                when (packageStatusFilter) {
                                    "All" -> true
                                    "Review Required" -> pkg.status == PackageStatus.REQUIRES_ADMIN_REVIEW || (pkg.status == PackageStatus.PENDING_APPROVAL && !pkg.isAutoVerified)
                                    "Published / Auto-Verified" -> pkg.status == PackageStatus.PUBLISHED || pkg.status == PackageStatus.AUTO_VERIFIED
                                    "Drafts" -> pkg.status == PackageStatus.DRAFT
                                    else -> true
                                }
                            }

                            if (filteredPackages.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = StatusVerified,
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "No packages requiring review.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Valid packages are automatically published to the tourist catalog.",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(filteredPackages) { pkg ->
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("admin_pkg_card_${pkg.id}"),
                                            shape = RoundedCornerShape(14.dp),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                        ) {
                                            Column(modifier = Modifier.padding(16.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = pkg.title,
                                                        style = MaterialTheme.typography.titleMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = when (pkg.status) {
                                                            PackageStatus.PUBLISHED, PackageStatus.AUTO_VERIFIED -> StatusVerifiedBg
                                                            PackageStatus.REQUIRES_ADMIN_REVIEW -> StatusRejectedBg
                                                            else -> StatusPendingBg
                                                        }
                                                    ) {
                                                        Text(
                                                            text = if (pkg.status == PackageStatus.PUBLISHED && pkg.isAutoVerified) "Auto-Verified" else pkg.status.displayName,
                                                            color = when (pkg.status) {
                                                                PackageStatus.PUBLISHED, PackageStatus.AUTO_VERIFIED -> StatusVerified
                                                                PackageStatus.REQUIRES_ADMIN_REVIEW -> StatusRejected
                                                                else -> TigerAmber
                                                            },
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(text = "Operator: ${pkg.operatorName} • Phone: ${pkg.operatorPhone}", style = MaterialTheme.typography.bodySmall)
                                                Text(text = "Price: ₹${pkg.pricePerPerson.toInt()} • Duration: ${pkg.durationText} • Max Guests: ${pkg.maxTourists}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text(text = "Start: ${pkg.startingLocation} • Route: ${pkg.route}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                                                if (pkg.riskSignals.isNotEmpty()) {
                                                    Spacer(modifier = Modifier.height(6.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = StatusRejectedBg
                                                    ) {
                                                        Column(modifier = Modifier.padding(8.dp)) {
                                                            Text(
                                                                text = "Flagged Signals (Risk Score: ${pkg.riskScore}/100):",
                                                                color = StatusRejected,
                                                                style = MaterialTheme.typography.labelSmall,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                            pkg.riskSignals.forEach { sig ->
                                                                Text(
                                                                    text = "• $sig",
                                                                    color = StatusRejected,
                                                                    style = MaterialTheme.typography.labelSmall
                                                                )
                                                            }
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(10.dp))
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Button(
                                                        onClick = { selectedPackageForReview = pkg },
                                                        colors = ButtonDefaults.buttonColors(containerColor = StatusAdmin),
                                                        shape = RoundedCornerShape(8.dp),
                                                        modifier = Modifier.testTag("review_pkg_btn_${pkg.id}")
                                                    ) {
                                                        Text(text = "Inspect & Decision", style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Complaints System
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(complaints) { cmp ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedComplaintDetail = cmp },
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = cmp.complaintId, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, color = StatusRejected)
                                            Text(text = cmp.category.displayName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = when (cmp.status) {
                                                ComplaintStatus.OPEN -> StatusPendingBg
                                                ComplaintStatus.UNDER_REVIEW -> TigerLight
                                                ComplaintStatus.RESOLVED -> StatusVerifiedBg
                                                ComplaintStatus.REJECTED -> StatusRejectedBg
                                            }
                                        ) {
                                            Text(
                                                text = cmp.status.displayName,
                                                color = when (cmp.status) {
                                                    ComplaintStatus.OPEN -> StatusPending
                                                    ComplaintStatus.UNDER_REVIEW -> TigerAmber
                                                    ComplaintStatus.RESOLVED -> StatusVerified
                                                    ComplaintStatus.REJECTED -> StatusRejected
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "Subject: ${cmp.subject}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                    Text(text = "From: ${cmp.complainantName} → Target: ${cmp.targetName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(text = cmp.description, style = MaterialTheme.typography.bodySmall, maxLines = 2, modifier = Modifier.padding(top = 4.dp))

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = { selectedComplaintDetail = cmp },
                                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Investigate / Adjudicate Complaint", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Disputes System
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(disputes) { disp ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedDisputeDetail = disp },
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = disp.disputeId, fontWeight = FontWeight.Bold, color = StatusAdmin, style = MaterialTheme.typography.labelMedium)
                                            Text(text = "Booking: ${disp.bookingId}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = when (disp.status) {
                                                DisputeStatus.OPEN -> StatusPendingBg
                                                DisputeStatus.UNDER_REVIEW, DisputeStatus.EVIDENCE_REQUESTED -> TigerLight
                                                DisputeStatus.RESOLVED_REFUND_CUSTOMER, DisputeStatus.RESOLVED_RELEASE_OPERATOR, DisputeStatus.RESOLVED_SPLIT -> StatusVerifiedBg
                                                DisputeStatus.DISMISSED -> StatusRejectedBg
                                            }
                                        ) {
                                            Text(
                                                text = disp.status.displayName,
                                                color = when (disp.status) {
                                                    DisputeStatus.OPEN -> StatusPending
                                                    DisputeStatus.UNDER_REVIEW, DisputeStatus.EVIDENCE_REQUESTED -> TigerAmber
                                                    DisputeStatus.RESOLVED_REFUND_CUSTOMER, DisputeStatus.RESOLVED_RELEASE_OPERATOR, DisputeStatus.RESOLVED_SPLIT -> StatusVerified
                                                    DisputeStatus.DISMISSED -> StatusRejected
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "Tourist: ${disp.customerName} • Paid: ₹${disp.paidAmount.toInt()}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                    Text(text = "Operator: ${disp.operatorName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(text = "Reason: ${disp.disputeReason}", style = MaterialTheme.typography.bodySmall, maxLines = 2, modifier = Modifier.padding(top = 4.dp))

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = { selectedDisputeDetail = disp },
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusAdmin),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Open Dispute Dossier & Ruling", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // Risk Telemetry & Alerts
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text(text = "Real-Time Telemetry Alerts", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }

                        if (adminAlerts.isEmpty()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StatusVerifiedBg,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(text = "✅ All telemetry channels nominal. No high-priority alerts.", modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall, color = StatusVerified)
                                }
                            }
                        } else {
                            items(adminAlerts) { alert ->
                                Card(
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = TigerLight
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(text = alert.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            Text(text = alert.type.displayName, fontWeight = FontWeight.Bold, color = TigerAmber, style = MaterialTheme.typography.labelSmall)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = alert.reason, style = MaterialTheme.typography.bodySmall)
                                        if (alert.recommendedInvestigation.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(text = "Investigation: ${alert.recommendedInvestigation}", style = MaterialTheme.typography.labelSmall, color = StatusAdmin)
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        if (!alert.isAcknowledged) {
                                            Button(
                                                onClick = { viewModel.acknowledgeAlert(alert.id) },
                                                colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary)
                                            ) {
                                                Text("Acknowledge Alert", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(text = "Flagged Risk Cases", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }

                        if (riskCases.isEmpty()) {
                            item {
                                Text(text = "No flagged risk cases currently.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        } else {
                            items(riskCases) { rcase ->
                                Card(shape = RoundedCornerShape(10.dp)) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(text = "${rcase.targetName} (${rcase.targetRole.displayName})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        Text(text = "Risk Level: ${rcase.riskLevel.displayName} • Score: ${rcase.riskScore}", color = StatusRejected, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                        rcase.signals.forEach { sig ->
                                            Text(text = "• ${sig.signalType.displayName}: ${sig.description}", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                4 -> {
                    // Immutable Audit Ledger
                    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault()) }
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(auditLogs) { entry ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = StatusAdmin.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = entry.action.name,
                                                color = StatusAdmin,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Text(
                                            text = dateFormat.format(Date(entry.timestamp)),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "Actor: ${entry.adminName} (${entry.adminId})", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                    Text(text = "Target: ${entry.targetType} [${entry.targetId}]", style = MaterialTheme.typography.labelSmall)
                                    if (entry.previousValue != null || entry.newValue != null) {
                                        Text(text = "Transition: ${entry.previousValue ?: "N/A"} → ${entry.newValue ?: "N/A"}", style = MaterialTheme.typography.labelSmall, color = MangrovePrimary)
                                    }
                                    Text(text = "Reason: ${entry.reason}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                5 -> {
                    // Articles Management (Sundarban Information System)
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(articles) { art ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(text = art.titleEn, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                            if (art.titleBn.isNotBlank()) {
                                                Text(text = art.titleBn, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                            }
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (art.isPublished) StatusVerifiedBg else StatusPendingBg
                                        ) {
                                            Text(
                                                text = if (art.isPublished) "Published" else "Draft",
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                color = if (art.isPublished) StatusVerified else StatusPending,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(text = art.summaryEn, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        TextButton(onClick = { viewModel.toggleArticlePublish(art.id) }) {
                                            Text(if (art.isPublished) "Unpublish" else "Publish", fontSize = 12.sp)
                                        }
                                        IconButton(onClick = { viewModel.deleteArticle(art.id) }) {
                                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = StatusRejected)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                6 -> {
                    // Videos Management
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(videos) { vid ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.size(50.dp),
                                        color = TigerLight
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(imageVector = Icons.Default.Videocam, contentDescription = null, tint = TigerAmber)
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = vid.titleEn, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                        Text(text = "${vid.category} • ${vid.durationText}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    }
                                    IconButton(onClick = { viewModel.deleteVideo(vid.id) }) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = StatusRejected)
                                    }
                                }
                            }
                        }
                    }
                }

                7 -> {
                    // Books & Guides Management
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(books) { bk ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.size(50.dp),
                                        color = MangroveContainer
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(imageVector = Icons.Default.MenuBook, contentDescription = null, tint = MangrovePrimary)
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = bk.titleEn, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                        Text(text = "By ${bk.author} • ${bk.chapters.size} Chapters • ${bk.pageCount} pages", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    }
                                    IconButton(onClick = { viewModel.deleteBook(bk.id) }) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = StatusRejected)
                                    }
                                }
                            }
                        }
                    }
                }

                8 -> {
                    // Bookings Management & Emergency Review Center
                    val emergencyCount = bookings.count { it.bookingStatus == BookingStatus.EMERGENCY_REVIEW }
                    val cancelReqCount = bookings.count { it.bookingStatus == BookingStatus.CANCEL_REQUESTED }

                    val filterOptions = listOf(
                        "All" to "All (${bookings.size})",
                        "EMERGENCY" to "🚨 Emergency Review ($emergencyCount)",
                        "CANCEL_REQ" to "Cancel Requested ($cancelReqCount)",
                        "CONFIRMED" to "Confirmed (${bookings.count { it.bookingStatus == BookingStatus.CONFIRMED || it.bookingStatus == BookingStatus.ACCEPTED }})",
                        "RESCHEDULED" to "Rescheduled (${bookings.count { it.bookingStatus == BookingStatus.RESCHEDULED }})",
                        "IN_PROGRESS" to "In Progress (${bookings.count { it.bookingStatus == BookingStatus.TOUR_IN_PROGRESS || it.bookingStatus == BookingStatus.IN_PROGRESS }})",
                        "COMPLETED" to "Completed (${bookings.count { it.bookingStatus == BookingStatus.COMPLETED }})",
                        "CANCELLED" to "Cancelled (${bookings.count { it.bookingStatus == BookingStatus.CANCELLED }})"
                    )

                    val filteredBookings = remember(bookings, bookingStatusFilter) {
                        when (bookingStatusFilter) {
                            "EMERGENCY" -> bookings.filter { it.bookingStatus == BookingStatus.EMERGENCY_REVIEW }
                            "CANCEL_REQ" -> bookings.filter { it.bookingStatus == BookingStatus.CANCEL_REQUESTED }
                            "CONFIRMED" -> bookings.filter { it.bookingStatus == BookingStatus.CONFIRMED || it.bookingStatus == BookingStatus.ACCEPTED }
                            "RESCHEDULED" -> bookings.filter { it.bookingStatus == BookingStatus.RESCHEDULED }
                            "IN_PROGRESS" -> bookings.filter { it.bookingStatus == BookingStatus.TOUR_IN_PROGRESS || it.bookingStatus == BookingStatus.IN_PROGRESS }
                            "COMPLETED" -> bookings.filter { it.bookingStatus == BookingStatus.COMPLETED }
                            "CANCELLED" -> bookings.filter { it.bookingStatus == BookingStatus.CANCELLED }
                            else -> bookings
                        }
                    }

                    Column(modifier = Modifier.fillMaxSize()) {
                        // Filter Bar
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filterOptions) { (key, label) ->
                                val isSelected = bookingStatusFilter == key
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { bookingStatusFilter = key },
                                    label = {
                                        Text(
                                            text = label,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (key == "EMERGENCY" && emergencyCount > 0) Color(0xFFC62828) else Color.Unspecified
                                        )
                                    }
                                )
                            }
                        }

                        // Emergency Alert Banner if any pending
                        if (emergencyCount > 0 && bookingStatusFilter != "EMERGENCY") {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFFFEBEE),
                                border = BorderStroke(1.dp, Color(0xFFEF9A9A))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = Color(0xFFC62828),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "$emergencyCount emergency cancellation request(s) require immediate Directorate review.",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFB71C1C),
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = { bookingStatusFilter = "EMERGENCY" }) {
                                        Text("Review", color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        if (filteredBookings.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.ConfirmationNumber,
                                        contentDescription = null,
                                        modifier = Modifier.size(48.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "No bookings found in this category",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(filteredBookings, key = { it.id }) { b ->
                                    val hoursLeft = remember(b.travelDate, b.tourStartTime) {
                                        CancellationTimeHelper.calculateHoursRemaining(b.travelDate, b.tourStartTime)
                                    }
                                    val timeSummary = remember(hoursLeft) {
                                        CancellationTimeHelper.formatHoursRemaining(hoursLeft)
                                    }

                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        border = BorderStroke(
                                            width = if (b.bookingStatus == BookingStatus.EMERGENCY_REVIEW) 2.dp else 1.dp,
                                            color = when (b.bookingStatus) {
                                                BookingStatus.EMERGENCY_REVIEW -> Color(0xFFC62828)
                                                BookingStatus.CANCEL_REQUESTED -> TigerAmber
                                                BookingStatus.CONFIRMED -> Color(0xFF2E7D32).copy(alpha = 0.4f)
                                                BookingStatus.RESCHEDULED -> Color(0xFF00897B).copy(alpha = 0.4f)
                                                else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                            }
                                        ),
                                        colors = CardDefaults.cardColors(
                                            containerColor = when (b.bookingStatus) {
                                                BookingStatus.EMERGENCY_REVIEW -> Color(0xFFFFF8F8)
                                                BookingStatus.CANCEL_REQUESTED -> Color(0xFFFFFDF5)
                                                else -> MaterialTheme.colorScheme.surface
                                            }
                                        )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            // Top Row: Status badge & Total Amount
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = when (b.bookingStatus) {
                                                        BookingStatus.EMERGENCY_REVIEW -> Color(0xFFC62828)
                                                        BookingStatus.CANCEL_REQUESTED -> TigerAmber
                                                        BookingStatus.CONFIRMED -> Color(0xFF2E7D32)
                                                        BookingStatus.RESCHEDULED -> Color(0xFF00897B)
                                                        BookingStatus.CANCELLED -> Color(0xFF757575)
                                                        BookingStatus.TOUR_IN_PROGRESS, BookingStatus.IN_PROGRESS -> Color(0xFF6A1B9A)
                                                        BookingStatus.COMPLETED -> Color(0xFF00695C)
                                                        else -> MaterialTheme.colorScheme.primary
                                                    }
                                                ) {
                                                    Text(
                                                        text = b.bookingStatus.displayName,
                                                        color = Color.White,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                    )
                                                }

                                                Text(
                                                    text = "₹${b.totalAmount.toInt()}",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = MangrovePrimary
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))

                                            Text(
                                                text = b.packageTitle,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Booking ID: #${b.id.takeLast(8).uppercase()} • Guests: ${b.guestCount}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )

                                            Spacer(modifier = Modifier.height(8.dp))
                                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                                            Spacer(modifier = Modifier.height(8.dp))

                                            // Tourist & Operator details
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "Tourist",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                    Text(
                                                        text = b.customerName,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    if (b.customerPhone.isNotBlank()) {
                                                        Text(
                                                            text = b.customerPhone,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }

                                                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                                    Text(
                                                        text = "Operator",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                    Text(
                                                        text = b.operatorName,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    if (b.operatorPhone.isNotBlank()) {
                                                        Text(
                                                            text = b.operatorPhone,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))

                                            // Schedule and Countdown
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "📅 ${b.travelDate} at ${b.tourStartTime}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Medium
                                                )
                                                Text(
                                                    text = "⏳ $timeSummary",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (hoursLeft in 0.0..5.0) Color(0xFFC62828) else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            // Payment Info
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Paid: ₹${b.paidAmount.toInt()} (${b.paymentStatus.displayName})" +
                                                        if (b.refundResolutionStatus != null) " • Refund: ${b.refundResolutionStatus}" else "",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (b.paidAmount > 0) Color(0xFF2E7D32) else Color(0xFFE65100),
                                                fontWeight = FontWeight.SemiBold
                                            )

                                            // Emergency Review Callout Box & Actions
                                            if (b.bookingStatus == BookingStatus.EMERGENCY_REVIEW) {
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = Color(0xFFFFEBEE),
                                                    border = BorderStroke(1.dp, Color(0xFFEF9A9A))
                                                ) {
                                                    Column(modifier = Modifier.padding(10.dp)) {
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Icon(
                                                                imageVector = Icons.Default.Warning,
                                                                contentDescription = null,
                                                                tint = Color(0xFFC62828),
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Text(
                                                                text = "EMERGENCY CANCELLATION (<5h remaining)",
                                                                style = MaterialTheme.typography.labelMedium,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color(0xFFB71C1C)
                                                            )
                                                        }
                                                        val req = b.activeCancellationRequest
                                                        if (req != null) {
                                                            Spacer(modifier = Modifier.height(4.dp))
                                                            Text(
                                                                text = "Initiated by: ${req.initiatedByName} (${req.initiatedByRole.name})",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                fontWeight = FontWeight.SemiBold
                                                            )
                                                            Text(
                                                                text = "Reason: ${req.reason}",
                                                                style = MaterialTheme.typography.bodySmall,
                                                                color = Color(0xFF5D4037)
                                                            )
                                                            if (!req.detailedExplanation.isNullOrBlank()) {
                                                                Text(
                                                                    text = "Details: ${req.detailedExplanation}",
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    color = Color(0xFF757575)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(10.dp))
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Button(
                                                        onClick = { selectedBookingForAdminEmergencyReview = b },
                                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Gavel,
                                                            contentDescription = null,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text("Issue Ruling")
                                                    }

                                                    OutlinedButton(
                                                        onClick = { selectedBookingForAdminDiscussion = b },
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Chat,
                                                            contentDescription = null,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text("Discussion (${b.activeCancellationRequest?.discussionMessages?.size ?: 0})")
                                                    }
                                                }
                                            }

                                            // Cancel Requested Callout Box & Actions (>5h mutual agreement)
                                            if (b.bookingStatus == BookingStatus.CANCEL_REQUESTED) {
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = Color(0xFFFFF8E1),
                                                    border = BorderStroke(1.dp, Color(0xFFFFE082))
                                                ) {
                                                    Column(modifier = Modifier.padding(10.dp)) {
                                                        Text(
                                                            text = "MUTUAL CANCELLATION REQUEST IN PROGRESS (>5h)",
                                                            style = MaterialTheme.typography.labelMedium,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFE65100)
                                                        )
                                                        val req = b.activeCancellationRequest
                                                        if (req != null) {
                                                            Spacer(modifier = Modifier.height(4.dp))
                                                            Text(
                                                                text = "Requested by: ${req.initiatedByName} (${req.initiatedByRole.name})",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                fontWeight = FontWeight.SemiBold
                                                            )
                                                            Text(
                                                                text = "Reason: ${req.reason}",
                                                                style = MaterialTheme.typography.bodySmall,
                                                                color = Color(0xFF5D4037)
                                                            )
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(10.dp))
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Button(
                                                        onClick = { selectedBookingForAdminDiscussion = b },
                                                        colors = ButtonDefaults.buttonColors(containerColor = TigerAmber),
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Chat,
                                                            contentDescription = null,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text("View & Mediate")
                                                    }

                                                    OutlinedButton(
                                                        onClick = { selectedBookingForAdminEmergencyReview = b },
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Gavel,
                                                            contentDescription = null,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text("Admin Ruling")
                                                    }
                                                }
                                            }

                                            // Rescheduled or Decision History details
                                            if (b.cancellationHistory.isNotEmpty()) {
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = "📜 Prior Actions: ${b.cancellationHistory.size} request record(s) on file",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                9 -> {
                    // Reviews Moderation
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(reviews) { rev ->
                            ReviewItemCard(
                                review = rev,
                                isAdmin = true,
                                onModerate = { isModerated, reason ->
                                    viewModel.moderateReview(rev.id, isModerated, reason)
                                }
                            )
                        }
                    }
                }

                10 -> {
                    // Analytics & Platform Intelligence
                    AdminAnalyticsView(
                        bookings = bookings,
                        transactions = transactions,
                        users = users,
                        complaints = complaints,
                        disputes = disputes,
                        refunds = refunds,
                        packages = packages
                    )
                }

                11 -> {
                    // Admin Creation & Role Governance (Super Admin Only)
                    AdminGovernanceView(
                        currentAdmin = currentAdmin,
                        adminUsers = adminUsers,
                        onProvisionAdminClick = { showProvisionAdminDialog = true }
                    )
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color = StatusAdmin,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = color)
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 9.sp, maxLines = 1)
        }
    }
}

@Composable
fun ProvisionAdminDialog(
    currentAdmin: UserProfile?,
    viewModel: AdminViewModel,
    onDismiss: () -> Unit,
    onSuccess: (String) -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var designation by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("Admin@1234") }
    var isSuperAdminRole by remember { mutableStateOf(false) }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!isLoading) onDismiss() },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF673AB7).copy(alpha = 0.15f),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(text = "👑", fontSize = 18.sp)
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Provision Admin Account",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Super Admin Only Authorization ✅",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF512DA8),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Policy reminder banner
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFEDE7F6),
                    border = BorderStroke(1.dp, Color(0xFFD1C4E9))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = Color(0xFF512DA8),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Public Signup: Admin ID ❌ (Disabled)\nNew Admin IDs can only be provisioned internally by an active Super Admin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF311B92),
                            lineHeight = 16.sp
                        )
                    }
                }

                if (errorMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                SundarbanTextField(
                    value = fullName,
                    onValueChange = { fullName = it; errorMessage = null },
                    label = "Admin Full Name *",
                    placeholder = "e.g., Subhasish Das, IFS",
                    modifier = Modifier.testTag("admin_provision_fullname_input")
                )

                SundarbanTextField(
                    value = email,
                    onValueChange = { email = it; errorMessage = null },
                    label = "Official Government Email *",
                    placeholder = "e.g., s.das.ifs@sundarbanexplorer.gov.in",
                    modifier = Modifier.testTag("admin_provision_email_input")
                )

                SundarbanTextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it; errorMessage = null },
                    label = "Official Mobile Number *",
                    placeholder = "e.g., 9830112233",
                    modifier = Modifier.testTag("admin_provision_phone_input")
                )

                SundarbanTextField(
                    value = designation,
                    onValueChange = { designation = it },
                    label = "Department / Designation",
                    placeholder = "e.g., Wildlife Range Officer (Sunderban Biosphere)",
                    modifier = Modifier.testTag("admin_provision_designation_input")
                )

                SundarbanTextField(
                    value = password,
                    onValueChange = { password = it; errorMessage = null },
                    label = "Initial Temporary Password *",
                    placeholder = "At least 8 chars, 1 uppercase, 1 digit, 1 special",
                    modifier = Modifier.testTag("admin_provision_password_input")
                )

                // Role privilege selection
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isSuperAdminRole) "👑 Super Admin Privilege" else "🛡️ Standard Admin (Staff)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (isSuperAdminRole) Color(0xFF512DA8) else StatusAdmin
                            )
                            Text(
                                text = if (isSuperAdminRole) "Can provision other admins & execute master overrides" else "Standard moderation, dispute resolution & inspection",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isSuperAdminRole,
                            onCheckedChange = { isSuperAdminRole = it },
                            modifier = Modifier.testTag("admin_provision_superadmin_switch")
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fullName.isBlank() || email.isBlank() || phoneNumber.isBlank() || password.isBlank()) {
                        errorMessage = "Please fill in all required fields marked with *"
                        return@Button
                    }
                    isLoading = true
                    viewModel.createAdmin(
                        fullName = fullName,
                        email = email,
                        phoneNumber = phoneNumber,
                        password = password,
                        designation = designation,
                        isSuperAdmin = isSuperAdminRole
                    ) { success, msg ->
                        isLoading = false
                        if (success) {
                            onSuccess(msg)
                            onDismiss()
                        } else {
                            errorMessage = msg
                        }
                    }
                },
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF673AB7)),
                modifier = Modifier.testTag("admin_provision_submit_btn")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text("Provision Admin ID", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                enabled = !isLoading,
                modifier = Modifier.testTag("admin_provision_cancel_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AdminGovernanceView(
    currentAdmin: UserProfile?,
    adminUsers: List<UserProfile>,
    onProvisionAdminClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSuper = currentAdmin?.isSuperAdmin == true

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("admin_governance_view"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. POLICY PROTOCOL CARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("governance_policy_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                border = BorderStroke(1.dp, Color(0xFF673AB7).copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = Color(0xFF673AB7),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Account Creation & Governance Policy",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Badges grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            color = MangrovePrimary.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, MangrovePrimary.copy(alpha = 0.3f))
                        ) {
                            Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Customer ID", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(text = "Public Signup ✅", color = MangrovePrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            color = TigerAmber.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, TigerAmber.copy(alpha = 0.3f))
                        ) {
                            Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Operator ID", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(text = "Application ✅", color = TigerAmber, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1.1f),
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f))
                        ) {
                            Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Admin ID", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(text = "Public Signup ❌", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF673AB7).copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, Color(0xFF673AB7).copy(alpha = 0.25f))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "👑", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Admin Creation: Super Admin Only ✅",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF512DA8)
                                )
                                Text(
                                    text = "To prevent unauthorized administrative access and safeguard biometric/document records, Admin IDs are never publicly registered. Only authorized Super Admins may create and assign new Admin IDs.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. CURRENT ADMINISTRATOR SESSION PRIVILEGE CARD
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSuper) Color(0xFFEDE7F6) else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(1.dp, if (isSuper) Color(0xFF673AB7) else StatusAdmin.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Current Administrator Session",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = currentAdmin?.fullName ?: "Administrator",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = currentAdmin?.designation ?: (if (isSuper) "Master Super Admin" else "Forest Administration Officer"),
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isSuper) Color(0xFF512DA8) else StatusAdmin
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSuper) Color(0xFF673AB7) else StatusAdmin
                        ) {
                            Text(
                                text = if (isSuper) "👑 Super Admin" else "🛡️ Standard Admin",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isSuper) {
                        Button(
                            onClick = onProvisionAdminClick,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("provision_admin_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF673AB7))
                        ) {
                            Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Provision New Admin ID (Super Admin)", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = Color.Gray,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Admin Creation Locked: Super Admin Only (✅). Standard admin accounts cannot provision other admins.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. DIRECTORY OF PROVISIONED ADMINS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Authorized Platform Administrators (${adminUsers.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Active & Vetted",
                    style = MaterialTheme.typography.labelSmall,
                    color = MangrovePrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        items(adminUsers) { admin ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_user_card_${admin.id}"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    1.dp,
                    if (admin.isSuperAdmin) Color(0xFF673AB7).copy(alpha = 0.4f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = if (admin.isSuperAdmin) Color(0xFFEDE7F6) else StatusAdmin.copy(alpha = 0.1f),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = if (admin.isSuperAdmin) "👑" else "🛡️",
                                        fontSize = 20.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = admin.fullName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = admin.designation ?: if (admin.isSuperAdmin) "Super Admin Authority" else "Forest Administration Officer",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (admin.isSuperAdmin) Color(0xFF512DA8) else StatusAdmin,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (admin.isSuperAdmin) Color(0xFF673AB7).copy(alpha = 0.15f) else StatusAdmin.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = if (admin.isSuperAdmin) "Super Admin" else "Admin",
                                color = if (admin.isSuperAdmin) Color(0xFF512DA8) else StatusAdmin,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = admin.email, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = admin.phoneNumber, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Privileges list
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (admin.isSuperAdmin)
                                    "• Master Privileges: Admin Provisioning (Super Admin Only ✅), Verification Overrides, Ledger Governance"
                                else
                                    "• Standard Privileges: Operator Review, Dispute Arbitration, Content Publishing (No Admin Provisioning 🔒)",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
