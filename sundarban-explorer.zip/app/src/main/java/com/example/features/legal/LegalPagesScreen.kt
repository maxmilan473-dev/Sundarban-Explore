package com.example.features.legal

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

enum class LegalDocumentType(
    val title: String,
    val subtitle: String,
    val icon: ImageVector
) {
    PRIVACY_POLICY(
        "Privacy Policy",
        "Data protection, KYC document security & privacy practices",
        Icons.Default.PrivacyTip
    ),
    TERMS_AND_CONDITIONS(
        "Terms & Conditions",
        "Platform usage terms, marketplace role & general governance",
        Icons.Default.Gavel
    ),
    REFUND_POLICY(
        "Refund Policy",
        "Guidelines on partial/full refunds, processing timelines & dispute payouts",
        Icons.Default.CurrencyExchange
    ),
    CANCELLATION_POLICY(
        "Cancellation Policy",
        "Timelines, weather disruption cancellations & operator policies",
        Icons.Default.Cancel
    ),
    CUSTOMER_TERMS(
        "Tourist / Customer Terms",
        "Tourist code of conduct, forest guidelines, safety precautions",
        Icons.Default.Person
    ),
    OPERATOR_TERMS(
        "Tour Operator Terms",
        "Operator obligations, marine safety gear, license verification",
        Icons.Default.DirectionsBoat
    ),
    SAFETY_DISCLAIMER(
        "Safety & Forest Disclaimer",
        "Forest department affiliation disclaimer & wildlife safety notices",
        Icons.Default.Warning
    ),
    CONTENT_COPYRIGHT(
        "Content & Copyright Notice",
        "Educational media licensing, digital books, and intellectual property",
        Icons.Default.MenuBook
    ),
    CONTACT_SUPPORT(
        "Directorate & Support Desk",
        "Direct emergency helpline, compliance officer & support contacts",
        Icons.Default.SupportAgent
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegalPagesScreen(
    initialDoc: LegalDocumentType = LegalDocumentType.PRIVACY_POLICY,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedDoc by remember { mutableStateOf(initialDoc) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("legal_pages_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "Legal, Privacy & Disclaimers", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(text = "Sundarban Explorer Official Compliance", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("legal_back_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ForestDarkest,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Horizontal Selector
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(LegalDocumentType.values()) { doc ->
                    FilterChip(
                        selected = selectedDoc == doc,
                        onClick = { selectedDoc = doc },
                        leadingIcon = {
                            Icon(imageVector = doc.icon, contentDescription = null, modifier = Modifier.size(16.dp))
                        },
                        label = { Text(doc.title, fontSize = 12.sp, fontWeight = if (selectedDoc == doc) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MangrovePrimary,
                            selectedLabelColor = Color.White,
                            selectedLeadingIconColor = Color.White
                        )
                    )
                }
            }

            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Document Content Viewer
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                LegalDocumentContent(documentType = selectedDoc)
            }
        }
    }
}

@Composable
fun LegalDocumentContent(documentType: LegalDocumentType) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MangrovePrimary.copy(alpha = 0.12f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(imageVector = documentType.icon, contentDescription = null, tint = MangrovePrimary)
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = documentType.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(text = documentType.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(16.dp))

            when (documentType) {
                LegalDocumentType.PRIVACY_POLICY -> PrivacyPolicyText()
                LegalDocumentType.TERMS_AND_CONDITIONS -> TermsAndConditionsText()
                LegalDocumentType.REFUND_POLICY -> RefundPolicyText()
                LegalDocumentType.CANCELLATION_POLICY -> CancellationPolicyText()
                LegalDocumentType.CUSTOMER_TERMS -> CustomerTermsText()
                LegalDocumentType.OPERATOR_TERMS -> OperatorTermsText()
                LegalDocumentType.SAFETY_DISCLAIMER -> SafetyDisclaimerText()
                LegalDocumentType.CONTENT_COPYRIGHT -> ContentCopyrightText()
                LegalDocumentType.CONTACT_SUPPORT -> ContactSupportText()
            }
        }
    }
}

@Composable
private fun PrivacyPolicyText() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LegalSectionHeader("1. Information We Collect")
        LegalParagraph("Sundarban Explorer collects minimal necessary data for tour booking, identity verification (KYC), payment processing, and wildlife safety. This includes your name, email, phone number, emergency contacts, and booking details. For tour operators, we collect government IDs (Aadhaar/PAN/Voter ID), boat registrations, and trade licenses strictly for verification purposes.")

        LegalSectionHeader("2. Protection of Identity Documents")
        LegalParagraph("Sensitive government identification numbers and KYC documents provided by operators are masked by default and encrypted. Unmasked verification documents are strictly accessible only by authorized administrators during compliance audits. We never sell, rent, or publicly expose personal identity numbers.")

        LegalSectionHeader("3. Financial & Payment Privacy")
        LegalParagraph("Payment transactions conducted via UPI, Cards, or Net Banking are processed through PCI-DSS compliant payment gateways. Sundarban Explorer does not store full credit card numbers or banking passwords. Transaction records and receipts are retained to satisfy statutory audit and tax compliance obligations.")

        LegalSectionHeader("4. Location & Sensor Data")
        LegalParagraph("If GPS location features are used for emergency SOS or watchtower navigation, location coordinates are processed only in real-time with user permission and are not continuously tracked in the background.")

        LegalSectionHeader("5. Account Deletion & Data Retention")
        LegalParagraph("Users may submit an account deletion request through the Profile Settings. Personal identifiers and profile data will be permanently anonymized or deleted within 30 days, except for historical financial ledgers and completed booking records which must be retained for legal, dispute resolution, and taxation requirements.")
    }
}

@Composable
private fun TermsAndConditionsText() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LegalSectionHeader("1. Independent Marketplace Platform")
        LegalParagraph("Sundarban Explorer operates as an independent discovery, booking facilitation, and information marketplace. The platform connects tourists with verified local tour operators. The platform facilitates booking transparency and dispute resolution but is not itself a travel agency or carrier.")

        LegalSectionHeader("2. Operator Verification Disclaimer")
        LegalParagraph("While Sundarban Explorer rigorously verifies operator trade licenses, boat registrations, and identity credentials, tourists are advised to follow all forest safety rules and conduct their own due diligence.")

        LegalSectionHeader("3. User Conduct & Prohibited Activities")
        LegalParagraph("Users agree not to attempt unauthorized access, reverse-engineering, payment fraud, false complaint submissions, or harassment of operators or fellow tourists. Violations may result in immediate warning, suspension, or permanent banning with administrative audit recording.")
    }
}

@Composable
private fun RefundPolicyText() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LegalSectionHeader("1. Standard Refund Eligibility")
        LegalParagraph("Refund eligibility is determined by the cancellation timeline and package terms agreed upon at the time of booking. For cancellations made at least 72 hours prior to tour departure, tourists are generally eligible for up to a 100% refund (less standard payment gateway processing fees).")

        LegalSectionHeader("2. Severe Weather & Cyclone Disruptions")
        LegalParagraph("If the West Bengal Forest Department or Directorate of Ports issues official red alert warnings or bans boat navigation due to cyclonic weather or storm surges, customers are entitled to a full refund or free rescheduling to a future available date.")

        LegalSectionHeader("3. Dispute Adjudication Refunds")
        LegalParagraph("In case of unresolved service complaints or safety breaches, our administrative mediators review timeline evidence and may award full or partial refunds directly back to the original payment source within 5-7 business days.")
    }
}

@Composable
private fun CancellationPolicyText() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LegalSectionHeader("1. Tourist Cancellation Timelines")
        LegalParagraph("• More than 72 hours before departure: Full refund eligible.\n• 24 to 72 hours before departure: 50% refund eligible.\n• Less than 24 hours or no-show: Non-refundable (as operator permits and boat food provisioning are already secured).")

        LegalSectionHeader("2. Operator Cancellation Policy")
        LegalParagraph("If a verified operator cancels a scheduled tour, the customer receives an immediate 100% refund or an equivalent priority rebooking with another verified operator.")
    }
}

@Composable
private fun CustomerTermsText() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LegalSectionHeader("1. Forest Directorate Rules & Bio-Reserve Conduct")
        LegalParagraph("Tourists visiting Sundarban Biosphere Reserve must strictly adhere to the following mandatory guidelines:\n• Single-use plastics are strictly prohibited inside the core mangrove zone.\n• Playing loud music, stereos, or shouting from boats is forbidden by forest law.\n• Never disembark from boats onto mudbanks or core forest areas outside designated watchtowers.\n• Do not feed, provoke, or throw items at monkeys, deer, crocodiles, or tigers.")

        LegalSectionHeader("2. Mandatory Valid Govt ID")
        LegalParagraph("Every tourist must carry an original government-issued photo ID (Aadhaar, Passport, Voter ID) for biometric verification at forest checkposts (Sajnekhali, Godkhali, Sonakhali).")
    }
}

@Composable
private fun OperatorTermsText() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LegalSectionHeader("1. Vessel Safety & Marine Standards")
        LegalParagraph("All boats registered on Sundarban Explorer must be equipped with certified life jackets for 100% passenger capacity, life buoys, fire extinguishers, first aid kits, and working marine GPS/VHF radio equipment.")

        LegalSectionHeader("2. Fair Pricing & No Hidden Charges")
        LegalParagraph("Operators must clearly disclose all inclusions and exclusions. Demanding unauthorized on-spot cash surcharges or misleading tourists regarding forest entry permits is grounds for immediate suspension.")

        LegalSectionHeader("3. Automated & Admin Verification Standards")
        LegalParagraph("Operators agree to submit legitimate business registrations and maintain a valid Inland Waterways fitness certificate. Falsifying documents results in permanent debarment and civil reporting.")
    }
}

@Composable
private fun SafetyDisclaimerText() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = StatusRejectedBg,
            border = BorderStroke(1.dp, StatusRejected.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "CRITICAL LEGAL DISCLAIMER",
                    fontWeight = FontWeight.Bold,
                    color = StatusRejected,
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Sundarban Explorer is an independent digital tourism technology platform and information portal. We are NOT an official agency or affiliate of the West Bengal Forest Department, Government of West Bengal, or Ministry of Environment & Forests.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        LegalSectionHeader("1. Wildlife & Nature Inherent Risks")
        LegalParagraph("The Sundarban Delta is a wild, tidal mangrove ecosystem inhabited by Royal Bengal Tigers, saltwater crocodiles, venomous snakes, and sharp tidal surges. Sightings are never guaranteed. Tourists enter forest zones under official Directorate permits at their own risk.")

        LegalSectionHeader("2. Medical & Emergency Response Limitations")
        LegalParagraph("Due to the remote geography of islands and waterways, response times for boat ambulances and specialized medical care may be higher than in urban centers. Travelers with acute heart conditions or severe mobility impairments should consult medical professionals before embarking on multi-day deep delta expeditions.")
    }
}

@Composable
private fun ContentCopyrightText() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LegalSectionHeader("1. Educational & Creative Content")
        LegalParagraph("All articles, field guides, and digital books featured in the Sundarban Information Platform are curated strictly for environmental education, conservation awareness, and eco-tourism promotion.")

        LegalSectionHeader("2. Respect for Intellectual Property")
        LegalParagraph("Sundarban Explorer does not distribute unauthorized or copyrighted commercial literature. Open-access conservation studies, government public safety guidelines, and author-authorized wildlife field guides are attributed accordingly.")
    }
}

@Composable
private fun ContactSupportText() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LegalSectionHeader("1. Grievance & Compliance Directorate")
        LegalParagraph("For any disputes, unaddressed complaints, or safety investigations, reach our dedicated compliance desk:\n• Email: compliance@sundarbanexplorer.in\n• Emergency Helpline: +91 98765 43210 (24/7 during active tours)\n• Address: Tourism Support Cell, Canning Ferry Road, South 24 Parganas, West Bengal 743329")

        LegalSectionHeader("2. Emergency Forest Rescue & Coastal Police")
        LegalParagraph("• Forest Department Control Room: 03218-255280\n• Coastal Police Station: 100 / 03218-256100\n• Riverine Medical Boat Ambulance: 108 / +91 94330 12345")
    }
}

@Composable
private fun LegalSectionHeader(title: String) {
    Text(
        text = title,
        fontWeight = FontWeight.Bold,
        style = MaterialTheme.typography.titleSmall,
        color = ForestDarkest
    )
}

@Composable
private fun LegalParagraph(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 20.sp
    )
}
