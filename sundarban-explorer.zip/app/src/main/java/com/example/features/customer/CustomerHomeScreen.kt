package com.example.features.customer

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NaturePeople
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Water
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.core.localization.AppLanguage
import com.example.core.localization.LanguageManager
import com.example.core.localization.LocalAppStrings
import com.example.core.model.Booking
import com.example.core.model.BookingStatus
import com.example.core.model.Payment
import com.example.core.model.PaymentMethod
import com.example.core.model.PaymentStatus
import com.example.core.model.SundarbanArticle
import com.example.core.model.TourPackage
import com.example.core.model.UserProfile
import com.example.core.ui.components.LanguageSelectorDialog
import com.example.core.ui.components.SundarbanTextField
import com.example.data.repositories.AuthRepository
import com.example.data.repositories.ContentRepository
import com.example.data.repositories.TourRepository
import com.example.ui.theme.ForestDarkest
import com.example.ui.theme.MangroveContainer
import com.example.ui.theme.MangroveDark
import com.example.ui.theme.MangroveMedium
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.RiverTeal
import com.example.ui.theme.SandBg
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedBg
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TigerAmber
import com.example.ui.theme.TigerGold
import com.example.ui.theme.TigerLight
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CustomerHomeViewModel(
    private val tourRepository: TourRepository,
    private val contentRepository: ContentRepository,
    private val authRepository: AuthRepository,
    val languageManager: LanguageManager? = null
) : ViewModel() {

    val currentUser = authRepository.currentUser
    val publicPackages = tourRepository.getPublicVerifiedPackages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val articles = contentRepository.getArticles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val userBookings: StateFlow<List<Booking>> = currentUser.flatMapLatest { user ->
        if (user != null) {
            tourRepository.getBookingsForCustomer(user.uid)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

    private val _bookingSuccessMessage = MutableStateFlow<String?>(null)
    val bookingSuccessMessage: StateFlow<String?> = _bookingSuccessMessage.asStateFlow()

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String?) {
        _selectedCategory.value = if (_selectedCategory.value == category) null else category
    }

    fun bookPackage(
        pkg: TourPackage,
        guests: Int,
        tourDate: String,
        paymentMethod: PaymentMethod,
        onComplete: () -> Unit
    ) {
        val user = currentUser.value ?: return
        val total = pkg.pricePerPerson * guests

        viewModelScope.launch {
            val booking = Booking(
                id = "",
                customerId = user.uid,
                customerName = user.fullName,
                customerPhone = user.phoneNumber,
                operatorId = pkg.operatorId,
                operatorName = pkg.operatorName,
                packageId = pkg.id,
                packageTitle = pkg.title,
                travelDate = tourDate,
                numberOfTourists = guests,
                totalAmount = total,
                paymentMethod = paymentMethod,
                paymentStatus = if (paymentMethod == PaymentMethod.CASH_ON_ARRIVAL) PaymentStatus.PENDING else PaymentStatus.PAID,
                bookingStatus = BookingStatus.CONFIRMED
            )

            tourRepository.createBooking(booking)
            if (paymentMethod != PaymentMethod.CASH_ON_ARRIVAL) {
                tourRepository.recordPayment(
                    Payment(
                        id = "",
                        bookingId = booking.id,
                        customerId = user.uid,
                        operatorId = pkg.operatorId,
                        amount = total,
                        paymentMethod = paymentMethod,
                        paymentStatus = PaymentStatus.PAID,
                        transactionRef = "UPI/SUN/" + System.currentTimeMillis().toString().takeLast(8)
                    )
                )
            }
            _bookingSuccessMessage.value = "Booking confirmed for ${pkg.title}! Safe travels in the Sundarbans."
            onComplete()
        }
    }

    fun clearBookingMessage() {
        _bookingSuccessMessage.value = null
    }

    fun setLanguage(lang: AppLanguage) {
        languageManager?.setLanguage(lang)
    }
}

data class QuickCategoryItem(
    val id: String,
    val title: String,
    val icon: ImageVector,
    val isWarm: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CustomerHomeScreen(
    viewModel: CustomerHomeViewModel,
    onNavigateToLibrary: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToArticleDetail: (String) -> Unit,
    onNavigateToDirectory: () -> Unit = {},
    onNavigateToSearch: () -> Unit = {},
    onNavigateToBookings: () -> Unit = {},
    onNavigateToPackageDetail: (String) -> Unit = {},
    onNavigateToCreateBooking: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val user by viewModel.currentUser.collectAsState()
    val packages by viewModel.publicPackages.collectAsState()
    val articles by viewModel.articles.collectAsState()
    val bookings by viewModel.userBookings.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val successMsg by viewModel.bookingSuccessMessage.collectAsState()

    var selectedBottomNav by remember { mutableIntStateOf(0) }
    var selectedPackageForBooking by remember { mutableStateOf<TourPackage?>(null) }
    var selectedPackageDetail by remember { mutableStateOf<TourPackage?>(null) }
    var showEmergencyDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showNotificationsDialog by remember { mutableStateOf(false) }

    val categories = listOf(
        QuickCategoryItem("boat", "Boat Tours", Icons.Default.DirectionsBoat, isWarm = false),
        QuickCategoryItem("wildlife", "Wildlife", Icons.Default.NaturePeople, isWarm = true),
        QuickCategoryItem("canopy", "Canopy Walk", Icons.Default.Explore, isWarm = false),
        QuickCategoryItem("guides", "Guides", Icons.Default.Person, isWarm = false),
        QuickCategoryItem("birding", "Birding", Icons.Default.Water, isWarm = true)
    )

    // Language Selector Dialog
    if (showLanguageDialog && viewModel.languageManager != null) {
        val currentLang by viewModel.languageManager.currentLanguage.collectAsState()
        LanguageSelectorDialog(
            currentLanguage = currentLang,
            onLanguageSelected = {
                viewModel.setLanguage(it)
                showLanguageDialog = false
            },
            onDismiss = { showLanguageDialog = false }
        )
    }

    // Booking Dialog
    if (selectedPackageForBooking != null) {
        val pkg = selectedPackageForBooking!!
        var guestCount by remember { mutableIntStateOf(2) }
        var tourDate by remember { mutableStateOf("2026-09-20") }
        var paymentMethod by remember { mutableStateOf(PaymentMethod.ONLINE_UPI_CARD) }

        AlertDialog(
            onDismissRequest = { selectedPackageForBooking = null },
            shape = RoundedCornerShape(28.dp),
            containerColor = SurfaceCard,
            title = {
                Text(
                    text = "Book: ${pkg.title}",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = ForestDarkest
                )
            },
            text = {
                Column {
                    Text(
                        text = "Verified Operator: ${pkg.operatorName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MangrovePrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Number of Guests: $guestCount", fontWeight = FontWeight.Bold, color = ForestDarkest)
                    Row(
                        modifier = Modifier.padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1, 2, 4, 6, 8).forEach { count ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { guestCount = count }
                                    .testTag("guest_count_$count"),
                                color = if (guestCount == count) MangrovePrimary else MangroveContainer
                            ) {
                                Text(
                                    text = "$count",
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    color = if (guestCount == count) Color.White else MangrovePrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    SundarbanTextField(
                        value = tourDate,
                        onValueChange = { tourDate = it },
                        label = "Preferred Travel Date (YYYY-MM-DD)",
                        leadingIcon = Icons.Default.CalendarMonth,
                        testTag = "booking_date_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Payment Option (Secure)", fontWeight = FontWeight.Bold, color = ForestDarkest)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { paymentMethod = PaymentMethod.ONLINE_UPI_CARD }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = (paymentMethod == PaymentMethod.ONLINE_UPI_CARD),
                            onClick = { paymentMethod = PaymentMethod.ONLINE_UPI_CARD },
                            colors = RadioButtonDefaults.colors(selectedColor = MangrovePrimary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(text = "Pay Online (UPI / Card / NetBanking)", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                            Text(text = "Instant digital receipt & verified insurance", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { paymentMethod = PaymentMethod.CASH_ON_ARRIVAL }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = (paymentMethod == PaymentMethod.CASH_ON_ARRIVAL),
                            onClick = { paymentMethod = PaymentMethod.CASH_ON_ARRIVAL },
                            colors = RadioButtonDefaults.colors(selectedColor = MangrovePrimary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(text = "Cash on Arrival (Ghat Handover)", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                            Text(text = "Pay boat captain at Godkhali entry point", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = Color(0xFFF1F5F9))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Total Payable:", fontWeight = FontWeight.Bold, color = ForestDarkest)
                        Text(
                            text = "₹${(pkg.pricePerPerson * guestCount).toInt()}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = MangrovePrimary
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.bookPackage(pkg, guestCount, tourDate, paymentMethod) {
                            selectedPackageForBooking = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("confirm_package_booking_button")
                ) {
                    Text("Confirm Booking", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedPackageForBooking = null }) {
                    Text(strings.cancel, color = Color.Gray)
                }
            }
        )
    }

    // Emergency Contact Hotline Dialog
    if (showEmergencyDialog) {
        AlertDialog(
            onDismissRequest = { showEmergencyDialog = false },
            shape = RoundedCornerShape(24.dp),
            containerColor = SurfaceCard,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Emergency, contentDescription = null, tint = Color(0xFFDC2626))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Sundarban Emergency Contacts", fontWeight = FontWeight.Bold, color = ForestDarkest)
                }
            },
            text = {
                Column {
                    EmergencyHelplineRow("Sundarban Tiger Reserve Control Room", "+91 3218 255280")
                    EmergencyHelplineRow("Canning Police Station", "+91 3218 255222")
                    EmergencyHelplineRow("Gosaba Coastal Police Station", "+91 3218 236233")
                    EmergencyHelplineRow("Sajnekhali Forest Department Gate", "+91 3218 255225")
                    EmergencyHelplineRow("Tourist Assistance & Marine Ambulance", "112 / 108")
                }
            },
            confirmButton = {
                Button(
                    onClick = { showEmergencyDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Close")
                }
            }
        )
    }

    // Package Details Modal
    if (selectedPackageDetail != null) {
        val p = selectedPackageDetail!!
        AlertDialog(
            onDismissRequest = { selectedPackageDetail = null },
            shape = RoundedCornerShape(28.dp),
            containerColor = SurfaceCard,
            title = {
                Text(text = p.title, fontWeight = FontWeight.Bold, color = ForestDarkest)
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(text = "Verified Operator: ${p.operatorName}", color = MangrovePrimary, fontWeight = FontWeight.Bold)
                    Text(text = "Contact: ${p.operatorPhone}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = p.description, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Destinations:", fontWeight = FontWeight.Bold, color = ForestDarkest)
                    Text(text = p.destinations.joinToString(" • "), color = RiverTeal, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Inclusions:", fontWeight = FontWeight.Bold, color = ForestDarkest)
                    p.inclusions.forEach { inc ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = StatusVerified, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = inc, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Departure Point: ${p.departurePoint}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pkgToBook = selectedPackageDetail
                        selectedPackageDetail = null
                        selectedPackageForBooking = pkgToBook
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Book Tour (₹${p.pricePerPerson.toInt()})", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedPackageDetail = null }) {
                    Text("Close", color = Color.Gray)
                }
            }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(SandBg)
            .testTag("customer_home_screen"),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showEmergencyDialog = true },
                containerColor = Color(0xFFDC2626),
                contentColor = Color.White,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .padding(bottom = 70.dp)
                    .testTag("emergency_sos_fab")
            ) {
                Row(modifier = Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Emergency, contentDescription = "Emergency SOS")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "SOS", fontWeight = FontWeight.Bold)
                }
            }
        },
        bottomBar = {
            // Immersive Bottom Navigation Dock with rounded-t-[2.5rem]
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
                    ),
                shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                color = SurfaceCard,
                border = BorderStroke(1.dp, Color(0xFFF1F5F9))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Home
                    ImmersiveNavItem(
                        icon = Icons.Default.Home,
                        label = "Home",
                        isSelected = selectedBottomNav == 0,
                        onClick = { selectedBottomNav = 0 }
                    )

                    // Explore / Eco Library
                    ImmersiveNavItem(
                        icon = Icons.Default.Explore,
                        label = "Explore",
                        isSelected = selectedBottomNav == 1,
                        onClick = {
                            selectedBottomNav = 1
                            onNavigateToLibrary()
                        }
                    )

                    // Bookings
                    ImmersiveNavItem(
                        icon = Icons.Default.ConfirmationNumber,
                        label = "Bookings",
                        isSelected = selectedBottomNav == 2,
                        onClick = { selectedBottomNav = 2 }
                    )

                    // Profile
                    ImmersiveNavItem(
                        icon = Icons.Default.Person,
                        label = "Profile",
                        isSelected = selectedBottomNav == 3,
                        onClick = {
                            selectedBottomNav = 3
                            onNavigateToProfile()
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SandBg)
                .padding(innerPadding)
        ) {
            // Immersive UI Top Header Bar (flex justify-between items-center px-6 pt-6 pb-2)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "GOOD MORNING",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = MangrovePrimary.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Explore, ${user?.fullName?.split(" ")?.firstOrNull() ?: "Ariful"}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = ForestDarkest
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Language Pill Badge
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                if (viewModel.languageManager != null) {
                                    showLanguageDialog = true
                                }
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = SurfaceCard,
                        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                        shadowElevation = 1.dp
                    ) {
                        Text(
                            text = when (viewModel.languageManager?.currentLanguage?.value) {
                                AppLanguage.BENGALI -> "বাং"
                                AppLanguage.HINDI -> "हिं"
                                else -> "EN"
                            },
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MangrovePrimary
                        )
                    }

                    // Universal Search Shortcut
                    IconButton(
                        onClick = onNavigateToSearch,
                        modifier = Modifier
                            .size(38.dp)
                            .background(MangroveContainer, CircleShape)
                            .testTag("customer_home_search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Universal Search",
                            tint = MangrovePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Eco Library Shortcut
                    IconButton(
                        onClick = onNavigateToLibrary,
                        modifier = Modifier
                            .size(38.dp)
                            .background(MangroveContainer, CircleShape)
                            .testTag("customer_home_library_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Eco Library",
                            tint = MangrovePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Profile Avatar Circle
                    Surface(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .clickable { onNavigateToProfile() }
                            .testTag("customer_home_profile_button"),
                        shape = CircleShape,
                        color = MangrovePrimary,
                        border = BorderStroke(2.dp, Color.White),
                        shadowElevation = 4.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            val initials = (user?.fullName ?: "AA")
                                .split(" ")
                                .mapNotNull { it.firstOrNull()?.toString() }
                                .take(2)
                                .joinToString("")
                                .uppercase()
                            Text(
                                text = if (initials.isNotBlank()) initials else "AA",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Main Scrollable Body
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                // If Bookings tab is active, show user's bookings first
                if (selectedBottomNav == 2) {
                    item {
                        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                            Text(
                                text = "My Tour Bookings",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = ForestDarkest
                            )
                            Text(
                                text = "Track your confirmed river cruises & digital passes",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (bookings.isEmpty()) {
                        item {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = SurfaceCard,
                                border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(imageVector = Icons.Default.DirectionsBoat, contentDescription = null, tint = MangrovePrimary, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(text = "No active bookings yet", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Text(text = "Explore verified packages below and book your first mangrove adventure!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                }
                            }
                        }
                    } else {
                        items(bookings) { b ->
                            CustomerBookingCard(booking = b, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
                        }
                    }
                }

                // Success Message Banner if any
                if (successMsg != null) {
                    item {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 8.dp)
                                .testTag("booking_success_banner"),
                            color = StatusVerifiedBg,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, StatusVerified.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = StatusVerified)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = successMsg ?: "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = StatusVerified,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                IconButton(onClick = { viewModel.clearBookingMessage() }) {
                                    Text("✕", fontWeight = FontWeight.Bold, color = StatusVerified)
                                }
                            }
                        }
                    }
                }

                // Immersive Hero Banner with Tiger & Mangrove Visual
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 6.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp),
                            shape = RoundedCornerShape(28.dp),
                            color = MangrovePrimary,
                            shadowElevation = 8.dp
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_royal_tiger),
                                    contentDescription = "Sundarban Mangrove & Tiger",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                // Gradient Overlay: from-[#06160E]/90 via-[#06160E]/40 to-transparent
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    ForestDarkest.copy(alpha = 0.5f),
                                                    ForestDarkest.copy(alpha = 0.92f)
                                                )
                                            )
                                        )
                                )
                                Column(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(20.dp)
                                ) {
                                    Surface(
                                        color = TigerAmber,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "VERIFIED OPERATORS",
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 9.sp,
                                            letterSpacing = 1.sp,
                                            color = Color.Black
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Tiger Sanctuary\nExcursion",
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        lineHeight = 24.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Starting from ₹4,500/person",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Immersive Quick Categories Section
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp, bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Quick Categories",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = ForestDarkest
                            )
                            if (selectedCategory != null) {
                                Text(
                                    text = "Clear filter",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TigerAmber,
                                    modifier = Modifier.clickable { viewModel.selectCategory(null) }
                                )
                            } else {
                                Text(
                                    text = "View all",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MangrovePrimary,
                                    modifier = Modifier.clickable { onNavigateToLibrary() }
                                )
                            }
                        }

                        LazyRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            contentPadding = PaddingValues(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(categories) { cat ->
                                val isSelected = selectedCategory == cat.id
                                val bgTint = if (isSelected) {
                                    if (cat.isWarm) TigerAmber else MangrovePrimary
                                } else {
                                    if (cat.isWarm) TigerLight else MangroveContainer
                                }
                                val iconColor = if (isSelected) {
                                    Color.White
                                } else {
                                    if (cat.isWarm) TigerAmber else MangrovePrimary
                                }

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable { viewModel.selectCategory(cat.id) }
                                ) {
                                    Surface(
                                        modifier = Modifier.size(64.dp),
                                        shape = RoundedCornerShape(20.dp),
                                        color = bgTint,
                                        shadowElevation = if (isSelected) 4.dp else 0.dp
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = cat.icon,
                                                contentDescription = cat.title,
                                                tint = iconColor,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = cat.title,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) ForestDarkest else Color(0xFF475569)
                                    )
                                }
                            }
                        }
                    }
                }

                // Search Bar with Immersive Outline
                item {
                    Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.onSearchQueryChange(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("tour_search_input"),
                            placeholder = { Text("Search Sajnekhali, Dobanki, Birding...", fontSize = 13.sp, color = Color.Gray) },
                            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MangrovePrimary) },
                            shape = RoundedCornerShape(18.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = SurfaceCard,
                                unfocusedContainerColor = SurfaceCard,
                                focusedBorderColor = MangrovePrimary,
                                unfocusedBorderColor = Color(0xFFE2E8F0)
                            ),
                            singleLine = true
                        )
                    }
                }

                // Section: Top Tour Operators & Verified Packages
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Top Tour Operators",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ForestDarkest
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { onNavigateToDirectory() }
                        ) {
                            Text(
                                text = "Directory (${packages.size})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MangrovePrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(
                                imageVector = Icons.Default.DirectionsBoat,
                                contentDescription = "Operator Directory",
                                tint = MangrovePrimary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                val filteredPackages = packages.filter { pkg ->
                    val matchesSearch = itMatches(pkg, searchQuery)
                    val matchesCategory = when (selectedCategory) {
                        "boat" -> pkg.destinations.any { d -> d.contains("River", ignoreCase = true) || d.contains("Canopy", ignoreCase = true) } || pkg.title.contains("Safari", ignoreCase = true)
                        "wildlife" -> pkg.highlights.any { h -> h.contains("tiger", ignoreCase = true) || h.contains("deer", ignoreCase = true) }
                        "canopy" -> pkg.destinations.any { d -> d.contains("Dobanki", ignoreCase = true) || d.contains("Canopy", ignoreCase = true) }
                        "guides" -> pkg.inclusions.any { inc -> inc.contains("Guide", ignoreCase = true) }
                        "birding" -> pkg.title.contains("Bird", ignoreCase = true) || pkg.destinations.any { d -> d.contains("Pakhiralay", ignoreCase = true) }
                        else -> true
                    }
                    matchesSearch && matchesCategory
                }

                items(filteredPackages) { pkg ->
                    ImmersiveTourCard(
                        pkg = pkg,
                        onBookClick = { selectedPackageForBooking = pkg },
                        onDetailsClick = { selectedPackageDetail = pkg },
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                    )
                }

                // Section: Sundarban Eco Knowledge & Guides
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Eco Library & Field Guide",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ForestDarkest
                        )
                        TextButton(onClick = onNavigateToLibrary) {
                            Text(text = "Explore All", fontWeight = FontWeight.Bold, color = MangrovePrimary, fontSize = 12.sp)
                        }
                    }
                }

                items(articles) { article ->
                    ImmersiveArticleCard(
                        article = article,
                        onClick = { onNavigateToArticleDetail(article.id) },
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

private fun itMatches(pkg: TourPackage, query: String): Boolean {
    if (query.isBlank()) return true
    return pkg.title.contains(query, ignoreCase = true) ||
           pkg.description.contains(query, ignoreCase = true) ||
           pkg.destinations.any { it.contains(query, ignoreCase = true) } ||
           pkg.operatorName.contains(query, ignoreCase = true)
}

@Composable
fun ImmersiveNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Surface(
            modifier = Modifier.size(if (isSelected) 42.dp else 36.dp),
            shape = RoundedCornerShape(14.dp),
            color = if (isSelected) MangrovePrimary.copy(alpha = 0.12f) else Color.Transparent
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) MangrovePrimary else Color(0xFF94A3B8),
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) MangrovePrimary else Color(0xFF94A3B8)
        )
    }
}

@Composable
fun ImmersiveTourCard(
    pkg: TourPackage,
    onBookClick: () -> Unit,
    onDetailsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val agencyInitials = pkg.operatorName
        .split(" ")
        .mapNotNull { it.firstOrNull()?.toString() }
        .take(2)
        .joinToString("")
        .uppercase()

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("tour_package_card_${pkg.id}"),
        shape = RoundedCornerShape(24.dp),
        color = SurfaceCard,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        shadowElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Operator Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = MangrovePrimary.copy(alpha = 0.1f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = if (agencyInitials.isNotBlank()) agencyInitials else "ME",
                            fontWeight = FontWeight.ExtraBold,
                            color = MangrovePrimary,
                            fontSize = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = pkg.operatorName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = ForestDarkest,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "Verified",
                            tint = Color(0xFF3B82F6),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "${pkg.durationDays}D/${pkg.durationNights}N • Departure: ${pkg.departurePoint.take(20)}...",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Text(
                            text = "★ ${pkg.rating}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TigerAmber
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "(${pkg.reviewCount} reviews)",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tour Package Title
            Text(
                text = pkg.title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = ForestDarkest
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = pkg.description,
                fontSize = 12.sp,
                color = Color(0xFF64748B),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = Color(0xFFF1F5F9))
            Spacer(modifier = Modifier.height(12.dp))

            // Price & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "₹${pkg.pricePerPerson.toInt()}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MangrovePrimary
                    )
                    Text(
                        text = "per person all-inclusive",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onDetailsClick,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.testTag("package_details_btn_${pkg.id}")
                    ) {
                        Text(text = "Details", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = ForestDarkest)
                    }

                    Button(
                        onClick = onBookClick,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                        modifier = Modifier.testTag("package_book_btn_${pkg.id}")
                    ) {
                        Text(text = "Book Now", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ImmersiveArticleCard(
    article: SundarbanArticle,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag("article_card_${article.id}"),
        shape = RoundedCornerShape(18.dp),
        color = SurfaceCard,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = RoundedCornerShape(14.dp),
                color = MangroveContainer
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.NaturePeople,
                        contentDescription = null,
                        tint = MangrovePrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = article.category.uppercase(),
                    fontSize = 9.sp,
                    color = TigerAmber,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = article.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ForestDarkest,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${article.readTimeMinutes} min read • Tap to learn",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }
        }
    }
}

@Composable
fun CustomerBookingCard(booking: Booking, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = SurfaceCard,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        shadowElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = booking.packageTitle,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = ForestDarkest,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = StatusVerifiedBg
                ) {
                    Text(
                        text = booking.bookingStatus.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = StatusVerified,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Operator: ${booking.operatorName}",
                fontSize = 12.sp,
                color = MangrovePrimary,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Date: ${booking.tourDate} • Guests: ${booking.guestCount} • Total: ₹${booking.totalAmount.toInt()}",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )
        }
    }
}

@Composable
fun EmergencyHelplineRow(title: String, phone: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ForestDarkest)
            Text(text = phone, style = MaterialTheme.typography.labelSmall, color = Color(0xFFDC2626))
        }
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFFEE2E2)
        ) {
            Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "CALL", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
