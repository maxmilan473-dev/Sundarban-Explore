package com.example.features.payment

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Forest
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.model.Booking
import com.example.core.model.BookingFinancialTimeline
import com.example.core.model.PaymentTransaction
import com.example.ui.theme.ForestDarkest
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.TigerGold

@Composable
fun PaymentReceiptDialog(
    booking: Booking,
    timeline: BookingFinancialTimeline?,
    transaction: PaymentTransaction? = null,
    onDismiss: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    val primaryTxn = transaction ?: timeline?.transactions?.firstOrNull()
    val totalPaid = timeline?.totalPaid ?: booking.paidAmount
    val remaining = timeline?.remainingAmount ?: (booking.totalAmount - booking.paidAmount).coerceAtLeast(0.0)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Bar with Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Forest,
                            contentDescription = null,
                            tint = MangrovePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Sundarban Explorer",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = ForestDarkest
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                // Official Receipt Title Header
                Text(
                    text = "OFFICIAL SAFARI PAYMENT RECEIPT",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Directorate of Eco-Tourism & Sundarban Biosphere",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Stamp / Status Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFFE8F5E9))
                        .border(1.dp, StatusVerified, RoundedCornerShape(24.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Verified",
                        tint = StatusVerified,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (remaining <= 0) "PAYMENT COMPLETED • PASS ISSUED" else "PARTIAL PAYMENT ACKNOWLEDGED",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B5E20)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Transaction & Booking Info Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "RECEIPT / TXN ID",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = primaryTxn?.transactionId ?: "TXN_${booking.id}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            IconButton(
                                onClick = {
                                    val idToCopy = primaryTxn?.transactionId ?: booking.id
                                    clipboardManager.setText(AnnotatedString(idToCopy))
                                    Toast.makeText(context, "Transaction ID copied to clipboard", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy ID",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))

                        DetailLine(label = "Booking ID", value = booking.id)
                        DetailLine(label = "Tour Package", value = booking.packageTitle)
                        DetailLine(label = "Travel Date", value = booking.travelDate)
                        DetailLine(label = "Tourists / Group", value = "${booking.numberOfGuests} Guests")
                        DetailLine(label = "Lead Tourist", value = booking.customerName)
                        DetailLine(label = "Verified Operator", value = booking.operatorName)
                        if (primaryTxn != null) {
                            DetailLine(label = "Payment Method", value = primaryTxn.method.displayName)
                            DetailLine(label = "Payment Date", value = "${primaryTxn.formattedDate} ${primaryTxn.formattedTime}")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Financial Breakdown Ledger
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "FINANCIAL BREAKDOWN",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        FinanceRow(label = "Total Safari Package Price", amount = "₹${String.format("%,.0f", booking.totalAmount)}")
                        
                        val adminCharge = if (primaryTxn != null && primaryTxn.platformCommission > 0) primaryTxn.platformCommission else (booking.totalAmount * 0.005)
                        val remainingAmount = if (primaryTxn != null && primaryTxn.operatorNetEarnings > 0) primaryTxn.operatorNetEarnings else (booking.totalAmount - adminCharge)
                        val adminChargeFormatted = if (adminCharge % 1.0 == 0.0) String.format("%,.0f", adminCharge) else String.format("%,.2f", adminCharge)
                        val remainingAmountFormatted = if (remainingAmount % 1.0 == 0.0) String.format("%,.0f", remainingAmount) else String.format("%,.2f", remainingAmount)

                        FinanceRow(label = "Admin Charge (0.5%)", amount = "₹$adminChargeFormatted")
                        FinanceRow(label = "Operator Net Payout (99.5%)", amount = "₹$remainingAmountFormatted")

                        if ((timeline?.onlinePaid ?: 0.0) > 0) {
                            FinanceRow(label = "Online Gateway Payments (UPI/Card)", amount = "₹${String.format("%,.0f", timeline?.onlinePaid ?: 0.0)}", isPositive = true)
                        }

                        if ((timeline?.cashPaid ?: 0.0) > 0) {
                            FinanceRow(label = "Cash Paid at Ghat / Boarding", amount = "₹${String.format("%,.0f", timeline?.cashPaid ?: 0.0)}", isPositive = true)
                        }

                        if ((timeline?.refundedAmount ?: 0.0) > 0) {
                            FinanceRow(label = "Refunds Disbursed", amount = "-₹${String.format("%,.0f", timeline?.refundedAmount ?: 0.0)}", isNegative = true)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(6.dp))

                        FinanceRow(
                            label = "Total Amount Paid",
                            amount = "₹${String.format("%,.0f", totalPaid)}",
                            isHighlight = true
                        )

                        FinanceRow(
                            label = "Remaining Balance Due",
                            amount = "₹${String.format("%,.0f", remaining)}",
                            isRemaining = true
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Digital Signature Seal
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Authentic",
                        tint = MangrovePrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Authentic digital invoice generated by Sundarban Explorer Escrow Engine.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            Toast.makeText(context, "Invoice downloaded to device storage (PDF)", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = "Download", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Download", fontSize = 13.sp)
                    }

                    Button(
                        onClick = {
                            Toast.makeText(context, "Sharing safari receipt link...", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("share_receipt_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun FinanceRow(
    label: String,
    amount: String,
    isPositive: Boolean = false,
    isNegative: Boolean = false,
    isHighlight: Boolean = false,
    isRemaining: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = if (isHighlight || isRemaining) 13.sp else 12.sp,
            fontWeight = if (isHighlight || isRemaining) FontWeight.Bold else FontWeight.Normal,
            color = if (isRemaining) Color(0xFFC62828) else MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = amount,
            fontSize = if (isHighlight || isRemaining) 14.sp else 12.sp,
            fontWeight = if (isHighlight || isRemaining) FontWeight.Bold else FontWeight.Medium,
            color = when {
                isRemaining -> Color(0xFFC62828)
                isPositive -> Color(0xFF2E7D32)
                isNegative -> Color(0xFFC62828)
                isHighlight -> ForestDarkest
                else -> MaterialTheme.colorScheme.onSurface
            }
        )
    }
}
