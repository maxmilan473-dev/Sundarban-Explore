package com.example.features.authentication.signup

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.localization.LocalAppStrings
import com.example.core.model.UserProfile
import com.example.core.ui.components.SundarbanButton
import com.example.core.ui.components.SundarbanTextField
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusPendingBg
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedBg
import com.example.ui.theme.TigerAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperatorSignUpScreen(
    viewModel: SignUpViewModel,
    onSignUpSuccess: (UserProfile) -> Unit,
    onNavigateBackToLogin: () -> Unit,
    onNavigateToHome: () -> Unit = onNavigateBackToLogin,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val state by viewModel.operatorState.collectAsState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("operator_signup_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Operator Registration",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (!state.isSubmittedSuccessfully) {
                            Text(
                                text = "Step ${state.currentStep} of 4: " + when (state.currentStep) {
                                    1 -> "Personal Information"
                                    2 -> "Operator Profile"
                                    3 -> "Tour & Payment Details"
                                    else -> "Review & Submit"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        } else {
                            Text(
                                text = "Registration Status",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (state.isSubmittedSuccessfully) {
                                onNavigateBackToLogin()
                            } else if (state.currentStep > 1) {
                                viewModel.proceedToPreviousStep()
                            } else {
                                onNavigateBackToLogin()
                            }
                        },
                        modifier = Modifier.testTag("operator_signup_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = TigerAmber,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            // Check if submitted successfully
            if (state.isSubmittedSuccessfully) {
                FinalSuccessView(
                    operator = state.createdOperator,
                    onGoToHome = onNavigateToHome,
                    onViewStatus = {
                        state.createdOperator?.let { onSignUpSuccess(it) } ?: onNavigateBackToLogin()
                    }
                )
            } else {
                // Public Registration Policy Badge
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = TigerAmber.copy(alpha = 0.1f)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TigerAmber
                        ) {
                            Text(
                                text = "Public Signup: Operator ID Application ✅",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Admin Creation is Super Admin Only (❌ Not Public)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // 4-Step Progress Indicator (1 → 2 → 3 → 4)
                OperatorStepIndicator(
                    currentStep = state.currentStep,
                    totalSteps = 4,
                    onStepClick = { targetStep ->
                        if (targetStep < state.currentStep) {
                            viewModel.onOperatorStepChanged(targetStep)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Error Message banner
                if (state.errorMessage != null) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 14.dp)
                            .testTag("operator_signup_error"),
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = state.errorMessage ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }

                // Steps 1 to 4
                when (state.currentStep) {
                    1 -> {
                        Step1PersonalInformation(
                            state = state,
                            viewModel = viewModel,
                            onBack = onNavigateBackToLogin,
                            onContinue = { viewModel.proceedToNextStep() }
                        )
                    }
                    2 -> {
                        Step2OperatorProfile(
                            state = state,
                            viewModel = viewModel,
                            onBack = { viewModel.proceedToPreviousStep() },
                            onContinue = { viewModel.proceedToNextStep() }
                        )
                    }
                    3 -> {
                        Step3TourAndPayment(
                            state = state,
                            viewModel = viewModel,
                            onBack = { viewModel.proceedToPreviousStep() },
                            onContinue = { viewModel.proceedToNextStep() }
                        )
                    }
                    4 -> {
                        Step4ReviewAndSubmit(
                            state = state,
                            viewModel = viewModel,
                            onBack = { viewModel.proceedToPreviousStep() },
                            onSubmit = {
                                viewModel.submitOperatorRegistration { /* State handles transition to success screen */ }
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Footer login link
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    TextButton(
                        onClick = onNavigateBackToLogin,
                        modifier = Modifier.testTag("operator_signup_to_login_button")
                    ) {
                        Text(
                            text = strings.alreadyHaveAccount,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TigerAmber
                        )
                    }
                }
            }
        }
    }
}

/**
 * 4-Step Visual Progress Indicator
 * 1: Personal Info | 2: Operator Profile | 3: Tour Details | 4: Review
 */
@Composable
private fun OperatorStepIndicator(
    currentStep: Int,
    totalSteps: Int = 4,
    onStepClick: (Int) -> Unit
) {
    val labels = listOf("Personal Info", "Operator Profile", "Tour Details", "Review")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            (1..totalSteps).forEach { stepNum ->
                val isCompleted = stepNum < currentStep
                val isCurrent = stepNum == currentStep

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .clickable(enabled = isCompleted) { onStepClick(stepNum) }
                ) {
                    Surface(
                        modifier = Modifier.size(36.dp),
                        shape = CircleShape,
                        color = if (isCurrent) TigerAmber else if (isCompleted) MangrovePrimary else Color.LightGray.copy(alpha = 0.35f),
                        shadowElevation = if (isCurrent) 3.dp else 0.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (isCompleted) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Completed",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            } else {
                                Text(
                                    text = "$stepNum",
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCurrent) Color.White else Color.DarkGray,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = labels.getOrElse(stepNum - 1) { "Step $stepNum" },
                        fontSize = 11.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = if (isCurrent) TigerAmber else if (isCompleted) MangrovePrimary else Color.Gray,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }

                // Connecting line
                if (stepNum < totalSteps) {
                    Box(
                        modifier = Modifier
                            .height(2.dp)
                            .width(16.dp)
                            .background(
                                if (stepNum < currentStep) MangrovePrimary else Color.LightGray.copy(alpha = 0.5f)
                            )
                    )
                }
            }
        }
    }
}

/**
 * STEP 1 OF 4 – PERSONAL INFORMATION
 * Collects:
 * - Full Name
 * - Mobile Number (with OTP verification)
 * - Email Address
 * - Date of Birth
 * - Gender
 * - Full Address
 * - State
 * - District
 * - Profile Photo
 * - Password & Confirm Password
 */
@Composable
private fun Step1PersonalInformation(
    state: OperatorSignUpState,
    viewModel: SignUpViewModel,
    onBack: () -> Unit,
    onContinue: () -> Unit
) {
    val strings = LocalAppStrings.current

    Column {
        Text(
            text = "1. Personal Information",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TigerAmber
        )
        Text(
            text = "Collect basic operator contact details & verify your mobile number with OTP.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Full Name
        SundarbanTextField(
            value = state.fullName,
            onValueChange = { viewModel.onOperatorNameChanged(it) },
            label = "Full Name",
            placeholder = "e.g. Ramesh Chandra Mondal",
            leadingIcon = Icons.Default.Person,
            errorMessage = state.nameError,
            testTag = "operator_step1_name"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Mobile Number
        SundarbanTextField(
            value = state.mobileNumber,
            onValueChange = { viewModel.onOperatorPhoneChanged(it) },
            label = "Mobile Number",
            placeholder = "e.g. 9831012345",
            leadingIcon = Icons.Default.Phone,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            errorMessage = state.phoneError,
            testTag = "operator_step1_phone"
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Mobile OTP Verification Box (MANDATORY REQUIREMENT)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (state.isPhoneVerified) StatusVerifiedBg else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            border = BorderStroke(1.dp, if (state.isPhoneVerified) StatusVerified.copy(alpha = 0.5f) else Color.LightGray.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                if (state.isPhoneVerified) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Verified",
                            tint = StatusVerified,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Mobile number verified using OTP",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            color = StatusVerified
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Mobile Number Verification",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "OTP verification is mandatory for operator registration",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        SundarbanButton(
                            text = if (state.isPhoneOtpSent) "Resend OTP" else "Send OTP",
                            onClick = { viewModel.requestPhoneOtp() },
                            isLoading = state.isLoading,
                            isSecondary = true,
                            modifier = Modifier.height(40.dp),
                            testTag = "operator_send_phone_otp_btn"
                        )
                    }

                    if (state.isPhoneOtpSent) {
                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(10.dp))

                        // Simulated OTP Notice for convenience
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TigerAmber.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Simulated SMS OTP: ${state.simulatedPhoneOtp.ifBlank { "123456" }}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = TigerAmber,
                                modifier = Modifier.padding(8.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            SundarbanTextField(
                                value = state.phoneOtpInput,
                                onValueChange = { viewModel.onOperatorPhoneOtpInputChanged(it) },
                                label = "Enter 6-digit OTP",
                                placeholder = "e.g. ${state.simulatedPhoneOtp.ifBlank { "123456" }}",
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                testTag = "operator_phone_otp_input"
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            SundarbanButton(
                                text = "Verify",
                                onClick = { viewModel.verifyPhoneOtp() },
                                isLoading = state.isLoading,
                                isSecondary = false,
                                modifier = Modifier.height(52.dp),
                                testTag = "operator_confirm_phone_otp_btn"
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Email Address
        SundarbanTextField(
            value = state.email,
            onValueChange = { viewModel.onOperatorEmailChanged(it) },
            label = "Email Address",
            placeholder = "e.g. operator@sundarbanecotours.in",
            leadingIcon = Icons.Default.Email,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            errorMessage = state.emailError,
            testTag = "operator_step1_email"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Date of Birth & Gender Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SundarbanTextField(
                value = state.dateOfBirth,
                onValueChange = { viewModel.onOperatorDobChanged(it) },
                label = "Date of Birth",
                placeholder = "YYYY-MM-DD",
                leadingIcon = Icons.Default.CalendarToday,
                errorMessage = state.dobError,
                modifier = Modifier.weight(1f),
                testTag = "operator_step1_dob"
            )

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Gender",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("Male", "Female", "Other").forEach { g ->
                        FilterChip(
                            selected = state.gender.equals(g, ignoreCase = true),
                            onClick = { viewModel.onOperatorGenderChanged(g) },
                            label = { Text(g, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MangrovePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Full Address
        SundarbanTextField(
            value = state.address,
            onValueChange = { viewModel.onOperatorAddressChanged(it) },
            label = "Full Address",
            placeholder = "Village / Town, Post Office, Police Station",
            leadingIcon = Icons.Default.Home,
            errorMessage = state.addressError,
            testTag = "operator_step1_address"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // State & District Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SundarbanTextField(
                value = state.state,
                onValueChange = { viewModel.onOperatorStateChanged(it) },
                label = "State",
                placeholder = "West Bengal",
                leadingIcon = Icons.Default.LocationOn,
                modifier = Modifier.weight(1f),
                testTag = "operator_step1_state"
            )

            SundarbanTextField(
                value = state.district,
                onValueChange = { viewModel.onOperatorDistrictChanged(it) },
                label = "District",
                placeholder = "South 24 Parganas",
                leadingIcon = Icons.Default.LocationOn,
                modifier = Modifier.weight(1f),
                testTag = "operator_step1_district"
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Profile Photo
        SundarbanTextField(
            value = state.profilePhotoUrl,
            onValueChange = { viewModel.onOperatorPhotoChanged(it) },
            label = "Profile Photo (URL / optional)",
            placeholder = "https://example.com/photo.jpg",
            leadingIcon = Icons.Default.Person,
            testTag = "operator_step1_photo"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Password & Confirm Password
        SundarbanTextField(
            value = state.password,
            onValueChange = { viewModel.onOperatorPasswordChanged(it) },
            label = strings.password,
            placeholder = "Min 8 characters",
            isPassword = true,
            leadingIcon = Icons.Default.Lock,
            errorMessage = state.passwordError,
            testTag = "operator_step1_password"
        )

        Spacer(modifier = Modifier.height(12.dp))

        SundarbanTextField(
            value = state.confirmPassword,
            onValueChange = { viewModel.onOperatorConfirmPasswordChanged(it) },
            label = strings.confirmPassword,
            placeholder = "Re-enter password",
            isPassword = true,
            leadingIcon = Icons.Default.Lock,
            errorMessage = state.confirmPasswordError,
            testTag = "operator_step1_confirm_password"
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Navigation Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("operator_step1_back_btn")
            ) {
                Text("Back")
            }

            SundarbanButton(
                text = "Continue",
                onClick = onContinue,
                isSecondary = false,
                modifier = Modifier.weight(1.5f),
                testTag = "operator_step1_continue_btn"
            )
        }
    }
}

/**
 * STEP 2 OF 4 – OPERATOR PROFILE
 * Collects professional information:
 * - Operator / Guide Name
 * - Type of Service
 * - Years of Experience
 * - Areas Covered
 * - Languages Spoken
 * - Maximum Number of Tourists
 * - Short Description / About Operator
 */
@Composable
private fun Step2OperatorProfile(
    state: OperatorSignUpState,
    viewModel: SignUpViewModel,
    onBack: () -> Unit,
    onContinue: () -> Unit
) {
    Column {
        Text(
            text = "2. Operator Profile",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TigerAmber
        )
        Text(
            text = "Collect professional ecotourism experience, services, and areas covered.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Operator / Guide Name
        SundarbanTextField(
            value = state.operatorBusinessName,
            onValueChange = { viewModel.onOperatorBusinessNameChanged(it) },
            label = "Operator / Guide Name",
            placeholder = "e.g. Sundarban Delta Eco-Tours or Animesh Mondal",
            leadingIcon = Icons.Default.Person,
            errorMessage = state.operatorBusinessNameError,
            testTag = "operator_step2_business_name"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Type of Service
        SundarbanTextField(
            value = state.serviceType,
            onValueChange = { viewModel.onOperatorServiceTypeChanged(it) },
            label = "Type of Service",
            placeholder = "e.g. Boat Safari & Wildlife Tour, Forest Trekking",
            leadingIcon = Icons.Default.DirectionsBoat,
            errorMessage = state.serviceTypeError,
            testTag = "operator_step2_service_type"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Years of Experience & Maximum Tourists Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SundarbanTextField(
                value = state.yearsOfExperience,
                onValueChange = { viewModel.onOperatorYearsExpChanged(it) },
                label = "Years of Experience",
                placeholder = "e.g. 5",
                leadingIcon = Icons.Default.Work,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f),
                testTag = "operator_step2_years_exp"
            )

            SundarbanTextField(
                value = state.maxTourists,
                onValueChange = { viewModel.onOperatorMaxTouristsChanged(it) },
                label = "Max Tourists Handled",
                placeholder = "e.g. 15",
                leadingIcon = Icons.Default.Group,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f),
                testTag = "operator_step2_max_tourists"
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Areas Covered
        SundarbanTextField(
            value = state.areasCovered,
            onValueChange = { viewModel.onOperatorAreasCoveredChanged(it) },
            label = "Areas Covered",
            placeholder = "e.g. Gosaba, Sajnekhali, Sudhanyakhali, Dobanki, Dayapur",
            leadingIcon = Icons.Default.LocationOn,
            errorMessage = state.areasCoveredError,
            testTag = "operator_step2_areas_covered"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Languages Spoken
        SundarbanTextField(
            value = state.languagesSpoken,
            onValueChange = { viewModel.onOperatorLanguagesChanged(it) },
            label = "Languages Spoken",
            placeholder = "e.g. Bengali, English, Hindi",
            leadingIcon = Icons.Default.Language,
            testTag = "operator_step2_languages"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Short Description / About Operator
        SundarbanTextField(
            value = state.shortDescription,
            onValueChange = { viewModel.onOperatorShortDescChanged(it) },
            label = "Short Description / About Operator",
            placeholder = "Tell tourists about your local expertise, certifications, boat master skills, etc.",
            singleLine = false,
            maxLines = 4,
            leadingIcon = Icons.Default.Description,
            testTag = "operator_step2_short_desc"
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Navigation Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("operator_step2_back_btn")
            ) {
                Text("Back")
            }

            SundarbanButton(
                text = "Continue",
                onClick = onContinue,
                isSecondary = false,
                modifier = Modifier.weight(1.5f),
                testTag = "operator_step2_continue_btn"
            )
        }
    }
}

/**
 * STEP 3 OF 4 – TOUR AND PAYMENT DETAILS
 * Collects service and payment information:
 * - Available Tour Packages
 * - Tour Duration
 * - Price (₹ per person)
 * - Maximum Tourist Capacity
 * - Available Dates
 * - Online Payment Available (Switch/Checkbox)
 * - Cash Payment Available (Switch/Checkbox)
 * Supported: Both online and cash payments.
 */
@Composable
private fun Step3TourAndPayment(
    state: OperatorSignUpState,
    viewModel: SignUpViewModel,
    onBack: () -> Unit,
    onContinue: () -> Unit
) {
    Column {
        Text(
            text = "3. Tour & Payment Details",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TigerAmber
        )
        Text(
            text = "Define your default tour package offering and choose supported payment modes.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Available Tour Packages
        SundarbanTextField(
            value = state.tourPackageTitle,
            onValueChange = { viewModel.onOperatorPackageTitleChanged(it) },
            label = "Available Tour Package Name",
            placeholder = "e.g. Sundarban 2D/1N Royal Bengal Tiger Eco Cruise",
            leadingIcon = Icons.Default.DirectionsBoat,
            errorMessage = state.packageTitleError,
            testTag = "operator_step3_package_name"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Tour Duration & Price Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SundarbanTextField(
                value = state.tourDuration,
                onValueChange = { viewModel.onOperatorTourDurationChanged(it) },
                label = "Tour Duration",
                placeholder = "e.g. 2 Days / 1 Night",
                leadingIcon = Icons.Default.Schedule,
                modifier = Modifier.weight(1f),
                testTag = "operator_step3_duration"
            )

            SundarbanTextField(
                value = state.tourPrice,
                onValueChange = { viewModel.onOperatorTourPriceChanged(it) },
                label = "Price (₹ / Person)",
                placeholder = "e.g. 4500",
                leadingIcon = Icons.Default.Payment,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                errorMessage = state.priceError,
                modifier = Modifier.weight(1f),
                testTag = "operator_step3_price"
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Maximum Tourist Capacity & Available Dates Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SundarbanTextField(
                value = state.tourMaxCapacity,
                onValueChange = { viewModel.onOperatorTourCapacityChanged(it) },
                label = "Tourist Capacity",
                placeholder = "e.g. 12",
                leadingIcon = Icons.Default.Group,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f),
                testTag = "operator_step3_capacity"
            )

            SundarbanTextField(
                value = state.tourAvailableDates,
                onValueChange = { viewModel.onOperatorAvailableDatesChanged(it) },
                label = "Available Dates",
                placeholder = "e.g. Daily / Weekends",
                leadingIcon = Icons.Default.CalendarToday,
                modifier = Modifier.weight(1f),
                testTag = "operator_step3_dates"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Payment Options Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccountBalance,
                        contentDescription = null,
                        tint = MangrovePrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Payment Method Support",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "The platform supports both Online and Offline Cash payments. All bookings and receipts will be recorded in your payment history.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Online Payment Option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { viewModel.onOperatorOnlinePaymentToggled(!state.onlinePaymentAvailable) }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Online Payment Available",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Accept UPI, Credit / Debit Cards, and Net Banking",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = state.onlinePaymentAvailable,
                        onCheckedChange = { viewModel.onOperatorOnlinePaymentToggled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = MangrovePrimary
                        ),
                        modifier = Modifier.testTag("operator_step3_online_pay_switch")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(10.dp))

                // Cash Payment Option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { viewModel.onOperatorCashPaymentToggled(!state.cashPaymentAvailable) }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Cash / Offline Payment Available",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Accept cash payments upon arrival at the Sundarban embarkation ghat",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = state.cashPaymentAvailable,
                        onCheckedChange = { viewModel.onOperatorCashPaymentToggled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = MangrovePrimary
                        ),
                        modifier = Modifier.testTag("operator_step3_cash_pay_switch")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Navigation Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("operator_step3_back_btn")
            ) {
                Text("Back")
            }

            SundarbanButton(
                text = "Continue",
                onClick = onContinue,
                isSecondary = false,
                modifier = Modifier.weight(1.5f),
                testTag = "operator_step3_continue_btn"
            )
        }
    }
}

/**
 * STEP 4 OF 4 – REVIEW & SUBMIT
 * Shows all information entered in Steps 1, 2 and 3.
 * User must confirm: "I confirm that the information provided is correct and genuine."
 * After confirmation:
 * Show "Your Operator Account Request is Ready to Submit"
 * Button: "Submit Operator Registration"
 * Status set to PENDING REVIEW. Sent to Admin Dashboard.
 */
@Composable
private fun Step4ReviewAndSubmit(
    state: OperatorSignUpState,
    viewModel: SignUpViewModel,
    onBack: () -> Unit,
    onSubmit: () -> Unit
) {
    Column {
        Text(
            text = "4. Review & Submit",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TigerAmber
        )
        Text(
            text = "Review all details entered across Steps 1, 2, and 3 before final submission.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Summary Card 1: Personal Information
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MangrovePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Step 1: Personal Information",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                    }

                    TextButton(
                        onClick = { viewModel.onOperatorStepChanged(1) },
                        modifier = Modifier.testTag("operator_edit_step1_btn")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit", fontSize = 12.sp)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                ReviewFieldRow(label = "Full Name", value = state.fullName)
                ReviewFieldRow(
                    label = "Mobile",
                    value = "${state.mobileNumber} ${if (state.isPhoneVerified) "✓ (OTP Verified)" else ""}"
                )
                ReviewFieldRow(label = "Email", value = state.email)
                ReviewFieldRow(label = "DOB & Gender", value = "${state.dateOfBirth} • ${state.gender}")
                ReviewFieldRow(label = "Address", value = "${state.address}, ${state.district}, ${state.state}")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Summary Card 2: Operator Profile
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Work,
                            contentDescription = null,
                            tint = TigerAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Step 2: Operator Profile",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                    }

                    TextButton(
                        onClick = { viewModel.onOperatorStepChanged(2) },
                        modifier = Modifier.testTag("operator_edit_step2_btn")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit", fontSize = 12.sp)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                ReviewFieldRow(label = "Operator / Guide", value = state.operatorBusinessName)
                ReviewFieldRow(label = "Service Type", value = state.serviceType)
                ReviewFieldRow(label = "Experience", value = "${state.yearsOfExperience} Years")
                ReviewFieldRow(label = "Areas Covered", value = state.areasCovered)
                ReviewFieldRow(label = "Languages", value = state.languagesSpoken)
                ReviewFieldRow(label = "Max Tourists", value = state.maxTourists)
                if (state.shortDescription.isNotBlank()) {
                    ReviewFieldRow(label = "About", value = state.shortDescription)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Summary Card 3: Tour & Payment
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Payment,
                            contentDescription = null,
                            tint = MangrovePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Step 3: Tour & Payment Details",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                    }

                    TextButton(
                        onClick = { viewModel.onOperatorStepChanged(3) },
                        modifier = Modifier.testTag("operator_edit_step3_btn")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit", fontSize = 12.sp)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                ReviewFieldRow(label = "Package Name", value = state.tourPackageTitle)
                ReviewFieldRow(label = "Duration", value = state.tourDuration)
                ReviewFieldRow(label = "Price", value = "₹ ${state.tourPrice} / Person")
                ReviewFieldRow(label = "Capacity", value = "${state.tourMaxCapacity} Guests")
                ReviewFieldRow(label = "Dates", value = state.tourAvailableDates)
                ReviewFieldRow(
                    label = "Payment Modes",
                    value = buildList {
                        if (state.onlinePaymentAvailable) add("Online (UPI/Cards)")
                        if (state.cashPaymentAvailable) add("Cash on Arrival")
                    }.joinToString(", ")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mandatory Confirmation Checkbox
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.onConfirmationChecked(!state.confirmationChecked) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = state.confirmationChecked,
                    onCheckedChange = { viewModel.onConfirmationChecked(it) },
                    modifier = Modifier.testTag("operator_confirm_checkbox")
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "I confirm that the information provided is correct and genuine.",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Ready to Submit Notice (Shown when user confirms)
        if (state.confirmationChecked) {
            Spacer(modifier = Modifier.height(14.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = StatusPendingBg,
                border = BorderStroke(1.dp, StatusPending.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = StatusPending,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Your Operator Account Request is Ready to Submit",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = StatusPending
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Every new Operator starts as PENDING REVIEW.\n• Your profile will be submitted to the Directorate Admin Dashboard for review.\n• Only ADMIN APPROVED operators can become publicly visible to tourists.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("operator_step4_back_btn")
            ) {
                Text("Back")
            }

            SundarbanButton(
                text = "Submit Operator Registration",
                onClick = onSubmit,
                isLoading = state.isLoading,
                isSecondary = false,
                modifier = Modifier.weight(2f),
                testTag = "operator_step4_submit_btn"
            )
        }
    }
}

/**
 * Summary key-value row
 */
@Composable
private fun ReviewFieldRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1.5f)
        )
    }
}

/**
 * FINAL SUCCESS SCREEN
 * After successful submission, display:
 * "Registration Submitted Successfully"
 * Message:
 * "Your Operator profile has been submitted for Admin review.
 * You will be notified after your account is approved."
 * Show status:
 * "PENDING ADMIN REVIEW"
 * Buttons:
 * - Go to Home
 * - View Application Status
 */
@Composable
private fun FinalSuccessView(
    operator: UserProfile?,
    onGoToHome: () -> Unit,
    onViewStatus: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.size(76.dp),
            shape = CircleShape,
            color = StatusPendingBg,
            border = BorderStroke(2.dp, StatusPending)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.HourglassTop,
                    contentDescription = "Pending Review",
                    tint = StatusPending,
                    modifier = Modifier.size(42.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = "Registration Submitted Successfully",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Your Operator profile has been submitted for Admin review.\nYou will be notified after your account is approved.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = StatusPendingBg),
            border = BorderStroke(1.dp, StatusPending.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "APPLICATION STATUS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = StatusPending,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = StatusPending
                ) {
                    Text(
                        text = "PENDING ADMIN REVIEW",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Reference ID: ${operator?.id ?: "OP-REQ"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Only ADMIN APPROVED operators can become publicly visible to tourists. Our administration team at the Sundarban Forest Tourism Directorate will verify your registration shortly.",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Buttons: View Application Status and Go to Home
        SundarbanButton(
            text = "View Application Status",
            onClick = onViewStatus,
            isSecondary = false,
            modifier = Modifier.fillMaxWidth(),
            testTag = "operator_view_status_btn"
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onGoToHome,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("operator_go_home_btn")
        ) {
            Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Go to Home", fontWeight = FontWeight.SemiBold)
        }
    }
}
