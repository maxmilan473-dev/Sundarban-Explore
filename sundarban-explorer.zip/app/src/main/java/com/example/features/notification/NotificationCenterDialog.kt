package com.example.features.notification

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.AppNotification
import com.example.core.model.NotificationType
import com.example.core.model.UserProfile
import com.example.data.repositories.TourRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationCenterDialog(
    currentUser: UserProfile?,
    tourRepository: TourRepository,
    onDismiss: () -> Unit,
    onNavigateToBooking: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val userId = currentUser?.id ?: "cust_tourist_001"
    val notifications by tourRepository.getNotificationsForUser(userId).collectAsState(initial = emptyList())

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("notification_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Notifications,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Notification Center",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (notifications.any { !it.isRead }) {
                    TextButton(onClick = {
                        coroutineScope.launch {
                            tourRepository.markAllNotificationsAsRead(userId)
                        }
                    }) {
                        Text("Mark all read", fontSize = 13.sp)
                    }
                }
            }

            HorizontalDivider()

            if (notifications.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Outlined.NotificationsNone,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No new notifications",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "You'll receive real-time safari booking updates here.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(notifications, key = { it.id }) { notif ->
                        NotificationItemCard(
                            notification = notif,
                            onClick = {
                                coroutineScope.launch {
                                    tourRepository.markNotificationAsRead(notif.id)
                                }
                                if (notif.bookingId != null) {
                                    onDismiss()
                                    onNavigateToBooking(notif.bookingId)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationItemCard(
    notification: AppNotification,
    onClick: () -> Unit
) {
    val icon = when (notification.type) {
        NotificationType.NEW_BOOKING -> Icons.Default.AddShoppingCart
        NotificationType.BOOKING_ACCEPTED -> Icons.Default.CheckCircle
        NotificationType.BOOKING_REJECTED -> Icons.Default.Cancel
        NotificationType.BOOKING_CONFIRMED -> Icons.Default.ConfirmationNumber
        NotificationType.BOOKING_CANCELLED -> Icons.Default.EventBusy
        NotificationType.PAYMENT_RECEIVED -> Icons.Default.AccountBalanceWallet
        NotificationType.CASH_PAYMENT_RECORDED -> Icons.Default.Payments
        NotificationType.REFUND_REQUESTED -> Icons.Default.ReceiptLong
        NotificationType.REFUND_PROCESSED -> Icons.Default.CurrencyRupee
        NotificationType.COMMISSION_UPDATED -> Icons.Default.Tune
        NotificationType.TRIP_REMINDER -> Icons.Default.Alarm
        NotificationType.OPERATOR_VERIFIED -> Icons.Default.Verified
        NotificationType.CANCELLATION_REQUESTED -> Icons.Default.EventBusy
        NotificationType.CANCELLATION_ACCEPTED -> Icons.Default.CheckCircle
        NotificationType.CANCELLATION_REJECTED -> Icons.Default.Cancel
        NotificationType.EMERGENCY_REVIEW_SUBMITTED -> Icons.Default.Warning
        NotificationType.ADMIN_DECISION_ISSUED -> Icons.Default.Gavel
        NotificationType.BOOKING_RESCHEDULED -> Icons.Default.Schedule
        NotificationType.OPERATOR_REASSIGNED -> Icons.Default.Sync
        NotificationType.SYSTEM_NOTICE -> Icons.Default.Info
    }

    val iconColor = when (notification.type) {
        NotificationType.BOOKING_ACCEPTED, NotificationType.BOOKING_CONFIRMED, NotificationType.OPERATOR_VERIFIED, NotificationType.CANCELLATION_ACCEPTED, NotificationType.BOOKING_RESCHEDULED, NotificationType.OPERATOR_REASSIGNED, NotificationType.CASH_PAYMENT_RECORDED, NotificationType.REFUND_PROCESSED -> Color(0xFF2E7D32)
        NotificationType.BOOKING_REJECTED, NotificationType.BOOKING_CANCELLED, NotificationType.CANCELLATION_REJECTED, NotificationType.EMERGENCY_REVIEW_SUBMITTED -> Color(0xFFC62828)
        NotificationType.PAYMENT_RECEIVED, NotificationType.REFUND_REQUESTED, NotificationType.CANCELLATION_REQUESTED, NotificationType.ADMIN_DECISION_ISSUED -> Color(0xFF1565C0)
        else -> MaterialTheme.colorScheme.primary
    }

    val dateStr = remember(notification.timestamp) {
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(notification.timestamp))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (notification.isRead) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            } else {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            }
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(iconColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(22.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = notification.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = if (notification.isRead) FontWeight.SemiBold else FontWeight.Bold
                    )

                    if (!notification.isRead) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = notification.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
