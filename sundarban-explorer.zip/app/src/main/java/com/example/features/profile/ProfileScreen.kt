package com.example.features.profile

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ContactEmergency
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.localization.AppLanguage
import com.example.core.localization.LocalAppStrings
import com.example.core.model.OperatorStatus
import com.example.core.model.UserRole
import com.example.core.ui.components.LanguageSelectorDialog
import com.example.core.ui.components.RoleBadge
import com.example.core.ui.components.SundarbanButton
import com.example.core.ui.components.SundarbanTextField
import com.example.core.ui.components.VerificationStatusBadge
import com.example.ui.theme.MangroveDark
import com.example.ui.theme.MangroveMedium
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusAdmin
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.TigerAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel,
    currentLanguage: AppLanguage,
    onLogout: () -> Unit,
    onNavigateToPayments: () -> Unit = {},
    onNavigateToEarnings: () -> Unit = {},
    onNavigateToTransactions: () -> Unit = {},
    onNavigateToLegal: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val state by viewModel.uiState.collectAsState()
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var deleteConfirmText by remember { mutableStateOf("") }

    if (state.showLanguageDialog) {
        LanguageSelectorDialog(
            currentLanguage = currentLanguage,
            onLanguageSelected = { viewModel.selectLanguage(it) },
            onDismiss = { viewModel.hideLanguageDialog() }
        )
    }

    if (state.showChangePassDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.hideChangePasswordDialog() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = MangrovePrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.changePassword,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            },
            text = {
                Column {
                    if (state.changePassSuccess) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            color = Color(0xFFDCFCE7),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Password changed successfully!",
                                color = StatusVerified,
                                modifier = Modifier.padding(10.dp),
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    if (state.changePassError != null) {
                        Text(
                            text = state.changePassError ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    SundarbanTextField(
                        value = state.changePassOld,
                        onValueChange = { viewModel.onChangePassOld(it) },
                        label = strings.oldPassword,
                        isPassword = true,
                        testTag = "profile_old_password_input"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    SundarbanTextField(
                        value = state.changePassNew,
                        onValueChange = { viewModel.onChangePassNew(it) },
                        label = strings.newPassword,
                        isPassword = true,
                        testTag = "profile_new_password_input"
                    )
                }
            },
            confirmButton = {
                if (state.changePassSuccess) {
                    Button(
                        onClick = { viewModel.hideChangePasswordDialog() },
                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary)
                    ) {
                        Text("Done")
                    }
                } else {
                    Button(
                        onClick = { viewModel.submitChangePassword() },
                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                        modifier = Modifier.testTag("profile_submit_change_password")
                    ) {
                        Text(strings.save)
                    }
                }
            },
            dismissButton = {
                if (!state.changePassSuccess) {
                    TextButton(onClick = { viewModel.hideChangePasswordDialog() }) {
                        Text(strings.cancel)
                    }
                }
            }
        )
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text(strings.logout, fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to sign out of Sundarban Explorer?") },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirm = false
                        viewModel.logout(onLogout)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_logout_button")
                ) {
                    Text("Sign Out")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) {
                    Text(strings.cancel)
                }
            }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("profile_screen"),
        topBar = {
            TopAppBar(
                title = { Text(strings.myProfile, fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(
                        onClick = { viewModel.showLanguageDialog() },
                        modifier = Modifier.testTag("profile_language_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Language",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = { showLogoutConfirm = true },
                        modifier = Modifier.testTag("profile_logout_icon_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Logout",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MangrovePrimary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        val user = state.user
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            // Profile Card Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        modifier = Modifier.size(80.dp),
                        shape = CircleShape,
                        color = MangrovePrimary.copy(alpha = 0.15f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Profile Photo",
                                tint = MangrovePrimary,
                                modifier = Modifier.size(68.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = user?.fullName ?: "User",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = user?.email ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (user != null) {
                            RoleBadge(role = user.role)

                            if (user.role == UserRole.OPERATOR && user.operatorDetails != null) {
                                VerificationStatusBadge(status = user.operatorDetails.verificationStatus)
                            } else if (user.isVerified) {
                                Surface(
                                    color = Color(0xFFDCFCE7),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Verified,
                                            contentDescription = null,
                                            tint = StatusVerified,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Verified Tourist",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StatusVerified,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Editing or Viewing Profile Details
            if (state.isEditing) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Edit Profile Details",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MangrovePrimary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        SundarbanTextField(
                            value = state.editFullName,
                            onValueChange = { viewModel.onEditNameChange(it) },
                            label = strings.fullName,
                            leadingIcon = Icons.Default.AccountCircle,
                            testTag = "edit_profile_name"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        SundarbanTextField(
                            value = state.editPhone,
                            onValueChange = { viewModel.onEditPhoneChange(it) },
                            label = strings.phoneNumber,
                            leadingIcon = Icons.Default.Phone,
                            testTag = "edit_profile_phone"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        SundarbanTextField(
                            value = state.editAddress,
                            onValueChange = { viewModel.onEditAddressChange(it) },
                            label = strings.address,
                            leadingIcon = Icons.Default.Home,
                            testTag = "edit_profile_address"
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Emergency Contact",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = TigerAmber
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        SundarbanTextField(
                            value = state.editEmerName,
                            onValueChange = { viewModel.onEditEmerNameChange(it) },
                            label = strings.emergencyContactName,
                            testTag = "edit_profile_emer_name"
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        SundarbanTextField(
                            value = state.editEmerPhone,
                            onValueChange = { viewModel.onEditEmerPhoneChange(it) },
                            label = strings.emergencyContactPhone,
                            testTag = "edit_profile_emer_phone"
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        SundarbanTextField(
                            value = state.editEmerRelation,
                            onValueChange = { viewModel.onEditEmerRelationChange(it) },
                            label = strings.emergencyContactRelation,
                            testTag = "edit_profile_emer_relation"
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.cancelEditing() },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(strings.cancel)
                            }

                            Button(
                                onClick = { viewModel.saveProfile() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary)
                            ) {
                                Text(strings.save)
                            }
                        }
                    }
                }
            } else {
                // Info Summary Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Contact & Safety Details",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = { viewModel.startEditing() },
                                modifier = Modifier.testTag("profile_edit_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Profile",
                                    tint = MangrovePrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        ProfileDetailRow(icon = Icons.Default.Phone, label = strings.phoneNumber, value = user?.phoneNumber ?: "Not provided")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        ProfileDetailRow(icon = Icons.Default.Home, label = strings.address, value = user?.address?.ifBlank { "Not provided" } ?: "Not provided")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        ProfileDetailRow(
                            icon = Icons.Default.ContactEmergency,
                            label = "Emergency Contact",
                            value = "${user?.emergencyContact?.name.orEmpty()} (${user?.emergencyContact?.relationship.orEmpty()}): ${user?.emergencyContact?.phoneNumber.orEmpty()}"
                        )

                        if (user?.role == UserRole.OPERATOR && user.operatorDetails != null) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                            ProfileDetailRow(icon = Icons.Default.Security, label = "Operating Delta Area", value = user.operatorDetails.operatingArea)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                            ProfileDetailRow(icon = Icons.Default.Policy, label = "Govt Tourism License", value = user.operatorDetails.licenseNumber)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Action List (Language, Change Password, Security & Trust)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    when (state.user?.role) {
                        UserRole.CUSTOMER -> {
                            ProfileMenuActionItem(
                                icon = Icons.Default.Payments,
                                title = "Payments & Invoices",
                                subtitle = "Transaction receipts, payment ledger & refund requests",
                                onClick = onNavigateToPayments,
                                testTag = "profile_payments_row"
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        }
                        UserRole.OPERATOR -> {
                            ProfileMenuActionItem(
                                icon = Icons.Default.AccountBalanceWallet,
                                title = "Earnings & Cash Collection",
                                subtitle = "Gross GMV, net payouts, cash at ghat & commission",
                                onClick = onNavigateToEarnings,
                                testTag = "profile_earnings_row"
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        }
                        UserRole.ADMIN -> {
                            ProfileMenuActionItem(
                                icon = Icons.Default.AccountBalance,
                                title = "Platform Transactions & Commission Hub",
                                subtitle = "Global audit ledger, refund approval & commission settings",
                                onClick = onNavigateToTransactions,
                                testTag = "profile_transactions_row"
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        }
                        null -> {}
                    }

                    ProfileMenuActionItem(
                        icon = Icons.Default.Language,
                        title = strings.language,
                        subtitle = currentLanguage.nativeName,
                        onClick = { viewModel.showLanguageDialog() },
                        testTag = "profile_language_row"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    ProfileMenuActionItem(
                        icon = Icons.Default.Lock,
                        title = strings.changePassword,
                        subtitle = "Update your security credentials",
                        onClick = { viewModel.showChangePasswordDialog() },
                        testTag = "profile_change_password_row"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    ProfileMenuActionItem(
                        icon = Icons.Default.Shield,
                        title = strings.securityAndTrust,
                        subtitle = "Anti-fraud protocols & verified operator badge system",
                        onClick = { onNavigateToLegal() },
                        testTag = "profile_security_row"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    ProfileMenuActionItem(
                        icon = Icons.Default.Policy,
                        title = "Legal, Privacy & Compliance",
                        subtitle = "Terms, Refund Policy, Forest Disclaimers & Support",
                        onClick = { onNavigateToLegal() },
                        testTag = "profile_legal_row"
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Logout Button
            SundarbanButton(
                text = strings.logout,
                onClick = { showLogoutConfirm = true },
                icon = Icons.Default.ExitToApp,
                isSecondary = true,
                testTag = "profile_logout_bottom_button"
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Delete Account Option
            TextButton(
                onClick = { showDeleteAccountDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_delete_account_button")
            ) {
                Text(
                    text = "Request Account Deletion",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = {
                showDeleteAccountDialog = false
                deleteConfirmText = ""
            },
            title = {
                Text(
                    text = "Delete Account & Anonymize Data",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "This action permanently disables your account. In compliance with data protection standards, your personal profile and identifiers will be deleted or anonymized within 30 days. Historical completed booking ledgers are retained for legal audit compliance.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Type 'DELETE' to confirm:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    SundarbanTextField(
                        value = deleteConfirmText,
                        onValueChange = { deleteConfirmText = it },
                        placeholder = "DELETE"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (deleteConfirmText.trim() == "DELETE") {
                            showDeleteAccountDialog = false
                            viewModel.logout(onLoggedOut = onLogout)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    enabled = deleteConfirmText.trim() == "DELETE"
                ) {
                    Text("Delete Account")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showDeleteAccountDialog = false
                    deleteConfirmText = ""
                }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ProfileDetailRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MangroveMedium,
            modifier = Modifier
                .size(20.dp)
                .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun ProfileMenuActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String = ""
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(40.dp),
            shape = CircleShape,
            color = MangrovePrimary.copy(alpha = 0.1f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MangrovePrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
