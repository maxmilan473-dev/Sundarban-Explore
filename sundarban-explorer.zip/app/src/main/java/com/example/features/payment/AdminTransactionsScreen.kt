package com.example.features.payment

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.model.Booking
import com.example.core.model.OperatorEarningsSummary
import com.example.core.model.PaymentRiskAlert
import com.example.core.model.PaymentTransaction
import com.example.core.model.PlatformCommissionConfig
import com.example.core.model.RefundRecord
import com.example.core.model.RefundStatus
import com.example.core.model.RiskSeverity
import com.example.core.model.TransactionStatus
import com.example.core.model.TransactionType
import com.example.core.model.UserProfile
import com.example.data.repositories.TourRepository
import com.example.ui.theme.ForestDarkest
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.TigerAmber
import com.example.ui.theme.TigerGold
import java.util.Locale
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminTransactionsScreen(
    currentUser: UserProfile,
    tourRepository: TourRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val platformFinancials by tourRepository.getGlobalPlatformFinancialSummary().collectAsState(
        initial = OperatorEarningsSummary(operatorId = "PLATFORM_GLOBAL")
    )
    val allTransactions by tourRepository.getAllTransactionsForAdmin().collectAsState(initial = emptyList())
    val refundRequests by tourRepository.getRefundRecords().collectAsState(initial = emptyList())
    val commissionConfig by tourRepository.platformCommissionConfig.collectAsState()
    val allBookings by tourRepository.getAllBookingsForAdmin().collectAsState(initial = emptyList())
    val paymentRiskAlerts by tourRepository.getSuspiciousPaymentAlerts().collectAsState(initial = emptyList())

    var activeTab by remember { mutableStateOf(0) } // 0: Transactions Ledger, 1: Refund Queue, 2: Risk Alerts, 3: Commission Policy
    var searchQuery by remember { mutableStateOf("") }
    var filterType by remember { mutableStateOf("ALL") }

    // Dialog states
    var selectedTxnForInspection by remember { mutableStateOf<PaymentTransaction?>(null) }
    var showCommissionDialog by remember { mutableStateOf(false) }
    var newCommissionRateInput by remember { mutableStateOf(commissionConfig.percentageCommission.toString()) }
    var newFixedFeeInput by remember { mutableStateOf(commissionConfig.fixedFeePerBooking.toString()) }
    var commissionPolicyNotes by remember { mutableStateOf(commissionConfig.description) }

    // Refund Action
    var selectedRefundToProcess by remember { mutableStateOf<RefundRecord?>(null) }
    var isApprovingRefund by remember { mutableStateOf(true) }
    var refundRejectReasonInput by remember { mutableStateOf("") }
    var showRefundProcessDialog by remember { mutableStateOf(false) }

    // Fraud & Risk Action
    var selectedAlertForResolution by remember { mutableStateOf<PaymentRiskAlert?>(null) }
    var alertResolutionNotes by remember { mutableStateOf("") }

    val pendingRefundsCount = refundRequests.count { it.status == RefundStatus.REQUESTED }
    val unresolvedAlertsCount = paymentRiskAlerts.count { !it.isResolved }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Financial Hub & Escrow Ledger", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("State Directorate Audit & Commission Controls", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            newCommissionRateInput = commissionConfig.percentageCommission.toString()
                            newFixedFeeInput = commissionConfig.fixedFeePerBooking.toString()
                            commissionPolicyNotes = commissionConfig.description
                            showCommissionDialog = true
                        },
                        modifier = Modifier.testTag("admin_commission_config_button")
                    ) {
                        Icon(imageVector = Icons.Default.Tune, contentDescription = "Commission Settings", tint = MangrovePrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Platform Financial Revenue Card
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = ForestDarkest)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "SUNDARBAN PLATFORM COMMISSION REVENUE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFA5D6A7),
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "₹${String.format("%,.0f", platformFinancials.totalCommission)}",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Rate: ${commissionConfig.percentageCommission}%",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Gross GMV", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                                Text("₹${String.format("%,.0f", platformFinancials.grossBookingValue)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("Online Gateway", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                                Text("₹${String.format("%,.0f", platformFinancials.onlinePayments)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF90CAF9))
                            }
                            Column {
                                Text("Cash at Ghat", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                                Text("₹${String.format("%,.0f", platformFinancials.cashPayments)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA5D6A7))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Refunds Disbursed", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                                Text("₹${String.format("%,.0f", platformFinancials.refunds)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFAB91))
                            }
                        }
                    }
                }
            }

            // Tab Navigation
            item {
                TabRow(
                    selectedTabIndex = activeTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MangrovePrimary
                ) {
                    Tab(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        text = { Text("Transactions (${allTransactions.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Refunds", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                if (pendingRefundsCount > 0) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFFC62828)
                                    ) {
                                        Text(
                                            text = "$pendingRefundsCount",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    )
                    Tab(
                        selected = activeTab == 2,
                        onClick = { activeTab = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Risk Alerts", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                if (unresolvedAlertsCount > 0) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFFE65100)
                                    ) {
                                        Text(
                                            text = "$unresolvedAlertsCount",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    )
                    Tab(
                        selected = activeTab == 3,
                        onClick = { activeTab = 3 },
                        text = { Text("Commission Policy", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            when (activeTab) {
                0 -> {
                    // Search & Filter Row
                    item {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search by Txn ID, Booking ID, Tourist, Operator...") },
                            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("admin_transaction_search"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }

                    item {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val filters = listOf(
                                "ALL" to "All (${allTransactions.size})",
                                "ONLINE" to "Online UPI/Card",
                                "CASH" to "Cash at Ghat",
                                "ADJUSTMENT" to "Cash Adjustments",
                                "REFUND" to "Refund Payouts"
                            )
                            items(filters) { (key, label) ->
                                FilterChip(
                                    selected = filterType == key,
                                    onClick = { filterType = key },
                                    label = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    val filtered = allTransactions.filter { txn ->
                        val matchesType = when (filterType) {
                            "ONLINE" -> txn.type == TransactionType.ONLINE_GATEWAY
                            "CASH" -> txn.type == TransactionType.OFFLINE_CASH
                            "ADJUSTMENT" -> txn.type == TransactionType.CASH_ADJUSTMENT
                            "REFUND" -> txn.type == TransactionType.REFUND_PAYOUT
                            else -> true
                        }
                        val matchesSearch = searchQuery.isBlank() ||
                            txn.transactionId.contains(searchQuery, ignoreCase = true) ||
                            txn.bookingId.contains(searchQuery, ignoreCase = true) ||
                            txn.payerName.contains(searchQuery, ignoreCase = true) ||
                            txn.receiverName.contains(searchQuery, ignoreCase = true) ||
                            (txn.gatewayPaymentId?.contains(searchQuery, ignoreCase = true) == true)

                        matchesType && matchesSearch
                    }

                    if (filtered.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No transaction logs match current search or filters.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    } else {
                        items(filtered) { txn ->
                            AdminTransactionCard(
                                txn = txn,
                                onClick = { selectedTxnForInspection = txn }
                            )
                        }
                    }
                }

                1 -> {
                    // Refund Processing Queue
                    if (refundRequests.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = StatusVerified, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No Refund Requests in Queue", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    Text("All cancellation and refund requests have been reviewed and reconciled.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    } else {
                        items(refundRequests) { refund ->
                            AdminRefundItemCard(
                                refund = refund,
                                onApprove = {
                                    selectedRefundToProcess = refund
                                    isApprovingRefund = true
                                    showRefundProcessDialog = true
                                },
                                onReject = {
                                    selectedRefundToProcess = refund
                                    isApprovingRefund = false
                                    refundRejectReasonInput = ""
                                    showRefundProcessDialog = true
                                }
                            )
                        }
                    }
                }

                2 -> {
                    // Risk & Fraud Alerts
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                            border = BorderStroke(1.dp, Color(0xFFFFB74D))
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Automated Payment Integrity Engine", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFE65100))
                                    Text("Scans payment velocities, geofence anomalies, high-value off-hour cash, and bank account changes.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    if (paymentRiskAlerts.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No risk alerts logged. Escrow and payment flow operating cleanly.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                            }
                        }
                    } else {
                        items(paymentRiskAlerts) { alert ->
                            AdminRiskAlertCard(
                                alert = alert,
                                onResolve = {
                                    selectedAlertForResolution = alert
                                    alertResolutionNotes = ""
                                }
                            )
                        }
                    }
                }

                3 -> {
                    // Commission Policy Information & Management
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Active Commission Policy", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                        Text("Version: ${commissionConfig.id}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                                    }

                                    Button(
                                        onClick = {
                                            newCommissionRateInput = commissionConfig.percentageCommission.toString()
                                            newFixedFeeInput = commissionConfig.fixedFeePerBooking.toString()
                                            commissionPolicyNotes = commissionConfig.description
                                            showCommissionDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("Edit Policy", fontSize = 12.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))
                                HorizontalDivider()
                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Commission Rate", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${commissionConfig.percentageCommission}%", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MangrovePrimary)
                                    }
                                    Column {
                                        Text("Fixed Booking Fee", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("₹${commissionConfig.fixedFeePerBooking}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = ForestDarkest)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Effective Since", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(commissionConfig.effectiveDate, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFE8F5E9)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = StatusVerified, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Historical Immutability Guarantee", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Updating platform commission rate will ONLY apply to new transactions going forward. Past transactions securely store their snapshotted commission rate and will never be altered retroactively.",
                                            fontSize = 11.sp,
                                            color = Color(0xFF2E7D32)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // Commission Configuration Dialog
    if (showCommissionDialog) {
        AlertDialog(
            onDismissRequest = { showCommissionDialog = false },
            title = {
                Text("Configure Platform Commission", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            },
            text = {
                Column {
                    Text(
                        text = "Set Sundarban Eco-Tourism Directorate platform fee applied to safari bookings.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = newCommissionRateInput,
                        onValueChange = { newCommissionRateInput = it },
                        label = { Text("Percentage Commission (%)") },
                        placeholder = { Text("e.g. 0.5") },
                        modifier = Modifier.fillMaxWidth().testTag("commission_rate_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newFixedFeeInput,
                        onValueChange = { newFixedFeeInput = it },
                        label = { Text("Fixed Fee per Booking (INR)") },
                        placeholder = { Text("e.g. 0 or 50") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = commissionPolicyNotes,
                        onValueChange = { commissionPolicyNotes = it },
                        label = { Text("Policy Change Note / Gazetted Order") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val rate = newCommissionRateInput.toDoubleOrNull() ?: 0.0
                        val fixed = newFixedFeeInput.toDoubleOrNull() ?: 0.0
                        if (rate < 0 || rate > 50) {
                            Toast.makeText(context, "Rate must be between 0% and 50%", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        scope.launch {
                            val updatedConfig = commissionConfig.copy(
                                percentageCommission = rate,
                                fixedFeePerBooking = fixed,
                                description = commissionPolicyNotes.ifBlank { commissionConfig.description }
                            )
                            val res = tourRepository.updateCommissionConfig(updatedConfig, currentUser.id)
                            if (res.isSuccess) {
                                Toast.makeText(context, "Commission policy updated & broadcasted!", Toast.LENGTH_LONG).show()
                                showCommissionDialog = false
                            } else {
                                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                    modifier = Modifier.testTag("save_commission_config_button")
                ) {
                    Text("Save Policy")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCommissionDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Refund Action Dialog (Approve / Reject)
    if (showRefundProcessDialog && selectedRefundToProcess != null) {
        val targetRefund = selectedRefundToProcess!!
        AlertDialog(
            onDismissRequest = { showRefundProcessDialog = false },
            title = {
                Text(
                    text = if (isApprovingRefund) "Approve & Disburse Refund" else "Reject Refund Request",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = if (isApprovingRefund) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                )
            },
            text = {
                Column {
                    Text(
                        text = "Booking: ${targetRefund.bookingId} (${targetRefund.packageTitle})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Tourist: ${targetRefund.customerName} | Operator: ${targetRefund.operatorName}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Refund Amount: ₹${String.format("%,.0f", targetRefund.amount)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isApprovingRefund) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                    Text(
                        text = "Reason: ${targetRefund.reason}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (!isApprovingRefund) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = refundRejectReasonInput,
                            onValueChange = { refundRejectReasonInput = it },
                            label = { Text("Rejection Justification") },
                            placeholder = { Text("e.g. Cancellation requested after permit issuance cutoff") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )
                    } else {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Approval will instantly initiate gateway escrow reversal to tourist's source payment method and update booking audit ledgers.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            val res = tourRepository.processRefund(
                                refundId = targetRefund.refundId,
                                approve = isApprovingRefund,
                                admin = currentUser,
                                rejectionReason = refundRejectReasonInput
                            )
                            if (res.isSuccess) {
                                Toast.makeText(context, if (isApprovingRefund) "Refund approved & disbursed!" else "Refund request rejected.", Toast.LENGTH_LONG).show()
                                showRefundProcessDialog = false
                            } else {
                                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isApprovingRefund) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(if (isApprovingRefund) "Confirm Disbursement" else "Reject Request")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRefundProcessDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Risk Alert Resolution Dialog
    if (selectedAlertForResolution != null) {
        val targetAlert = selectedAlertForResolution!!
        AlertDialog(
            onDismissRequest = { selectedAlertForResolution = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MangrovePrimary, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Resolve Security Alert", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Alert ID: ${targetAlert.id}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Booking Ref: ${targetAlert.bookingId} • Txn: ${targetAlert.transactionId.take(12)}...",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Risk Severity: ${targetAlert.severity.name} (Score: ${targetAlert.riskScore}/100)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (targetAlert.severity) {
                            RiskSeverity.CRITICAL -> Color(0xFFC62828)
                            RiskSeverity.HIGH -> Color(0xFFD84315)
                            RiskSeverity.MEDIUM -> Color(0xFFEF6C00)
                            else -> Color(0xFF2E7D32)
                        }
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Flagged Signals:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    targetAlert.flaggedSignals.forEach { signal ->
                        Text("• $signal", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = alertResolutionNotes,
                        onValueChange = { alertResolutionNotes = it },
                        label = { Text("Audit / Resolution Justification") },
                        placeholder = { Text("e.g. Tourist identity verified via phone call & permit matches") },
                        modifier = Modifier.fillMaxWidth().testTag("admin_alert_resolution_notes"),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            val notes = alertResolutionNotes.ifBlank { "Verified and cleared by administrator ${currentUser.fullName}" }
                            val res = tourRepository.resolvePaymentRiskAlert(targetAlert.id, notes, currentUser)
                            if (res.isSuccess) {
                                Toast.makeText(context, "Security alert resolved and marked clean.", Toast.LENGTH_SHORT).show()
                                selectedAlertForResolution = null
                            } else {
                                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Failed to resolve alert", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                    modifier = Modifier.testTag("confirm_resolve_alert_btn")
                ) {
                    Text("Confirm Resolution")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedAlertForResolution = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Detailed Transaction Inspection Modal
    if (selectedTxnForInspection != null) {
        val txn = selectedTxnForInspection!!
        Dialog(
            onDismissRequest = { selectedTxnForInspection = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(vertical = 24.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Transaction Deep Inspection", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        IconButton(onClick = { selectedTxnForInspection = null }) {
                            Icon(imageVector = Icons.Default.Cancel, contentDescription = "Close")
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    DetailItem(label = "Transaction ID", value = txn.transactionId, isMonospace = true)
                    DetailItem(label = "Booking ID", value = txn.bookingId, isMonospace = true)
                    DetailItem(label = "Tour Package", value = txn.packageTitle)
                    DetailItem(label = "Transaction Type", value = txn.type.displayName)
                    DetailItem(label = "Payment Method", value = txn.method.displayName)
                    DetailItem(label = "Status", value = txn.status.displayName)
                    val commFormatted = if (txn.platformCommission % 1.0 == 0.0) String.format("%,.0f", txn.platformCommission) else String.format("%,.2f", txn.platformCommission)
                    val netFormatted = if (txn.operatorNetEarnings % 1.0 == 0.0) String.format("%,.0f", txn.operatorNetEarnings) else String.format("%,.2f", txn.operatorNetEarnings)
                    val rateFormatted = String.format(Locale.US, "%.1f", txn.commissionRate * 100).removeSuffix(".0")
                    DetailItem(label = "Amount", value = "₹${String.format("%,.0f", txn.amount)}")
                    DetailItem(label = "Admin Commission", value = "₹$commFormatted ($rateFormatted%)")
                    DetailItem(label = "Operator Net Credit", value = "₹$netFormatted")
                    DetailItem(label = "Tourist / Payer", value = "${txn.payerName} (${txn.payerPhone})")
                    DetailItem(label = "Receiver Operator", value = txn.receiverName)
                    DetailItem(label = "Timestamp", value = "${txn.formattedDate} ${txn.formattedTime}")

                    if (txn.gatewayOrderId != null) {
                        DetailItem(label = "Gateway Order ID", value = txn.gatewayOrderId, isMonospace = true)
                    }
                    if (txn.gatewayPaymentId != null) {
                        DetailItem(label = "Gateway Payment ID", value = txn.gatewayPaymentId, isMonospace = true)
                    }
                    if (txn.gatewaySignature != null) {
                        DetailItem(label = "HMAC Server Signature", value = txn.gatewaySignature, isMonospace = true)
                    }
                    if (txn.cashReceiptNumber != null) {
                        DetailItem(label = "Cash Receipt No.", value = txn.cashReceiptNumber, isMonospace = true)
                    }
                    if (txn.isAdjustment) {
                        DetailItem(label = "Adjustment Reason", value = txn.adjustmentReason ?: "")
                        DetailItem(label = "Original Txn Ref", value = txn.originalTransactionId ?: "", isMonospace = true)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { selectedTxnForInspection = null },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary)
                    ) {
                        Text("Close Inspector")
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminTransactionCard(
    txn: PaymentTransaction,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = txn.transactionId,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Booking: ${txn.bookingId}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    val isNeg = txn.amount < 0 || txn.type == TransactionType.REFUND_PAYOUT
                    Text(
                        text = "${if (isNeg) "-" else "+"}₹${String.format("%,.0f", Math.abs(txn.amount))}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isNeg) Color(0xFFC62828) else Color(0xFF2E7D32)
                    )
                    Text(
                        text = txn.status.displayName,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = when (txn.status) {
                            TransactionStatus.SUCCESS, TransactionStatus.CASH_RECORDED -> StatusVerified
                            TransactionStatus.REFUNDED -> Color(0xFFC62828)
                            else -> TigerAmber
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${txn.method.displayName} • ${txn.payerName} → ${txn.receiverName}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val commFormatted = if (txn.platformCommission % 1.0 == 0.0) String.format("%,.0f", txn.platformCommission) else String.format("%,.2f", txn.platformCommission)
                val netFormatted = if (txn.operatorNetEarnings % 1.0 == 0.0) String.format("%,.0f", txn.operatorNetEarnings) else String.format("%,.2f", txn.operatorNetEarnings)
                Text(
                    text = "Admin Charge (0.5%): ₹$commFormatted | Op Net: ₹$netFormatted",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "${txn.formattedDate} ${txn.formattedTime}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun AdminRefundItemCard(
    refund: RefundRecord,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Refund ID: ${refund.refundId}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFC62828)
                    )
                    Text(
                        text = "Booking: ${refund.bookingId}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when (refund.status) {
                        RefundStatus.REQUESTED -> Color(0xFFFFF8E1)
                        RefundStatus.COMPLETED -> Color(0xFFE8F5E9)
                        else -> Color(0xFFFFEBEE)
                    }
                ) {
                    Text(
                        text = refund.status.displayName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (refund.status) {
                            RefundStatus.REQUESTED -> TigerAmber
                            RefundStatus.COMPLETED -> StatusVerified
                            else -> Color(0xFFC62828)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Package: ${refund.packageTitle}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "Tourist: ${refund.customerName} | Operator: ${refund.operatorName}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Amount: ₹${String.format("%,.0f", refund.amount)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = ForestDarkest
            )
            Text(
                text = "Reason: ${refund.reason}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (refund.status == RefundStatus.REQUESTED) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onReject,
                        modifier = Modifier.weight(1f).height(40.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Reject", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    }

                    Button(
                        onClick = onApprove,
                        modifier = Modifier.weight(1.4f).height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Approve & Disburse", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailItem(label: String, value: String, isMonospace: Boolean = false) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun AdminRiskAlertCard(
    alert: PaymentRiskAlert,
    onResolve: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("risk_alert_card_${alert.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (alert.isResolved) Color(0xFFF1F8E9) else Color(0xFFFFF8E1)
        ),
        border = BorderStroke(
            1.dp,
            if (alert.isResolved) StatusVerified.copy(alpha = 0.5f) else when (alert.severity) {
                RiskSeverity.CRITICAL -> Color(0xFFE57373)
                RiskSeverity.HIGH -> Color(0xFFFFB74D)
                else -> Color(0xFFFFD54F)
            }
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (alert.isResolved) Icons.Default.Shield else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (alert.isResolved) StatusVerified else when (alert.severity) {
                            RiskSeverity.CRITICAL -> Color(0xFFC62828)
                            RiskSeverity.HIGH -> Color(0xFFD84315)
                            else -> Color(0xFFEF6C00)
                        },
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = alert.id,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (alert.isResolved) StatusVerified else when (alert.severity) {
                        RiskSeverity.CRITICAL -> Color(0xFFC62828)
                        RiskSeverity.HIGH -> Color(0xFFD84315)
                        else -> Color(0xFFEF6C00)
                    }
                ) {
                    Text(
                        text = if (alert.isResolved) "RESOLVED" else alert.severity.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Booking: ${alert.bookingId} • Txn: ${alert.transactionId.take(16)}...",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Calculated Risk Score: ${alert.riskScore}/100",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (alert.riskScore >= 70) Color(0xFFC62828) else Color(0xFFE65100)
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Signals Detected:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            alert.flaggedSignals.forEach { signal ->
                Text(
                    text = "• $signal",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (alert.isResolved && !alert.resolutionNotes.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFE8F5E9)
                ) {
                    Text(
                        text = "Resolution Notes: ${alert.resolutionNotes}",
                        fontSize = 11.sp,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            if (!alert.isResolved) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onResolve,
                    modifier = Modifier.fillMaxWidth().testTag("resolve_alert_btn_${alert.id}"),
                    colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Investigate & Resolve Alert", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
