package com.example.features.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.localization.AppLanguage
import com.example.core.localization.LanguageManager
import com.example.core.model.EmergencyContact
import com.example.core.model.UserProfile
import com.example.data.repositories.AuthRepository
import com.example.data.repositories.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileUiState(
    val user: UserProfile? = null,
    val isLoading: Boolean = false,
    val isEditing: Boolean = false,
    val editFullName: String = "",
    val editPhone: String = "",
    val editAddress: String = "",
    val editEmerName: String = "",
    val editEmerPhone: String = "",
    val editEmerRelation: String = "",
    val changePassOld: String = "",
    val changePassNew: String = "",
    val showChangePassDialog: Boolean = false,
    val changePassError: String? = null,
    val changePassSuccess: Boolean = false,
    val showLanguageDialog: Boolean = false,
    val message: String? = null
)

class ProfileViewModel(
    private val authRepository: AuthRepository,
    private val languageManager: LanguageManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState(user = authRepository.currentUser.value))
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                _uiState.update {
                    it.copy(
                        user = user,
                        editFullName = user?.fullName ?: "",
                        editPhone = user?.phoneNumber ?: "",
                        editAddress = user?.address ?: "",
                        editEmerName = user?.emergencyContact?.name ?: "",
                        editEmerPhone = user?.emergencyContact?.phoneNumber ?: "",
                        editEmerRelation = user?.emergencyContact?.relationship ?: ""
                    )
                }
            }
        }
    }

    fun startEditing() {
        val u = _uiState.value.user ?: return
        _uiState.update {
            it.copy(
                isEditing = true,
                editFullName = u.fullName,
                editPhone = u.phoneNumber,
                editAddress = u.address,
                editEmerName = u.emergencyContact.name,
                editEmerPhone = u.emergencyContact.phoneNumber,
                editEmerRelation = u.emergencyContact.relationship
            )
        }
    }

    fun cancelEditing() {
        _uiState.update { it.copy(isEditing = false, message = null) }
    }

    fun onEditNameChange(v: String) = _uiState.update { it.copy(editFullName = v) }
    fun onEditPhoneChange(v: String) = _uiState.update { it.copy(editPhone = v) }
    fun onEditAddressChange(v: String) = _uiState.update { it.copy(editAddress = v) }
    fun onEditEmerNameChange(v: String) = _uiState.update { it.copy(editEmerName = v) }
    fun onEditEmerPhoneChange(v: String) = _uiState.update { it.copy(editEmerPhone = v) }
    fun onEditEmerRelationChange(v: String) = _uiState.update { it.copy(editEmerRelation = v) }

    fun saveProfile() {
        val current = _uiState.value.user ?: return
        val updated = current.copy(
            fullName = _uiState.value.editFullName.trim(),
            phoneNumber = _uiState.value.editPhone.trim(),
            address = _uiState.value.editAddress.trim(),
            emergencyContact = EmergencyContact(
                name = _uiState.value.editEmerName.trim(),
                phoneNumber = _uiState.value.editEmerPhone.trim(),
                relationship = _uiState.value.editEmerRelation.trim()
            )
        )

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val res = authRepository.updateProfile(updated)
            when (res) {
                is AuthResult.Success -> {
                    _uiState.update { it.copy(isLoading = false, isEditing = false, message = "Profile updated successfully") }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, message = res.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun showChangePasswordDialog() = _uiState.update { it.copy(showChangePassDialog = true, changePassError = null, changePassSuccess = false, changePassOld = "", changePassNew = "") }
    fun hideChangePasswordDialog() = _uiState.update { it.copy(showChangePassDialog = false) }
    fun onChangePassOld(v: String) = _uiState.update { it.copy(changePassOld = v, changePassError = null) }
    fun onChangePassNew(v: String) = _uiState.update { it.copy(changePassNew = v, changePassError = null) }

    fun submitChangePassword() {
        val oldP = _uiState.value.changePassOld
        val newP = _uiState.value.changePassNew
        if (oldP.isBlank() || newP.isBlank()) {
            _uiState.update { it.copy(changePassError = "Both fields are required") }
            return
        }

        viewModelScope.launch {
            val res = authRepository.changePassword(oldP, newP)
            when (res) {
                is AuthResult.Success -> {
                    _uiState.update { it.copy(changePassSuccess = true, changePassError = null) }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(changePassError = res.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun showLanguageDialog() = _uiState.update { it.copy(showLanguageDialog = true) }
    fun hideLanguageDialog() = _uiState.update { it.copy(showLanguageDialog = false) }

    fun selectLanguage(lang: AppLanguage) {
        languageManager.setLanguage(lang)
        hideLanguageDialog()
    }

    fun logout(onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            authRepository.logout()
            onLoggedOut()
        }
    }
}
