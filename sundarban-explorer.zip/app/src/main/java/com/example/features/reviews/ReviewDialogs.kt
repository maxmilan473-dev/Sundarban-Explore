package com.example.features.reviews

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Booking
import com.example.core.model.BookingStatus
import com.example.core.model.Review
import com.example.core.model.UserProfile
import com.example.core.ui.components.SundarbanTextField
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.TigerAmber
import com.example.ui.theme.TigerGold
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AddReviewDialog(
    booking: Booking,
    currentUser: UserProfile,
    onDismiss: () -> Unit,
    onSubmitReview: (rating: Int, comment: String, photoUrl: String?) -> Unit
) {
    var rating by remember { mutableStateOf(5) }
    var comment by remember { mutableStateOf("") }
    var photoUrl by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val isCompleted = booking.bookingStatus == BookingStatus.COMPLETED

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "Rate & Review Safari",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = booking.packageTitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (!isCompleted) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f)
                    ) {
                        Text(
                            text = "Reviews can only be submitted after your safari trip is marked COMPLETED.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                // Star Rating Selector
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Your Rating: $rating of 5 Stars",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TigerAmber
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 1..5) {
                            IconButton(
                                onClick = { if (isCompleted) rating = i },
                                modifier = Modifier
                                    .size(44.dp)
                                    .testTag("review_star_$i")
                            ) {
                                Icon(
                                    imageVector = if (i <= rating) Icons.Default.Star else Icons.Outlined.Star,
                                    contentDescription = "$i Stars",
                                    tint = if (i <= rating) TigerGold else MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                    }
                }

                // Review Text
                SundarbanTextField(
                    value = comment,
                    onValueChange = {
                        comment = it
                        errorMessage = null
                    },
                    label = "Your Safari Experience Review",
                    placeholder = "Describe boat condition, guide knowledge, wildlife sightings, food quality, safety, and punctuality...",
                    minLines = 4,
                    modifier = Modifier.testTag("review_comment_input")
                )

                // Optional Photo Attachment URL
                SundarbanTextField(
                    value = photoUrl,
                    onValueChange = { photoUrl = it },
                    label = "Optional Safari Photo Link / Image URL",
                    placeholder = "https://example.com/tiger_sighting.jpg",
                    leadingIcon = Icons.Default.Image
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!isCompleted) {
                        errorMessage = "Reviews require a COMPLETED safari booking."
                        return@Button
                    }
                    if (comment.trim().length < 10) {
                        errorMessage = "Please enter at least 10 characters in your review."
                        return@Button
                    }
                    onSubmitReview(
                        rating,
                        comment.trim(),
                        if (photoUrl.isNotBlank()) photoUrl.trim() else null
                    )
                    onDismiss()
                },
                enabled = isCompleted,
                colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                modifier = Modifier.testTag("submit_review_btn")
            ) {
                Text("Submit Review")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun ReviewItemCard(
    review: Review,
    isAdmin: Boolean = false,
    onModerate: ((isModerated: Boolean, reason: String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
    val dateStr = remember(review.createdAt) { dateFormat.format(Date(review.createdAt)) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("review_card_${review.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (review.isModerated) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
            else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            1.dp,
            if (review.isModerated) StatusRejected.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = review.customerName.ifBlank { "Verified Tourist" },
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    if (review.packageTitle.isNotBlank()) {
                        Text(
                            text = review.packageTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    for (i in 1..5) {
                        Icon(
                            imageVector = if (i <= review.rating) Icons.Default.Star else Icons.Outlined.Star,
                            contentDescription = null,
                            tint = if (i <= review.rating) TigerGold else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${review.rating}.0",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelMedium,
                        color = TigerAmber
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = review.comment,
                style = MaterialTheme.typography.bodyMedium
            )

            if (!review.photoUrl.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Image, contentDescription = null, modifier = Modifier.size(14.dp), tint = MangrovePrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Photo Attached", style = MaterialTheme.typography.labelSmall, color = MangrovePrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )

                if (review.isModerated) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = StatusRejected.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "Moderated / Hidden",
                            color = StatusRejected,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            if (isAdmin && onModerate != null) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (review.isModerated) {
                        TextButton(
                            onClick = { onModerate(false, "Restored by Administrator") },
                            colors = ButtonDefaults.textButtonColors(contentColor = StatusVerified)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Restore Review", fontSize = 12.sp)
                        }
                    } else {
                        OutlinedButton(
                            onClick = { onModerate(true, "Violates community guidelines or fraudulent content") },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejected),
                            border = BorderStroke(1.dp, StatusRejected.copy(alpha = 0.5f))
                        ) {
                            Icon(imageVector = Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Moderate / Hide", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
