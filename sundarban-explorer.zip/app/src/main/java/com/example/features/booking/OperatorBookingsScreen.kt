package com.example.features.booking

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Booking
import com.example.core.model.BookingStatus
import com.example.core.model.UserProfile
import com.example.core.model.UserRole
import com.example.data.repositories.TourRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperatorBookingsScreen(
    currentUser: UserProfile?,
    tourRepository: TourRepository,
    onNavigateBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val operatorId = currentUser?.id ?: "op_verified_001"

    val bookings by tourRepository.getBookingsForOperator(operatorId).collectAsState(initial = emptyList())
    var selectedTab by remember { mutableStateOf(0) }

    var bookingToDecline by remember { mutableStateOf<Booking?>(null) }
    var declineReason by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }

    var bookingForCancellationRequest by remember { mutableStateOf<Booking?>(null) }
    var bookingForDiscussion by remember { mutableStateOf<Booking?>(null) }

    val filteredBookings = remember(bookings, selectedTab) {
        when (selectedTab) {
            0 -> bookings.filter { it.bookingStatus == BookingStatus.PENDING }
            1 -> bookings.filter { it.bookingStatus == BookingStatus.ACCEPTED }
            2 -> bookings.filter {
                it.bookingStatus == BookingStatus.CONFIRMED ||
                        it.bookingStatus == BookingStatus.PAID ||
                        it.bookingStatus == BookingStatus.UPCOMING ||
                        it.bookingStatus == BookingStatus.PROCESSING
            }
            3 -> bookings.filter {
                it.bookingStatus == BookingStatus.CANCEL_REQUESTED ||
                        it.bookingStatus == BookingStatus.EMERGENCY_REVIEW ||
                        it.bookingStatus == BookingStatus.RESCHEDULE_REQUESTED ||
                        it.bookingStatus == BookingStatus.RESCHEDULED
            }
            4 -> bookings.filter { it.bookingStatus == BookingStatus.IN_PROGRESS }
            5 -> bookings.filter { it.bookingStatus == BookingStatus.COMPLETED }
            else -> bookings.filter {
                it.bookingStatus == BookingStatus.CANCELLED ||
                        it.bookingStatus == BookingStatus.REJECTED ||
                        it.bookingStatus == BookingStatus.DISPUTED
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Operator Safari Orders", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("op_bookings_back_btn")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Scrollable Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Pending (${bookings.count { it.bookingStatus == BookingStatus.PENDING }})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Accepted (${bookings.count { it.bookingStatus == BookingStatus.ACCEPTED }})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text("Confirmed (${bookings.count {
                            it.bookingStatus == BookingStatus.CONFIRMED ||
                                    it.bookingStatus == BookingStatus.PAID ||
                                    it.bookingStatus == BookingStatus.UPCOMING ||
                                    it.bookingStatus == BookingStatus.PROCESSING
                        }})")
                    }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = {
                        Text("Reviews / Cancel (${bookings.count {
                            it.bookingStatus == BookingStatus.CANCEL_REQUESTED ||
                                    it.bookingStatus == BookingStatus.EMERGENCY_REVIEW ||
                                    it.bookingStatus == BookingStatus.RESCHEDULE_REQUESTED ||
                                    it.bookingStatus == BookingStatus.RESCHEDULED
                        }})")
                    }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("Active (${bookings.count { it.bookingStatus == BookingStatus.IN_PROGRESS }})") }
                )
                Tab(
                    selected = selectedTab == 5,
                    onClick = { selectedTab = 5 },
                    text = { Text("Completed (${bookings.count { it.bookingStatus == BookingStatus.COMPLETED }})") }
                )
                Tab(
                    selected = selectedTab == 6,
                    onClick = { selectedTab = 6 },
                    text = {
                        Text("Cancelled (${bookings.count {
                            it.bookingStatus == BookingStatus.CANCELLED ||
                                    it.bookingStatus == BookingStatus.REJECTED ||
                                    it.bookingStatus == BookingStatus.DISPUTED
                        }})")
                    }
                )
            }

            if (filteredBookings.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Outlined.DirectionsBoat,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No booking orders in this section",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "New safari reservations from tourists will appear here in real-time.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filteredBookings, key = { it.id }) { booking ->
                        OperatorBookingCard(
                            booking = booking,
                            currentUser = currentUser,
                            onAccept = {
                                coroutineScope.launch {
                                    tourRepository.updateBookingStatus(
                                        bookingId = booking.id,
                                        newStatus = BookingStatus.ACCEPTED,
                                        changedByUid = currentUser?.id ?: operatorId,
                                        changedByName = currentUser?.fullName ?: "Operator",
                                        changedByRole = UserRole.OPERATOR,
                                        reason = "Vessel and guide slots confirmed. Booking request accepted."
                                    )
                                    snackbarHostState.showSnackbar("Booking ${booking.id} accepted.")
                                }
                            },
                            onDecline = {
                                bookingToDecline = booking
                                declineReason = ""
                            },
                            onStartTrip = {
                                coroutineScope.launch {
                                    tourRepository.updateBookingStatus(
                                        bookingId = booking.id,
                                        newStatus = BookingStatus.IN_PROGRESS,
                                        changedByUid = currentUser?.id ?: operatorId,
                                        changedByName = currentUser?.fullName ?: "Operator",
                                        changedByRole = UserRole.OPERATOR,
                                        reason = "Motor launch has departed from Godkhali Jetty. Safari in progress."
                                    )
                                    snackbarHostState.showSnackbar("Safari ${booking.id} is now Active.")
                                }
                            },
                            onCompleteTrip = {
                                coroutineScope.launch {
                                    tourRepository.updateBookingStatus(
                                        bookingId = booking.id,
                                        newStatus = BookingStatus.COMPLETED,
                                        changedByUid = currentUser?.id ?: operatorId,
                                        changedByName = currentUser?.fullName ?: "Operator",
                                        changedByRole = UserRole.OPERATOR,
                                        reason = "Tourists safely returned to Godkhali. Safari completed successfully."
                                    )
                                    snackbarHostState.showSnackbar("Safari ${booking.id} marked as Completed.")
                                }
                            },
                            onCancelClick = {
                                bookingForCancellationRequest = booking
                            },
                            onDiscussionClick = {
                                bookingForDiscussion = booking
                            }
                        )
                    }
                }
            }
        }
    }

    // Cancellation Request Dialog (Rules: >5h normal mutual agreement, <=5h emergency review)
    if (bookingForCancellationRequest != null) {
        val target = bookingForCancellationRequest!!
        RequestCancellationDialog(
            booking = target,
            currentUser = currentUser,
            onDismiss = { bookingForCancellationRequest = null },
            onSubmit = { reason, detailedExplanation ->
                if (currentUser == null) return@RequestCancellationDialog
                coroutineScope.launch {
                    val result = tourRepository.requestBookingCancellation(
                        bookingId = target.id,
                        initiator = currentUser,
                        reason = reason,
                        detailedExplanation = detailedExplanation
                    )
                    bookingForCancellationRequest = null
                    result.onSuccess { req ->
                        val msg = if (req.isEmergency) {
                            "🚨 Emergency cancellation submitted. Directorate Admin will review this case (< 5h remaining)."
                        } else {
                            "Cancellation request sent to tourist (> 5h remaining). Awaiting mutual agreement."
                        }
                        snackbarHostState.showSnackbar(msg)
                    }.onFailure { err ->
                        snackbarHostState.showSnackbar("Error: ${err.message}")
                    }
                }
            }
        )
    }

    // Cancellation Discussion & Dossier Dialog
    if (bookingForDiscussion != null) {
        val target = bookingForDiscussion!!
        CancellationDiscussionDialog(
            booking = target,
            currentUser = currentUser,
            onDismiss = { bookingForDiscussion = null },
            onSendMessage = { msg ->
                if (currentUser == null) return@CancellationDiscussionDialog
                coroutineScope.launch {
                    tourRepository.addCancellationDiscussionMessage(target.id, currentUser, msg)
                }
            },
            onAcceptCancellation = {
                if (currentUser == null) return@CancellationDiscussionDialog
                coroutineScope.launch {
                    val result = tourRepository.respondToCancellationRequest(
                        bookingId = target.id,
                        responder = currentUser,
                        accept = true,
                        responseNotes = "Operator agreed to cancellation."
                    )
                    bookingForDiscussion = null
                    result.onSuccess {
                        snackbarHostState.showSnackbar("Cancellation accepted. Booking cancelled and refund processed.")
                    }.onFailure { err ->
                        snackbarHostState.showSnackbar("Error: ${err.message}")
                    }
                }
            },
            onRejectCancellation = { note ->
                if (currentUser == null) return@CancellationDiscussionDialog
                coroutineScope.launch {
                    val result = tourRepository.respondToCancellationRequest(
                        bookingId = target.id,
                        responder = currentUser,
                        accept = false,
                        responseNotes = note
                    )
                    bookingForDiscussion = null
                    result.onSuccess {
                        snackbarHostState.showSnackbar("Cancellation request rejected. Booking remains confirmed.")
                    }.onFailure { err ->
                        snackbarHostState.showSnackbar("Error: ${err.message}")
                    }
                }
            }
        )
    }

    // Decline / Reject Booking Dialog
    if (bookingToDecline != null) {
        val target = bookingToDecline!!
        AlertDialog(
            onDismissRequest = { if (!isProcessing) bookingToDecline = null },
            title = { Text("Decline Booking Request ${target.id}?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Please provide a reason to the tourist:")
                    OutlinedTextField(
                        value = declineReason,
                        onValueChange = { declineReason = it },
                        label = { Text("Reason for declining *") },
                        placeholder = { Text("e.g. Vessel maintenance, high tide advisory...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (declineReason.isBlank()) return@Button
                        isProcessing = true
                        coroutineScope.launch {
                            tourRepository.updateBookingStatus(
                                bookingId = target.id,
                                newStatus = BookingStatus.REJECTED,
                                changedByUid = currentUser?.id ?: operatorId,
                                changedByName = currentUser?.fullName ?: "Operator",
                                changedByRole = UserRole.OPERATOR,
                                reason = declineReason
                            )
                            isProcessing = false
                            bookingToDecline = null
                            snackbarHostState.showSnackbar("Booking ${target.id} declined.")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    enabled = !isProcessing && declineReason.isNotBlank()
                ) {
                    Text("Decline Request")
                }
            },
            dismissButton = {
                TextButton(onClick = { bookingToDecline = null }, enabled = !isProcessing) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun OperatorBookingCard(
    booking: Booking,
    currentUser: UserProfile?,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    onStartTrip: () -> Unit,
    onCompleteTrip: () -> Unit,
    onCancelClick: () -> Unit = {},
    onDiscussionClick: () -> Unit = {}
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }

    val statusColor = when (booking.bookingStatus) {
        BookingStatus.PROCESSING -> Color(0xFFE65100)
        BookingStatus.PENDING -> Color(0xFFE65100)
        BookingStatus.ACCEPTED -> Color(0xFF1565C0)
        BookingStatus.CONFIRMED -> Color(0xFF2E7D32)
        BookingStatus.UPCOMING -> Color(0xFF1565C0)
        BookingStatus.PARTIALLY_PAID -> Color(0xFFE65100)
        BookingStatus.PAID -> Color(0xFF2E7D32)
        BookingStatus.IN_PROGRESS -> Color(0xFF6A1B9A)
        BookingStatus.TOUR_IN_PROGRESS -> Color(0xFF6A1B9A)
        BookingStatus.COMPLETED -> Color(0xFF00695C)
        BookingStatus.CANCEL_REQUESTED -> Color(0xFFD97706)
        BookingStatus.CANCELLED -> Color(0xFFC62828)
        BookingStatus.RESCHEDULE_REQUESTED -> Color(0xFF1565C0)
        BookingStatus.RESCHEDULED -> Color(0xFF00897B)
        BookingStatus.EMERGENCY_REVIEW -> Color(0xFFC62828)
        BookingStatus.REJECTED -> Color(0xFFB71C1C)
        BookingStatus.DISPUTED -> Color(0xFFAD1457)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Booking ID & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = booking.id,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    booking.refundResolutionStatus?.let { refStatus ->
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = refStatus,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    Surface(
                        color = statusColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = booking.bookingStatus.displayName.uppercase(),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Cancellation / Emergency Notices
            if (booking.bookingStatus == BookingStatus.CANCEL_REQUESTED) {
                Surface(
                    color = Color(0xFFD97706).copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Cancellation Requested (> 5h before tour)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFFD97706)
                            )
                            booking.activeCancellationRequest?.reason?.let { r ->
                                Text("Reason: $r", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        TextButton(onClick = onDiscussionClick) {
                            Text("Discuss", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            } else if (booking.bookingStatus == BookingStatus.EMERGENCY_REVIEW) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🚨 Emergency Review Escalated (≤ 5h to safari)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                            Text(
                                text = "Directorate Administration is reviewing this urgent case.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        TextButton(onClick = onDiscussionClick) {
                            Text("View Dossier", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Text(text = booking.packageTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(6.dp))

            // Tourist Info Pill
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = booking.customerName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(text = "${booking.numberOfTourists} Guests • Travel: ${booking.travelDate}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        if (booking.customerPhone.isNotBlank()) {
                            IconButton(onClick = {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${booking.customerPhone}"))
                                context.startActivity(intent)
                            }) {
                                Icon(Icons.Default.Phone, contentDescription = "Call Tourist", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Pickup: ${booking.pickupLocation}", style = MaterialTheme.typography.bodySmall)

                    if (booking.specialRequirements.isNotBlank()) {
                        Text(text = "Req: ${booking.specialRequirements}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }

                    if (booking.emergencyContact.phoneNumber.isNotBlank()) {
                        Text(
                            text = "Emergency: ${booking.emergencyContact.name} (${booking.emergencyContact.phoneNumber})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Payment & Revenue Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Payment: ${booking.paymentMethod.displayName} (${booking.paymentStatus.name})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "₹${booking.totalAmount.toInt()}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            val adminCharge = booking.totalAmount * 0.005
            val remainingAmount = booking.totalAmount - adminCharge
            val adminChargeFormatted = if (adminCharge % 1.0 == 0.0) String.format("%,.0f", adminCharge) else String.format("%,.2f", adminCharge)
            val remainingFormatted = if (remainingAmount % 1.0 == 0.0) String.format("%,.0f", remainingAmount) else String.format("%,.2f", remainingAmount)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Admin Charge (0.5%): ₹$adminChargeFormatted",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                )
                Text(
                    text = "Net Earnings: ₹$remainingFormatted",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF2E7D32)
                )
            }

            // Expandable History
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Audit Timeline (${booking.statusTimeline.size} entries)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Icon(if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null, modifier = Modifier.size(16.dp))
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    booking.statusTimeline.forEach { history ->
                        TimelineItemView(history = history, isLatest = false)
                    }
                }
            }

            // Operator Action Buttons
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (booking.bookingStatus) {
                    BookingStatus.PENDING -> {
                        OutlinedButton(
                            onClick = onDecline,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Decline", fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onAccept,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Accept Booking", fontSize = 13.sp)
                        }
                    }
                    BookingStatus.ACCEPTED, BookingStatus.CONFIRMED, BookingStatus.PAID, BookingStatus.UPCOMING, BookingStatus.PROCESSING -> {
                        OutlinedButton(
                            onClick = onCancelClick,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Cancel / Emergency", fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onStartTrip,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.DirectionsBoat, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Start Safari Launch", fontSize = 13.sp)
                        }
                    }
                    BookingStatus.CANCEL_REQUESTED -> {
                        Button(
                            onClick = onDiscussionClick,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Discuss & Respond", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    BookingStatus.EMERGENCY_REVIEW -> {
                        Button(
                            onClick = onDiscussionClick,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Directorate Review Dossier", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    BookingStatus.IN_PROGRESS -> {
                        Button(
                            onClick = onCompleteTrip,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                        ) {
                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Mark Tour Completed", fontSize = 13.sp)
                        }
                    }
                    else -> {}
                }
            }
        }
    }
}
