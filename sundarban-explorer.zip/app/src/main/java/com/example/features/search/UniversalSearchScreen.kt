package com.example.features.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.data.repositories.ContentRepository
import com.example.data.repositories.TourRepository

enum class SearchCategory(val title: String) {
    ALL("All Results"),
    OPERATORS("Operators"),
    PACKAGES("Tour Packages"),
    ARTICLES("Articles & Guides"),
    VIDEOS("Videos"),
    BOOKS("Books & Research")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UniversalSearchScreen(
    tourRepository: TourRepository,
    contentRepository: ContentRepository,
    onNavigateBack: () -> Unit,
    onSelectOperator: (String) -> Unit,
    onSelectPackage: (String) -> Unit,
    onNavigateToLibrary: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(SearchCategory.ALL) }
    var showFilterSheet by remember { mutableStateOf(false) }

    // Filters
    var verifiedOnly by remember { mutableStateOf(false) }
    var minRating by remember { mutableStateOf(0.0) }
    var maxPrice by remember { mutableStateOf(10000.0) }
    var selectedDuration by remember { mutableStateOf("All") }

    val operators by tourRepository.getVerifiedOperators().collectAsState(initial = emptyList())
    val packages by tourRepository.getPublicVerifiedPackages().collectAsState(initial = emptyList())
    val articles by contentRepository.getArticles().collectAsState(initial = emptyList())
    val videos by contentRepository.getVideos().collectAsState(initial = emptyList())
    val books by contentRepository.getBooks().collectAsState(initial = emptyList())

    val filteredOperators = remember(operators, searchQuery, verifiedOnly, minRating) {
        operators.filter { op ->
            val matchesQuery = searchQuery.isBlank() ||
                    op.name.contains(searchQuery, ignoreCase = true) ||
                    op.operatingArea.contains(searchQuery, ignoreCase = true) ||
                    op.guideExperience.contains(searchQuery, ignoreCase = true)
            val matchesVerified = !verifiedOnly || op.verifiedBadge
            val matchesRating = op.rating >= minRating

            matchesQuery && matchesVerified && matchesRating
        }
    }

    val filteredPackages = remember(packages, searchQuery, minRating, maxPrice, selectedDuration) {
        packages.filter { pkg ->
            val matchesQuery = searchQuery.isBlank() ||
                    pkg.title.contains(searchQuery, ignoreCase = true) ||
                    pkg.description.contains(searchQuery, ignoreCase = true) ||
                    pkg.destination.contains(searchQuery, ignoreCase = true) ||
                    pkg.route.contains(searchQuery, ignoreCase = true)

            val matchesRating = pkg.rating >= minRating
            val matchesPrice = pkg.pricePerPerson <= maxPrice
            val matchesDuration = when (selectedDuration) {
                "1 Day" -> pkg.durationDays == 1
                "2D/1N" -> pkg.durationDays == 2
                "3D/2N+" -> pkg.durationDays >= 3
                else -> true
            }

            matchesQuery && matchesRating && matchesPrice && matchesDuration
        }
    }

    val filteredArticles = remember(articles, searchQuery) {
        articles.filter { a ->
            searchQuery.isBlank() ||
                    a.titleEn.contains(searchQuery, ignoreCase = true) ||
                    a.summaryEn.contains(searchQuery, ignoreCase = true) ||
                    a.category.contains(searchQuery, ignoreCase = true) ||
                    a.tags.any { it.contains(searchQuery, ignoreCase = true) }
        }
    }

    val filteredVideos = remember(videos, searchQuery) {
        videos.filter { v ->
            searchQuery.isBlank() ||
                    v.titleEn.contains(searchQuery, ignoreCase = true) ||
                    v.descriptionEn.contains(searchQuery, ignoreCase = true) ||
                    v.channel.contains(searchQuery, ignoreCase = true) ||
                    v.category.contains(searchQuery, ignoreCase = true)
        }
    }

    val filteredBooks = remember(books, searchQuery) {
        books.filter { b ->
            searchQuery.isBlank() ||
                    b.titleEn.contains(searchQuery, ignoreCase = true) ||
                    b.author.contains(searchQuery, ignoreCase = true) ||
                    b.descriptionEn.contains(searchQuery, ignoreCase = true) ||
                    b.category.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Universal Sundarban Search", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("search_back_btn")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showFilterSheet = true }, modifier = Modifier.testTag("search_filters_btn")) {
                        Icon(Icons.Default.Tune, contentDescription = "Search Filters")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Input Field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("universal_search_input"),
                placeholder = { Text("Search operators, packages, tigers, watchtowers...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Category Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(SearchCategory.values()) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat.title) }
                    )
                }
            }

            // Results List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Section: Operators
                if (selectedCategory == SearchCategory.ALL || selectedCategory == SearchCategory.OPERATORS) {
                    if (filteredOperators.isNotEmpty()) {
                        item {
                            SearchSectionHeader(
                                title = "Verified Operators (${filteredOperators.size})",
                                icon = Icons.Default.DirectionsBoat
                            )
                        }

                        items(filteredOperators) { op ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectOperator(op.operatorId) },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(text = op.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                            if (op.verifiedBadge) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(Icons.Default.Verified, contentDescription = "Verified", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                        Text(text = "${op.experienceYears} Yrs Exp • ${op.operatingArea}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    }
                                    Text(text = "₹${op.startingPrice.toInt()}/p", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }

                // Section: Tour Packages
                if (selectedCategory == SearchCategory.ALL || selectedCategory == SearchCategory.PACKAGES) {
                    if (filteredPackages.isNotEmpty()) {
                        item {
                            SearchSectionHeader(
                                title = "Tour Packages (${filteredPackages.size})",
                                icon = Icons.Default.Explore
                            )
                        }

                        items(filteredPackages) { pkg ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectPackage(pkg.id) },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(text = pkg.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        Text(text = "₹${pkg.pricePerPerson.toInt()}/p", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "${pkg.durationText} • ${pkg.destination}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                // Section: Articles
                if (selectedCategory == SearchCategory.ALL || selectedCategory == SearchCategory.ARTICLES) {
                    if (filteredArticles.isNotEmpty()) {
                        item {
                            SearchSectionHeader(
                                title = "Articles & Guides (${filteredArticles.size})",
                                icon = Icons.Default.Article
                            )
                        }

                        items(filteredArticles) { art ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onNavigateToLibrary() },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = art.category,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = art.titleEn, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = art.summaryEn, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                                }
                            }
                        }
                    }
                }

                // Section: Videos
                if (selectedCategory == SearchCategory.ALL || selectedCategory == SearchCategory.VIDEOS) {
                    if (filteredVideos.isNotEmpty()) {
                        item {
                            SearchSectionHeader(
                                title = "Videos (${filteredVideos.size})",
                                icon = Icons.Default.Videocam
                            )
                        }

                        items(filteredVideos) { vid ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onNavigateToLibrary() },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(text = vid.titleEn, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "${vid.channel} • ${vid.durationText}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                // Section: Books
                if (selectedCategory == SearchCategory.ALL || selectedCategory == SearchCategory.BOOKS) {
                    if (filteredBooks.isNotEmpty()) {
                        item {
                            SearchSectionHeader(
                                title = "Digital Books (${filteredBooks.size})",
                                icon = Icons.Default.AutoStories
                            )
                        }

                        items(filteredBooks) { book ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onNavigateToLibrary() },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(text = book.titleEn, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "By ${book.author} • ${book.pageCount} pages", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                // Empty State
                if (filteredOperators.isEmpty() && filteredPackages.isEmpty() && filteredArticles.isEmpty() && filteredVideos.isEmpty() && filteredBooks.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Outlined.SearchOff, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("No results found for \"$searchQuery\"", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Try different search keywords or adjust filters.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }

    // Filter Sheet
    if (showFilterSheet) {
        ModalBottomSheet(onDismissRequest = { showFilterSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Search & Discovery Filters", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

                // Verified Only Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Verified Operators Only", style = MaterialTheme.typography.titleSmall)
                    Switch(checked = verifiedOnly, onCheckedChange = { verifiedOnly = it })
                }

                // Minimum Rating
                Text("Minimum Rating: ${if (minRating == 0.0) "Any" else "$minRating+ ★"}", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.0, 4.0, 4.5, 4.8).forEach { r ->
                        FilterChip(
                            selected = minRating == r,
                            onClick = { minRating = r },
                            label = { Text(if (r == 0.0) "All" else "$r+ ★") }
                        )
                    }
                }

                // Tour Duration
                Text("Tour Duration", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("All", "1 Day", "2D/1N", "3D/2N+").forEach { d ->
                        FilterChip(
                            selected = selectedDuration == d,
                            onClick = { selectedDuration = d },
                            label = { Text(d) }
                        )
                    }
                }

                // Max Price
                Text("Max Price per person: ₹${maxPrice.toInt()}", style = MaterialTheme.typography.titleSmall)
                Slider(
                    value = maxPrice.toFloat(),
                    onValueChange = { maxPrice = it.toDouble() },
                    valueRange = 1000f..15000f,
                    steps = 14
                )

                Button(
                    onClick = { showFilterSheet = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Apply Search Filters")
                }
            }
        }
    }
}

@Composable
fun SearchSectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}
