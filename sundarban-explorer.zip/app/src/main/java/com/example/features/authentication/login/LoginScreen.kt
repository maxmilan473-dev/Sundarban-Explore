package com.example.features.authentication.login

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.localization.AppLanguage
import com.example.core.localization.LocalAppStrings
import com.example.core.model.UserProfile
import com.example.core.model.UserRole
import com.example.core.ui.components.LanguageSelectorDialog
import com.example.core.ui.components.SundarbanButton
import com.example.core.ui.components.SundarbanTextField
import com.example.ui.theme.MangroveDark
import com.example.ui.theme.MangroveMedium
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusAdmin
import com.example.ui.theme.TigerAmber
import com.example.ui.theme.TigerGold

@Composable
fun LoginScreen(
    viewModel: LoginViewModel,
    onLoginSuccess: (UserProfile) -> Unit,
    onNavigateToCustomerSignUp: () -> Unit,
    onNavigateToOperatorSignUp: () -> Unit,
    onNavigateToForgotPassword: () -> Unit,
    currentLanguage: AppLanguage,
    onLanguageSelected: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val state by viewModel.uiState.collectAsState()
    var showLanguageDialog by remember { mutableStateOf(false) }

    if (showLanguageDialog) {
        LanguageSelectorDialog(
            currentLanguage = currentLanguage,
            onLanguageSelected = onLanguageSelected,
            onDismiss = { showLanguageDialog = false }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("login_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Language Switcher Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { showLanguageDialog = true }
                        .testTag("login_language_button"),
                    color = MangrovePrimary.copy(alpha = 0.08f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = MangrovePrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = currentLanguage.nativeName,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MangrovePrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Emblem / Branding
            Surface(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape),
                color = MangrovePrimary.copy(alpha = 0.1f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(id = R.drawable.img_sundarban_icon),
                        contentDescription = "Sundarban Explorer Emblem",
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = strings.appName,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MangroveDark
            )

            Text(
                text = strings.tagline,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Role Selector Tabs (Tourist, Tour Operator, Admin)
            Text(
                text = strings.selectRole,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            val roles = listOf(UserRole.CUSTOMER, UserRole.OPERATOR, UserRole.ADMIN)
            val selectedTabIndex = roles.indexOf(state.selectedRole).coerceAtLeast(0)

            TabRow(
                selectedTabIndex = selectedTabIndex,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .testTag("role_tab_row"),
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = when (state.selectedRole) {
                            UserRole.CUSTOMER -> MangrovePrimary
                            UserRole.OPERATOR -> TigerAmber
                            UserRole.ADMIN -> StatusAdmin
                        }
                    )
                }
            ) {
                roles.forEachIndexed { index, role ->
                    val isSelected = state.selectedRole == role
                    Tab(
                        selected = isSelected,
                        onClick = { viewModel.onRoleChanged(role) },
                        modifier = Modifier.testTag("role_tab_${role.name.lowercase()}"),
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = when (role) {
                                        UserRole.CUSTOMER -> Icons.Default.Person
                                        UserRole.OPERATOR -> Icons.Default.DirectionsBoat
                                        UserRole.ADMIN -> Icons.Default.AdminPanelSettings
                                    },
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (isSelected) {
                                        when (role) {
                                            UserRole.CUSTOMER -> MangrovePrimary
                                            UserRole.OPERATOR -> TigerAmber
                                            UserRole.ADMIN -> StatusAdmin
                                        }
                                    } else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = when (role) {
                                        UserRole.CUSTOMER -> "Tourist"
                                        UserRole.OPERATOR -> "Operator"
                                        UserRole.ADMIN -> "Admin"
                                    },
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) {
                                        when (role) {
                                            UserRole.CUSTOMER -> MangrovePrimary
                                            UserRole.OPERATOR -> TigerAmber
                                            UserRole.ADMIN -> StatusAdmin
                                        }
                                    } else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Error Banner if any
            if (state.errorMessage != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .testTag("login_error_banner"),
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = state.errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            // Input Fields
            SundarbanTextField(
                value = state.email,
                onValueChange = { viewModel.onEmailChanged(it) },
                label = "Email / Mobile Number",
                placeholder = "e.g. user@example.com or 9831012345",
                leadingIcon = if (state.email.any { it.isDigit() } && !state.email.contains("@")) Icons.Default.Phone else Icons.Default.Email,
                errorMessage = state.emailError,
                testTag = "login_email_input"
            )

            Spacer(modifier = Modifier.height(14.dp))

            SundarbanTextField(
                value = state.password,
                onValueChange = { viewModel.onPasswordChanged(it) },
                label = strings.password,
                leadingIcon = Icons.Default.Lock,
                isPassword = true,
                errorMessage = state.passwordError,
                testTag = "login_password_input"
            )

            // Forgot Password Link
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = onNavigateToForgotPassword,
                    modifier = Modifier.testTag("login_forgot_password_button")
                ) {
                    Text(
                        text = strings.forgotPassword,
                        style = MaterialTheme.typography.labelMedium,
                        color = MangroveMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sign In Button
            SundarbanButton(
                text = strings.login,
                onClick = { viewModel.login(onLoginSuccess) },
                isLoading = state.isLoading,
                testTag = "login_submit_button"
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Quick Demo Credentials for Fast Testing
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "⚡ Instant Demo Sign-In (One-Tap Test)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MangrovePrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { viewModel.quickFillDemo(UserRole.CUSTOMER) }
                                .testTag("quick_fill_tourist"),
                            color = MangrovePrimary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "👤 Tourist\n(Customer ID)",
                                modifier = Modifier.padding(vertical = 6.dp),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MangrovePrimary
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { viewModel.quickFillDemo(UserRole.OPERATOR) }
                                .testTag("quick_fill_operator"),
                            color = TigerAmber.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "🚤 Operator\n(Application)",
                                modifier = Modifier.padding(vertical = 6.dp),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = TigerAmber
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1.1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { viewModel.quickFillSuperAdmin() }
                                .testTag("quick_fill_super_admin"),
                            color = Color(0xFF673AB7).copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "👑 Super Admin\n(Creator)",
                                modifier = Modifier.padding(vertical = 6.dp),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF512DA8)
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { viewModel.quickFillStandardAdmin() }
                                .testTag("quick_fill_admin"),
                            color = StatusAdmin.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "🛡️ Admin\n(Staff)",
                                modifier = Modifier.padding(vertical = 6.dp),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusAdmin
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Registration navigation links & Security Access Policy
            if (state.selectedRole == UserRole.ADMIN) {
                // Public Signup: Admin ID ❌ (Forbidden) - Admin Creation: Super Admin Only ✅
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_signup_restricted_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Public Signup: Admin ID ❌ (Restricted)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Admin Creation: Super Admin Only ✅\nPublic self-registration is strictly disabled for Admin accounts. New Admin credentials can only be created and authorized from the Super Admin Console.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            TextButton(
                                onClick = onNavigateToCustomerSignUp,
                                modifier = Modifier.testTag("admin_redirect_customer_signup")
                            ) {
                                Text(
                                    text = "Customer ID ✅",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MangrovePrimary
                                )
                            }
                            TextButton(
                                onClick = onNavigateToOperatorSignUp,
                                modifier = Modifier.testTag("admin_redirect_operator_signup")
                            ) {
                                Text(
                                    text = "Operator ID Application ✅",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TigerAmber
                                )
                            }
                        }
                    }
                }
            } else if (state.selectedRole == UserRole.OPERATOR) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TextButton(
                        onClick = onNavigateToOperatorSignUp,
                        modifier = Modifier.testTag("login_operator_signup_link")
                    ) {
                        Text(
                            text = "Public Signup: Operator ID Application ✅ (Apply Here)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TigerAmber,
                            textAlign = TextAlign.Center
                        )
                    }
                    TextButton(
                        onClick = onNavigateToCustomerSignUp,
                        modifier = Modifier.testTag("login_switch_to_customer_signup")
                    ) {
                        Text(
                            text = "Tourist? Register for Customer ID ✅",
                            style = MaterialTheme.typography.bodySmall,
                            color = MangrovePrimary
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TextButton(
                        onClick = onNavigateToCustomerSignUp,
                        modifier = Modifier.testTag("login_customer_signup_link")
                    ) {
                        Text(
                            text = "Public Signup: Customer ID ✅ (Register Here)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MangrovePrimary,
                            textAlign = TextAlign.Center
                        )
                    }
                    TextButton(
                        onClick = onNavigateToOperatorSignUp,
                        modifier = Modifier.testTag("login_switch_to_operator_signup")
                    ) {
                        Text(
                            text = "Tour Operator? Operator ID Application ✅",
                            style = MaterialTheme.typography.bodySmall,
                            color = TigerAmber
                        )
                    }
                }
            }
        }
    }
}
