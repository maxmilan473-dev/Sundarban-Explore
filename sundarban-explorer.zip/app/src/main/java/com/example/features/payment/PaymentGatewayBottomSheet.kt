package com.example.features.payment

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Booking
import com.example.core.model.PaymentGatewayMethod
import com.example.core.model.PaymentTransaction
import com.example.core.model.UserProfile
import com.example.data.repositories.TourRepository
import com.example.ui.theme.ForestDarkest
import com.example.ui.theme.MangrovePrimary
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.TigerAmber
import com.example.ui.theme.TigerGold
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

enum class PaymentStep {
    SELECT_METHOD,
    INPUT_DETAILS,
    SERVER_PROCESSING,
    SUCCESS_RECEIPT,
    FAILURE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentGatewayBottomSheet(
    booking: Booking,
    amountToPay: Double,
    currentUser: UserProfile,
    tourRepository: TourRepository,
    onDismiss: () -> Unit,
    onPaymentCompleted: (PaymentTransaction) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    var currentStep by remember { mutableStateOf(PaymentStep.SELECT_METHOD) }
    var selectedMethod by remember { mutableStateOf(PaymentGatewayMethod.UPI) }

    // UPI states
    var selectedUpiApp by remember { mutableStateOf("Google Pay") }
    var customVpa by remember { mutableStateOf(if (currentUser.email.isNotBlank()) "${currentUser.email.substringBefore("@")}@okaxis" else "tourist@upi") }

    // Card states (Never stored raw, only simulated client tokenization)
    var cardNumber by remember { mutableStateOf("4532 •••• •••• 8892") }
    var cardExpiry by remember { mutableStateOf("11/29") }
    var cardCvv by remember { mutableStateOf("•••") }
    var cardHolder by remember { mutableStateOf(currentUser.fullName.ifBlank { "Tourist Name" }) }

    // Net banking states
    var selectedBank by remember { mutableStateOf("State Bank of India (SBI)") }

    var isProcessing by remember { mutableStateOf(false) }
    var processingStatusMessage by remember { mutableStateOf("Connecting to Secure Payment Gateway...") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var completedTransaction by remember { mutableStateOf<PaymentTransaction?>(null) }

    val idempotencyKey = remember { "idemp_${booking.id}_${System.currentTimeMillis()}" }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Security Badge Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFE8F5E9))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "256-bit SSL Secure",
                    tint = StatusVerified,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Sundarban Gateway Escrow • 256-Bit SSL Encrypted",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B5E20)
                    )
                    Text(
                        text = "Server-Side HMAC Verified • Direct RBI-Compliant Routing",
                        fontSize = 10.sp,
                        color = Color(0xFF2E7D32)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Order Summary Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Booking Ref: ${booking.id}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = booking.packageTitle,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Amount Payable",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "₹${String.format("%,.0f", amountToPay)}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = ForestDarkest
                            )
                            val adminCharge = amountToPay * 0.005
                            val adminChargeFormatted = if (adminCharge % 1.0 == 0.0) String.format("%,.0f", adminCharge) else String.format("%,.2f", adminCharge)
                            Text(
                                text = "Admin Charge (0.5%): ₹$adminChargeFormatted",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            when (currentStep) {
                PaymentStep.SELECT_METHOD -> {
                    Text(
                        text = "Select Indian Payment Method",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // UPI Method
                    PaymentMethodSelectCard(
                        title = "UPI (Instant 0% Convenience Fee)",
                        subtitle = "Google Pay, PhonePe, Paytm, BHIM or any UPI ID",
                        icon = Icons.Default.QrCodeScanner,
                        isSelected = selectedMethod == PaymentGatewayMethod.UPI,
                        onClick = { selectedMethod = PaymentGatewayMethod.UPI }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Card Method
                    PaymentMethodSelectCard(
                        title = "Credit / Debit Cards",
                        subtitle = "Visa, Mastercard, RuPay & Corporate Cards",
                        icon = Icons.Default.CreditCard,
                        isSelected = selectedMethod == PaymentGatewayMethod.CREDIT_CARD || selectedMethod == PaymentGatewayMethod.DEBIT_CARD,
                        onClick = { selectedMethod = PaymentGatewayMethod.CREDIT_CARD }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Net Banking
                    PaymentMethodSelectCard(
                        title = "Net Banking (All Indian Banks)",
                        subtitle = "SBI, HDFC, ICICI, Axis, PNB, Bank of Baroda",
                        icon = Icons.Default.AccountBalance,
                        isSelected = selectedMethod == PaymentGatewayMethod.NET_BANKING,
                        onClick = { selectedMethod = PaymentGatewayMethod.NET_BANKING }
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = { currentStep = PaymentStep.INPUT_DETAILS },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("proceed_to_payment_details_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Proceed to Pay ₹${String.format("%,.0f", amountToPay)}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                PaymentStep.INPUT_DETAILS -> {
                    when (selectedMethod) {
                        PaymentGatewayMethod.UPI -> {
                            Text(
                                text = "Choose Fast UPI Option",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Google Pay", "PhonePe", "Paytm", "BHIM").forEach { app ->
                                    val isAppSelected = selectedUpiApp == app
                                    Surface(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { selectedUpiApp = app },
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(
                                            width = if (isAppSelected) 2.dp else 1.dp,
                                            color = if (isAppSelected) MangrovePrimary else MaterialTheme.colorScheme.outlineVariant
                                        ),
                                        color = if (isAppSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
                                    ) {
                                        Text(
                                            text = app,
                                            fontSize = 12.sp,
                                            fontWeight = if (isAppSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isAppSelected) MangrovePrimary else MaterialTheme.colorScheme.onSurface,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedTextField(
                                value = customVpa,
                                onValueChange = { customVpa = it },
                                label = { Text("UPI ID / Virtual Payment Address (VPA)") },
                                placeholder = { Text("e.g. mobile@upi or username@okaxis") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("upi_id_input"),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                        }

                        PaymentGatewayMethod.CREDIT_CARD, PaymentGatewayMethod.DEBIT_CARD -> {
                            Text(
                                text = "Card Information (RBI Tokenized)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = cardNumber,
                                onValueChange = { cardNumber = it },
                                label = { Text("Card Number") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = cardExpiry,
                                    onValueChange = { cardExpiry = it },
                                    label = { Text("Expiry (MM/YY)") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = cardCvv,
                                    onValueChange = { cardCvv = it },
                                    label = { Text("CVV") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                    singleLine = true
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = cardHolder,
                                onValueChange = { cardHolder = it },
                                label = { Text("Cardholder Name") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                        }

                        PaymentGatewayMethod.NET_BANKING -> {
                            Text(
                                text = "Select Popular Net Banking Bank",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            val banks = listOf(
                                "State Bank of India (SBI)",
                                "HDFC Bank",
                                "ICICI Bank",
                                "Axis Bank",
                                "Punjab National Bank (PNB)",
                                "Bank of Baroda"
                            )

                            banks.forEach { bank ->
                                val isSelected = selectedBank == bank
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { selectedBank = bank }
                                        .padding(vertical = 8.dp, horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { selectedBank = bank }
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = bank,
                                        fontSize = 14.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                        else -> {}
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { currentStep = PaymentStep.SELECT_METHOD },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Back")
                        }

                        Button(
                            onClick = {
                                currentStep = PaymentStep.SERVER_PROCESSING
                                isProcessing = true
                                scope.launch {
                                    try {
                                        // Step 1: Request backend order creation
                                        processingStatusMessage = "1/4: Initializing Secure Gateway Order..."
                                        val orderResult = tourRepository.createPaymentOrder(
                                            bookingId = booking.id,
                                            amount = amountToPay,
                                            method = selectedMethod,
                                            payer = currentUser,
                                            idempotencyKey = idempotencyKey
                                        )

                                        if (orderResult.isFailure) {
                                            errorMessage = orderResult.exceptionOrNull()?.message ?: "Order creation failed"
                                            currentStep = PaymentStep.FAILURE
                                            isProcessing = false
                                            return@launch
                                        }

                                        val createdTxn = orderResult.getOrThrow()
                                        delay(800)

                                        // Step 2: Gateway challenge & user authentication simulation
                                        processingStatusMessage = "2/4: Authorizing through $selectedMethod..."
                                        delay(900)

                                        // Step 3: Server-side cryptographic signature verification
                                        processingStatusMessage = "3/4: Server-Side HMAC Verification..."
                                        val mockGatewayPaymentId = "pay_rzp_live_${UUID.randomUUID().toString().take(10)}"
                                        val mockSignature = "sig_hmac_sha256_${UUID.randomUUID().toString().take(12)}"

                                        val verifyResult = tourRepository.verifyAndProcessOnlinePayment(
                                            transactionId = createdTxn.transactionId,
                                            gatewayOrderId = createdTxn.gatewayOrderId ?: "order_mock",
                                            gatewayPaymentId = mockGatewayPaymentId,
                                            gatewaySignature = mockSignature,
                                            idempotencyKey = idempotencyKey
                                        )

                                        if (verifyResult.isFailure) {
                                            errorMessage = verifyResult.exceptionOrNull()?.message ?: "Verification failed"
                                            currentStep = PaymentStep.FAILURE
                                            isProcessing = false
                                            return@launch
                                        }

                                        // Step 4: Finalize & dispatch audit updates
                                        processingStatusMessage = "4/4: Booking Confirmed & Permits Updated!"
                                        val verifiedTxn = verifyResult.getOrThrow()
                                        delay(600)

                                        completedTransaction = verifiedTxn
                                        currentStep = PaymentStep.SUCCESS_RECEIPT
                                        isProcessing = false
                                        onPaymentCompleted(verifiedTxn)
                                    } catch (e: Exception) {
                                        errorMessage = e.message ?: "An unexpected error occurred during payment processing"
                                        currentStep = PaymentStep.FAILURE
                                        isProcessing = false
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1.5f)
                                .height(50.dp)
                                .testTag("authorize_payment_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Authorize ₹${String.format("%,.0f", amountToPay)}",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                PaymentStep.SERVER_PROCESSING -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(54.dp),
                            color = MangrovePrimary,
                            strokeWidth = 4.dp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "Processing Secure Payment",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = processingStatusMessage,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Please do not press back or refresh while server verification is in progress.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                PaymentStep.SUCCESS_RECEIPT -> {
                    val txn = completedTransaction
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE8F5E9)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Success",
                                tint = StatusVerified,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Payment Verified Successfully!",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )

                        Text(
                            text = "₹${String.format("%,.0f", amountToPay)} credited towards safari booking",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Receipt Summary Card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                ReceiptRow(label = "Transaction ID", value = txn?.transactionId ?: "TXN_PROCESSED")
                                ReceiptRow(label = "Gateway Ref", value = txn?.gatewayPaymentId ?: "pay_rzp_live")
                                ReceiptRow(label = "Payment Method", value = txn?.method?.displayName ?: selectedMethod.displayName)
                                ReceiptRow(label = "Date & Time", value = "${txn?.formattedDate} ${txn?.formattedTime}")
                                ReceiptRow(label = "Payer", value = currentUser.fullName)
                                ReceiptRow(label = "Operator", value = booking.operatorName)
                                ReceiptRow(label = "Status", value = "SUCCESS (HMAC Verified)", isSuccess = true)
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("done_payment_receipt_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("View Updated Booking & Invoice", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                PaymentStep.FAILURE -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Payment Failed",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Payment Verification Failed",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage ?: "The payment gateway rejected the transaction or signature verification failed.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Cancel")
                            }
                            Button(
                                onClick = { currentStep = PaymentStep.SELECT_METHOD },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MangrovePrimary),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Retry Payment")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PaymentMethodSelectCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) MangrovePrimary else MaterialTheme.colorScheme.outlineVariant
        ),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) MangrovePrimary else MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            RadioButton(
                selected = isSelected,
                onClick = onClick
            )
        }
    }
}

@Composable
fun ReceiptRow(
    label: String,
    value: String,
    isSuccess: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = if (isSuccess) FontWeight.Bold else FontWeight.Medium,
            color = if (isSuccess) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurface,
            fontFamily = if (label.contains("ID") || label.contains("Ref")) FontFamily.Monospace else FontFamily.Default
        )
    }
}
