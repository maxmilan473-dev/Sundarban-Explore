package com.example.features.operator

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.localization.LocalAppStrings
import com.example.core.model.*
import com.example.core.ui.components.EmptyStateView
import com.example.core.ui.components.SundarbanTextField
import com.example.data.repositories.AuthRepository
import com.example.data.repositories.TourRepository
import com.example.features.complaints.FileComplaintDialog
import com.example.features.disputes.DisputeDetailDialog
import com.example.features.reviews.ReviewItemCard
import com.example.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class OperatorViewModel(
    val authRepository: AuthRepository,
    val tourRepository: TourRepository
) : ViewModel() {

    val currentUser = authRepository.currentUser

    val myPackages = currentUser.flatMapLatest { user ->
        if (user != null) tourRepository.getPackagesForOperator(user.uid)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val myBookings = currentUser.flatMapLatest { user ->
        if (user != null) tourRepository.getBookingsForOperator(user.uid)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val myDisputes = currentUser.flatMapLatest { user ->
        if (user != null) tourRepository.getDisputesForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val myReviews = currentUser.flatMapLatest { user ->
        if (user != null) tourRepository.getReviewsForOperator(user.uid)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _createSuccess = MutableStateFlow(false)
    val createSuccess = _createSuccess.asStateFlow()

    fun createPackage(
        title: String,
        description: String,
        durationDays: Int,
        durationNights: Int,
        price: Double,
        maxGuests: Int,
        departure: String,
        destinations: List<String>,
        inclusions: List<String>
    ) {
        val user = currentUser.value ?: return
        val isVerified = user.operatorDetails?.verificationStatus == OperatorStatus.VERIFIED ||
                         user.operatorDetails?.verificationStatus == OperatorStatus.AUTOMATICALLY_VERIFIED ||
                         user.isVerified

        val newPackage = TourPackage(
            id = "",
            operatorId = user.uid,
            operatorName = user.fullName,
            operatorPhone = user.phoneNumber,
            isOperatorVerified = isVerified,
            title = title,
            description = description,
            durationDays = durationDays,
            durationNights = durationNights,
            pricePerPerson = price,
            price = price,
            maxTourists = maxGuests,
            startingLocation = departure,
            destinations = destinations,
            includedServices = inclusions,
            route = "$departure -> ${destinations.joinToString(" -> ")}",
            destination = destinations.firstOrNull() ?: "Sundarban Tiger Reserve",
            rating = 5.0,
            reviewCount = 1
        )

        viewModelScope.launch {
            tourRepository.createPackage(newPackage)
            _createSuccess.value = true
        }
    }

    fun deletePackage(packageId: String, onResult: (Boolean, String) -> Unit) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val res = tourRepository.deletePackage(packageId, user.uid)
            if (res.isSuccess) {
                onResult(true, "Package deleted successfully")
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Failed to delete package")
            }
        }
    }

    fun fileComplaint(
        targetId: String,
        targetName: String,
        category: ComplaintCategory,
        subject: String,
        description: String,
        evidence: List<String>
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val complaint = Complaint(
                id = "CMP-${System.currentTimeMillis().toString().takeLast(6)}",
                complaintId = "CMP-${System.currentTimeMillis().toString().takeLast(6)}",
                complainantId = user.id,
                complainantName = user.fullName,
                complainantRole = UserRole.OPERATOR,
                targetId = targetId,
                targetName = targetName,
                targetRole = UserRole.CUSTOMER,
                category = category,
                subject = subject,
                description = description,
                evidenceUrls = evidence,
                status = ComplaintStatus.OPEN
            )
            tourRepository.fileComplaint(complaint, user)
        }
    }

    fun sendDisputeMessage(disputeId: String, message: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            tourRepository.addDisputeMessage(disputeId, message, null, user)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperatorDashboardScreen(
    viewModel: OperatorViewModel,
    onNavigateToProfile: () -> Unit,
    onNavigateToEarnings: () -> Unit = {},
    onNavigateToPackages: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val user by viewModel.currentUser.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val packages by viewModel.myPackages.collectAsState()
    val bookings by viewModel.myBookings.collectAsState()
    val disputes by viewModel.myDisputes.collectAsState()
    val reviews by viewModel.myReviews.collectAsState()
    val opStatus = user?.operatorDetails?.verificationStatus
    val isAutoVerified = opStatus == OperatorStatus.AUTOMATICALLY_VERIFIED
    val isVerified = opStatus == OperatorStatus.VERIFIED || isAutoVerified || (user?.isVerified == true)
    val isReviewRequired = opStatus == OperatorStatus.REQUIRES_ADMIN_REVIEW

    var selectedTab by remember { mutableIntStateOf(0) }
    var showCreatePackageModal by remember { mutableStateOf(false) }
    var showComplaintModal by remember { mutableStateOf(false) }
    var selectedDisputeForDetail by remember { mutableStateOf<DisputeRecord?>(null) }
    var packageToDelete by remember { mutableStateOf<TourPackage?>(null) }

    // Delete Package Confirmation Dialog
    if (packageToDelete != null) {
        val targetPkg = packageToDelete!!
        AlertDialog(
            onDismissRequest = { packageToDelete = null },
            icon = {
                Icon(
                    Icons.Default.DeleteOutline,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text("Delete Tour Package?", fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        text = "Are you sure you want to delete \"${targetPkg.title}\"?",
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Package Management Rule:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Editing existing packages is not permitted. When you need to change information in an existing package, you must delete this package and create a new package.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pkgId = targetPkg.id
                        val title = targetPkg.title
                        packageToDelete = null
                        viewModel.deletePackage(pkgId) { success, msg ->
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar(if (success) "Package \"$title\" deleted successfully." else msg)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("op_confirm_delete_pkg_btn")
                ) {
                    Text("Delete Package")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { packageToDelete = null },
                    modifier = Modifier.testTag("op_cancel_delete_pkg_btn")
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Create Package Dialog
    if (showCreatePackageModal) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var days by remember { mutableStateOf("2") }
        var nights by remember { mutableStateOf("1") }
        var price by remember { mutableStateOf("4500") }
        var guests by remember { mutableStateOf("12") }
        var departure by remember { mutableStateOf("Godkhali Ferry Ghat") }
        var destinationsText by remember { mutableStateOf("Sajnekhali, Sudhanyakhali, Dobanki") }
        var inclusionsText by remember { mutableStateOf("Govt Permits, Guide, Traditional Meals, Life Jackets") }

        AlertDialog(
            onDismissRequest = { showCreatePackageModal = false },
            title = {
                Text(text = "Add Tour Package Listing", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Notice: Once published, packages cannot be edited. If you need to change details later, you must delete this package and create a new one.",
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(8.dp),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    if (!isVerified) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            color = StatusPendingBg,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Note: Your account is PENDING VERIFICATION. This package will be listed after Admin approves your license.",
                                color = StatusPending,
                                modifier = Modifier.padding(8.dp),
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }

                    SundarbanTextField(value = title, onValueChange = { title = it }, label = "Package Title", placeholder = "e.g. 2D/1N River Safari", testTag = "op_pkg_title")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = description, onValueChange = { description = it }, label = "Description & Itinerary", minLines = 3, testTag = "op_pkg_desc")
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SundarbanTextField(value = days, onValueChange = { days = it }, label = "Days", modifier = Modifier.weight(1f), testTag = "op_pkg_days")
                        SundarbanTextField(value = nights, onValueChange = { nights = it }, label = "Nights", modifier = Modifier.weight(1f), testTag = "op_pkg_nights")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SundarbanTextField(value = price, onValueChange = { price = it }, label = "Price (₹/person)", modifier = Modifier.weight(1f), testTag = "op_pkg_price")
                        SundarbanTextField(value = guests, onValueChange = { guests = it }, label = "Max Capacity", modifier = Modifier.weight(1f), testTag = "op_pkg_guests")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = departure, onValueChange = { departure = it }, label = "Departure Point", testTag = "op_pkg_departure")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = destinationsText, onValueChange = { destinationsText = it }, label = "Destinations (Comma separated)", testTag = "op_pkg_destinations")
                    Spacer(modifier = Modifier.height(8.dp))
                    SundarbanTextField(value = inclusionsText, onValueChange = { inclusionsText = it }, label = "Inclusions (Comma separated)", testTag = "op_pkg_inclusions")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createPackage(
                            title = title.ifBlank { "Sundarban Delta Cruise" },
                            description = description.ifBlank { "Standard eco cruise through mangrove rivers." },
                            durationDays = days.toIntOrNull() ?: 2,
                            durationNights = nights.toIntOrNull() ?: 1,
                            price = price.toDoubleOrNull() ?: 4500.0,
                            maxGuests = guests.toIntOrNull() ?: 12,
                            departure = departure.ifBlank { "Godkhali" },
                            destinations = destinationsText.split(",").map { it.trim() },
                            inclusions = inclusionsText.split(",").map { it.trim() }
                        )
                        showCreatePackageModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TigerAmber),
                    modifier = Modifier.testTag("op_submit_package_btn")
                ) {
                    Text("Publish Package")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreatePackageModal = false }) {
                    Text(strings.cancel)
                }
            }
        )
    }

    // Operator Complaint Filing Dialog
    val activeUser = user
    if (showComplaintModal && activeUser != null) {
        FileComplaintDialog(
            currentUser = activeUser,
            linkedBookings = bookings,
            onDismiss = { showComplaintModal = false },
            onSubmitComplaint = { complaint ->
                coroutineScope.launch {
                    viewModel.tourRepository.fileComplaint(complaint, activeUser)
                }
                showComplaintModal = false
            }
        )
    }

    // Operator Dispute Participation Dialog
    if (selectedDisputeForDetail != null && activeUser != null) {
        val currentDisp = selectedDisputeForDetail!!
        DisputeDetailDialog(
            dispute = currentDisp,
            currentUser = activeUser,
            onDismiss = { selectedDisputeForDetail = null },
            onSendMessage = { msg ->
                viewModel.sendDisputeMessage(currentDisp.disputeId, msg)
            }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("operator_dashboard_screen"),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "Operator Control Hub", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text(text = user?.fullName ?: "Tour Operator", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToPackages, modifier = Modifier.testTag("operator_packages_hub_btn")) {
                        Icon(imageVector = Icons.Default.Tour, contentDescription = "Package Management", tint = Color.White)
                    }
                    IconButton(onClick = { showComplaintModal = true }, modifier = Modifier.testTag("op_complaint_btn")) {
                        Icon(imageVector = Icons.Default.ReportProblem, contentDescription = "File Complaint", tint = Color.White)
                    }
                    IconButton(onClick = onNavigateToEarnings, modifier = Modifier.testTag("operator_earnings_button")) {
                        Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = "Earnings & Cash Collection", tint = Color.White)
                    }
                    IconButton(onClick = onNavigateToProfile, modifier = Modifier.testTag("operator_profile_button")) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = "Profile", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = TigerAmber,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            if (selectedTab == 0) {
                FloatingActionButton(
                    onClick = { showCreatePackageModal = true },
                    containerColor = TigerAmber,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("operator_add_package_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Package")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Operator Status Banner
            val bannerBg = when {
                isAutoVerified || isVerified -> StatusVerifiedBg
                isReviewRequired -> StatusRejectedBg
                else -> StatusPendingBg
            }
            val bannerBorder = when {
                isAutoVerified || isVerified -> StatusVerified.copy(alpha = 0.3f)
                isReviewRequired -> StatusRejected.copy(alpha = 0.3f)
                else -> StatusPending.copy(alpha = 0.3f)
            }
            val bannerIcon = when {
                isAutoVerified || isVerified -> Icons.Default.CheckCircle
                isReviewRequired -> Icons.Default.Warning
                else -> Icons.Default.HourglassTop
            }
            val bannerTint = when {
                isAutoVerified || isVerified -> StatusVerified
                isReviewRequired -> StatusRejected
                else -> StatusPending
            }
            val bannerTitle = when {
                isAutoVerified -> "AUTO-VERIFIED OPERATOR (PUBLISHED)"
                isVerified -> "VERIFIED OPERATOR STATUS"
                isReviewRequired -> "ADMIN REVIEW REQUIRED"
                else -> "VERIFICATION PENDING APPROVAL"
            }
            val bannerSubtitle = when {
                isAutoVerified -> "Your credentials passed automated safety & compliance checks. Your profile and packages are published publicly."
                isVerified -> "Your government documents & boat fitness are verified. Your packages are live to all tourists."
                isReviewRequired -> "Automated checks flagged an issue: ${user?.operatorDetails?.riskSignals?.firstOrNull() ?: "Compliance review in progress"}. Directorate administration will inspect your dossier."
                else -> "Your registration has been submitted. Compliant submissions auto-publish publicly."
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(14.dp),
                color = bannerBg,
                border = BorderStroke(1.dp, bannerBorder)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = bannerIcon,
                        contentDescription = null,
                        tint = bannerTint,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = bannerTitle,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = bannerTint
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = bannerSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = TigerAmber
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Packages (${packages.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Bookings (${bookings.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Disputes (${disputes.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Reviews (${reviews.size})", fontWeight = FontWeight.Bold) }
                )
            }

            when (selectedTab) {
                0 -> {
                    // Packages List
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Policy banner
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, TigerAmber.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = TigerAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Package Policy: Editing Disabled",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TigerAmber
                                    )
                                    Text(
                                        text = "Packages cannot be edited once created. To modify package information, delete the old package and create a new package.",
                                        style = MaterialTheme.typography.bodySmall,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }

                        if (packages.isEmpty()) {
                            EmptyStateView(
                                title = "No Tour Packages Created",
                                subtitle = "Tap the + button below to create your first Sundarban safari package.",
                                icon = Icons.Default.DirectionsBoat,
                                actionButtonText = "Create Package",
                                onActionClick = { showCreatePackageModal = true }
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(16.dp)
                            ) {
                                items(packages) { pkg ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp),
                                        shape = RoundedCornerShape(14.dp),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(text = pkg.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = when (pkg.status) {
                                                            PackageStatus.PUBLISHED, PackageStatus.AUTO_VERIFIED -> StatusVerifiedBg
                                                            PackageStatus.REQUIRES_ADMIN_REVIEW -> StatusRejectedBg
                                                            else -> StatusPendingBg
                                                        }
                                                    ) {
                                                        Text(
                                                            text = if (pkg.status == PackageStatus.PUBLISHED && pkg.isAutoVerified) "Auto-Verified • Published" else pkg.status.displayName,
                                                            color = when (pkg.status) {
                                                                PackageStatus.PUBLISHED, PackageStatus.AUTO_VERIFIED -> StatusVerified
                                                                PackageStatus.REQUIRES_ADMIN_REVIEW -> StatusRejected
                                                                else -> TigerAmber
                                                            },
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Text(text = "₹${pkg.pricePerPerson.toInt()}/person", fontWeight = FontWeight.Bold, color = TigerAmber)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(text = pkg.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                                Text(text = "⏱️ ${pkg.durationDays}D/${pkg.durationNights}N", style = MaterialTheme.typography.labelSmall)
                                                Text(text = "👥 Max: ${pkg.maxGuests} guests", style = MaterialTheme.typography.labelSmall)
                                                Text(text = "📍 ${pkg.departurePoint}", style = MaterialTheme.typography.labelSmall)
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .background(
                                                        MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                                                        RoundedCornerShape(6.dp)
                                                    )
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Lock,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(13.dp),
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "Editing disabled (Delete & create new to change)",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(10.dp))
                                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                            Spacer(modifier = Modifier.height(8.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                OutlinedButton(
                                                    onClick = { packageToDelete = pkg },
                                                    colors = ButtonDefaults.outlinedButtonColors(
                                                        contentColor = MaterialTheme.colorScheme.error
                                                    ),
                                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.testTag("op_delete_pkg_${pkg.id}")
                                                ) {
                                                    Icon(
                                                        Icons.Default.DeleteOutline,
                                                        contentDescription = "Delete Package",
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Delete Package", fontSize = 12.sp)
                                                }

                                                TextButton(
                                                    onClick = onNavigateToPackages,
                                                    modifier = Modifier.testTag("op_manage_pkg_btn_${pkg.id}")
                                                ) {
                                                    Text("Manage Details", fontSize = 12.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // Bookings List
                    if (bookings.isEmpty()) {
                        EmptyStateView(
                            title = "No Tourist Bookings Yet",
                            subtitle = "When tourists book your tours, their reservations and contact details will appear here.",
                            icon = Icons.Default.Person
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp)
                        ) {
                            items(bookings) { b ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(text = b.packageTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = StatusVerifiedBg
                                            ) {
                                                Text(text = b.bookingStatus.name, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = StatusVerified, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = "Tourist: ${b.customerName} (${b.customerPhone})", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                        Text(text = "Tour Date: ${b.tourDate} • Guests: ${b.guestCount} • Total: ₹${b.totalAmount.toInt()}", style = MaterialTheme.typography.bodySmall)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = "Payment: ${b.paymentMethod.name} (${b.paymentStatus.name})", style = MaterialTheme.typography.labelSmall, color = TigerAmber, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Disputes
                    if (disputes.isEmpty()) {
                        EmptyStateView(
                            title = "No Disputes Lodged",
                            subtitle = "Any tourist dispute requiring mediation will appear here.",
                            icon = Icons.Default.Gavel
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(disputes) { disp ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedDisputeForDetail = disp },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(text = disp.disputeId, fontWeight = FontWeight.Bold, color = StatusAdmin)
                                            Text(text = disp.status.displayName, fontWeight = FontWeight.Bold, color = TigerAmber, style = MaterialTheme.typography.labelSmall)
                                        }
                                        Text(text = "Tourist: ${disp.customerName} • Claim: ₹${disp.claimedAmount.toInt()}", style = MaterialTheme.typography.bodySmall)
                                        Text(text = "Reason: ${disp.disputeReason}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Button(
                                            onClick = { selectedDisputeForDetail = disp },
                                            colors = ButtonDefaults.buttonColors(containerColor = TigerAmber),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Respond & View Evidence", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    // Reviews (Read-only for operator; cannot delete customer reviews)
                    if (reviews.isEmpty()) {
                        EmptyStateView(
                            title = "No Customer Reviews Yet",
                            subtitle = "Verified reviews from tourists after completed safaris will appear here.",
                            icon = Icons.Default.Star
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "ℹ️ Note: Operator cannot delete customer reviews. Inappropriate content is moderated by Admin Governance.",
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(8.dp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            items(reviews) { rev ->
                                ReviewItemCard(
                                    review = rev,
                                    isAdmin = false
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
