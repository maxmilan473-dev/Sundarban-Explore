package com.example.features.disputes

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.core.ui.components.SundarbanTextField
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun OpenDisputeDialog(
    booking: Booking,
    currentUser: UserProfile,
    onDismiss: () -> Unit,
    onConfirmOpenDispute: (reason: String, evidenceUrl: String?) -> Unit
) {
    var reason by remember { mutableStateOf("") }
    var evidenceUrl by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Gavel, contentDescription = null, tint = StatusRejected)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Open Formal Dispute", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "Booking: ${booking.id} (${booking.packageTitle})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        Text(text = "Total Paid: ₹${booking.paidAmount}", style = MaterialTheme.typography.bodySmall, color = MangrovePrimary)
                        Text(
                            text = "Counterparty: ${if (currentUser.role == UserRole.CUSTOMER) booking.operatorName else booking.customerName}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Text(
                    text = "A formal dispute freezes payout escrow and initiates official arbitration by the Sundarban Directorate. Please state the exact grounds for dispute.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                SundarbanTextField(
                    value = reason,
                    onValueChange = {
                        reason = it
                        errorMessage = null
                    },
                    label = "Dispute Reason & Financial Claim",
                    placeholder = "Describe the breach of contract, service failure, cancellation discrepancy, or refund demand...",
                    minLines = 4,
                    modifier = Modifier.testTag("dispute_reason_input")
                )

                SundarbanTextField(
                    value = evidenceUrl,
                    onValueChange = { evidenceUrl = it },
                    label = "Evidence Attachment URL / Receipt Link (Optional)",
                    placeholder = "https://example.com/dispute_evidence.jpg",
                    leadingIcon = Icons.Default.AttachFile
                )

                if (errorMessage != null) {
                    Text(text = errorMessage!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (reason.trim().length < 15) {
                        errorMessage = "Please enter a detailed dispute reason (at least 15 characters)."
                        return@Button
                    }
                    onConfirmOpenDispute(
                        reason.trim(),
                        if (evidenceUrl.isNotBlank()) evidenceUrl.trim() else null
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = StatusRejected),
                modifier = Modifier.testTag("submit_dispute_btn")
            ) {
                Text("Open Dispute")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DisputeDetailDialog(
    dispute: DisputeRecord,
    currentUser: UserProfile,
    onDismiss: () -> Unit,
    onSendMessage: (message: String) -> Unit,
    onRequestEvidence: ((instructions: String) -> Unit)? = null,
    onAdjudicate: ((decision: DisputeStatus, refundType: RefundDecisionType, amount: Double, summary: String) -> Unit)? = null
) {
    val isAdmin = currentUser.role == UserRole.ADMIN
    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    var replyText by remember { mutableStateOf("") }
    var showAdjudicatePanel by remember { mutableStateOf(false) }
    var showEvidenceRequestPanel by remember { mutableStateOf(false) }

    var selectedRuling by remember { mutableStateOf(DisputeStatus.RESOLVED_REFUND_CUSTOMER) }
    var selectedRefundType by remember { mutableStateOf(RefundDecisionType.FULL_REFUND) }
    var customRefundAmount by remember { mutableStateOf(dispute.paidAmount.toString()) }
    var adjudicationSummary by remember { mutableStateOf("") }
    var evidenceRequestText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = dispute.disputeId,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = StatusRejected
                    )
                    Text(
                        text = "Booking: ${dispute.bookingId}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (dispute.status) {
                        DisputeStatus.OPEN -> StatusPendingBg
                        DisputeStatus.UNDER_REVIEW, DisputeStatus.EVIDENCE_REQUESTED -> TigerLight
                        DisputeStatus.RESOLVED_REFUND_CUSTOMER, DisputeStatus.RESOLVED_RELEASE_OPERATOR, DisputeStatus.RESOLVED_SPLIT -> StatusVerifiedBg
                        DisputeStatus.DISMISSED -> StatusRejectedBg
                    }
                ) {
                    Text(
                        text = dispute.status.displayName,
                        fontWeight = FontWeight.Bold,
                        color = when (dispute.status) {
                            DisputeStatus.OPEN -> StatusPending
                            DisputeStatus.UNDER_REVIEW, DisputeStatus.EVIDENCE_REQUESTED -> TigerAmber
                            DisputeStatus.RESOLVED_REFUND_CUSTOMER, DisputeStatus.RESOLVED_RELEASE_OPERATOR, DisputeStatus.RESOLVED_SPLIT -> StatusVerified
                            DisputeStatus.DISMISSED -> StatusRejected
                        },
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Financial & Party Summary Dossier
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Tourist: ${dispute.customerName}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            Text(text = "Paid: ₹${dispute.paidAmount.toInt()}", fontWeight = FontWeight.Bold, color = MangrovePrimary, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(text = "Operator: ${dispute.operatorName} (${dispute.operatorPhone})", style = MaterialTheme.typography.bodySmall)
                        Text(text = "Tour Package: ${dispute.packageTitle}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Dispute Reason: ${dispute.disputeReason}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                    }
                }

                // Final Ruling if decided
                if (dispute.decidedAt != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusVerifiedBg,
                        border = BorderStroke(1.dp, StatusVerified.copy(alpha = 0.4f))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Official Adjudication Ruling:", fontWeight = FontWeight.Bold, color = StatusVerified, style = MaterialTheme.typography.labelMedium)
                            Text(text = "Decision: ${dispute.status.displayName}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text(text = "Refund Settlement: ${dispute.refundDecision.displayName} (₹${dispute.refundAmount.toInt()})", style = MaterialTheme.typography.bodySmall)
                            if (!dispute.decisionSummary.isNullOrBlank()) {
                                Text(text = "Summary: ${dispute.decisionSummary}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text(text = "Decided by: ${dispute.decidedByName ?: "Admin Directorate"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Communication Log / Evidence Exchange
                Text(
                    text = "Dispute Mediation & Message Thread (${dispute.messages.size}):",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    dispute.messages.forEach { msg ->
                        val isSelf = msg.senderId == currentUser.id
                        val isAdminMsg = msg.senderRole == UserRole.ADMIN

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when {
                                isAdminMsg -> StatusAdmin.copy(alpha = 0.15f)
                                isSelf -> MangrovePrimary.copy(alpha = 0.12f)
                                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${msg.senderName} (${msg.senderRole.displayName})",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isAdminMsg) StatusAdmin else if (isSelf) MangrovePrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = dateFormat.format(Date(msg.timestamp)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = msg.message, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                // Send Message Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        placeholder = { Text("Add statement / mediation note...", fontSize = 12.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dispute_message_input")
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            if (replyText.isNotBlank()) {
                                onSendMessage(replyText.trim())
                                replyText = ""
                            }
                        },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = MangrovePrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }

                // Admin Adjudication Form Panel
                if (isAdmin && showAdjudicatePanel) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
                        border = BorderStroke(1.dp, StatusAdmin.copy(alpha = 0.3f))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = "Final Dispute Adjudication Ruling", fontWeight = FontWeight.Bold, color = StatusAdmin, style = MaterialTheme.typography.titleSmall)

                            // Ruling Type
                            Text(text = "Adjudication Verdict:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            listOf(
                                DisputeStatus.RESOLVED_REFUND_CUSTOMER to "Refund Customer",
                                DisputeStatus.RESOLVED_RELEASE_OPERATOR to "Release Payout to Operator",
                                DisputeStatus.RESOLVED_SPLIT to "Split Settlement",
                                DisputeStatus.DISMISSED to "Dismiss Dispute"
                            ).forEach { (status, label) ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    RadioButton(
                                        selected = selectedRuling == status,
                                        onClick = {
                                            selectedRuling = status
                                            when (status) {
                                                DisputeStatus.RESOLVED_REFUND_CUSTOMER -> {
                                                    selectedRefundType = RefundDecisionType.FULL_REFUND
                                                    customRefundAmount = dispute.paidAmount.toString()
                                                }
                                                DisputeStatus.RESOLVED_RELEASE_OPERATOR -> {
                                                    selectedRefundType = RefundDecisionType.OPERATOR_RELEASE
                                                    customRefundAmount = "0"
                                                }
                                                DisputeStatus.RESOLVED_SPLIT -> {
                                                    selectedRefundType = RefundDecisionType.PARTIAL_REFUND
                                                    customRefundAmount = (dispute.paidAmount / 2).toString()
                                                }
                                                DisputeStatus.DISMISSED -> {
                                                    selectedRefundType = RefundDecisionType.NONE
                                                    customRefundAmount = "0"
                                                }
                                                else -> {}
                                            }
                                        }
                                    )
                                    Text(text = label, style = MaterialTheme.typography.bodySmall)
                                }
                            }

                            if (selectedRuling == DisputeStatus.RESOLVED_SPLIT || selectedRuling == DisputeStatus.RESOLVED_REFUND_CUSTOMER) {
                                SundarbanTextField(
                                    value = customRefundAmount,
                                    onValueChange = { customRefundAmount = it },
                                    label = "Refund Amount to Tourist (₹)",
                                    placeholder = "e.g. 4500"
                                )
                            }

                            SundarbanTextField(
                                value = adjudicationSummary,
                                onValueChange = { adjudicationSummary = it },
                                label = "Official Decision Summary & Policy Grounds",
                                placeholder = "Cite weather permit closure, cancellation policy clauses, or service proof..."
                            )

                            Button(
                                onClick = {
                                    val amt = customRefundAmount.toDoubleOrNull() ?: 0.0
                                    onAdjudicate?.invoke(
                                        selectedRuling,
                                        selectedRefundType,
                                        amt,
                                        adjudicationSummary.trim().ifBlank { "Adjudicated by Admin Directorate." }
                                    )
                                    showAdjudicatePanel = false
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StatusAdmin),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Execute Final Adjudication Ruling")
                            }
                        }
                    }
                }

                // Evidence Request Panel
                if (isAdmin && showEvidenceRequestPanel) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = TigerLight
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Request Specific Evidence from Parties", fontWeight = FontWeight.Bold, color = TigerAmber, style = MaterialTheme.typography.labelMedium)
                            Spacer(modifier = Modifier.height(6.dp))
                            SundarbanTextField(
                                value = evidenceRequestText,
                                onValueChange = { evidenceRequestText = it },
                                label = "Evidence Required (e.g. Launch master logbook, GPS tracker record, payment slip)",
                                placeholder = "Enter clear instructions..."
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(
                                onClick = {
                                    if (evidenceRequestText.isNotBlank()) {
                                        onRequestEvidence?.invoke(evidenceRequestText.trim())
                                        showEvidenceRequestPanel = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = TigerAmber),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Issue Formal Evidence Request")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (isAdmin && !showAdjudicatePanel && dispute.decidedAt == null) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = { showEvidenceRequestPanel = !showEvidenceRequestPanel },
                        colors = ButtonDefaults.buttonColors(containerColor = TigerAmber)
                    ) {
                        Text("Request Evidence")
                    }
                    Button(
                        onClick = { showAdjudicatePanel = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusAdmin)
                    ) {
                        Text("Adjudicate")
                    }
                }
            } else {
                TextButton(onClick = onDismiss) {
                    Text("Close")
                }
            }
        },
        dismissButton = {
            if (showAdjudicatePanel || showEvidenceRequestPanel) {
                TextButton(onClick = {
                    showAdjudicatePanel = false
                    showEvidenceRequestPanel = false
                }) {
                    Text("Cancel Action")
                }
            }
        }
    )
}
