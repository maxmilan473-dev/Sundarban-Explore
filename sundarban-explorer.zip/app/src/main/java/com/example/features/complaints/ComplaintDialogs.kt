package com.example.features.complaints

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.core.ui.components.SundarbanTextField
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileComplaintDialog(
    currentUser: UserProfile,
    targetUsers: List<UserProfile> = emptyList(),
    linkedBookings: List<Booking> = emptyList(),
    initialBookingId: String? = null,
    onDismiss: () -> Unit,
    onSubmitComplaint: (Complaint) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(ComplaintCategory.PAYMENT_PROBLEM) }
    var categoryExpanded by remember { mutableStateOf(false) }

    var selectedBookingId by remember { mutableStateOf(initialBookingId ?: linkedBookings.firstOrNull()?.id.orEmpty()) }
    var bookingExpanded by remember { mutableStateOf(false) }

    var targetId by remember { mutableStateOf("") }
    var targetName by remember { mutableStateOf("") }
    var targetRole by remember { mutableStateOf<UserRole?>(null) }
    var targetExpanded by remember { mutableStateOf(false) }

    var subject by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var evidenceUrl by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Auto-fill target if booking selected
    LaunchedEffect(selectedBookingId) {
        val bk = linkedBookings.firstOrNull { it.id == selectedBookingId }
        if (bk != null) {
            if (currentUser.role == UserRole.CUSTOMER) {
                targetId = bk.operatorId
                targetName = bk.operatorName
                targetRole = UserRole.OPERATOR
            } else if (currentUser.role == UserRole.OPERATOR) {
                targetId = bk.customerId
                targetName = bk.customerName
                targetRole = UserRole.CUSTOMER
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.ReportProblem, contentDescription = null, tint = StatusRejected)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "File Formal Complaint", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Sundarban Directorate Complaint System processes complaints with official investigation tracking.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Category Selector
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedCategory.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Complaint Category") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("complaint_category_picker")
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false }
                    ) {
                        ComplaintCategory.values().forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.displayName) },
                                onClick = {
                                    selectedCategory = cat
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }

                // Linked Booking Selector
                if (linkedBookings.isNotEmpty()) {
                    ExposedDropdownMenuBox(
                        expanded = bookingExpanded,
                        onExpandedChange = { bookingExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = if (selectedBookingId.isNotBlank()) selectedBookingId else "Select Related Safari Booking (Optional)",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Linked Safari Booking") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = bookingExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = bookingExpanded,
                            onDismissRequest = { bookingExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("None (General Inquiry / Report)") },
                                onClick = {
                                    selectedBookingId = ""
                                    bookingExpanded = false
                                }
                            )
                            linkedBookings.forEach { bk ->
                                DropdownMenuItem(
                                    text = { Text("${bk.id} - ${bk.packageTitle}") },
                                    onClick = {
                                        selectedBookingId = bk.id
                                        bookingExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Target Party (Operator or Tourist)
                if (targetName.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = MangrovePrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = "Target Party: $targetName", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                Text(text = "Role: ${targetRole?.displayName ?: "Party"}", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                } else {
                    SundarbanTextField(
                        value = targetName,
                        onValueChange = { targetName = it },
                        label = "Name of Operator / Tourist being reported",
                        placeholder = "e.g. Tiger Trails Agency or Tourist Name"
                    )
                }

                // Subject
                SundarbanTextField(
                    value = subject,
                    onValueChange = {
                        subject = it
                        errorMessage = null
                    },
                    label = "Complaint Subject Summary",
                    placeholder = "e.g. Overcharged beyond package fee / Unsafe boat engine",
                    modifier = Modifier.testTag("complaint_subject_input")
                )

                // Description
                SundarbanTextField(
                    value = description,
                    onValueChange = {
                        description = it
                        errorMessage = null
                    },
                    label = "Detailed Incident Description",
                    placeholder = "Describe exactly what occurred, dates, checkposts, guides involved, and communications...",
                    minLines = 4,
                    modifier = Modifier.testTag("complaint_desc_input")
                )

                // Optional Evidence URL / Document Link
                SundarbanTextField(
                    value = evidenceUrl,
                    onValueChange = { evidenceUrl = it },
                    label = "Evidence Attachment URL / Photo Link (Optional)",
                    placeholder = "https://example.com/receipt_or_photo.jpg",
                    leadingIcon = Icons.Default.AttachFile
                )

                if (errorMessage != null) {
                    Text(text = errorMessage!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (subject.trim().length < 5) {
                        errorMessage = "Please enter a subject (at least 5 characters)."
                        return@Button
                    }
                    if (description.trim().length < 15) {
                        errorMessage = "Please enter a detailed description (at least 15 characters)."
                        return@Button
                    }
                    val selectedBk = linkedBookings.firstOrNull { it.id == selectedBookingId }
                    val complaint = Complaint(
                        bookingId = if (selectedBookingId.isNotBlank()) selectedBookingId else null,
                        packageTitle = selectedBk?.packageTitle,
                        targetId = targetId,
                        targetName = if (targetName.isNotBlank()) targetName else "Operator Directorate",
                        targetRole = targetRole ?: UserRole.OPERATOR,
                        category = selectedCategory,
                        subject = subject.trim(),
                        description = description.trim(),
                        evidenceUrls = if (evidenceUrl.isNotBlank()) listOf(evidenceUrl.trim()) else emptyList()
                    )
                    onSubmitComplaint(complaint)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = StatusRejected),
                modifier = Modifier.testTag("submit_complaint_btn")
            ) {
                Text("File Complaint")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun ComplaintDetailDialog(
    complaint: Complaint,
    currentUser: UserProfile,
    onDismiss: () -> Unit,
    onInvestigate: ((adminNotes: String) -> Unit)? = null,
    onRequestEvidence: ((instructions: String) -> Unit)? = null,
    onResolve: ((resolution: String) -> Unit)? = null,
    onReject: ((rejectionReason: String) -> Unit)? = null,
    onOpenDispute: (() -> Unit)? = null
) {
    val isAdmin = currentUser.role == UserRole.ADMIN
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
    val dateStr = remember(complaint.createdAt) { dateFormat.format(Date(complaint.createdAt)) }

    var showActionPanel by remember { mutableStateOf<String?>(null) } // "INVESTIGATE", "EVIDENCE", "RESOLVE", "REJECT"
    var actionNote by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = complaint.complaintId,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = StatusRejected
                    )
                    Text(
                        text = complaint.category.displayName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (complaint.status) {
                        ComplaintStatus.OPEN -> StatusPendingBg
                        ComplaintStatus.UNDER_REVIEW -> TigerLight
                        ComplaintStatus.RESOLVED -> StatusVerifiedBg
                        ComplaintStatus.REJECTED -> StatusRejectedBg
                    }
                ) {
                    Text(
                        text = complaint.status.displayName,
                        fontWeight = FontWeight.Bold,
                        color = when (complaint.status) {
                            ComplaintStatus.OPEN -> StatusPending
                            ComplaintStatus.UNDER_REVIEW -> TigerAmber
                            ComplaintStatus.RESOLVED -> StatusVerified
                            ComplaintStatus.REJECTED -> StatusRejected
                        },
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = complaint.subject,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "Complainant: ${complaint.complainantName} (${complaint.complainantRole.displayName})", style = MaterialTheme.typography.bodySmall)
                        Text(text = "Target: ${complaint.targetName}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        if (!complaint.bookingId.isNullOrBlank()) {
                            Text(text = "Booking ID: ${complaint.bookingId}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(text = "Filed: $dateStr", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Text(
                    text = "Incident Details:",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )
                Text(
                    text = complaint.description,
                    style = MaterialTheme.typography.bodySmall
                )

                if (complaint.evidenceUrls.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Evidence:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    complaint.evidenceUrls.forEach { url ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(14.dp), tint = MangrovePrimary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = url, style = MaterialTheme.typography.bodySmall, color = MangrovePrimary)
                        }
                    }
                }

                if (!complaint.adminNotes.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = TigerLight
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Admin Investigation Notes:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = TigerAmber)
                            Text(text = complaint.adminNotes, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                if (!complaint.evidenceRequested.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Evidence Requested by Directorate:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            Text(text = complaint.evidenceRequested, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                if (!complaint.resolutionNote.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusVerifiedBg
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Official Resolution:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = StatusVerified)
                            Text(text = complaint.resolutionNote, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                if (!complaint.rejectionReason.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusRejectedBg
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Rejection Reason:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = StatusRejected)
                            Text(text = complaint.rejectionReason, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                // Action form when button is pressed
                if (showActionPanel != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(6.dp))
                    SundarbanTextField(
                        value = actionNote,
                        onValueChange = { actionNote = it },
                        label = when (showActionPanel) {
                            "INVESTIGATE" -> "Admin Investigation Notes"
                            "EVIDENCE" -> "Specific Evidence Instructions Required"
                            "RESOLVE" -> "Formal Resolution & Corrective Action Taken"
                            "REJECT" -> "Reason for Rejecting Complaint"
                            else -> "Notes"
                        },
                        placeholder = "Enter administrative decision details..."
                    )
                }
            }
        },
        confirmButton = {
            if (isAdmin && showActionPanel != null) {
                Button(
                    onClick = {
                        if (actionNote.isNotBlank()) {
                            when (showActionPanel) {
                                "INVESTIGATE" -> onInvestigate?.invoke(actionNote)
                                "EVIDENCE" -> onRequestEvidence?.invoke(actionNote)
                                "RESOLVE" -> onResolve?.invoke(actionNote)
                                "REJECT" -> onReject?.invoke(actionNote)
                            }
                            onDismiss()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (showActionPanel == "RESOLVE") StatusVerified else if (showActionPanel == "REJECT") StatusRejected else MangrovePrimary
                    )
                ) {
                    Text("Confirm ${showActionPanel?.lowercase()?.replaceFirstChar { it.uppercase() }}")
                }
            } else if (isAdmin) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (complaint.status == ComplaintStatus.OPEN) {
                        Button(
                            onClick = { showActionPanel = "INVESTIGATE" },
                            colors = ButtonDefaults.buttonColors(containerColor = TigerAmber)
                        ) {
                            Text("Investigate")
                        }
                    }
                    if (complaint.status != ComplaintStatus.RESOLVED) {
                        Button(
                            onClick = { showActionPanel = "RESOLVE" },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusVerified)
                        ) {
                            Text("Resolve")
                        }
                    }
                }
            } else {
                TextButton(onClick = onDismiss) {
                    Text("Close")
                }
            }
        },
        dismissButton = {
            if (isAdmin && showActionPanel != null) {
                TextButton(onClick = { showActionPanel = null }) {
                    Text("Cancel Action")
                }
            } else if (isAdmin && complaint.status != ComplaintStatus.REJECTED && complaint.status != ComplaintStatus.RESOLVED) {
                OutlinedButton(
                    onClick = { showActionPanel = "REJECT" },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejected)
                ) {
                    Text("Reject")
                }
            }
        }
    )
}
