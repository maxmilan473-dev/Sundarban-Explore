package com.example.features.authentication.signup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.EmergencyContact
import com.example.core.model.UserProfile
import com.example.core.model.VerificationDocument
import com.example.core.security.SecurityManager
import com.example.data.repositories.AuthRepository
import com.example.data.repositories.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class CustomerSignUpState(
    val fullName: String = "",
    val mobileNumber: String = "",
    val email: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val profilePhotoUrl: String = "",
    val address: String = "",
    val emergencyContactName: String = "",
    val emergencyContactPhone: String = "",
    val emergencyContactRelation: String = "Family",
    val isPhoneVerified: Boolean = false,
    val isPhoneOtpSent: Boolean = false,
    val phoneOtpInput: String = "",
    val phoneOtpCountdown: Int = 0,
    val simulatedPhoneOtp: String = "",
    val phoneVerificationStatusText: String? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val nameError: String? = null,
    val phoneError: String? = null,
    val emailError: String? = null,
    val passwordError: String? = null,
    val confirmPasswordError: String? = null,
    val emergencyNameError: String? = null,
    val emergencyPhoneError: String? = null
)

data class OperatorSignUpState(
    val currentStep: Int = 1, // 1: Personal Info, 2: Operator Profile, 3: Tour & Payment, 4: Review & Submit
    val isSubmittedSuccessfully: Boolean = false,

    // Step 1: Personal Information
    val fullName: String = "",
    val mobileNumber: String = "",
    val email: String = "",
    val dateOfBirth: String = "1990-05-15",
    val gender: String = "Male",
    val address: String = "",
    val state: String = "West Bengal",
    val district: String = "South 24 Parganas",
    val profilePhotoUrl: String = "",
    val password: String = "",
    val confirmPassword: String = "",

    // Phone OTP Verification (Step 1)
    val isPhoneVerified: Boolean = false,
    val isPhoneOtpSent: Boolean = false,
    val phoneOtpInput: String = "",
    val phoneOtpCountdown: Int = 0,
    val simulatedPhoneOtp: String = "",
    val phoneVerificationStatusText: String? = null,

    // Step 2: Operator Profile
    val operatorBusinessName: String = "",
    val serviceType: String = "Boat Safari & Wildlife Tour",
    val yearsOfExperience: String = "5",
    val areasCovered: String = "Gosaba, Sajnekhali, Sudhanyakhali, Dobanki",
    val languagesSpoken: String = "Bengali, English, Hindi",
    val maxTourists: String = "15",
    val shortDescription: String = "Certified local forest guide and experienced boat master operating safe, registered eco-tours in Sundarban delta.",

    // Step 3: Tour and Payment Details
    val tourPackageTitle: String = "Sundarban 2D/1N Royal Bengal Tiger Eco Cruise",
    val tourDuration: String = "2 Days / 1 Night",
    val tourPrice: String = "4500",
    val tourMaxCapacity: String = "12",
    val tourAvailableDates: String = "Daily / Weekends / Flexible",
    val onlinePaymentAvailable: Boolean = true,
    val cashPaymentAvailable: Boolean = true,

    // Step 4: Review & Submit
    val confirmationChecked: Boolean = false,

    // Submission & UI status
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val createdOperator: UserProfile? = null,

    // Errors
    val nameError: String? = null,
    val phoneError: String? = null,
    val emailError: String? = null,
    val dobError: String? = null,
    val addressError: String? = null,
    val passwordError: String? = null,
    val confirmPasswordError: String? = null,
    val operatorBusinessNameError: String? = null,
    val serviceTypeError: String? = null,
    val areasCoveredError: String? = null,
    val packageTitleError: String? = null,
    val priceError: String? = null,

    // Backwards-compatible legacy fields
    val operatingArea: String = "Gosaba & Sajnekhali",
    val guideExperience: String = "",
    val emergencyContactName: String = "",
    val emergencyContactPhone: String = "",
    val emergencyContactRelation: String = "Business Partner",
    val govIdType: String = "Aadhaar Card",
    val govIdNumber: String = "",
    val licenseNumber: String = "",
    val boatRegistrationNumber: String = "",
    val bankUpiId: String = "",
    val documents: List<VerificationDocument> = emptyList(),
    val isEmailVerified: Boolean = false,
    val isEmailCodeSent: Boolean = false,
    val emailCodeInput: String = "",
    val simulatedEmailCode: String = "",
    val emailVerificationStatusText: String? = null,
    val autoValidationOutcomeText: String? = null,
    val autoValidationOutcomeStatus: String? = null,
    val operatingAreaError: String? = null,
    val govIdError: String? = null,
    val licenseError: String? = null,
    val upiError: String? = null
)

class SignUpViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _customerState = MutableStateFlow(CustomerSignUpState())
    val customerState: StateFlow<CustomerSignUpState> = _customerState.asStateFlow()

    private val _operatorState = MutableStateFlow(OperatorSignUpState())
    val operatorState: StateFlow<OperatorSignUpState> = _operatorState.asStateFlow()

    // Customer state setters
    fun onCustomerNameChanged(v: String) = _customerState.update { it.copy(fullName = v, nameError = null, errorMessage = null) }
    fun onCustomerPhoneChanged(v: String) = _customerState.update {
        it.copy(
            mobileNumber = v,
            phoneError = null,
            isPhoneVerified = false,
            isPhoneOtpSent = false,
            phoneOtpInput = "",
            phoneVerificationStatusText = null,
            errorMessage = null
        )
    }
    fun onCustomerPhoneOtpInputChanged(v: String) = _customerState.update { it.copy(phoneOtpInput = v) }
    fun onCustomerEmailChanged(v: String) = _customerState.update { it.copy(email = v, emailError = null, errorMessage = null) }
    fun onCustomerPasswordChanged(v: String) = _customerState.update { it.copy(password = v, passwordError = null, errorMessage = null) }
    fun onCustomerConfirmPasswordChanged(v: String) = _customerState.update { it.copy(confirmPassword = v, confirmPasswordError = null, errorMessage = null) }
    fun onCustomerAddressChanged(v: String) = _customerState.update { it.copy(address = v, errorMessage = null) }
    fun onCustomerPhotoChanged(v: String) = _customerState.update { it.copy(profilePhotoUrl = v) }
    fun onCustomerEmergencyNameChanged(v: String) = _customerState.update { it.copy(emergencyContactName = v, emergencyNameError = null) }
    fun onCustomerEmergencyPhoneChanged(v: String) = _customerState.update { it.copy(emergencyContactPhone = v, emergencyPhoneError = null) }
    fun onCustomerEmergencyRelationChanged(v: String) = _customerState.update { it.copy(emergencyContactRelation = v) }

    // Customer Phone OTP Actions
    private var customerCountdownJob: kotlinx.coroutines.Job? = null
    private fun startCustomerOtpCountdown() {
        customerCountdownJob?.cancel()
        customerCountdownJob = viewModelScope.launch {
            for (sec in SecurityManager.OTP_COOLDOWN_SECONDS downTo 0) {
                _customerState.update { it.copy(phoneOtpCountdown = sec) }
                kotlinx.coroutines.delay(1000L)
            }
        }
    }

    fun requestCustomerPhoneOtp() {
        val phone = _customerState.value.mobileNumber.trim()
        if (!SecurityManager.isValidPhoneNumber(phone)) {
            _customerState.update { it.copy(phoneError = "Please enter a valid 10-digit mobile number first") }
            return
        }
        viewModelScope.launch {
            _customerState.update { it.copy(isLoading = true, errorMessage = null) }
            val res = authRepository.sendPhoneOtp(phone)
            when (res) {
                is AuthResult.Success -> {
                    _customerState.update {
                        it.copy(
                            isLoading = false,
                            isPhoneOtpSent = true,
                            simulatedPhoneOtp = res.data,
                            phoneOtpInput = res.data,
                            phoneVerificationStatusText = "OTP sent to $phone"
                        )
                    }
                    startCustomerOtpCountdown()
                }
                is AuthResult.Error -> {
                    _customerState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun verifyCustomerPhoneOtp() {
        val phone = _customerState.value.mobileNumber.trim()
        val otp = _customerState.value.phoneOtpInput.trim()
        if (otp.isBlank()) {
            _customerState.update { it.copy(errorMessage = "Please enter the 6-digit OTP code") }
            return
        }
        viewModelScope.launch {
            _customerState.update { it.copy(isLoading = true, errorMessage = null) }
            val res = authRepository.verifyPhoneOtp(phone, otp)
            when (res) {
                is AuthResult.Success -> {
                    _customerState.update {
                        it.copy(
                            isLoading = false,
                            isPhoneVerified = true,
                            phoneError = null,
                            phoneVerificationStatusText = "✓ Mobile Verified"
                        )
                    }
                }
                is AuthResult.Error -> {
                    _customerState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    // Operator Step 1: Personal Information Setters
    fun onOperatorNameChanged(v: String) = _operatorState.update { it.copy(fullName = v, nameError = null, errorMessage = null) }
    fun onOperatorPhoneChanged(v: String) = _operatorState.update { it.copy(mobileNumber = v, phoneError = null, isPhoneVerified = false, isPhoneOtpSent = false, phoneVerificationStatusText = null, errorMessage = null) }
    fun onOperatorEmailChanged(v: String) = _operatorState.update { it.copy(email = v, emailError = null, errorMessage = null) }
    fun onOperatorDobChanged(v: String) = _operatorState.update { it.copy(dateOfBirth = v, dobError = null, errorMessage = null) }
    fun onOperatorGenderChanged(v: String) = _operatorState.update { it.copy(gender = v) }
    fun onOperatorAddressChanged(v: String) = _operatorState.update { it.copy(address = v, addressError = null, errorMessage = null) }
    fun onOperatorStateChanged(v: String) = _operatorState.update { it.copy(state = v) }
    fun onOperatorDistrictChanged(v: String) = _operatorState.update { it.copy(district = v) }
    fun onOperatorPhotoChanged(v: String) = _operatorState.update { it.copy(profilePhotoUrl = v) }
    fun onOperatorPasswordChanged(v: String) = _operatorState.update { it.copy(password = v, passwordError = null, errorMessage = null) }
    fun onOperatorConfirmPasswordChanged(v: String) = _operatorState.update { it.copy(confirmPassword = v, confirmPasswordError = null, errorMessage = null) }
    fun onOperatorPhoneOtpInputChanged(v: String) = _operatorState.update { it.copy(phoneOtpInput = v) }

    // Operator Step 2: Professional Profile Setters
    fun onOperatorBusinessNameChanged(v: String) = _operatorState.update { it.copy(operatorBusinessName = v, operatorBusinessNameError = null, errorMessage = null) }
    fun onOperatorServiceTypeChanged(v: String) = _operatorState.update { it.copy(serviceType = v, serviceTypeError = null, errorMessage = null) }
    fun onOperatorYearsExpChanged(v: String) = _operatorState.update { it.copy(yearsOfExperience = v) }
    fun onOperatorAreasCoveredChanged(v: String) = _operatorState.update { it.copy(areasCovered = v, operatingArea = v, areasCoveredError = null, errorMessage = null) }
    fun onOperatorLanguagesChanged(v: String) = _operatorState.update { it.copy(languagesSpoken = v) }
    fun onOperatorMaxTouristsChanged(v: String) = _operatorState.update { it.copy(maxTourists = v) }
    fun onOperatorShortDescChanged(v: String) = _operatorState.update { it.copy(shortDescription = v, guideExperience = v) }

    // Operator Step 3: Tour & Payment Setters
    fun onOperatorPackageTitleChanged(v: String) = _operatorState.update { it.copy(tourPackageTitle = v, packageTitleError = null, errorMessage = null) }
    fun onOperatorTourDurationChanged(v: String) = _operatorState.update { it.copy(tourDuration = v) }
    fun onOperatorTourPriceChanged(v: String) = _operatorState.update { it.copy(tourPrice = v, priceError = null, errorMessage = null) }
    fun onOperatorTourCapacityChanged(v: String) = _operatorState.update { it.copy(tourMaxCapacity = v) }
    fun onOperatorAvailableDatesChanged(v: String) = _operatorState.update { it.copy(tourAvailableDates = v) }
    fun onOperatorOnlinePaymentToggled(v: Boolean) = _operatorState.update { it.copy(onlinePaymentAvailable = v, errorMessage = null) }
    fun onOperatorCashPaymentToggled(v: Boolean) = _operatorState.update { it.copy(cashPaymentAvailable = v, errorMessage = null) }

    // Operator Step 4: Review & Confirmation
    fun onConfirmationChecked(v: Boolean) = _operatorState.update { it.copy(confirmationChecked = v, errorMessage = null) }
    fun onOperatorStepChanged(step: Int) = _operatorState.update { it.copy(currentStep = step.coerceIn(1, 4), errorMessage = null) }

    // Legacy setters for compatibility
    fun onOperatorOperatingAreaChanged(v: String) = onOperatorAreasCoveredChanged(v)
    fun onOperatorGuideExpChanged(v: String) = onOperatorShortDescChanged(v)
    fun onOperatorEmergencyNameChanged(v: String) = _operatorState.update { it.copy(emergencyContactName = v) }
    fun onOperatorEmergencyPhoneChanged(v: String) = _operatorState.update { it.copy(emergencyContactPhone = v) }
    fun onOperatorGovIdTypeChanged(v: String) = _operatorState.update { it.copy(govIdType = v) }
    fun onOperatorGovIdNumberChanged(v: String) = _operatorState.update { it.copy(govIdNumber = v) }
    fun onOperatorLicenseNumberChanged(v: String) = _operatorState.update { it.copy(licenseNumber = v) }
    fun onOperatorBoatRegChanged(v: String) = _operatorState.update { it.copy(boatRegistrationNumber = v) }
    fun onOperatorBankUpiChanged(v: String) = _operatorState.update { it.copy(bankUpiId = v) }
    fun onOperatorEmailCodeInputChanged(v: String) = _operatorState.update { it.copy(emailCodeInput = v) }

    // Operator Phone OTP Action (Step 1 requirement)
    private var operatorCountdownJob: kotlinx.coroutines.Job? = null
    private fun startOperatorOtpCountdown() {
        operatorCountdownJob?.cancel()
        operatorCountdownJob = viewModelScope.launch {
            for (sec in SecurityManager.OTP_COOLDOWN_SECONDS downTo 0) {
                _operatorState.update { it.copy(phoneOtpCountdown = sec) }
                kotlinx.coroutines.delay(1000L)
            }
        }
    }

    fun requestPhoneOtp() {
        val phone = _operatorState.value.mobileNumber.trim()
        if (!SecurityManager.isValidPhoneNumber(phone)) {
            _operatorState.update { it.copy(phoneError = "Please enter a valid 10-digit mobile number first") }
            return
        }
        viewModelScope.launch {
            _operatorState.update { it.copy(isLoading = true, errorMessage = null) }
            val res = authRepository.sendPhoneOtp(phone)
            when (res) {
                is AuthResult.Success -> {
                    _operatorState.update {
                        it.copy(
                            isLoading = false,
                            isPhoneOtpSent = true,
                            simulatedPhoneOtp = res.data,
                            phoneOtpInput = res.data, // Pre-fill for user convenience in testing
                            phoneVerificationStatusText = "OTP sent to $phone"
                        )
                    }
                    startOperatorOtpCountdown()
                }
                is AuthResult.Error -> {
                    _operatorState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun verifyPhoneOtp() {
        val phone = _operatorState.value.mobileNumber.trim()
        val otp = _operatorState.value.phoneOtpInput.trim()
        viewModelScope.launch {
            _operatorState.update { it.copy(isLoading = true, errorMessage = null) }
            val res = authRepository.verifyPhoneOtp(phone, otp)
            when (res) {
                is AuthResult.Success -> {
                    _operatorState.update {
                        it.copy(
                            isLoading = false,
                            isPhoneVerified = true,
                            phoneError = null,
                            phoneVerificationStatusText = "✓ Mobile number verified successfully with OTP"
                        )
                    }
                }
                is AuthResult.Error -> {
                    _operatorState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    // Step navigation
    fun proceedToNextStep(): Boolean {
        val s = _operatorState.value
        when (s.currentStep) {
            1 -> {
                var hasErr = false
                var nErr: String? = null
                var pErr: String? = null
                var eErr: String? = null
                var dErr: String? = null
                var aErr: String? = null
                var passErr: String? = null
                var confErr: String? = null

                if (s.fullName.trim().isBlank()) {
                    nErr = "Full Name is required"
                    hasErr = true
                }
                if (!SecurityManager.isValidPhoneNumber(s.mobileNumber)) {
                    pErr = "Valid mobile number is required"
                    hasErr = true
                } else if (!s.isPhoneVerified) {
                    pErr = "Mobile number must be verified using OTP"
                    hasErr = true
                }
                if (!SecurityManager.isValidEmail(s.email)) {
                    eErr = "Valid email address is required"
                    hasErr = true
                }
                if (s.dateOfBirth.trim().isBlank()) {
                    dErr = "Date of Birth is required"
                    hasErr = true
                }
                if (s.address.trim().isBlank()) {
                    aErr = "Full address is required"
                    hasErr = true
                }
                val passVal = SecurityManager.validatePassword(s.password)
                if (!passVal.isValid) {
                    passErr = passVal.errorMessage
                    hasErr = true
                }
                if (s.password != s.confirmPassword) {
                    confErr = "Passwords do not match"
                    hasErr = true
                }

                if (hasErr) {
                    _operatorState.update {
                        it.copy(
                            nameError = nErr,
                            phoneError = pErr,
                            emailError = eErr,
                            dobError = dErr,
                            addressError = aErr,
                            passwordError = passErr,
                            confirmPasswordError = confErr,
                            errorMessage = if (!s.isPhoneVerified && pErr != null) "Please verify your mobile number with OTP to continue" else "Please complete all required fields"
                        )
                    }
                    return false
                }
                _operatorState.update { it.copy(currentStep = 2, errorMessage = null) }
                return true
            }
            2 -> {
                var hasErr = false
                var opNameErr: String? = null
                var srvErr: String? = null
                var areaErr: String? = null

                if (s.operatorBusinessName.trim().isBlank()) {
                    opNameErr = "Operator / Guide Name is required"
                    hasErr = true
                }
                if (s.serviceType.trim().isBlank()) {
                    srvErr = "Type of Service is required"
                    hasErr = true
                }
                if (s.areasCovered.trim().isBlank()) {
                    areaErr = "Areas Covered is required"
                    hasErr = true
                }

                if (hasErr) {
                    _operatorState.update {
                        it.copy(
                            operatorBusinessNameError = opNameErr,
                            serviceTypeError = srvErr,
                            areasCoveredError = areaErr,
                            errorMessage = "Please fill in all operator profile details"
                        )
                    }
                    return false
                }
                _operatorState.update { it.copy(currentStep = 3, errorMessage = null) }
                return true
            }
            3 -> {
                var hasErr = false
                var pkgErr: String? = null
                var prcErr: String? = null

                if (s.tourPackageTitle.trim().isBlank()) {
                    pkgErr = "Available Tour Package name is required"
                    hasErr = true
                }
                val priceVal = s.tourPrice.toDoubleOrNull()
                if (priceVal == null || priceVal <= 0) {
                    prcErr = "Please enter a valid price"
                    hasErr = true
                }
                if (!s.onlinePaymentAvailable && !s.cashPaymentAvailable) {
                    _operatorState.update { it.copy(errorMessage = "Please enable at least one payment method (Online or Cash)") }
                    return false
                }

                if (hasErr) {
                    _operatorState.update {
                        it.copy(
                            packageTitleError = pkgErr,
                            priceError = prcErr,
                            errorMessage = "Please complete all tour & payment information"
                        )
                    }
                    return false
                }
                _operatorState.update { it.copy(currentStep = 4, errorMessage = null) }
                return true
            }
            else -> return true
        }
    }

    fun proceedToPreviousStep() {
        val cur = _operatorState.value.currentStep
        if (cur > 1) {
            _operatorState.update { it.copy(currentStep = cur - 1, errorMessage = null) }
        }
    }

    // Legacy email stubs
    fun requestEmailVerification() {}
    fun verifyEmailCode() {}

    fun registerCustomer(onSuccess: (UserProfile) -> Unit) {
        val s = _customerState.value
        var hasError = false
        var nameErr: String? = null
        var phoneErr: String? = null
        var emailErr: String? = null
        var passErr: String? = null
        var confErr: String? = null
        var emerNameErr: String? = null
        var emerPhoneErr: String? = null

        if (s.fullName.trim().isEmpty()) {
            nameErr = "Full name is required"
            hasError = true
        }
        if (!SecurityManager.isValidPhoneNumber(s.mobileNumber)) {
            phoneErr = "Valid 10-digit mobile number is required"
            hasError = true
        } else if (!s.isPhoneVerified) {
            phoneErr = "Mobile number must be verified using OTP before account creation"
            hasError = true
        }
        if (!SecurityManager.isValidEmail(s.email)) {
            emailErr = "Valid email address is required"
            hasError = true
        }
        val passValidation = SecurityManager.validatePassword(s.password)
        if (!passValidation.isValid) {
            passErr = passValidation.errorMessage
            hasError = true
        }
        if (s.password != s.confirmPassword) {
            confErr = "Passwords do not match"
            hasError = true
        }
        if (s.emergencyContactName.trim().isEmpty()) {
            emerNameErr = "Emergency contact name required for tour safety"
            hasError = true
        }
        if (!SecurityManager.isValidPhoneNumber(s.emergencyContactPhone)) {
            emerPhoneErr = "Emergency phone number required"
            hasError = true
        }

        if (hasError) {
            _customerState.update {
                it.copy(
                    nameError = nameErr,
                    phoneError = phoneErr,
                    emailError = emailErr,
                    passwordError = passErr,
                    confirmPasswordError = confErr,
                    emergencyNameError = emerNameErr,
                    emergencyPhoneError = emerPhoneErr
                )
            }
            return
        }

        viewModelScope.launch {
            _customerState.update { it.copy(isLoading = true, errorMessage = null) }
            val emergencyContact = EmergencyContact(
                name = s.emergencyContactName.trim(),
                phoneNumber = s.emergencyContactPhone.trim(),
                relationship = s.emergencyContactRelation.trim()
            )
            val result = authRepository.signUpCustomer(
                fullName = s.fullName,
                email = s.email,
                phoneNumber = s.mobileNumber,
                password = s.password,
                address = s.address,
                profilePhotoUrl = s.profilePhotoUrl.ifBlank { null },
                emergencyContact = emergencyContact,
                phoneVerified = s.isPhoneVerified
            )
            when (result) {
                is AuthResult.Success -> {
                    _customerState.update { it.copy(isLoading = false) }
                    onSuccess(result.data)
                }
                is AuthResult.Error -> {
                    _customerState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {
                    _customerState.update { it.copy(isLoading = true) }
                }
            }
        }
    }

    fun submitOperatorRegistration(onSuccess: (UserProfile) -> Unit) {
        val s = _operatorState.value
        if (!s.confirmationChecked) {
            _operatorState.update { it.copy(errorMessage = "Please confirm that the information provided is correct and genuine.") }
            return
        }

        viewModelScope.launch {
            _operatorState.update { it.copy(isLoading = true, errorMessage = null) }

            val years = s.yearsOfExperience.toIntOrNull() ?: 5
            val maxGuests = s.maxTourists.toIntOrNull() ?: 15
            val tourCapacity = s.tourMaxCapacity.toIntOrNull() ?: 12
            val priceVal = s.tourPrice.toDoubleOrNull() ?: 4500.0

            val result = authRepository.signUpOperator(
                fullName = s.fullName,
                email = s.email,
                phoneNumber = s.mobileNumber,
                password = s.password,
                address = s.address,
                profilePhotoUrl = s.profilePhotoUrl.ifBlank { null },
                dateOfBirth = s.dateOfBirth,
                gender = s.gender,
                state = s.state,
                district = s.district,
                operatorBusinessName = s.operatorBusinessName,
                serviceType = s.serviceType,
                yearsOfExperience = years,
                areasCovered = s.areasCovered,
                languagesSpoken = s.languagesSpoken,
                maxTourists = maxGuests,
                shortDescription = s.shortDescription,
                tourPackageTitle = s.tourPackageTitle,
                tourDuration = s.tourDuration,
                tourPrice = priceVal,
                tourMaxCapacity = tourCapacity,
                tourAvailableDates = s.tourAvailableDates,
                onlinePaymentAvailable = s.onlinePaymentAvailable,
                cashPaymentAvailable = s.cashPaymentAvailable,
                phoneVerified = s.isPhoneVerified
            )

            when (result) {
                is AuthResult.Success -> {
                    val user = result.data
                    _operatorState.update {
                        it.copy(
                            isLoading = false,
                            isSubmittedSuccessfully = true,
                            createdOperator = user
                        )
                    }
                    onSuccess(user)
                }
                is AuthResult.Error -> {
                    _operatorState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {
                    _operatorState.update { it.copy(isLoading = true) }
                }
            }
        }
    }

    fun submitSmartOperatorRegistration(onComplete: (UserProfile) -> Unit) {
        submitOperatorRegistration(onComplete)
    }
}
