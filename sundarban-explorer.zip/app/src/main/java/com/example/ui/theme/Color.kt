package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI Forest & Mangrove Greens
val ForestDarkest = Color(0xFF06160E)
val MangroveDark = Color(0xFF0F3826)
val MangrovePrimary = Color(0xFF1B4332)
val MangroveMedium = Color(0xFF2D6A4F)
val MangroveLight = Color(0xFF40916C)
val MangroveContainer = Color(0xFFE8F3ED)
val OnMangroveContainer = Color(0xFF06160E)

// Immersive UI Amber & Tangerine Accents
val TigerAmber = Color(0xFFFF8A00)
val TigerGold = Color(0xFFF59E0B)
val TigerLight = Color(0xFFFFF4E5)
val OnTigerLight = Color(0xFF663000)

// Sundarban River Deep Teal & Blue
val RiverTeal = Color(0xFF0E7490)
val RiverTealLight = Color(0xFFE0F2FE)
val OnRiverTeal = Color(0xFF0369A1)

// Immersive Nature Canvas & Cards
val SandBg = Color(0xFFF8FAF8)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceCardAlt = Color(0xFFF1F5F9)
val OutlineBorder = Color(0xFFE2E8F0)
val OutlineSubtle = Color(0xFFF1F5F9)
val TextPrimary = Color(0xFF06160E)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF94A3B8)

// Status & Trust Indicators
val StatusVerified = Color(0xFF16A34A)
val StatusVerifiedBg = Color(0xFFDCFCE7)
val StatusPending = Color(0xFFD97706)
val StatusPendingBg = Color(0xFFFEF3C7)
val StatusRejected = Color(0xFFDC2626)
val StatusRejectedBg = Color(0xFFFEE2E2)
val StatusAdmin = Color(0xFF4338CA)
val StatusAdminBg = Color(0xFFEEF2FF)

// Dark Theme Colors
val MangrovePrimaryDark = Color(0xFF52B788)
val MangroveContainerDark = Color(0xFF081C12)
val TigerAmberDark = Color(0xFFFFA726)
val RiverTealDark = Color(0xFF38BDF8)
val BackgroundDark = Color(0xFF06160E)
val SurfaceDark = Color(0xFF0C2417)
val SurfaceCardDark = Color(0xFF143324)
val TextPrimaryDark = Color(0xFFF8FAF8)
val TextSecondaryDark = Color(0xFF94A3B8)
