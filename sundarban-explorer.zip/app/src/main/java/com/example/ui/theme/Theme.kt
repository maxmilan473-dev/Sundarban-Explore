package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MangrovePrimaryDark,
    onPrimary = Color(0xFF003822),
    primaryContainer = MangroveContainerDark,
    onPrimaryContainer = Color(0xFF8FF7BD),
    secondary = TigerAmberDark,
    onSecondary = Color(0xFF452B00),
    secondaryContainer = Color(0xFF623F00),
    onSecondaryContainer = Color(0xFFFFDDB8),
    tertiary = RiverTealDark,
    onTertiary = Color(0xFF003544),
    tertiaryContainer = Color(0xFF004D62),
    onTertiaryContainer = Color(0xFFBBE9FF),
    background = BackgroundDark,
    onBackground = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceCardDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = Color(0xFF89938D)
)

private val LightColorScheme = lightColorScheme(
    primary = MangrovePrimary,
    onPrimary = Color.White,
    primaryContainer = MangroveContainer,
    onPrimaryContainer = OnMangroveContainer,
    secondary = TigerAmber,
    onSecondary = Color.White,
    secondaryContainer = TigerLight,
    onSecondaryContainer = OnTigerLight,
    tertiary = RiverTeal,
    onTertiary = Color.White,
    tertiaryContainer = RiverTealLight,
    onTertiaryContainer = OnRiverTeal,
    background = SandBg,
    onBackground = TextPrimary,
    surface = SurfaceCard,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCardAlt,
    onSurfaceVariant = TextSecondary,
    outline = OutlineBorder
)

@Composable
fun SundarbanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) = SundarbanTheme(darkTheme = darkTheme, content = content)
