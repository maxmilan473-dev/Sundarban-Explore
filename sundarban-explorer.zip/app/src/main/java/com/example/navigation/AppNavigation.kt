package com.example.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.core.di.AppContainer
import com.example.core.localization.LocalAppStrings
import com.example.core.model.UserRole
import com.example.features.admin.AdminDashboardScreen
import com.example.features.admin.AdminViewModel
import com.example.features.authentication.forgotpassword.ForgotPasswordScreen
import com.example.features.authentication.forgotpassword.ForgotPasswordViewModel
import com.example.features.authentication.login.LoginScreen
import com.example.features.authentication.login.LoginViewModel
import com.example.features.authentication.onboarding.OnboardingScreen
import com.example.features.authentication.signup.CustomerSignUpScreen
import com.example.features.authentication.signup.OperatorSignUpScreen
import com.example.features.authentication.signup.SignUpViewModel
import com.example.features.authentication.splash.SplashScreen
import com.example.features.booking.CreateBookingScreen
import com.example.features.booking.CustomerBookingsScreen
import com.example.features.booking.OperatorBookingsScreen
import com.example.features.customer.CustomerHomeScreen
import com.example.features.customer.CustomerHomeViewModel
import com.example.features.library.EcoLibraryScreen
import com.example.features.library.EcoLibraryViewModel
import com.example.features.operator.OperatorDashboardScreen
import com.example.features.operator.OperatorViewModel
import com.example.features.operator.directory.OperatorDirectoryScreen
import com.example.features.operator.directory.OperatorPublicProfileScreen
import com.example.features.operator.packages.CreatePackageScreen
import com.example.features.operator.packages.OperatorPackagesScreen
import com.example.features.packages.PackageDetailScreen
import com.example.features.payment.AdminTransactionsScreen
import com.example.features.payment.CustomerPaymentsScreen
import com.example.features.payment.OperatorEarningsScreen
import com.example.features.legal.LegalPagesScreen
import com.example.features.profile.ProfileScreen
import com.example.features.profile.ProfileViewModel
import com.example.features.search.UniversalSearchScreen

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val LOGIN = "login"
    const val CUSTOMER_SIGN_UP = "customer_sign_up"
    const val OPERATOR_SIGN_UP = "operator_sign_up"
    const val FORGOT_PASSWORD = "forgot_password"
    const val CUSTOMER_HOME = "customer_home"
    const val OPERATOR_DASHBOARD = "operator_dashboard"
    const val ADMIN_DASHBOARD = "admin_dashboard"
    const val ECO_LIBRARY = "eco_library"
    const val PROFILE = "profile"

    // Part 3 Routes
    const val OPERATOR_DIRECTORY = "operator_directory"
    const val OPERATOR_PUBLIC_PROFILE = "operator_public_profile/{operatorId}"
    const val OPERATOR_PACKAGES = "operator_packages"
    const val CREATE_PACKAGE = "create_package"
    const val PACKAGE_DETAIL = "package_detail/{packageId}"
    const val CREATE_BOOKING = "create_booking/{packageId}"
    const val CUSTOMER_BOOKINGS = "customer_bookings"
    const val OPERATOR_BOOKINGS = "operator_bookings"
    const val UNIVERSAL_SEARCH = "universal_search"

    // Part 4 Routes
    const val CUSTOMER_PAYMENTS = "customer_payments"
    const val OPERATOR_EARNINGS = "operator_earnings"
    const val ADMIN_TRANSACTIONS = "admin_transactions"
    const val LEGAL_PAGES = "legal_pages"
}

@Composable
fun AppNavigation(
    appContainer: AppContainer,
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
) {
    val currentLanguage by appContainer.languageManager.currentLanguage.collectAsState()
    val localizedStrings by appContainer.languageManager.currentStrings.collectAsState()
    val currentUser by appContainer.authRepository.currentUser.collectAsState()

    CompositionLocalProvider(LocalAppStrings provides localizedStrings) {
        NavHost(
            navController = navController,
            startDestination = Routes.SPLASH,
            modifier = modifier
        ) {
            // Splash Screen
            composable(Routes.SPLASH) {
                SplashScreen(
                    onSplashFinished = {
                        val destination = if (currentUser != null) {
                            when (currentUser?.role) {
                                UserRole.CUSTOMER -> Routes.CUSTOMER_HOME
                                UserRole.OPERATOR -> Routes.OPERATOR_DASHBOARD
                                UserRole.ADMIN -> Routes.ADMIN_DASHBOARD
                                null -> Routes.LOGIN
                            }
                        } else {
                            Routes.ONBOARDING
                        }
                        navController.navigate(destination) {
                            popUpTo(Routes.SPLASH) { inclusive = true }
                        }
                    }
                )
            }

            // Onboarding Screen
            composable(Routes.ONBOARDING) {
                OnboardingScreen(
                    onGetStarted = {
                        navController.navigate(Routes.LOGIN) {
                            popUpTo(Routes.ONBOARDING) { inclusive = true }
                        }
                    },
                    currentLanguage = currentLanguage,
                    onLanguageSelected = { appContainer.languageManager.setLanguage(it) }
                )
            }

            // Login Screen
            composable(Routes.LOGIN) {
                val loginViewModel = remember { LoginViewModel(appContainer.authRepository) }
                LoginScreen(
                    viewModel = loginViewModel,
                    onLoginSuccess = { user ->
                        val target = when (user.role) {
                            UserRole.CUSTOMER -> Routes.CUSTOMER_HOME
                            UserRole.OPERATOR -> Routes.OPERATOR_DASHBOARD
                            UserRole.ADMIN -> Routes.ADMIN_DASHBOARD
                        }
                        navController.navigate(target) {
                            popUpTo(Routes.LOGIN) { inclusive = true }
                        }
                    },
                    onNavigateToCustomerSignUp = { navController.navigate(Routes.CUSTOMER_SIGN_UP) },
                    onNavigateToOperatorSignUp = { navController.navigate(Routes.OPERATOR_SIGN_UP) },
                    onNavigateToForgotPassword = { navController.navigate(Routes.FORGOT_PASSWORD) },
                    currentLanguage = currentLanguage,
                    onLanguageSelected = { appContainer.languageManager.setLanguage(it) }
                )
            }

            // Customer Sign Up
            composable(Routes.CUSTOMER_SIGN_UP) {
                val signUpViewModel = remember { SignUpViewModel(appContainer.authRepository) }
                CustomerSignUpScreen(
                    viewModel = signUpViewModel,
                    onSignUpSuccess = {
                        navController.navigate(Routes.CUSTOMER_HOME) {
                            popUpTo(Routes.LOGIN) { inclusive = true }
                        }
                    },
                    onNavigateBackToLogin = { navController.popBackStack() }
                )
            }

            // Operator Sign Up
            composable(Routes.OPERATOR_SIGN_UP) {
                val signUpViewModel = remember { SignUpViewModel(appContainer.authRepository) }
                OperatorSignUpScreen(
                    viewModel = signUpViewModel,
                    onSignUpSuccess = {
                        navController.navigate(Routes.OPERATOR_DASHBOARD) {
                            popUpTo(Routes.LOGIN) { inclusive = true }
                        }
                    },
                    onNavigateBackToLogin = { navController.popBackStack() }
                )
            }

            // Forgot Password
            composable(Routes.FORGOT_PASSWORD) {
                val forgotViewModel = remember { ForgotPasswordViewModel(appContainer.authRepository) }
                ForgotPasswordScreen(
                    viewModel = forgotViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Customer / Tourist Home
            composable(Routes.CUSTOMER_HOME) {
                val customerHomeViewModel = remember {
                    CustomerHomeViewModel(
                        tourRepository = appContainer.tourRepository,
                        contentRepository = appContainer.contentRepository,
                        authRepository = appContainer.authRepository,
                        languageManager = appContainer.languageManager
                    )
                }
                CustomerHomeScreen(
                    viewModel = customerHomeViewModel,
                    onNavigateToLibrary = { navController.navigate(Routes.ECO_LIBRARY) },
                    onNavigateToProfile = { navController.navigate(Routes.PROFILE) },
                    onNavigateToArticleDetail = { navController.navigate(Routes.ECO_LIBRARY) },
                    onNavigateToDirectory = { navController.navigate(Routes.OPERATOR_DIRECTORY) },
                    onNavigateToSearch = { navController.navigate(Routes.UNIVERSAL_SEARCH) },
                    onNavigateToBookings = { navController.navigate(Routes.CUSTOMER_BOOKINGS) },
                    onNavigateToPackageDetail = { pkgId -> navController.navigate("package_detail/$pkgId") },
                    onNavigateToCreateBooking = { pkgId -> navController.navigate("create_booking/$pkgId") }
                )
            }

            // Operator Dashboard
            composable(Routes.OPERATOR_DASHBOARD) {
                val operatorViewModel = remember {
                    OperatorViewModel(
                        authRepository = appContainer.authRepository,
                        tourRepository = appContainer.tourRepository
                    )
                }
                OperatorDashboardScreen(
                    viewModel = operatorViewModel,
                    onNavigateToProfile = { navController.navigate(Routes.PROFILE) },
                    onNavigateToEarnings = { navController.navigate(Routes.OPERATOR_EARNINGS) },
                    onNavigateToPackages = { navController.navigate(Routes.OPERATOR_PACKAGES) }
                )
            }

            // Admin Governance Console
            composable(Routes.ADMIN_DASHBOARD) {
                val adminViewModel = remember {
                    AdminViewModel(
                        authRepository = appContainer.authRepository,
                        tourRepository = appContainer.tourRepository,
                        contentRepository = appContainer.contentRepository
                    )
                }
                AdminDashboardScreen(
                    viewModel = adminViewModel,
                    onNavigateToProfile = { navController.navigate(Routes.PROFILE) },
                    onNavigateToTransactions = { navController.navigate(Routes.ADMIN_TRANSACTIONS) }
                )
            }

            // Eco Library Screen
            composable(Routes.ECO_LIBRARY) {
                val ecoLibraryViewModel = remember {
                    EcoLibraryViewModel(
                        contentRepository = appContainer.contentRepository,
                        languageManager = appContainer.languageManager
                    )
                }
                EcoLibraryScreen(
                    viewModel = ecoLibraryViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Profile Screen
            composable(Routes.PROFILE) {
                val profileViewModel = remember {
                    ProfileViewModel(
                        authRepository = appContainer.authRepository,
                        languageManager = appContainer.languageManager
                    )
                }
                ProfileScreen(
                    viewModel = profileViewModel,
                    currentLanguage = currentLanguage,
                    onLogout = {
                        navController.navigate(Routes.LOGIN) {
                            popUpTo(0) { inclusive = true }
                        }
                    },
                    onNavigateToPayments = { navController.navigate(Routes.CUSTOMER_PAYMENTS) },
                    onNavigateToEarnings = { navController.navigate(Routes.OPERATOR_EARNINGS) },
                    onNavigateToTransactions = { navController.navigate(Routes.ADMIN_TRANSACTIONS) },
                    onNavigateToLegal = { navController.navigate(Routes.LEGAL_PAGES) }
                )
            }

            // Tour Operator Directory
            composable(Routes.OPERATOR_DIRECTORY) {
                OperatorDirectoryScreen(
                    tourRepository = appContainer.tourRepository,
                    onNavigateBack = { navController.popBackStack() },
                    onSelectOperator = { opId ->
                        navController.navigate("operator_public_profile/$opId")
                    },
                    onBookPackage = { pkgId ->
                        navController.navigate("create_booking/$pkgId")
                    }
                )
            }

            // Operator Public Profile
            composable(
                route = Routes.OPERATOR_PUBLIC_PROFILE
            ) { backStackEntry ->
                val operatorId = backStackEntry.arguments?.getString("operatorId") ?: ""
                OperatorPublicProfileScreen(
                    operatorId = operatorId,
                    tourRepository = appContainer.tourRepository,
                    onNavigateBack = { navController.popBackStack() },
                    onBookPackage = { pkgId ->
                        navController.navigate("create_booking/$pkgId")
                    }
                )
            }

            // Operator Packages Management
            composable(Routes.OPERATOR_PACKAGES) {
                OperatorPackagesScreen(
                    currentUser = currentUser,
                    tourRepository = appContainer.tourRepository,
                    onNavigateBack = { navController.popBackStack() },
                    onCreatePackage = { navController.navigate(Routes.CREATE_PACKAGE) },
                    onViewPackageDetail = { pkgId -> navController.navigate("package_detail/$pkgId") }
                )
            }

            // Create Package Screen
            composable(Routes.CREATE_PACKAGE) {
                CreatePackageScreen(
                    currentUser = currentUser,
                    tourRepository = appContainer.tourRepository,
                    onNavigateBack = { navController.popBackStack() },
                    onPackageCreated = { navController.popBackStack() }
                )
            }

            // Package Detail Screen
            composable(
                route = Routes.PACKAGE_DETAIL
            ) { backStackEntry ->
                val packageId = backStackEntry.arguments?.getString("packageId") ?: ""
                PackageDetailScreen(
                    packageId = packageId,
                    tourRepository = appContainer.tourRepository,
                    onNavigateBack = { navController.popBackStack() },
                    onViewOperatorProfile = { opId ->
                        navController.navigate("operator_public_profile/$opId")
                    },
                    onBookNow = { pkgId ->
                        navController.navigate("create_booking/$pkgId")
                    }
                )
            }

            // Create Booking Screen
            composable(
                route = Routes.CREATE_BOOKING
            ) { backStackEntry ->
                val packageId = backStackEntry.arguments?.getString("packageId") ?: ""
                CreateBookingScreen(
                    packageId = packageId,
                    currentUser = currentUser,
                    tourRepository = appContainer.tourRepository,
                    onNavigateBack = { navController.popBackStack() },
                    onBookingSuccess = { bookingId ->
                        navController.navigate(Routes.CUSTOMER_BOOKINGS) {
                            popUpTo(Routes.CUSTOMER_HOME)
                        }
                    }
                )
            }

            // Customer Bookings Dashboard
            composable(Routes.CUSTOMER_BOOKINGS) {
                CustomerBookingsScreen(
                    currentUser = currentUser,
                    tourRepository = appContainer.tourRepository,
                    onNavigateBack = { navController.popBackStack() },
                    onExplorePackages = { navController.navigate(Routes.OPERATOR_DIRECTORY) },
                    onNavigateToPayments = { navController.navigate(Routes.CUSTOMER_PAYMENTS) }
                )
            }

            // Operator Bookings Dashboard
            composable(Routes.OPERATOR_BOOKINGS) {
                OperatorBookingsScreen(
                    currentUser = currentUser,
                    tourRepository = appContainer.tourRepository,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Universal Search Screen
            composable(Routes.UNIVERSAL_SEARCH) {
                UniversalSearchScreen(
                    tourRepository = appContainer.tourRepository,
                    contentRepository = appContainer.contentRepository,
                    onNavigateBack = { navController.popBackStack() },
                    onSelectOperator = { opId ->
                        navController.navigate("operator_public_profile/$opId")
                    },
                    onSelectPackage = { pkgId ->
                        navController.navigate("package_detail/$pkgId")
                    },
                    onNavigateToLibrary = {
                        navController.navigate(Routes.ECO_LIBRARY)
                    }
                )
            }

            // Customer Payments & Invoices Screen
            composable(Routes.CUSTOMER_PAYMENTS) {
                currentUser?.let { user ->
                    CustomerPaymentsScreen(
                        currentUser = user,
                        tourRepository = appContainer.tourRepository,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

            // Operator Earnings & Financials Screen
            composable(Routes.OPERATOR_EARNINGS) {
                currentUser?.let { user ->
                    OperatorEarningsScreen(
                        currentUser = user,
                        tourRepository = appContainer.tourRepository,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

            // Admin Platform Transactions & Commission Screen
            composable(Routes.ADMIN_TRANSACTIONS) {
                currentUser?.let { user ->
                    AdminTransactionsScreen(
                        currentUser = user,
                        tourRepository = appContainer.tourRepository,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

            // Legal, Privacy & Compliance Pages Screen
            composable(Routes.LEGAL_PAGES) {
                LegalPagesScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}
