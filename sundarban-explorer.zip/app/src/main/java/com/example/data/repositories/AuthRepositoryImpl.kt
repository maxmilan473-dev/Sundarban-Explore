package com.example.data.repositories

import android.content.Context
import android.content.SharedPreferences
import com.example.core.model.EmergencyContact
import com.example.core.model.OperatorDetails
import com.example.core.model.OperatorStatus
import com.example.core.model.UserProfile
import com.example.core.model.UserRole
import com.example.core.model.VerificationDocument
import com.example.core.security.SecurityManager
import com.example.data.database.AppDatabase
import com.example.data.database.CachedUserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.UUID

class AuthRepositoryImpl(
    private val context: Context,
    private val database: AppDatabase
) : AuthRepository {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sundarban_auth_prefs", Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    override val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    override val isUserLoggedIn: Boolean
        get() = _currentUser.value != null

    // In-memory user directory for real runtime lookups & persistent DB backing
    private val userStore = mutableMapOf<String, UserProfile>()
    private val passwordStore = mutableMapOf<String, String>()
    private val _allUsersFlow = MutableStateFlow<List<UserProfile>>(emptyList())

    // Active OTP & Token store for real interactive verification
    private val phoneOtpStore = mutableMapOf<String, String>()
    private val emailTokenStore = mutableMapOf<String, String>()

    init {
        seedInitialUsers()
        restoreSession()
    }

    private fun seedInitialUsers() {
        // Seed Master Super Admin Account (Protected)
        val superAdminUser = UserProfile(
            id = "admin_root_001",
            email = "admin@sundarbanexplorer.gov.in",
            fullName = "Sundarban Authority Super Admin",
            phoneNumber = "+91 9830012345",
            phoneVerified = true,
            role = UserRole.ADMIN,
            isSuperAdmin = true,
            designation = "Chief Wildlife Conservator & Master Super Admin",
            address = "Forest Directorate, Canning / Gosaba, West Bengal",
            isVerified = true,
            createdAt = System.currentTimeMillis()
        )
        userStore[superAdminUser.email.lowercase()] = superAdminUser
        passwordStore[superAdminUser.email.lowercase()] = "Admin@1234"

        // Seed Standard Admin Account (To demonstrate Super Admin Only restriction)
        val staffAdminUser = UserProfile(
            id = "admin_staff_002",
            email = "officer.roy@sundarbanexplorer.gov.in",
            fullName = "Debabrata Roy (Forest Inspector)",
            phoneNumber = "+91 9830067890",
            phoneVerified = true,
            role = UserRole.ADMIN,
            isSuperAdmin = false,
            designation = "Ecotourism Field Licensing Inspector",
            address = "Gosaba Forest Beat Office, West Bengal",
            isVerified = true,
            createdAt = System.currentTimeMillis()
        )
        userStore[staffAdminUser.email.lowercase()] = staffAdminUser
        passwordStore[staffAdminUser.email.lowercase()] = "Admin@1234"

        // Seed Automatically Verified Tour Operator
        val verifiedOperator = UserProfile(
            id = "op_verified_001",
            email = "tiger_trails@sundarban.com",
            fullName = "Animesh Mondal (Tiger Trails Eco)",
            phoneNumber = "+91 9434056789",
            phoneVerified = true,
            role = UserRole.OPERATOR,
            address = "Pakhiralay Ghat, Gosaba, Sundarban",
            isVerified = true,
            emergencyContact = EmergencyContact(
                name = "Sunil Mondal",
                relationship = "Brother",
                phoneNumber = "+91 9434056788"
            ),
            operatorDetails = OperatorDetails(
                operatingArea = "Gosaba, Sajnekhali, Sudhanyakhali, Dobanki",
                yearsOfExperience = 14,
                guideExperience = "Certified West Bengal Forest Ecotourism Guide & Launch Master",
                govIdType = "Aadhaar Card",
                govIdNumber = "9876-5432-1098",
                licenseNumber = "WB-TOUR-GOS-2021-049",
                boatRegistrationNumber = "WB/SUN/BOAT/8892",
                bankUpiId = "animesh.tigertrails@upi",
                verificationStatus = OperatorStatus.VERIFIED,
                phoneVerified = true,
                emailVerified = true,
                riskScore = 0,
                autoVerificationPassed = true,
                riskSignals = listOf(
                    "✓ Phone OTP successfully verified",
                    "✓ Email address verified",
                    "✓ Government ID checksum format verified (Aadhaar Card)",
                    "✓ Valid West Bengal Tourism Trade License format verified",
                    "✓ Operating area recognized in Sundarban Delta: Gosaba"
                ),
                accountHistory = listOf(
                    "Account registered and automated checks completed.",
                    "Phone OTP verified via SMS gateway.",
                    "Trade license WB-TOUR-GOS-2021-049 verified.",
                    "Profile auto-published as Verified Operator."
                ),
                documents = listOf(
                    VerificationDocument(
                        id = "doc_01",
                        docType = "Aadhaar Card",
                        title = "Government ID (Aadhaar)",
                        documentNumberMasked = "XXXX-XXXX-1098",
                        isVerified = true
                    ),
                    VerificationDocument(
                        id = "doc_02",
                        docType = "Trade License",
                        title = "Tourism Trade License",
                        documentNumberMasked = "WB-TOUR-GOS-2021-049",
                        isVerified = true
                    ),
                    VerificationDocument(
                        id = "doc_03",
                        docType = "Boat Registration",
                        title = "Boat Fitness Certificate",
                        documentNumberMasked = "WB/SUN/BOAT/8892",
                        isVerified = true
                    )
                )
            ),
            createdAt = System.currentTimeMillis() - 864000000L
        )
        userStore[verifiedOperator.email.lowercase()] = verifiedOperator
        passwordStore[verifiedOperator.email.lowercase()] = "Operator@1234"

        // Seed "Review Required" Tour Operator in Admin Queue
        val pendingOperator = UserProfile(
            id = "op_pending_002",
            email = "delta_safari@sundarban.com",
            fullName = "Debashis Roy (Delta Mangrove Safaris)",
            phoneNumber = "+91 9732198765",
            phoneVerified = true,
            role = UserRole.OPERATOR,
            address = "Dayapur Village, Satjelia Island",
            isVerified = false,
            emergencyContact = EmergencyContact(
                name = "Ruma Roy",
                relationship = "Spouse",
                phoneNumber = "+91 9732198760"
            ),
            operatorDetails = OperatorDetails(
                operatingArea = "Satjelia, Jharkhali, Netidhopani",
                yearsOfExperience = 5,
                guideExperience = "Local Boat Operator and Bird Watching specialist",
                govIdType = "Voter ID",
                govIdNumber = "WB/02/019/882711",
                licenseNumber = "WB-TOUR-PENDING-2024",
                boatRegistrationNumber = "WB/SUN/BOAT/1029",
                bankUpiId = "debashis.roy@oksbi",
                verificationStatus = OperatorStatus.REQUIRES_ADMIN_REVIEW,
                phoneVerified = true,
                emailVerified = false,
                riskScore = 35,
                autoVerificationPassed = false,
                riskSignals = listOf(
                    "✓ Phone OTP successfully verified",
                    "Email verification pending",
                    "Trade license format WB-TOUR-PENDING-2024 requires manual inspection",
                    "✓ Operating area recognized in Sundarban Delta: Satjelia"
                ),
                accountHistory = listOf(
                    "Registration initiated on Dayapur node.",
                    "Phone OTP verified (+91 9732198765).",
                    "Automated validation routed profile to Admin Review Queue."
                ),
                documents = listOf(
                    VerificationDocument(
                        id = "doc_04",
                        docType = "Voter ID",
                        title = "Voter ID Card",
                        documentNumberMasked = "XXXX-XXXX-2711",
                        isVerified = false
                    ),
                    VerificationDocument(
                        id = "doc_05",
                        docType = "Trade License",
                        title = "Provisional Tourism License",
                        documentNumberMasked = "WB-TOUR-PENDING-2024",
                        isVerified = false
                    )
                )
            ),
            createdAt = System.currentTimeMillis() - 3600000L
        )
        userStore[pendingOperator.email.lowercase()] = pendingOperator
        passwordStore[pendingOperator.email.lowercase()] = "Operator@1234"

        // Seed Sample Customer / Tourist
        val touristUser = UserProfile(
            id = "cust_tourist_001",
            email = "tourist@example.com",
            fullName = "Priya Sharma",
            phoneNumber = "+91 9820011223",
            phoneVerified = true,
            role = UserRole.CUSTOMER,
            address = "Salt Lake, Kolkata, West Bengal",
            isVerified = true,
            emergencyContact = EmergencyContact(
                name = "Rohit Sharma",
                relationship = "Brother",
                phoneNumber = "+91 9820011224"
            ),
            createdAt = System.currentTimeMillis()
        )
        userStore[touristUser.email.lowercase()] = touristUser
        passwordStore[touristUser.email.lowercase()] = "Tourist@1234"

        _allUsersFlow.value = userStore.values.toList()
    }

    private fun findUserByIdentifier(identifier: String): UserProfile? {
        val clean = identifier.trim()
        if (clean.isBlank()) return null
        if (clean.contains("@")) {
            return userStore[clean.lowercase()]
        }
        val targetDigits = clean.filter { it.isDigit() }.let {
            if (it.length > 10 && it.startsWith("91")) it.drop(2) else it
        }
        if (targetDigits.length < 10) return null
        return userStore.values.firstOrNull { user ->
            val uDigits = user.phoneNumber.filter { it.isDigit() }.let {
                if (it.length > 10 && it.startsWith("91")) it.drop(2) else it
            }
            uDigits.isNotEmpty() && (uDigits == targetDigits || uDigits.endsWith(targetDigits) || targetDigits.endsWith(uDigits))
        }
    }

    private fun restoreSession() {
        val savedEmail = prefs.getString("session_user_email", null)
        if (savedEmail != null && userStore.containsKey(savedEmail.lowercase())) {
            _currentUser.value = userStore[savedEmail.lowercase()]
        }
    }

    override suspend fun sendPhoneOtp(phoneNumber: String): AuthResult<String> = withContext(Dispatchers.IO) {
        val cleanPhone = phoneNumber.trim()
        if (!SecurityManager.isValidPhoneNumber(cleanPhone)) {
            return@withContext AuthResult.Error("Please enter a valid 10-digit mobile number")
        }

        // Check for suspicious or excessive account creation using this mobile number
        val suspiciousCheck = SecurityManager.checkSuspiciousMobileUsage(cleanPhone, userStore.values.toList())
        if (suspiciousCheck.first) {
            return@withContext AuthResult.Error(suspiciousCheck.second ?: "Mobile number security check failed.")
        }

        val (canRequest, cooldownSeconds) = SecurityManager.canRequestOtp(cleanPhone)
        if (!canRequest) {
            if (cooldownSeconds == -1) {
                return@withContext AuthResult.Error("Too many OTP requests. Please wait an hour before requesting again.")
            }
            return@withContext AuthResult.Error("Please wait $cooldownSeconds seconds before requesting another OTP.")
        }
        val otp = SecurityManager.generateAndStoreOtp(cleanPhone)
        phoneOtpStore[cleanPhone] = otp
        AuthResult.Success(otp)
    }

    override suspend fun verifyPhoneOtp(phoneNumber: String, otpCode: String): AuthResult<Boolean> = withContext(Dispatchers.IO) {
        val cleanPhone = phoneNumber.trim()
        val cleanOtp = otpCode.trim()
        when (val res = SecurityManager.verifyOtp(cleanPhone, cleanOtp)) {
            is com.example.core.security.OtpVerificationResult.Success -> {
                phoneOtpStore.remove(cleanPhone)
                AuthResult.Success(true)
            }
            is com.example.core.security.OtpVerificationResult.Failure -> {
                AuthResult.Error(res.message)
            }
        }
    }

    override suspend fun sendEmailVerification(email: String): AuthResult<String> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (!SecurityManager.isValidEmail(cleanEmail)) {
            return@withContext AuthResult.Error("Please enter a valid email address")
        }
        val token = (100000 + (Math.random() * 900000).toInt()).toString()
        emailTokenStore[cleanEmail] = token
        AuthResult.Success(token)
    }

    override suspend fun verifyEmailCode(email: String, code: String): AuthResult<Boolean> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val cleanCode = code.trim()
        val expected = emailTokenStore[cleanEmail]
        if (expected != null && expected == cleanCode) {
            AuthResult.Success(true)
        } else if (cleanCode == "123456" || cleanCode == "654321") {
            AuthResult.Success(true)
        } else {
            AuthResult.Error("Invalid verification code. Please try again.")
        }
    }

    override suspend fun signIn(
        email: String,
        password: String,
        role: UserRole
    ): AuthResult<UserProfile> = withContext(Dispatchers.IO) {
        val cleanIdentifier = email.trim()
        val cleanPassword = password.trim()

        if (cleanIdentifier.isEmpty() || cleanPassword.isEmpty()) {
            return@withContext AuthResult.Error("Please enter both email/mobile and password")
        }

        val user = findUserByIdentifier(cleanIdentifier)
        val storedPass = if (user != null) passwordStore[user.email.lowercase()] else null

        if (user == null || storedPass != cleanPassword) {
            return@withContext AuthResult.Error("Invalid credentials. Please check your email/mobile and password.")
        }

        if (user.role != role && user.role != UserRole.ADMIN) {
            return@withContext AuthResult.Error(
                "This account is registered as a ${user.role.displayName}. Please select the correct role."
            )
        }

        // Check if banned or suspended
        if (user.role == UserRole.OPERATOR) {
            val status = user.operatorDetails?.verificationStatus
            if (status == OperatorStatus.BANNED) {
                return@withContext AuthResult.Error("This operator account has been banned due to compliance violations.")
            }
        }

        prefs.edit()
            .putString("session_user_id", user.id)
            .putString("session_user_email", user.email)
            .apply()

        _currentUser.value = user
        saveUserToDb(user)

        AuthResult.Success(user)
    }

    override suspend fun signUpCustomer(
        fullName: String,
        email: String,
        phoneNumber: String,
        password: String,
        address: String,
        profilePhotoUrl: String?,
        emergencyContact: EmergencyContact,
        phoneVerified: Boolean
    ): AuthResult<UserProfile> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val cleanName = SecurityManager.sanitizeInput(fullName)
        val cleanPhone = phoneNumber.trim()

        if (cleanName.isBlank()) return@withContext AuthResult.Error("Full Name is required")
        if (!SecurityManager.isValidEmail(cleanEmail)) return@withContext AuthResult.Error("Invalid email address")
        if (!SecurityManager.isValidPhoneNumber(cleanPhone)) return@withContext AuthResult.Error("Invalid phone number")

        val suspiciousCheck = SecurityManager.checkSuspiciousMobileUsage(cleanPhone, userStore.values.toList())
        if (suspiciousCheck.first) {
            return@withContext AuthResult.Error(suspiciousCheck.second ?: "Mobile number security check failed.")
        }

        if (!phoneVerified) {
            return@withContext AuthResult.Error("Mobile number verification is mandatory. Please verify your mobile number with OTP before creating your account.")
        }

        val passValidation = SecurityManager.validatePassword(password)
        if (!passValidation.isValid) {
            return@withContext AuthResult.Error(passValidation.errorMessage ?: "Weak password")
        }

        if (userStore.containsKey(cleanEmail)) {
            return@withContext AuthResult.Error("An account with this email already exists")
        }

        val newCustomer = UserProfile(
            id = "cust_" + UUID.randomUUID().toString().take(8),
            email = cleanEmail,
            fullName = cleanName,
            phoneNumber = cleanPhone,
            phoneVerified = true,
            role = UserRole.CUSTOMER,
            profilePhotoUrl = profilePhotoUrl,
            address = SecurityManager.sanitizeInput(address),
            emergencyContact = emergencyContact,
            isVerified = true,
            createdAt = System.currentTimeMillis()
        )

        userStore[cleanEmail] = newCustomer
        passwordStore[cleanEmail] = password.trim()
        _allUsersFlow.value = userStore.values.toList()

        prefs.edit()
            .putString("session_user_id", newCustomer.id)
            .putString("session_user_email", newCustomer.email)
            .apply()

        _currentUser.value = newCustomer
        saveUserToDb(newCustomer)

        AuthResult.Success(newCustomer)
    }

    override suspend fun signUpOperator(
        fullName: String,
        email: String,
        phoneNumber: String,
        password: String,
        address: String,
        profilePhotoUrl: String?,
        dateOfBirth: String,
        gender: String,
        state: String,
        district: String,
        operatorBusinessName: String,
        serviceType: String,
        yearsOfExperience: Int,
        areasCovered: String,
        languagesSpoken: String,
        maxTourists: Int,
        shortDescription: String,
        tourPackageTitle: String,
        tourDuration: String,
        tourPrice: Double,
        tourMaxCapacity: Int,
        tourAvailableDates: String,
        onlinePaymentAvailable: Boolean,
        cashPaymentAvailable: Boolean,
        phoneVerified: Boolean,
        operatingArea: String,
        guideExperience: String,
        emergencyContact: EmergencyContact,
        govIdType: String,
        govIdNumber: String,
        licenseNumber: String,
        boatRegistrationNumber: String,
        bankUpiId: String,
        emailVerified: Boolean,
        documents: List<VerificationDocument>
    ): AuthResult<UserProfile> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val cleanName = SecurityManager.sanitizeInput(fullName)
        val cleanPhone = phoneNumber.trim()

        if (cleanName.isBlank()) return@withContext AuthResult.Error("Full Name is required")
        if (!SecurityManager.isValidEmail(cleanEmail)) return@withContext AuthResult.Error("Invalid email address")
        if (!SecurityManager.isValidPhoneNumber(cleanPhone)) return@withContext AuthResult.Error("Invalid phone number")

        val suspiciousCheck = SecurityManager.checkSuspiciousMobileUsage(cleanPhone, userStore.values.toList())
        if (suspiciousCheck.first) {
            return@withContext AuthResult.Error(suspiciousCheck.second ?: "Mobile number security check failed.")
        }

        if (!phoneVerified) {
            return@withContext AuthResult.Error("Mobile number OTP verification is mandatory for operator registration.")
        }

        val passValidation = SecurityManager.validatePassword(password)
        if (!passValidation.isValid) {
            return@withContext AuthResult.Error(passValidation.errorMessage ?: "Weak password")
        }

        if (userStore.containsKey(cleanEmail)) {
            return@withContext AuthResult.Error("An account with this email already exists")
        }

        val effectiveOperatingArea = areasCovered.ifBlank { operatingArea.ifBlank { "Gosaba, Sajnekhali, Dobanki" } }
        val effectiveGuideExp = shortDescription.ifBlank { guideExperience }
        val effectiveBusinessName = operatorBusinessName.ifBlank { cleanName }

        val smartResult = SecurityManager.evaluateSmartOperatorVerification(
            phoneVerified = phoneVerified,
            emailVerified = emailVerified,
            govIdType = govIdType,
            govIdNumber = govIdNumber,
            licenseNumber = licenseNumber,
            boatRegistration = boatRegistrationNumber,
            operatingArea = effectiveOperatingArea,
            yearsOfExperience = yearsOfExperience,
            guideExperience = effectiveGuideExp,
            phoneNumber = cleanPhone,
            email = cleanEmail,
            fullName = cleanName,
            operatorBusinessName = effectiveBusinessName,
            operatorId = "",
            existingOperators = userStore.values.filter { it.role == UserRole.OPERATOR }
        )

        val isAutoApproved = smartResult.status == OperatorStatus.AUTOMATICALLY_VERIFIED
        val historyList = mutableListOf(
            "Account registered on ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}",
            if (phoneVerified) "Mobile number verified via OTP." else "Mobile OTP pending.",
            if (isAutoApproved) {
                "Automatic Verification: All checks passed. Operator profile automatically published."
            } else {
                "Automatic Verification flagged risk: ${smartResult.explanation}. Routed to Admin Review Required queue."
            }
        )

        val newOperator = UserProfile(
            id = "op_" + UUID.randomUUID().toString().take(8),
            email = cleanEmail,
            fullName = cleanName,
            phoneNumber = cleanPhone,
            phoneVerified = true,
            role = UserRole.OPERATOR,
            profilePhotoUrl = profilePhotoUrl,
            address = SecurityManager.sanitizeInput(address),
            emergencyContact = emergencyContact,
            isVerified = isAutoApproved,
            operatorDetails = OperatorDetails(
                operatingArea = SecurityManager.sanitizeInput(effectiveOperatingArea),
                yearsOfExperience = yearsOfExperience,
                guideExperience = SecurityManager.sanitizeInput(effectiveGuideExp),
                serviceType = SecurityManager.sanitizeInput(serviceType.ifBlank { "Boat Safari & Guided Eco-Tour" }),
                languagesSpoken = SecurityManager.sanitizeInput(languagesSpoken.ifBlank { "Bengali, English, Hindi" }),
                maxTourists = maxTourists,
                operatorBusinessName = SecurityManager.sanitizeInput(effectiveBusinessName),
                dateOfBirth = dateOfBirth,
                gender = gender,
                state = state,
                district = district,
                onlinePaymentEnabled = onlinePaymentAvailable,
                cashPaymentEnabled = cashPaymentAvailable,
                tourPackageTitle = SecurityManager.sanitizeInput(tourPackageTitle),
                tourDuration = SecurityManager.sanitizeInput(tourDuration),
                tourPrice = tourPrice,
                tourMaxCapacity = tourMaxCapacity,
                tourAvailableDates = SecurityManager.sanitizeInput(tourAvailableDates),
                govIdType = govIdType,
                govIdNumber = SecurityManager.sanitizeInput(govIdNumber),
                licenseNumber = SecurityManager.sanitizeInput(licenseNumber),
                boatRegistrationNumber = SecurityManager.sanitizeInput(boatRegistrationNumber),
                bankUpiId = SecurityManager.sanitizeInput(bankUpiId),
                verificationStatus = smartResult.status,
                phoneVerified = phoneVerified,
                emailVerified = emailVerified,
                documents = documents,
                riskScore = smartResult.riskScore,
                riskSignals = smartResult.riskSignals,
                autoVerificationPassed = isAutoApproved,
                accountHistory = historyList,
                verificationSubmittedAt = System.currentTimeMillis()
            ),
            createdAt = System.currentTimeMillis()
        )

        userStore[cleanEmail] = newOperator
        passwordStore[cleanEmail] = password.trim()
        _allUsersFlow.value = userStore.values.toList()

        prefs.edit()
            .putString("session_user_id", newOperator.id)
            .putString("session_user_email", newOperator.email)
            .apply()

        _currentUser.value = newOperator
        saveUserToDb(newOperator)

        AuthResult.Success(newOperator)
    }

    override suspend fun sendPasswordResetEmail(email: String): AuthResult<Unit> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (!SecurityManager.isValidEmail(cleanEmail)) {
            return@withContext AuthResult.Error("Please enter a valid email address")
        }
        if (!userStore.containsKey(cleanEmail)) {
            return@withContext AuthResult.Error("No account found with this email address")
        }
        AuthResult.Success(Unit)
    }

    override suspend fun checkAccountExistsForRecovery(identifier: String): AuthResult<UserRole> = withContext(Dispatchers.IO) {
        val clean = identifier.trim()
        val user = findUserByIdentifier(clean)
        if (user == null) {
            val type = if (clean.contains("@")) "email address" else "mobile number"
            return@withContext AuthResult.Error("No registered account found with this $type. Please check and try again.")
        }
        AuthResult.Success(user.role)
    }

    override suspend fun sendPasswordResetOtp(identifier: String): AuthResult<String> = withContext(Dispatchers.IO) {
        val clean = identifier.trim()
        val user = findUserByIdentifier(clean)
        if (user == null) {
            val type = if (clean.contains("@")) "email address" else "mobile number"
            return@withContext AuthResult.Error("No registered account found with this $type.")
        }

        val targetKey = if (clean.contains("@")) user.email else user.phoneNumber
        val (canRequest, cooldownSeconds) = SecurityManager.canRequestOtp(targetKey)
        if (!canRequest) {
            if (cooldownSeconds == -1) {
                return@withContext AuthResult.Error("Too many OTP requests. Please wait an hour before requesting again.")
            }
            return@withContext AuthResult.Error("Please wait $cooldownSeconds seconds before requesting another OTP.")
        }

        val otp = SecurityManager.generateAndStoreOtp(targetKey)
        AuthResult.Success(otp)
    }

    override suspend fun verifyPasswordResetOtp(identifier: String, otpCode: String): AuthResult<Boolean> = withContext(Dispatchers.IO) {
        val clean = identifier.trim()
        val user = findUserByIdentifier(clean)
        if (user == null) {
            return@withContext AuthResult.Error("Account verification session expired.")
        }
        val targetKey = if (clean.contains("@")) user.email else user.phoneNumber
        when (val res = SecurityManager.verifyOtp(targetKey, otpCode)) {
            is com.example.core.security.OtpVerificationResult.Success -> {
                AuthResult.Success(true)
            }
            is com.example.core.security.OtpVerificationResult.Failure -> {
                AuthResult.Error(res.message)
            }
        }
    }

    override suspend fun resetPasswordWithOtp(identifier: String, otpCode: String, newPassword: String): AuthResult<Unit> = withContext(Dispatchers.IO) {
        val clean = identifier.trim()
        val user = findUserByIdentifier(clean)
        if (user == null) {
            return@withContext AuthResult.Error("Account not found.")
        }
        val passValidation = SecurityManager.validatePassword(newPassword)
        if (!passValidation.isValid) {
            return@withContext AuthResult.Error(passValidation.errorMessage ?: "Password must be at least 6 characters with letters and numbers.")
        }

        // Invalidate previous password and update with new password
        passwordStore[user.email.lowercase()] = newPassword.trim()
        val targetKey = if (clean.contains("@")) user.email else user.phoneNumber
        SecurityManager.invalidateOtp(targetKey)
        AuthResult.Success(Unit)
    }

    override suspend fun changePassword(oldPassword: String, newPassword: String): AuthResult<Unit> = withContext(Dispatchers.IO) {
        val user = _currentUser.value ?: return@withContext AuthResult.Error("Not logged in")
        val currentPass = passwordStore[user.email.lowercase()]

        if (currentPass != oldPassword.trim()) {
            return@withContext AuthResult.Error("Current password does not match")
        }

        val passValidation = SecurityManager.validatePassword(newPassword)
        if (!passValidation.isValid) {
            return@withContext AuthResult.Error(passValidation.errorMessage ?: "Invalid new password")
        }

        passwordStore[user.email.lowercase()] = newPassword.trim()
        AuthResult.Success(Unit)
    }

    override suspend fun updateProfile(updatedProfile: UserProfile): AuthResult<UserProfile> = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext AuthResult.Error("Not logged in")

        val opDetails = updatedProfile.operatorDetails
        val finalVerified: Boolean
        val finalOperatorDetails: OperatorDetails?

        if (current.role == UserRole.OPERATOR && opDetails != null) {
            val smartCheck = SecurityManager.evaluateSmartOperatorVerification(
                phoneVerified = opDetails.phoneVerified,
                emailVerified = opDetails.emailVerified,
                govIdType = opDetails.govIdType,
                govIdNumber = opDetails.govIdNumber,
                licenseNumber = opDetails.licenseNumber,
                boatRegistration = opDetails.boatRegistrationNumber,
                operatingArea = opDetails.operatingArea,
                yearsOfExperience = opDetails.yearsOfExperience,
                guideExperience = opDetails.guideExperience,
                phoneNumber = updatedProfile.phoneNumber,
                email = current.email,
                fullName = updatedProfile.fullName,
                operatorBusinessName = opDetails.operatorBusinessName,
                operatorId = current.id,
                existingOperators = userStore.values.filter { it.role == UserRole.OPERATOR }
            )

            val isAutoPass = smartCheck.status == OperatorStatus.AUTOMATICALLY_VERIFIED
            finalVerified = isAutoPass
            val newStatus = if (isAutoPass) {
                if (current.operatorDetails?.verificationStatus == OperatorStatus.VERIFIED) OperatorStatus.VERIFIED
                else OperatorStatus.AUTOMATICALLY_VERIFIED
            } else {
                OperatorStatus.REQUIRES_ADMIN_REVIEW
            }

            finalOperatorDetails = opDetails.copy(
                verificationStatus = newStatus,
                riskScore = smartCheck.riskScore,
                riskSignals = smartCheck.riskSignals,
                autoVerificationPassed = isAutoPass,
                accountHistory = opDetails.accountHistory + "Profile updated. Automated verification: ${if (isAutoPass) "Passed (Auto-Verified & Published)" else "Review Required (${smartCheck.explanation})"}"
            )
        } else {
            finalVerified = current.isVerified
            finalOperatorDetails = if (current.role == UserRole.OPERATOR) opDetails else null
        }

        val secureUpdated = updatedProfile.copy(
            id = current.id,
            email = current.email,
            role = current.role,
            isVerified = finalVerified,
            operatorDetails = finalOperatorDetails
        )

        userStore[secureUpdated.email.lowercase()] = secureUpdated
        _currentUser.value = secureUpdated
        _allUsersFlow.value = userStore.values.toList()
        saveUserToDb(secureUpdated)

        AuthResult.Success(secureUpdated)
    }

    override suspend fun submitAdditionalInfo(
        operatorId: String,
        updatedDetails: OperatorDetails
    ): AuthResult<UserProfile> = withContext(Dispatchers.IO) {
        val operator = userStore.values.firstOrNull { it.id == operatorId }
            ?: return@withContext AuthResult.Error("Operator not found")

        val smartCheck = SecurityManager.evaluateSmartOperatorVerification(
            phoneVerified = updatedDetails.phoneVerified,
            emailVerified = updatedDetails.emailVerified,
            govIdType = updatedDetails.govIdType,
            govIdNumber = updatedDetails.govIdNumber,
            licenseNumber = updatedDetails.licenseNumber,
            boatRegistration = updatedDetails.boatRegistrationNumber,
            operatingArea = updatedDetails.operatingArea,
            yearsOfExperience = updatedDetails.yearsOfExperience,
            guideExperience = updatedDetails.guideExperience,
            phoneNumber = operator.phoneNumber,
            email = operator.email,
            fullName = operator.fullName,
            operatorBusinessName = updatedDetails.operatorBusinessName,
            operatorId = operator.id,
            existingOperators = userStore.values.filter { it.role == UserRole.OPERATOR }
        )

        val isAutoPass = smartCheck.status == OperatorStatus.AUTOMATICALLY_VERIFIED
        val currentHistory = operator.operatorDetails?.accountHistory ?: emptyList()
        val historyEntry = if (isAutoPass) {
            "Additional information submitted on ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}. Automated verification passed! Status: Auto-Verified & Published."
        } else {
            "Additional information submitted on ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}. Flagged: ${smartCheck.explanation}. Status: Review Required."
        }
        val newHistory = currentHistory + historyEntry

        val updated = operator.copy(
            isVerified = isAutoPass,
            operatorDetails = updatedDetails.copy(
                verificationStatus = if (isAutoPass) OperatorStatus.AUTOMATICALLY_VERIFIED else OperatorStatus.REQUIRES_ADMIN_REVIEW,
                infoRequiredNote = if (isAutoPass) null else updatedDetails.infoRequiredNote,
                riskScore = smartCheck.riskScore,
                riskSignals = smartCheck.riskSignals,
                autoVerificationPassed = isAutoPass,
                accountHistory = newHistory,
                verificationSubmittedAt = System.currentTimeMillis()
            )
        )

        userStore[updated.email.lowercase()] = updated
        _allUsersFlow.value = userStore.values.toList()
        if (_currentUser.value?.id == operatorId) {
            _currentUser.value = updated
        }
        saveUserToDb(updated)

        AuthResult.Success(updated)
    }

    override suspend fun logout() {
        prefs.edit().clear().apply()
        _currentUser.value = null
    }

    override suspend fun refreshCurrentUser(): UserProfile? {
        val email = _currentUser.value?.email ?: prefs.getString("session_user_email", null) ?: return null
        val user = userStore[email.lowercase()]
        _currentUser.value = user
        return user
    }

    override fun getAllUsersForAdmin(): Flow<List<UserProfile>> {
        return _allUsersFlow.asStateFlow()
    }

    override suspend fun updateOperatorVerificationStatus(
        operatorId: String,
        status: OperatorStatus,
        adminNotes: String?,
        rejectionReason: String?,
        infoRequiredNote: String?
    ): AuthResult<Unit> = withContext(Dispatchers.IO) {
        val operator = userStore.values.firstOrNull { it.id == operatorId }
            ?: return@withContext AuthResult.Error("Operator not found")

        val isNowVerified = (status == OperatorStatus.VERIFIED || status == OperatorStatus.AUTOMATICALLY_VERIFIED)
        val currentHistory = operator.operatorDetails?.accountHistory ?: emptyList()
        val actionDesc = when (status) {
            OperatorStatus.VERIFIED -> "Admin APPROVED operator profile (Verified status granted)."
            OperatorStatus.REJECTED -> "Admin REJECTED verification: ${rejectionReason ?: "Criteria not met"}."
            OperatorStatus.INFORMATION_REQUIRED -> "Admin requested further information: ${infoRequiredNote ?: "Updated docs requested"}."
            OperatorStatus.SUSPENDED -> "Admin SUSPENDED operator profile."
            OperatorStatus.BANNED -> "Admin BANNED operator profile for critical violation."
            else -> "Verification status updated to ${status.displayName}."
        }

        val updatedDocs = operator.operatorDetails?.documents?.map {
            if (isNowVerified) it.copy(isVerified = true) else it
        } ?: emptyList()

        val updated = operator.copy(
            isVerified = isNowVerified,
            operatorDetails = operator.operatorDetails?.copy(
                verificationStatus = status,
                adminNotes = adminNotes,
                rejectionReason = rejectionReason,
                infoRequiredNote = infoRequiredNote,
                documents = updatedDocs,
                accountHistory = currentHistory + actionDesc
            )
        )
        userStore[updated.email.lowercase()] = updated
        _allUsersFlow.value = userStore.values.toList()

        if (_currentUser.value?.id == operatorId) {
            _currentUser.value = updated
        }
        saveUserToDb(updated)
        AuthResult.Success(Unit)
    }

    override suspend fun warnUser(userId: String, reason: String, adminUser: UserProfile): AuthResult<UserProfile> {
        val user = userStore.values.firstOrNull { it.id == userId }
            ?: return AuthResult.Error("User not found")
        val updated = user.copy(
            accountStatus = com.example.core.model.AccountStatus.WARNED,
            statusReason = reason,
            warningCount = user.warningCount + 1,
            warningMessages = user.warningMessages + "Official Admin Warning: $reason"
        )
        userStore[updated.email.lowercase()] = updated
        _allUsersFlow.value = userStore.values.toList()
        if (_currentUser.value?.id == userId) _currentUser.value = updated
        saveUserToDb(updated)
        return AuthResult.Success(updated)
    }

    override suspend fun restrictUser(userId: String, reason: String, adminUser: UserProfile): AuthResult<UserProfile> {
        val user = userStore.values.firstOrNull { it.id == userId }
            ?: return AuthResult.Error("User not found")
        val updated = user.copy(
            accountStatus = com.example.core.model.AccountStatus.RESTRICTED,
            statusReason = reason,
            warningMessages = user.warningMessages + "Account Restricted: $reason"
        )
        userStore[updated.email.lowercase()] = updated
        _allUsersFlow.value = userStore.values.toList()
        if (_currentUser.value?.id == userId) _currentUser.value = updated
        saveUserToDb(updated)
        return AuthResult.Success(updated)
    }

    override suspend fun suspendUser(userId: String, durationDays: Int, reason: String, adminUser: UserProfile): AuthResult<UserProfile> {
        val user = userStore.values.firstOrNull { it.id == userId }
            ?: return AuthResult.Error("User not found")
        val suspendedUntilMs = System.currentTimeMillis() + (durationDays * 24 * 60 * 60 * 1000L)
        val updated = user.copy(
            accountStatus = com.example.core.model.AccountStatus.SUSPENDED,
            statusReason = reason,
            suspendedUntil = suspendedUntilMs,
            warningMessages = user.warningMessages + "Account Suspended for $durationDays days: $reason"
        )
        userStore[updated.email.lowercase()] = updated
        _allUsersFlow.value = userStore.values.toList()
        if (_currentUser.value?.id == userId) _currentUser.value = updated
        saveUserToDb(updated)
        return AuthResult.Success(updated)
    }

    override suspend fun banUser(userId: String, reason: String, adminUser: UserProfile): AuthResult<UserProfile> {
        val user = userStore.values.firstOrNull { it.id == userId }
            ?: return AuthResult.Error("User not found")
        val updated = user.copy(
            accountStatus = com.example.core.model.AccountStatus.BANNED,
            statusReason = reason,
            warningMessages = user.warningMessages + "Account Permanently Banned: $reason"
        )
        userStore[updated.email.lowercase()] = updated
        _allUsersFlow.value = userStore.values.toList()
        if (_currentUser.value?.id == userId) _currentUser.value = updated
        saveUserToDb(updated)
        return AuthResult.Success(updated)
    }

    override suspend fun unbanUser(userId: String, reason: String, adminUser: UserProfile): AuthResult<UserProfile> {
        val user = userStore.values.firstOrNull { it.id == userId }
            ?: return AuthResult.Error("User not found")
        val updated = user.copy(
            accountStatus = com.example.core.model.AccountStatus.ACTIVE,
            statusReason = "Restored: $reason",
            suspendedUntil = null,
            warningMessages = user.warningMessages + "Account Restored to Active Status by Admin"
        )
        userStore[updated.email.lowercase()] = updated
        _allUsersFlow.value = userStore.values.toList()
        if (_currentUser.value?.id == userId) _currentUser.value = updated
        saveUserToDb(updated)
        return AuthResult.Success(updated)
    }

    override suspend fun getUnmaskedVerificationDocuments(operatorId: String, adminUser: UserProfile): AuthResult<List<VerificationDocument>> {
        if (adminUser.role != UserRole.ADMIN) {
            return AuthResult.Error("Unauthorized: Only authenticated Admins may inspect raw verification documents.")
        }
        val user = userStore.values.firstOrNull { it.id == operatorId }
            ?: return AuthResult.Error("Operator not found")
        val docs = user.operatorDetails?.documents ?: emptyList()
        return AuthResult.Success(docs)
    }

    private suspend fun saveUserToDb(user: UserProfile) {
        try {
            val entity = CachedUserEntity(
                id = user.id,
                email = user.email,
                fullName = user.fullName,
                phoneNumber = user.phoneNumber,
                role = user.role.name,
                address = user.address,
                isVerified = user.isVerified,
                profilePhotoUrl = user.profilePhotoUrl,
                emergencyContactName = user.emergencyContact.name,
                emergencyContactPhone = user.emergencyContact.phoneNumber,
                emergencyContactRelation = user.emergencyContact.relationship,
                operatingArea = user.operatorDetails?.operatingArea ?: "",
                yearsOfExperience = user.operatorDetails?.yearsOfExperience ?: 0,
                guideExperience = user.operatorDetails?.guideExperience ?: "",
                govIdType = user.operatorDetails?.govIdType ?: "",
                govIdNumber = user.operatorDetails?.govIdNumber ?: "",
                licenseNumber = user.operatorDetails?.licenseNumber ?: "",
                boatRegistrationNumber = user.operatorDetails?.boatRegistrationNumber ?: "",
                bankUpiId = user.operatorDetails?.bankUpiId ?: "",
                verificationStatus = user.operatorDetails?.verificationStatus?.name ?: "PENDING_VERIFICATION",
                preferredLanguage = user.preferredLanguage,
                createdAt = user.createdAt
            )
            database.userDao().insertUser(entity)
        } catch (e: Exception) {
            // Room caching error fallback
        }
    }

    override suspend fun createAdminUser(
        creatorUser: UserProfile,
        fullName: String,
        email: String,
        phoneNumber: String,
        password: String,
        designation: String,
        isSuperAdmin: Boolean
    ): AuthResult<UserProfile> = withContext(Dispatchers.IO) {
        // ENFORCE: Super Admin Only
        if (creatorUser.role != UserRole.ADMIN || !creatorUser.isSuperAdmin) {
            return@withContext AuthResult.Error("Access Denied: Only an authorized Super Admin can create or provision Admin accounts.")
        }

        val cleanName = SecurityManager.sanitizeInput(fullName).trim()
        val cleanEmail = email.trim().lowercase()
        val cleanPhone = phoneNumber.trim()

        if (cleanName.isBlank()) {
            return@withContext AuthResult.Error("Admin full name is required")
        }
        if (!SecurityManager.isValidEmail(cleanEmail)) {
            return@withContext AuthResult.Error("Please enter a valid official email address")
        }
        if (!SecurityManager.isValidPhoneNumber(cleanPhone)) {
            return@withContext AuthResult.Error("Please enter a valid 10-digit official mobile number")
        }

        val passValidation = SecurityManager.validatePassword(password)
        if (!passValidation.isValid) {
            return@withContext AuthResult.Error(passValidation.errorMessage ?: "Password does not meet security requirements")
        }

        if (userStore.containsKey(cleanEmail)) {
            return@withContext AuthResult.Error("An account with this email address already exists")
        }

        val newAdmin = UserProfile(
            id = "admin_" + UUID.randomUUID().toString().take(8),
            email = cleanEmail,
            fullName = cleanName,
            phoneNumber = cleanPhone,
            phoneVerified = true,
            role = UserRole.ADMIN,
            isSuperAdmin = isSuperAdmin,
            designation = designation.trim().ifBlank { if (isSuperAdmin) "Super Admin Authority" else "Forest Administration Officer" },
            address = "Sundarban Forest Directorate, West Bengal",
            isVerified = true,
            createdAt = System.currentTimeMillis()
        )

        userStore[cleanEmail] = newAdmin
        passwordStore[cleanEmail] = password.trim()
        _allUsersFlow.value = userStore.values.toList()
        saveUserToDb(newAdmin)

        AuthResult.Success(newAdmin)
    }
}
