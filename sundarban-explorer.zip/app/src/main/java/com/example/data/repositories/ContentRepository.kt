package com.example.data.repositories

import com.example.core.model.BookChapter
import com.example.core.model.BookResource
import com.example.core.model.SundarbanArticle
import com.example.core.model.VideoResource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

interface ContentRepository {
    // Articles & Sundarban Information System
    fun getArticles(): Flow<List<SundarbanArticle>>
    fun getArticleById(id: String): SundarbanArticle?
    suspend fun addArticle(article: SundarbanArticle): Boolean
    suspend fun updateArticle(article: SundarbanArticle): Boolean
    suspend fun toggleArticlePublish(id: String): Boolean
    suspend fun archiveArticle(id: String): Boolean
    suspend fun deleteArticle(id: String): Boolean

    // Videos
    fun getVideos(): Flow<List<VideoResource>>
    fun getVideoById(id: String): VideoResource?
    suspend fun addVideo(video: VideoResource): Boolean
    suspend fun updateVideo(video: VideoResource): Boolean
    suspend fun toggleVideoPublish(id: String): Boolean
    suspend fun deleteVideo(id: String): Boolean

    // Books & Digital Reading Library
    fun getBooks(): Flow<List<BookResource>>
    fun getBookById(id: String): BookResource?
    suspend fun addBook(book: BookResource): Boolean
    suspend fun updateBook(book: BookResource): Boolean
    suspend fun updateReadingProgress(bookId: String, progressPercent: Int): Boolean
    suspend fun toggleBookmark(bookId: String, pageOrChapter: Int): Boolean
    suspend fun deleteBook(bookId: String): Boolean
}

class ContentRepositoryImpl : ContentRepository {

    private val _articles = MutableStateFlow<List<SundarbanArticle>>(seedArticles())
    private val _videos = MutableStateFlow<List<VideoResource>>(seedVideos())
    private val _books = MutableStateFlow<List<BookResource>>(seedBooks())

    override fun getArticles(): Flow<List<SundarbanArticle>> = _articles.asStateFlow()
    override fun getArticleById(id: String): SundarbanArticle? = _articles.value.firstOrNull { it.id == id }

    override suspend fun addArticle(article: SundarbanArticle): Boolean {
        val newArticle = if (article.id.isBlank()) article.copy(id = "art_" + UUID.randomUUID().toString().take(8)) else article
        _articles.value = listOf(newArticle) + _articles.value
        return true
    }

    override suspend fun updateArticle(article: SundarbanArticle): Boolean {
        _articles.value = _articles.value.map { if (it.id == article.id) article else it }
        return true
    }

    override suspend fun toggleArticlePublish(id: String): Boolean {
        _articles.value = _articles.value.map {
            if (it.id == id) it.copy(isPublished = !it.isPublished) else it
        }
        return true
    }

    override suspend fun archiveArticle(id: String): Boolean {
        _articles.value = _articles.value.map {
            if (it.id == id) it.copy(isArchived = !it.isArchived) else it
        }
        return true
    }

    override suspend fun deleteArticle(id: String): Boolean {
        _articles.value = _articles.value.filterNot { it.id == id }
        return true
    }

    override fun getVideos(): Flow<List<VideoResource>> = _videos.asStateFlow()
    override fun getVideoById(id: String): VideoResource? = _videos.value.firstOrNull { it.id == id }

    override suspend fun addVideo(video: VideoResource): Boolean {
        val newVideo = if (video.id.isBlank()) video.copy(id = "vid_" + UUID.randomUUID().toString().take(8)) else video
        _videos.value = listOf(newVideo) + _videos.value
        return true
    }

    override suspend fun updateVideo(video: VideoResource): Boolean {
        _videos.value = _videos.value.map { if (it.id == video.id) video else it }
        return true
    }

    override suspend fun toggleVideoPublish(id: String): Boolean {
        _videos.value = _videos.value.map {
            if (it.id == id) it.copy(isPublished = !it.isPublished) else it
        }
        return true
    }

    override suspend fun deleteVideo(id: String): Boolean {
        _videos.value = _videos.value.filterNot { it.id == id }
        return true
    }

    override fun getBooks(): Flow<List<BookResource>> = _books.asStateFlow()
    override fun getBookById(id: String): BookResource? = _books.value.firstOrNull { it.id == id }

    override suspend fun addBook(book: BookResource): Boolean {
        val newBook = if (book.id.isBlank()) book.copy(id = "bk_" + UUID.randomUUID().toString().take(8)) else book
        _books.value = listOf(newBook) + _books.value
        return true
    }

    override suspend fun updateBook(book: BookResource): Boolean {
        _books.value = _books.value.map { if (it.id == book.id) book else it }
        return true
    }

    override suspend fun updateReadingProgress(bookId: String, progressPercent: Int): Boolean {
        _books.value = _books.value.map {
            if (it.id == bookId) it.copy(readingProgressPercent = progressPercent.coerceIn(0, 100)) else it
        }
        return true
    }

    override suspend fun toggleBookmark(bookId: String, pageOrChapter: Int): Boolean {
        _books.value = _books.value.map { book ->
            if (book.id == bookId) {
                val currentBookmarks = book.bookmarks.toMutableList()
                if (currentBookmarks.contains(pageOrChapter)) {
                    currentBookmarks.remove(pageOrChapter)
                } else {
                    currentBookmarks.add(pageOrChapter)
                }
                book.copy(bookmarks = currentBookmarks)
            } else book
        }
        return true
    }

    override suspend fun deleteBook(bookId: String): Boolean {
        _books.value = _books.value.filterNot { it.id == bookId }
        return true
    }

    companion object {
        private fun seedArticles(): List<SundarbanArticle> = listOf(
            SundarbanArticle(
                id = "art_about_01",
                titleEn = "About Sundarbans: The World's Largest Mangrove Delta",
                titleBn = "সুন্দরবন পরিচিতি: বিশ্বের বৃহত্তম ম্যানগ্রোভ বদ্বীপ",
                titleHi = "सुंदरबन का परिचय: विश्व का सबसे बड़ा मैंग्रोव डेल्टा",
                category = "About Sundarbans",
                summaryEn = "A UNESCO World Heritage Site and Biosphere Reserve spanning over 10,000 sq km across India and Bangladesh.",
                summaryBn = "ইউনেস্কো ওয়ার্ল্ড হেরিটেজ সাইট ও বায়োস্ফিয়ার রিজার্ভ যা ভারত ও বাংলাদেশে বিস্তৃত।",
                summaryHi = "यूनेस्को विश्व धरोहर स्थल और बायोस्फीयर रिजर्व जो भारत और बांग्लादेश में फैला है।",
                contentEn = "The Sundarbans delta is formed by the confluence of the Ganges, Brahmaputra, and Meghna rivers across the Bay of Bengal. Covering approximately 10,000 square kilometres (about 40% in India and 60% in Bangladesh), it is celebrated for its dense mangrove network, tidal waterways, and extraordinary biological diversity. It was designated a UNESCO World Heritage Site in 1987 (India) and 1997 (Bangladesh).",
                contentBn = "গঙ্গা, ব্রহ্মপুত্র ও মেঘনা নদীর সঙ্গমস্থলে বঙ্গোপসাগরের কোল ঘেঁষে গঠিত সুন্দরবন বদ্বীপ প্রায় ১০,০০০ বর্গকিলোমিটার এলাকা জুড়ে বিস্তৃত। এর ৪০% ভারতে এবং ৬০% বাংলাদেশে অবস্থিত। এটি তার ঘন ম্যানগ্রোভ বনাঞ্চল এবং রয়্যাল বেঙ্গল টাইগারের জন্য পৃথিবীজুড়ে খ্যাত।",
                contentHi = "गंगा, ब्रह्मपुत्र और मेघना नदियों के संगम पर बंगाल की खाड़ी के पास स्थित सुंदरबन डेल्टा लगभग 10,000 वर्ग किमी में फैला है। यह अपने अद्वितीय मैंग्रोव जंगलों और रॉयल बंगाल टाइगर के लिए दुनिया भर में प्रसिद्ध है।",
                readTimeMinutes = 5
            ),
            SundarbanArticle(
                id = "art_history_02",
                titleEn = "History & Ancient Maritime Chronicles of the Delta",
                titleBn = "বদ্বীপের ইতিহাস ও প্রাচীন সামুদ্রিক রূপরেখা",
                titleHi = "डेल्टा का इतिहास और प्राचीन समुद्री इतिहास",
                category = "History",
                summaryEn = "From ancient Mauryan maritime trade routes to the Mughal imperial forest grants and British conservation enactments.",
                summaryBn = "মৌর্য যুগের বাণিজ্য পথ থেকে শুরু করে মুঘল বন অনুদান এবং ব্রিটিশ সংরক্ষণ আইন।",
                summaryHi = "मौर्य युगीन व्यापार मार्गों से लेकर मुगल वन अनुदान और ब्रिटिश संरक्षण अधिनियम तक।",
                contentEn = "Archaeological findings suggest human settlements existed along the periphery of the Sundarbans since the 2nd century BCE. During the Mughal period, Emperor Akbar leased forest tracts, and later under British rule in 1875, the Sundarbans were declared a reserved forest under the Forest Act of 1865, marking one of the earliest scientific forest conservation regimes in Asia.",
                contentBn = "খ্রিস্টপূর্ব ২য় শতক থেকেই সুন্দরবনের উপকণ্ঠে জনবসতির নিদর্শন পাওয়া যায়। মুঘল সম্রাট আকবরের আমলে সুন্দরবনের বনাঞ্চল ইজারা দেওয়া হতো। ১৮৭৫ সালে ব্রিটিশ শাসনামলে সুন্দরবনকে সংরক্ষিত বন হিসেবে ঘোষণা করা হয়।",
                contentHi = "सुंदरबन में दूसरी शताब्दी ईसा पूर्व से बस्तियों के प्रमाण मिलते हैं। 1875 में ब्रिटिश काल के दौरान इसे आरक्षित वन घोषित किया गया, जो एशिया के सबसे पुराने वैज्ञानिक संरक्षण प्रयासों में से एक है।",
                readTimeMinutes = 6
            ),
            SundarbanArticle(
                id = "art_tiger_03",
                titleEn = "Royal Bengal Tiger: Behavioral Adaptations to Tidal Mangroves",
                titleBn = "রয়্যাল বেঙ্গল টাইগার: জোয়ার-ভাটার ম্যানগ্রোভে অভিযোজন",
                titleHi = "रॉयल बंगाल टाइगर: ज्वारीय मैंग्रोव में रहने के अनूठे गुण",
                category = "Royal Bengal Tiger",
                summaryEn = "Discover how Sundarban tigers have evolved into exceptional swimmers who navigate tidal rivers and hunt in saline ecosystems.",
                summaryBn = "সুন্দরবনের বাঘ কীভাবে জলে সাঁতার কেটে নদী পারাপার করে এবং লবণাক্ত পরিবেশে টিকে থাকে।",
                summaryHi = "जानिए कैसे सुंदरबन के बाघ तैरने में माहिर हैं और खारे पानी में शिकार करते हैं।",
                contentEn = "Sundarban is home to the world's only mangrove-dwelling tigers (Panthera tigris tigris). These tigers are apex predators who have adapted to drink brackish water, swim across river channels over a kilometre wide against fierce currents, and prey upon spotted deer, wild boar, and water monitors. Forest department solar fences and nylon net barriers have successfully mitigated tiger-human interactions along inhabited village fringes.",
                contentBn = "সুন্দরবনের বাঘ বিশ্বের একমাত্র ম্যানগ্রোভ বনবাসী বাঘ। এরা তীব্র স্রোতেও সহজে নদী পার হতে পারে এবং লবণাক্ত জলের সাথে খাপ খাইয়ে নিয়েছে। বন দপ্তরের নাইলন জালের সুরক্ষার কারণে মানুষ ও বন্যপ্রাণীর দ্বন্দ্ব অনেক কমেছে।",
                contentHi = "सुंदरबन के बाघ दुनिया के एकमात्र मैंग्रोव निवासी बाघ हैं। वे खारे पानी में तैरने और शिकार करने में माहिर हैं। वन विभाग के नायलॉन बाड़ ने मानव-बाघ संघर्ष को काफी कम कर दिया है।",
                readTimeMinutes = 7
            ),
            SundarbanArticle(
                id = "art_mangrove_04",
                titleEn = "Mangrove Forest Ecology & Breathing Roots (Pneumatophores)",
                titleBn = "ম্যানগ্রোভ বনের বাস্তুতন্ত্র ও শ্বাসমূল (নিউম্যাটোফোর)",
                titleHi = "मैंग्रोव वन पारिस्थितिकी और श्वासमूल (न्यूमैटोफोर)",
                category = "Mangrove Forest",
                summaryEn = "How Sundari, Goran, Gewa and Kankra trees survive in saline, oxygen-deficient mudflats through specialized roots.",
                summaryBn = "সুন্দরী, গরান, গেওয়া এবং কাঁকড়া গাছ কীভাবে শ্বাসমূলের সাহায্যে বেঁচে থাকে।",
                summaryHi = "सुंदरी, गोरन और कंकड़ा के पेड़ कैसे श्वासमूलों की मदद से जीवित रहते हैं।",
                contentEn = "Mangroves are halophytic woody plants that thrive in intertidal zones. Because marsh sediment is anaerobic (devoid of oxygen), trees like Sundari (Heritiera fomes) send up thousands of pencil-like vertical roots called pneumatophores equipped with lenticels to breathe air during low tide. The stilt roots of Rhizophora also anchor the shoreline against severe cyclonic storm surges.",
                contentBn = "ম্যানগ্রোভের উদ্ভিদ কাদা ও লবণাক্ত জলে শ্বাস নেওয়ার জন্য মাটির উপরে হাজার হাজার শ্বাসমূল (Pneumatophores) পাঠায়। এই জটিল শিকড় সমুদ্রের ভয়াবহ ঘূর্ণিঝড় ও জলোচ্ছ্বাসের বিরুদ্ধে প্রাকৃতিক প্রাচীর হিসেবে কাজ করে।",
                contentHi = "मैंग्रोव पौधे खारे और कीचड़ वाले वातावरण में सांस लेने के लिए जमीन से ऊपर सांस की जड़ें निकालते हैं। ये जड़ें चक्रवाती तूफानों से तटों की रक्षा करती हैं।",
                readTimeMinutes = 5
            ),
            SundarbanArticle(
                id = "art_rivers_05",
                titleEn = "Rivers & Estuaries: The Lifelines of the Sunderban Delta",
                titleBn = "নদী ও মোহনা: সুন্দরবন বদ্বীপের প্রাণপ্রবাহ",
                titleHi = "नदियां और मुहाने: सुंदरबन डेल्टा की जीवन रेखाएं",
                category = "Rivers",
                summaryEn = "Exploring the Matla, Bidyadhari, Raimangal, Gosaba and Piyali river channels and their tidal dynamics.",
                summaryBn = "মাতলা, বিদ্যাধরী, রায়মঙ্গল, গোসাবা ও পিয়ালী নদীর জোয়ার-ভাটা এবং নৌ-চলাচল।",
                summaryHi = "मातला, बिद्याधरी, रायमंगल और गोसाबा नदियों के ज्वार-भाटा और नौवहन मार्ग।",
                contentEn = "The Sundarbans is interwoven with massive tidal estuaries that experience semidiurnal tides (two high tides and two low tides every 24 hours). Rivers like the Matla and Raimangal carry nutrient-rich silt, creating feeding grounds for mudskippers, crabs, and river dolphins (Orcaella brevirostris and Platanista gangetica).",
                contentBn = "সুন্দরবনের নদীগুলোতে দিনে দুবার জোয়ার এবং দুবার ভাটা হয়। মাতলা, রায়মঙ্গল ও গোসাবা নদী পলল বহন করে এবং ডলফিন ও সামুদ্রিক প্রাণীদের সমৃদ্ধ আবাসস্থল প্রদান করে।",
                contentHi = "सुंदरबन की नदियां ज्वार-भाटे से नियंत्रित होती हैं। मातला और रायमंगल जैसी नदियां गाद और डॉल्फ़िन के लिए समृद्ध आवास प्रदान करती हैं।",
                readTimeMinutes = 4
            ),
            SundarbanArticle(
                id = "art_islands_06",
                titleEn = "Islands of the Delta: Satjelia, Bali, Gosaba and Lothian",
                titleBn = "বদ্বীপের দ্বীপসমূহ: সাতজেলিয়া, বালি, গোসাবা ও লোথিয়ান",
                titleHi = "डेल्टा के द्वीप: सातजेलिया, बाली, गोसाबा और लोथियन",
                category = "Islands",
                summaryEn = "Discover the inhabited river islands, village embankments, and protected sanctuary islands across South 24 Parganas.",
                summaryBn = "দক্ষিণ ২৪ পরগনার জনবসতিপূর্ণ দ্বীপ ও সংরক্ষিত বন্যপ্রাণী অভয়ারণ্য দ্বীপসমূহ।",
                summaryHi = "दक्षिण 24 परगना के बसे हुए नदी द्वीप और संरक्षित वन्यजीव अभयारण्य।",
                contentEn = "The Indian Sundarbans contains 102 islands, of which 54 are inhabited by agricultural and fishing communities, while 48 are densely forested protected reserves. Islands like Gosaba are centers of eco-tourism, while Lothian and Halliday islands serve as strictly protected wildlife sanctuaries.",
                contentBn = "ভারতীয় সুন্দরবনে ১০২টি দ্বীপ রয়েছে, যার মধ্যে ৫৪টিতে মানুষ বাস করে এবং ৪৮টি সম্পূর্ণ সংরক্ষিত বনাঞ্চল। গোসাবা ও পাখিরালায় পর্যটনের প্রধান কেন্দ্র।",
                contentHi = "भारतीय सुंदरबन में 102 द्वीप हैं, जिनमें से 54 पर बस्तियां हैं और 48 संरक्षित वन हैं। गोसाबा पर्यटन का मुख्य केंद्र है।",
                readTimeMinutes = 5
            ),
            SundarbanArticle(
                id = "art_wildlife_07",
                titleEn = "Wildlife Diversity: Spotted Deer, Wild Boar & Fishing Cats",
                titleBn = "বন্যপ্রাণী বৈচিত্র্য: চিত্রা হরিণ, বুনো শূকর ও বাঘরোল",
                titleHi = "वन्यजीव विविधता: चीतल, जंगली सूअर और फिशिंग कैट",
                category = "Wildlife",
                summaryEn = "A comprehensive overview of mammals, ungulates, and endangered predators roaming the mangrove floor.",
                summaryBn = "ম্যানগ্রোভের চিত্রা হরিণ, মেছো বিড়াল এবং অন্যান্য স্তন্যপায়ী প্রাণীদের বিবরণ।",
                summaryHi = "मैंग्रोव जंगलों में घूमने वाले चीतल, जंगली सूअर और फिशिंग कैट की जानकारी।",
                contentEn = "Beyond the Royal Bengal Tiger, Sundarban supports robust populations of Chital (Axis axis), Eurasian Wild Boar, and the elusive Fishing Cat (Prionailurus viverrinus) — the state animal of West Bengal. Small clawless otters and rhesus macaques are frequent sightings along canal banks during low tides.",
                contentBn = "বাঘ ছাড়াও সুন্দরবনে প্রচুর চিত্রা হরিণ, বুনো শূকর এবং পশ্চিমবঙ্গের রাজ্য প্রাণী মেছো বিড়াল বা বাঘরোল বাস করে। নদী তীরে প্রায়ই ভোঁদড় ও বানর দেখা যায়।",
                contentHi = "बाघ के अलावा सुंदरबन में चीतल, जंगली सूअर और पश्चिम बंगाल का राज्य पशु फिशिंग कैट प्रचुर मात्रा में पाए जाते हैं।",
                readTimeMinutes = 5
            ),
            SundarbanArticle(
                id = "art_birds_08",
                titleEn = "Birds of the Sanctuary: Kingfishers, Sea Eagles & Masked Finfoot",
                titleBn = "পাখিদের স্বর্গরাজ্য: মাছরাঙা, সমুদ্র ঈগল ও কালামুখ প্যারাফিট",
                titleHi = "पक्षियों का स्वर्ग: किंगफिशर, समुद्री चील और दुर्लभ पक्षी",
                category = "Birds",
                summaryEn = "Ornithological guide to 315+ bird species, featuring 8 distinct kingfishers and rare raptors.",
                summaryBn = "৩১৫টিরও বেশি প্রজাতির পাখি এবং ৮ ধরনের মাছরাঙার সন্ধান সজনেখালী ও সংলগ্ন অঞ্চলে।",
                summaryHi = "सजनेखाली और आसपास पाए जाने वाले 315+ पक्षियों और 8 प्रकार के किंगफिशर की गाइड।",
                contentEn = "Sajnekhali Bird Sanctuary is celebrated for sightings of 8 Kingfisher species including the Pied, Goliath Stork-billed, and Brown-winged Kingfisher. Magnificent raptors like the White-bellied Sea Eagle and Brahminy Kite soar above the canopy.",
                contentBn = "সজনেখালী পাখি অভয়ারণ্যে ৮ প্রজাতির মাছরাঙা, সাদা পেটের সমুদ্র ঈগল এবং শঙ্খ চিল দেখা যায়। শীতকালে পরিযায়ী পাখিরা ভিড় জমায়।",
                contentHi = "सजनेखाली में 8 प्रजातियों के किंगफिशर और सफेद पेट वाले समुद्री चील देखे जाते हैं। सर्दियों में प्रवासी पक्षी आते हैं।",
                readTimeMinutes = 4
            ),
            SundarbanArticle(
                id = "art_reptiles_09",
                titleEn = "Reptiles & Amphibians: Estuarine Crocodiles & King Cobras",
                titleBn = "সরীসৃপ ও উভচর: মোহনার কুমির ও শঙ্খচূড় সাপ",
                titleHi = "सरीसृप और उभयचर: खारे पानी के मगरमच्छ और किंग कोबरा",
                category = "Reptiles",
                summaryEn = "Encounter the world's largest living reptile — the Saltwater Crocodile (Crocodylus porosus) and majestic monitor lizards.",
                summaryBn = "বিশ্বের বৃহত্তম সরীসৃপ লোনা জলের কুমির এবং বিশাল গুইসাপের বাসস্থান।",
                summaryHi = "दुनिया का सबसे बड़ा सरीसृप - खारे पानी का मगरमच्छ और मॉनिटर छिपकली।",
                contentEn = "Sundarbans delta hosts the largest Indian population of Saltwater Crocodiles basking on mudflats at low tide. Water monitor lizards (Varanus salvator) growing up to 2.5 meters and Olive Ridley sea turtles along coastal beaches highlight the reptilian richness.",
                contentBn = "সুন্দরবনের নদীচরে ভাটার সময় বিশালাকার লোনা জলের কুমির রোদ পোহায়। এছাড়া আড়াই মিটার লম্বা গুইসাপ এবং জলজ কচ্ছপ দেখা যায়।",
                contentHi = "भाटे के दौरान नदी के किनारों पर विशाल खारे पानी के मगरमच्छ धूप सेकते हैं। यहां बड़े मॉनिटर छिपकली भी मिलते हैं।",
                readTimeMinutes = 4
            ),
            SundarbanArticle(
                id = "art_safety_10",
                titleEn = "Safety & Emergency Protocols: Boat, Tide & Wildlife Regulations",
                titleBn = "নিরাপত্তা ও জরুরি নিয়মাবলী: নৌকা, জোয়ার ও বন্যপ্রাণী বিধি",
                titleHi = "सुरक्षा और आपातकालीन नियम: नाव, ज्वार और वन नियम",
                category = "Safety",
                summaryEn = "Mandatory life jacket usage, boat fitness verification, permitted entry hours, and emergency SOS contacts.",
                summaryBn = "লাইফ জ্যাকেট ব্যবহার, অনুমোদিত নৌকার সনদ যাচাই এবং বন দপ্তরের জরুরি নির্দেশিকা।",
                summaryHi = "लाइफ जैकेट का अनिवार्य उपयोग, नाव फिटनेस सत्यापन और आपातकालीन नियम।",
                contentEn = "All visitors must strictly wear life jackets while on vessel decks. Boats are strictly prohibited from sailing inside core tiger reserves between sunset and sunrise. Only enter forests accompanied by a licensed Forest Department eco-guide with mandatory forest entry permits (PIR). In emergency, contact the Canning Forest Division helpline.",
                contentBn = "ডেকের উপর সমস্ত পর্যটককে অবশ্যই লাইফ জ্যাকেট পরতে হবে। সূর্যাস্তের পর মূল সংরক্ষিত বনাঞ্চলে নৌযান চলাচল সম্পূর্ণ নিষিদ্ধ। অনুমোদিত ফরেস্ট গাইড ছাড়া নামা বেআইনি।",
                contentHi = "नाव के डेक पर लाइफ जैकेट पहनना अनिवार्य है। सूर्यास्त के बाद मुख्य बाघ क्षेत्र में नाव चलाना सख्त मना है। हमेशा पंजीकृत गाइड के साथ जाएं।",
                readTimeMinutes = 6
            ),
            SundarbanArticle(
                id = "art_destinations_11",
                titleEn = "Top Tourist Destinations: Sajnekhali, Dobanki & Sudhanyakhali",
                titleBn = "প্রধান পর্যটন কেন্দ্র: সজনেখালী, দোবাঁকি ও সুধন্যখালী",
                titleHi = "प्रमुख पर्यटन स्थल: सजनेखाली, दोबांकी और सुधन्यखाली",
                category = "Tourist Destinations",
                summaryEn = "Watch towers, sweet water pond observation posts, mangrove interpretation centers, and canopy walks.",
                summaryBn = "ওয়াচ টাওয়ার, মিষ্টি জলের পুকুর, ম্যানগ্রোভ ইন্টারপ্রিটেশন সেন্টার ও ক্যানোপি ওয়াক।",
                summaryHi = "वॉच टावर, मीठे पानी के तालाब, मैंग्रोव केंद्र और कैनोपी वॉक।",
                contentEn = "Sudhanyakhali Watch Tower provides panoramic views of tiger feeding grounds around a fresh-water pond. Dobanki features a 496-meter-long canopy walkway elevated 20 feet above the forest floor enclosed in safety mesh, while Sajnekhali hosts the Museum and Crocodile Park.",
                contentBn = "সুধন্যখালী ওয়াচ টাওয়ারে মিষ্টি জলের পুকুরে বাঘ ও হরিণের দেখা মেলে। দোবাঁকিতে ২০ ফুট উঁচুতে জাল ঘেরা মনোরম ক্যানোপি ওয়াকওয়ে রয়েছে।",
                contentHi = "सुधन्यखाली वॉच टावर से मीठे पानी के तालाब पर वन्यजीव दिखते हैं। दोबांकी में 20 फीट ऊंचा कैनोपी वॉकवे बेहद लोकप्रिय है।",
                readTimeMinutes = 5
            ),
            SundarbanArticle(
                id = "art_best_time_12",
                titleEn = "Best Time to Visit: Weather, Seasons & Migratory Windows",
                titleBn = "ভ্রমণের সেরা সময়: আবহাওয়া, ঋতু ও পরিযায়ী পাখির সময়",
                titleHi = "यात्रा का सर्वोत्तम समय: मौसम, ऋतुएं और पक्षी प्रवास",
                category = "Best Time to Visit",
                summaryEn = "November to March offers pleasant temperatures, clear waters, and optimal wildlife basking conditions.",
                summaryBn = "নভেম্বর থেকে মার্চ মাস সুন্দরবন ভ্রমণের জন্য সবচেয়ে আরামদায়ক ও অনুকূল।",
                summaryHi = "नवंबर से मार्च तक का समय सुखद मौसम और वन्यजीव दर्शन के लिए सबसे अच्छा है।",
                contentEn = "The ideal season for tourism in Sundarbans is between late October and March when the weather is cool (15°C to 25°C) and water levels are calm. Reptiles and tigers frequently bask in the warm sun on river mudflats during winter mornings.",
                contentBn = "অক্টোবর থেকে মার্চ মাসের মধ্যে আবহাওয়া মনোরম থাকে এবং বাঘ ও কুমির শীতের সকালে নদীচরে রোদ পোহাতে আসে।",
                contentHi = "अक्टूबर से मार्च के बीच मौसम ठंडा रहता है और सर्दियों की सुबह में बाघ और मगरमच्छ धूप सेकने आते हैं।",
                readTimeMinutes = 3
            ),
            SundarbanArticle(
                id = "art_rules_13",
                titleEn = "Forest Rules & Tourist Responsibilities: Zero Plastic & Noise Laws",
                titleBn = "বনের নিয়ম ও পর্যটকদের দায়িত্ব: প্লাস্টিক মুক্ত ও শব্দহীন সুন্দরবন",
                titleHi = "वन नियम और पर्यटकों के दायित्व: प्लास्टिक मुक्त और शांत सुंदरबन",
                category = "Forest Rules",
                summaryEn = "Strict bans on single-use plastics, loud loudspeakers, feeding wildlife, or stepping onto core banks.",
                summaryBn = "একবার ব্যবহার্য প্লাস্টিক সম্পূর্ণ নিষিদ্ধ, মাইক বাজানো ও বন্যপ্রাণীকে খাবার দেওয়া দণ্ডনীয় অপরাধ।",
                summaryHi = "सिंगल यूज प्लास्टिक पर प्रतिबंध, लाउडस्पीकर बजाना और जानवरों को खाना खिलाना गैरकानूनी है।",
                contentEn = "The Sundarban Biosphere is a fragile ecology. Single-use plastic bottles and polythene are legally banned. Use of loudspeakers or musical systems on tourist launches is punishable with heavy fines under Wildlife Protection Acts. Always keep silence while approaching wildlife watch zones.",
                contentBn = "সুন্দরবনে পলিথিন ও প্লাস্টিক বোতল ব্যবহার আইনত নিষিদ্ধ। পর্যটক নৌকায় উচ্চস্বরে গান বাজানো কঠোরভাবে নিষিদ্ধ এবং দণ্ডনীয় অপরাধ।",
                contentHi = "सुंदरबन में प्लास्टिक ले जाना और लाउडस्पीकर बजाना वन्यजीव संरक्षण अधिनियम के तहत दंडनीय है। शांति बनाए रखें।",
                readTimeMinutes = 4
            ),
            SundarbanArticle(
                id = "art_faqs_14",
                titleEn = "Frequently Asked Questions (FAQs) for Sundarban Travelers",
                titleBn = "সুন্দরবন ভ্রমণকারীদের জন্য সাধারণ প্রশ্নোত্তর (FAQs)",
                titleHi = "सुंदरबन यात्रियों के लिए अक्सर पूछे जाने वाले प्रश्न (FAQs)",
                category = "FAQs",
                summaryEn = "Answers on permits, food, mobile network availability, medical aid, and booking verified operators.",
                summaryBn = "অনুমতিপত্র, খাবার, মোবাইল নেটওয়ার্ক এবং যাচাইকৃত অপারেটর বুকিং সংক্রান্ত প্রশ্নাবলী।",
                summaryHi = "परमिट, भोजन, मोबाइल नेटवर्क और सत्यापित टूर ऑपरेटर बुकिंग से जुड़े उत्तर।",
                contentEn = "Q: Is Sundarban safe for families and children? Yes, provided you travel with a verified operator equipped with safety gears.\nQ: Do I need a passport or permit? Indian citizens require Aadhaar/Voter ID for forest permits; foreign nationals require valid passports and Indian visas.\nQ: Is mobile network available? BSNL, Airtel, and Jio have decent connectivity around Gosaba, Dayapur, and Sajnekhali.",
                contentBn = "প্রশ্ন: পরিবার নিয়ে যাওয়া কি নিরাপদ? হ্যাঁ, যাচাইকৃত লাইসেন্সপ্রাপ্ত অপারেটরের সাথে ভ্রমণ সম্পূর্ণ নিরাপদ।\nপ্রশ্ন: আইডি প্রুফ কী লাগে? ভারতীয়দের আধার বা ভোটার কার্ড এবং বিদেশিদের পাসপোর্ট প্রয়োজন।\nপ্রশ্ন: মোবাইল নেটওয়ার্ক কেমন? গোসাবা ও সজনেখালীতে ভালো সিগন্যাল থাকে।",
                contentHi = "प्रश्न: क्या सुंदरबन परिवारों के लिए सुरक्षित है? हां, सत्यापित ऑपरेटर के साथ यात्रा सुरक्षित है।\nप्रश्न: पहचान पत्र क्या चाहिए? आधार कार्ड या पासपोर्ट आवश्यक है।",
                readTimeMinutes = 5
            )
        )

        private fun seedVideos(): List<VideoResource> = listOf(
            VideoResource(
                id = "vid_intro_01",
                titleEn = "Sundarban: Life Inside the Tidal Mangrove Kingdom",
                titleBn = "সুন্দরবন: জোয়ার-ভাটার ম্যানগ্রোভ রাজ্যের জীবন",
                titleHi = "सुंदरबन: ज्वारीय मैंग्रोव साम्राज्य का जीवन",
                descriptionEn = "An introduction to the UNESCO World Heritage delta, mangrove root dynamics, and tidal channels.",
                descriptionBn = "ইউনেস্কো হেরিটেজ সুন্দরবনের প্রাকৃতিক রূপ ও নদীর চ্যানেলের মুগ্ধকর পরিচয়।",
                descriptionHi = "यूनेस्को विश्व धरोहर सुंदरबन के प्राकृतिक सौंदर्य और चैनलों का परिचय।",
                durationText = "14:30",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                channel = "Sundarban Biosphere Foundation",
                category = "Sundarban Introduction"
            ),
            VideoResource(
                id = "vid_travel_02",
                titleEn = "Complete Travel Guide: From Kolkata to Sajnekhali Watchtower",
                titleBn = "সম্পূর্ণ ভ্রমণ গাইড: কলকাতা থেকে সজনেখালী ওয়াচ টাওয়ার",
                titleHi = "संपूर्ण यात्रा गाइड: कोलकाता से सजनेखाली वॉचटावर तक",
                descriptionEn = "Step-by-step route guide via Canning, Godkhali ferry ghat, boat safety, and island resorts.",
                descriptionBn = "ক্যানিং ও গদখালি ঘাট হয়ে সজনেখালী পৌঁছানোর সম্পূর্ণ পথনির্দেশিকা।",
                descriptionHi = "कैनिंग और गोदखाली घाट के रास्ते सजनेखाली पहुंचने का पूरा मार्ग।",
                durationText = "12:15",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                channel = "Bengal Tourism Explorer",
                category = "Travel Guide"
            ),
            VideoResource(
                id = "vid_wildlife_03",
                titleEn = "Tracking the Swimming Tigers of Sundarban",
                titleBn = "সুন্দরবনের সাঁতারু বাঘের পদচিহ্ন অনুসরণ",
                titleHi = "सुंदरबन के तैरने वाले बाघों की खोज",
                descriptionEn = "Forest department researchers explain pugmark tracking, camera traps, and river crossing behaviors.",
                descriptionBn = "বন দপ্তরের ক্যামেরায় ধরা পড়া বাঘের গতিবিধি ও নদী পারাপারের দুর্লভ দৃশ্য।",
                descriptionHi = "बाघों के पगमार्क और नदी पार करने के दुर्लभ दृश्यों का विवरण।",
                durationText = "18:40",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                channel = "Wild Bengal Wildlife Archive",
                category = "Wildlife"
            ),
            VideoResource(
                id = "vid_safety_04",
                titleEn = "Essential River Safety & Tide Survival Precautions",
                titleBn = "জরুরি নদী নিরাপত্তা ও জোয়ার-ভাটার সতর্কতা",
                titleHi = "आवश्यक नदी सुरक्षा और ज्वार-भाटा सावधानियां",
                descriptionEn = "Life jacket protocols, avoiding mudflats, and boat anchoring safety rules for tourists.",
                descriptionBn = "নৌকায় লাইফ জ্যাকেট পরা এবং কাদার চরে না নামার গুরুত্বপূর্ণ নির্দেশাবলী।",
                descriptionHi = "लाइफ जैकेट पहनने और कीचड़ वाले किनारों से दूर रहने के सुरक्षा नियम।",
                durationText = "08:50",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                channel = "Marine Safety Division",
                category = "Safety"
            ),
            VideoResource(
                id = "vid_culture_05",
                titleEn = "Bonbibi: Faith, Folklore & Honey Hunters of the Delta",
                titleBn = "বনবিবি: সুন্দরবনের লোকসংস্কৃতি ও মধু সংগ্রহকারী মৌয়ালী",
                titleHi = "बनबीबी: लोक संस्कृति और शहद इकट्ठा करने वाले मौवाली",
                descriptionEn = "Explore the legendary folklore of Bonbibi, Mawalis (honey collectors), and traditional forest rituals.",
                descriptionBn = "মা বনবিবির গান, লোকনাটক এবং সুন্দরবনের মৌয়ালীদের জীবনগাথা।",
                descriptionHi = "माँ बनबीबी की कथाएं और सुंदरबन के शहद संग्रहकर्ताओं की परंपराएं।",
                durationText = "16:10",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                channel = "Delta Heritage Folk Archive",
                category = "Local Culture"
            )
        )

        private fun seedBooks(): List<BookResource> = listOf(
            BookResource(
                id = "bk_tiger_field_01",
                titleEn = "Sundarban Tiger & Wildlife Field Companion",
                titleBn = "সুন্দরবন বাঘ ও বন্যপ্রাণী ফিল্ড গাইড",
                titleHi = "सुंदरबन बाघ और वन्यजीव फील्ड गाइड",
                author = "Dr. S. K. Sen & Forest Directorate",
                descriptionEn = "A comprehensive handbook for identifying tracks, pugmarks, deer alarms, and 120+ fauna species of the mangrove delta.",
                descriptionBn = "ম্যানগ্রোভ বদ্বীপের বাঘের পায়ের ছাপ, হরিণ এবং ১২০টিরও বেশি বন্যপ্রাণী সনাক্তকরণের সচিত্র বই।",
                descriptionHi = "बाघ के पगमार्क और 120+ प्रजातियों की पहचान के लिए सचित्र हैंडबुक।",
                pageCount = 180,
                language = "English / Bengali / Hindi",
                category = "Wildlife & Tiger Field Guides",
                format = "PDF / Article",
                readingProgressPercent = 25,
                bookmarks = listOf(1, 4),
                chapters = listOf(
                    BookChapter("ch_1", 1, "Introduction to Mangrove Mammals", "The mangrove delta ecosystem presents unique challenges for mammalian life. Salinity, thick tidal mud, and fluctuating water levels require evolutionary specializations. The Royal Bengal Tiger (Panthera tigris tigris) has developed dense muscular paws and swimming prowess, capable of covering 5-8 kilometers against strong tides."),
                    BookChapter("ch_2", 2, "Pugmark Identification & Tracking", "A tiger pugmark consists of a main pad and four distinct toe impressions. In Sundarban's wet silt, measuring the stride length and pad-to-toe width helps wildlife guards determine whether the tiger is male, female, or a sub-adult cub."),
                    BookChapter("ch_3", 3, "Spotted Deer (Chital) & Warning Calls", "Spotted deer maintain a symbiotic alarm call system with Rhesus macaques. When a tiger approaches, langurs and macaques in the upper foliage issue sharp barking alarms, instantly alerting deer herds."),
                    BookChapter("ch_4", 4, "Crocodiles & Estuarine Reptiles", "Saltwater crocodiles (Crocodylus porosus) in Sundarbans grow up to 6 meters in length. They are cold-blooded ectotherms who regulate body temperature by basking on sandbars during low tides.")
                )
            ),
            BookResource(
                id = "bk_mangrove_botany_02",
                titleEn = "Botanical Survey of Sunderban Mangrove Flora",
                titleBn = "সুন্দরবনের উদ্ভিদ ও ম্যানগ্রোভ বোটানিক্যাল সমীক্ষা",
                titleHi = "सुंदरबन मैंग्रोव वनस्पति विज्ञान सर्वेक्षण",
                author = "Botanical Survey of India (BSI)",
                descriptionEn = "Detailed botanical classifications of Sundari, Goran, Gewa, Golpata and medicinal mangrove species.",
                descriptionBn = "সুন্দরী, গরান, গেওয়া, গোলপাতা এবং ঔষধি ম্যানগ্রোভ উদ্ভিদের বৈজ্ঞানিক বিবরণ।",
                descriptionHi = "सुंदरी, गोरन, गोलपाता और औषधीय मैंग्रोव पौधों का विस्तृत विवरण।",
                pageCount = 140,
                language = "English / Bengali",
                category = "Botanical & Mangrove Surveys",
                format = "PDF / Article",
                readingProgressPercent = 10,
                bookmarks = listOf(1),
                chapters = listOf(
                    BookChapter("ch_21", 1, "The Sundari Tree (Heritiera fomes)", "Sundari is the flagship mangrove tree that gives Sundarban its name. Growing up to 25 meters tall, its dense, heavy timber is highly resistant to marine shipworms. Its vertical pneumatophores pierce the muddy soil to absorb atmospheric oxygen."),
                    BookChapter("ch_22", 2, "Goran & Gewa Shrublands", "Goran (Ceriops decandra) forms dense shrub layers along canal margins. Gewa (Excoecaria agallocha) exudes a white milky latex used in traditional medicines but requiring cautious handling."),
                    BookChapter("ch_23", 3, "Golpata: The Mangrove Palm", "Nypa fruticans (Golpata) is the only palm adapted to mangrove biomes. Its trunk grows underground while large fronds reach upwards, traditionally used by islanders for thatch roofing.")
                )
            ),
            BookResource(
                id = "bk_history_laws_03",
                titleEn = "Forest Governance, Coastal Laws & Travelers Handbook",
                titleBn = "বন পরিচালনা, উপকূলীয় আইন ও পর্যটক নির্দেশিকা",
                titleHi = "वन शासन, तटीय कानून और पर्यटक पुस्तिका",
                author = "Sundarban Biosphere Reserve Authority",
                descriptionEn = "Legal frameworks, Wildlife Protection Act (1972), core zone regulations, tourist dos and don'ts.",
                descriptionBn = "বন্যপ্রাণী সংরক্ষণ আইন, পর্যটকদের করণীয় ও বর্জনীয় এবং আইনি নির্দেশাবলী।",
                descriptionHi = "वन्यजीव संरक्षण कानून और पर्यटकों के लिए आवश्यक कानूनी नियम।",
                pageCount = 110,
                language = "English / Bengali / Hindi",
                category = "Forest Governance & Laws",
                format = "PDF / Article",
                readingProgressPercent = 50,
                bookmarks = listOf(2),
                chapters = listOf(
                    BookChapter("ch_31", 1, "Statutory Core Zones & Buffer Areas", "The Sundarbans National Park is designated as a strict core preservation zone where all extraction and unauthorized entry are prohibited. Tourism is confined to designated ecotourism zones with licensed forest guides."),
                    BookChapter("ch_32", 2, "Vessel Fitness & Anti-Pollution Mandates", "Every commercial tourist boat must maintain valid pollution clearance, bilge filters to prevent diesel discharge into riverways, and sufficient certified life jackets for all passengers on board.")
                )
            )
        )
    }
}
