package com.example.data.repositories

import com.example.core.model.*
import com.example.core.security.RiskMonitoringEngine
import com.example.core.security.SecurityManager
import com.example.core.util.CancellationTimeHelper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

interface TourRepository {
    // Packages
    fun getPublicVerifiedPackages(): Flow<List<TourPackage>>
    fun getPackagesForOperator(operatorId: String): Flow<List<TourPackage>>
    fun getAllPackagesForAdmin(): Flow<List<TourPackage>>
    fun getPackageById(packageId: String): TourPackage?
    suspend fun createPackage(pkg: TourPackage): Result<TourPackage>
    suspend fun updatePackage(pkg: TourPackage): Result<TourPackage>
    suspend fun deletePackage(packageId: String, operatorId: String): Result<Unit>
    suspend fun moderatePackageStatus(packageId: String, status: PackageStatus, rejectionReason: String? = null): Result<Unit>

    // Operator Public Directory
    fun getVerifiedOperators(
        searchQuery: String = "",
        minRating: Double = 0.0,
        minExperienceYears: Int = 0,
        operatingArea: String = "All Areas"
    ): Flow<List<OperatorPublicProfile>>
    fun getOperatorPublicProfile(operatorId: String): OperatorPublicProfile?

    // Bookings & Safety
    fun getBookingsForCustomer(customerId: String): Flow<List<Booking>>
    fun getBookingsForOperator(operatorId: String): Flow<List<Booking>>
    fun getAllBookingsForAdmin(): Flow<List<Booking>>
    fun getBookingById(bookingId: String): Booking?
    suspend fun validateAndCreateBooking(booking: Booking, customer: UserProfile): Result<Booking>
    suspend fun createBooking(booking: Booking): Result<Booking>
    suspend fun updateBookingStatus(
        bookingId: String,
        newStatus: BookingStatus,
        changedByUid: String,
        changedByName: String,
        changedByRole: UserRole,
        reason: String
    ): Result<Booking>
    suspend fun cancelBooking(bookingId: String, customerId: String, reason: String): Result<Unit>
    suspend fun disputeBooking(bookingId: String, customerId: String, reason: String): Result<Unit>

    // Booking Cancellation and Emergency Review System
    fun calculateHoursUntilTour(booking: Booking, nowMs: Long = System.currentTimeMillis()): Double

    suspend fun requestBookingCancellation(
        bookingId: String,
        initiator: UserProfile,
        reason: String,
        detailedExplanation: String? = null
    ): Result<CancellationRequest>

    suspend fun respondToCancellationRequest(
        bookingId: String,
        responder: UserProfile,
        accept: Boolean,
        responseNotes: String? = null
    ): Result<Booking>

    suspend fun addCancellationDiscussionMessage(
        bookingId: String,
        sender: UserProfile,
        message: String
    ): Result<CancellationDiscussionMessage>

    suspend fun adminResolveEmergencyCancellation(
        bookingId: String,
        admin: UserProfile,
        decisionType: AdminDecisionType,
        refundDecision: AdminRefundDecision,
        refundAmount: Double = 0.0,
        rescheduledDate: String? = null,
        newOperatorId: String? = null,
        reason: String
    ): Result<Booking>

    // Payments & Financials (Part 4)
    fun getPayments(): Flow<List<Payment>>
    suspend fun recordPayment(payment: Payment): Result<Payment>
    fun getAllTransactionsForAdmin(): Flow<List<PaymentTransaction>>
    fun getTransactionsForCustomer(customerId: String): Flow<List<PaymentTransaction>>
    fun getTransactionsForOperator(operatorId: String): Flow<List<PaymentTransaction>>
    fun getTransactionsForBooking(bookingId: String): Flow<List<PaymentTransaction>>
    fun getBookingFinancialTimeline(bookingId: String): Flow<BookingFinancialTimeline?>
    fun getOperatorEarningsSummary(operatorId: String): Flow<OperatorEarningsSummary>
    fun getGlobalPlatformFinancialSummary(): Flow<OperatorEarningsSummary>
    val platformCommissionConfig: StateFlow<PlatformCommissionConfig>
    suspend fun updateCommissionConfig(newConfig: PlatformCommissionConfig, adminUid: String): Result<Unit>
    fun getRefundRecords(): Flow<List<RefundRecord>>
    fun getRefundRecordsForBooking(bookingId: String): Flow<List<RefundRecord>>
    fun getRefundRecordsForCustomer(customerId: String): Flow<List<RefundRecord>>
    suspend fun createPaymentOrder(
        bookingId: String,
        amount: Double,
        method: PaymentGatewayMethod,
        payer: UserProfile,
        idempotencyKey: String
    ): Result<PaymentTransaction>
    suspend fun verifyAndProcessOnlinePayment(
        transactionId: String,
        gatewayOrderId: String,
        gatewayPaymentId: String,
        gatewaySignature: String,
        idempotencyKey: String
    ): Result<PaymentTransaction>
    suspend fun recordCashPayment(
        bookingId: String,
        amount: Double,
        notes: String,
        receiptNumber: String?,
        proofUrl: String?,
        operator: UserProfile
    ): Result<PaymentTransaction>
    suspend fun recordCashAdjustment(
        originalTxnId: String,
        adjustmentAmount: Double,
        reason: String,
        operator: UserProfile
    ): Result<PaymentTransaction>
    suspend fun requestRefund(
        bookingId: String,
        transactionId: String,
        amount: Double,
        reason: String,
        requester: UserProfile
    ): Result<RefundRecord>
    suspend fun processRefund(
        refundId: String,
        approve: Boolean,
        admin: UserProfile,
        rejectionReason: String?
    ): Result<RefundRecord>
    fun getPayoutDestinationForOperator(operatorId: String): Flow<PayoutDestination?>
    suspend fun saveOperatorPayoutDestination(destination: PayoutDestination, operator: UserProfile): Result<PayoutDestination>
    suspend fun verifyOperatorPayoutDestination(operatorId: String, adminUser: UserProfile): Result<Unit>
    fun getSuspiciousPaymentAlerts(): Flow<List<PaymentRiskAlert>>
    suspend fun resolvePaymentRiskAlert(alertId: String, resolutionNotes: String, adminUser: UserProfile): Result<Unit>

    // Reviews & Ratings (Part 5)
    fun getReviewsForOperator(operatorId: String): Flow<List<Review>>
    fun getReviewsForPackage(packageId: String): Flow<List<Review>>
    fun getAllReviewsForAdmin(): Flow<List<Review>>
    suspend fun addReview(review: Review, user: UserProfile): Result<Review>
    suspend fun moderateReview(reviewId: String, isModerated: Boolean, reason: String?, adminUser: UserProfile): Result<Unit>

    // Complaints System (Part 5)
    fun getComplaints(): Flow<List<Complaint>>
    fun getComplaintsForUser(userId: String): Flow<List<Complaint>>
    suspend fun fileComplaint(complaint: Complaint, complainantUser: UserProfile): Result<Complaint>
    suspend fun investigateComplaint(complaintId: String, adminNotes: String, adminUser: UserProfile): Result<Unit>
    suspend fun requestComplaintEvidence(complaintId: String, instructions: String, adminUser: UserProfile): Result<Unit>
    suspend fun resolveComplaint(complaintId: String, resolution: String, adminUser: UserProfile): Result<Unit>
    suspend fun rejectComplaint(complaintId: String, rejectionReason: String, adminUser: UserProfile): Result<Unit>

    // Dispute System (Part 5)
    fun getDisputes(): Flow<List<DisputeRecord>>
    fun getDisputesForUser(userId: String): Flow<List<DisputeRecord>>
    fun getDisputeById(disputeId: String): DisputeRecord?
    suspend fun openFormalDispute(
        bookingId: String,
        complaintId: String?,
        reason: String,
        evidenceUrls: List<String>,
        requester: UserProfile
    ): Result<DisputeRecord>
    suspend fun addDisputeMessage(
        disputeId: String,
        message: String,
        attachmentUrl: String?,
        sender: UserProfile
    ): Result<DisputeRecord>
    suspend fun requestDisputeEvidence(
        disputeId: String,
        instructions: String,
        adminUser: UserProfile
    ): Result<Unit>
    suspend fun adjudicateDispute(
        disputeId: String,
        decision: DisputeStatus,
        refundDecision: RefundDecisionType,
        refundAmount: Double,
        decisionSummary: String,
        adminUser: UserProfile
    ): Result<DisputeRecord>

    // Fraud & Risk Monitoring (Part 5)
    fun getFlaggedRiskCases(): Flow<List<FlaggedRiskCase>>
    fun getAdminAlerts(): Flow<List<AdminAlert>>
    suspend fun reviewRiskCase(caseId: String, notes: String, adminUser: UserProfile): Result<Unit>
    suspend fun acknowledgeAlert(alertId: String): Result<Unit>

    // Audit Log (Part 5)
    fun getAuditLogs(): Flow<List<AuditLogEntry>>
    suspend fun recordAuditLog(entry: AuditLogEntry): Result<Unit>

    // Platform Settings & Controls
    val platformSettings: StateFlow<PlatformSettings>
    suspend fun updatePlatformSettings(settings: PlatformSettings): Result<Unit>
    suspend fun togglePublicOperatorPhone(allow: Boolean): Result<Unit>

    // Notifications
    fun getNotificationsForUser(userId: String): Flow<List<AppNotification>>
    suspend fun markNotificationAsRead(notificationId: String): Result<Unit>
    suspend fun markAllNotificationsAsRead(userId: String): Result<Unit>
    suspend fun sendNotification(notification: AppNotification): Result<AppNotification>
}

class TourRepositoryImpl(
    private val authRepository: AuthRepository? = null
) : TourRepository {

    private val _platformSettings = MutableStateFlow(
        PlatformSettings(
            allowPublicOperatorPhone = true,
            autoApprovePackages = false,
            platformNotice = "Mandatory Biometric check at Godkhali Forest Checkpost active for high tide departures."
        )
    )
    override val platformSettings: StateFlow<PlatformSettings> = _platformSettings.asStateFlow()

    private val packages = MutableStateFlow<List<TourPackage>>(listOf(
        TourPackage(
            id = "pkg_01",
            operatorId = "op_verified_001",
            operatorName = "Animesh Mondal (Tiger Trails Eco)",
            operatorPhone = "+91 9434056789",
            isOperatorVerified = true,
            title = "Royal Tiger & Sajnekhali 2D/1N River Safari",
            description = "Complete eco-cruise covering Sajnekhali Watch Tower, Mangrove Interpretation Centre, Sudhanyakhali Tiger tracking, and Dobanki Canopy Walk.",
            photos = listOf(
                "https://images.unsplash.com/photo-1549366021-9f761d450615",
                "https://images.unsplash.com/photo-1518709268805-4e9042af9f23"
            ),
            durationText = "2 Days / 1 Night",
            startingLocation = "Godkhali Ferry Ghat, Canning",
            route = "Godkhali -> Gosaba -> Sajnekhali -> Sudhanyakhali -> Dobanki -> Godkhali",
            destination = "Sundarban Tiger Reserve & Core Delta",
            destinations = listOf("Sajnekhali", "Sudhanyakhali", "Dobanki Canopy Walk", "Pakhiralay"),
            durationDays = 2,
            durationNights = 1,
            maxTourists = 12,
            price = 4500.0,
            pricePerPerson = 4500.0,
            includedServices = listOf(
                "Govt Forest Entry Permits",
                "Armed Forest Guide & Naturalist",
                "Traditional Bengali Meals on Boat (Breakfast, Lunch, Dinner)",
                "Life Jackets & Emergency Safety Gear",
                "Twin Sharing Eco-Cottage Stay at Pakhiralay"
            ),
            excludedServices = listOf(
                "Personal snacks & packed mineral water",
                "Camera & Video permit fee at forest counter",
                "Train/Vehicle transport to Godkhali Ghat"
            ),
            boatDetails = "M.B. Sundarban Pride - 42ft Twin-Diesel Deluxe Motor Boat with observation upper deck, western toilet, life buoys & GPS tracker",
            foodDetails = "Day 1: Breakfast (Luchi, Cholar Dal, Sweet), Lunch (Rice, Bhetki Macher Jhol, Dal, Bhaja, Chutney, Papad), Evening Snacks (Pakora, Tea), Dinner (Chicken Curry, Roti/Rice). Day 2: Bed Tea, Poori Sabzi, Crab Masala / Fish Special Lunch.",
            accommodationDetails = "River-facing Eco-Cottage at Pakhiralay with attached western bath, 24/7 power backup, and mosquito netting.",
            guideDetails = "Certified Forest Dept Naturalist & local tracker with 14+ years delta wildlife experience.",
            permitInfo = "All Forest Department permits, eco-cess, and biometric clearances processed in advance.",
            pickupInfo = "Godkhali Ghat at 08:30 AM. Optional pickup from Canning Railway Station (+Rs 200/p).",
            cancellationPolicy = "100% refund if cancelled 72+ hours prior. 50% refund between 24-72 hours. Non-refundable within 24 hours.",
            availableDates = listOf("2026-09-10", "2026-09-15", "2026-09-20", "2026-09-25", "2026-10-02", "2026-10-10"),
            importantInstructions = "1. Carry original Govt ID (mandatory at checkpost).\n2. Single-use plastic is strictly banned.\n3. Avoid loud sound or music on boat.\n4. Wear muted camouflage colors (khaki, forest green).",
            status = PackageStatus.PUBLISHED,
            rating = 4.9,
            reviewCount = 48,
            createdAt = System.currentTimeMillis() - 864000000L
        ),
        TourPackage(
            id = "pkg_02",
            operatorId = "op_verified_001",
            operatorName = "Animesh Mondal (Tiger Trails Eco)",
            operatorPhone = "+91 9434056789",
            isOperatorVerified = true,
            title = "Deep Delta & Netidhopani Historical 3D/2N Expedition",
            description = "An extensive journey into deeper estuaries including the 400-year-old Netidhopani temple ruins, Burirdabri mud walk, and Lothian sanctuary.",
            photos = listOf(
                "https://images.unsplash.com/photo-1507525428034-b723cf961d3e"
            ),
            durationText = "3 Days / 2 Nights",
            startingLocation = "Godkhali Ghat, Sundarban",
            route = "Godkhali -> Sajnekhali -> Netidhopani -> Burirdabri -> Dobanki -> Jharkhali",
            destination = "Netidhopani Core Sanctuary & Burirdabri",
            destinations = listOf("Netidhopani", "Burirdabri", "Dobanki", "Jharkhali Tiger Rescue"),
            durationDays = 3,
            durationNights = 2,
            maxTourists = 10,
            price = 7800.0,
            pricePerPerson = 7800.0,
            includedServices = listOf(
                "Deep forest special permits & entry passes",
                "All meals + evening cultural Baul folk music",
                "High-power binoculars provided on board",
                "Experienced Naturalist & Local Spotter",
                "2 Nights stay at Deluxe Jungle Resort"
            ),
            excludedServices = listOf(
                "Personal expenses and porter charges",
                "Foreign national special forest cess"
            ),
            boatDetails = "M.B. Delta Voyager - 50ft Covered Cruiser with 360-degree viewing roof, solar lighting, and VHF Marine Radio",
            foodDetails = "Gourmet Bengali traditional meals including Hilsa (Ilish) fish in season, Golda Chingri, and local sweets.",
            accommodationDetails = "Deluxe AC Cottages with river promenade at Dayapur Village.",
            guideDetails = "Senior Ecotourism Naturalist & Wildlife Biologist guide.",
            permitInfo = "Special Deep Delta Forest permits and guide allocations included.",
            pickupInfo = "Godkhali Ghat at 08:00 AM or Science City Kolkata (Add-on shared cab).",
            cancellationPolicy = "Full refund up to 5 days before trip. 50% refund 2-5 days before trip.",
            availableDates = listOf("2026-09-12", "2026-09-18", "2026-09-26", "2026-10-05"),
            importantInstructions = "Carry waterproof covers for electronic equipment and raincoats during tidal surges.",
            status = PackageStatus.PUBLISHED,
            rating = 4.8,
            reviewCount = 32,
            createdAt = System.currentTimeMillis() - 432000000L
        ),
        TourPackage(
            id = "pkg_03",
            operatorId = "op_verified_001",
            operatorName = "Animesh Mondal (Tiger Trails Eco)",
            operatorPhone = "+91 9434056789",
            isOperatorVerified = true,
            title = "Sundarban Bird Watching & Creek Exploration 1-Day",
            description = "Specialized dawn-to-dusk quiet electric-hybrid boat journey through narrow mangrove creeks for photography and birding enthusiasts.",
            photos = emptyList(),
            durationText = "1 Day (07:00 AM to 05:30 PM)",
            startingLocation = "Godkhali Ferry Ghat",
            route = "Godkhali -> Gomdi Creek -> Sajnekhali Bird Sanctuary -> Pakhiralay -> Godkhali",
            destination = "Sajnekhali Bird Sanctuary & Gomdi Creeks",
            destinations = listOf("Pakhiralay", "Sajnekhali Bird Sanctuary", "Gomdi Creek"),
            durationDays = 1,
            durationNights = 0,
            maxTourists = 8,
            price = 2200.0,
            pricePerPerson = 2200.0,
            includedServices = listOf(
                "Day breakfast & hot lunch served on boat",
                "Bird checklist handbook & forest permit",
                "All-day tea, coffee & biscuit station",
                "Certified Ornithology Guide"
            ),
            excludedServices = listOf(
                "Camera lenses over 300mm commercial fee"
            ),
            boatDetails = "M.B. Kingfisher - Silent slow-speed 30ft wooden country boat with silent engine and canopy shade",
            foodDetails = "Light breakfast with boiled eggs & bananas. Hot lunch with steamed rice, seasonal vegetables, Rui fish, and tomato chutney.",
            accommodationDetails = "Day tour (No overnight stay required).",
            guideDetails = "Birding specialist guide with extensive checklist knowledge (over 200 resident and migratory species).",
            permitInfo = "Day permit included.",
            pickupInfo = "Godkhali Jetty at 07:15 AM sharp.",
            cancellationPolicy = "Free cancellation up to 24 hours in advance.",
            availableDates = listOf("2026-09-08", "2026-09-11", "2026-09-14", "2026-09-17", "2026-09-22"),
            importantInstructions = "Maintain silence during narrow creek navigation to observe kingfishers and raptors.",
            status = PackageStatus.PUBLISHED,
            rating = 4.7,
            reviewCount = 19,
            createdAt = System.currentTimeMillis() - 172800000L
        ),
        TourPackage(
            id = "pkg_flagged_04",
            operatorId = "op_pending_002",
            operatorName = "Debashis Roy (Mangrove Birds)",
            operatorPhone = "+91 9732198765",
            isOperatorVerified = false,
            title = "Unregulated Delta Creek Ride",
            description = "Quick boat tour into delta mangrove area. Flexible timing.",
            photos = emptyList(),
            durationText = "4 Hours",
            startingLocation = "Dayapur Ghat",
            route = "Dayapur -> Creeks",
            destination = "Inner Mangroves",
            destinations = listOf("Inner Mangroves"),
            durationDays = 1,
            durationNights = 0,
            maxTourists = 6,
            price = 0.0,
            pricePerPerson = 0.0,
            includedServices = listOf("Boat ride"),
            excludedServices = listOf("Permits", "Safety Gear"),
            boatDetails = "Country wooden dinghy without life vests",
            foodDetails = "None",
            accommodationDetails = "None",
            guideDetails = "Self-guided",
            permitInfo = "Forest permits not included",
            pickupInfo = "Dayapur Ghat",
            cancellationPolicy = "Non-refundable",
            availableDates = listOf("2026-09-20"),
            importantInstructions = "None",
            status = PackageStatus.REQUIRES_ADMIN_REVIEW,
            isAutoVerified = false,
            verificationStatusText = "Review Required",
            riskScore = 75,
            riskSignals = listOf(
                "Invalid package price: Amount must be greater than ₹0",
                "Missing mandatory safety gear or Forest Directorate permit details",
                "Submitting operator account is currently under administrative review"
            ),
            createdAt = System.currentTimeMillis() - 7200000L
        )
    ))

    private val reviews = MutableStateFlow<List<Review>>(listOf(
        Review(
            id = "rev_01",
            bookingId = "bk_demo_01",
            operatorId = "op_verified_001",
            customerId = "cust_tourist_001",
            customerName = "Priya Sharma",
            rating = 5,
            comment = "Exceptional experience! Animesh and his crew knew every creek. We spotted a swimming tiger near Sudhanyakhali, plus dozens of crocodiles. Food on boat was fresh and delicious!",
            createdAt = System.currentTimeMillis() - 86400000L
        ),
        Review(
            id = "rev_02",
            bookingId = "bk_demo_02",
            operatorId = "op_verified_001",
            customerId = "cust_tourist_002",
            customerName = "Arunav Chatterjee",
            rating = 5,
            comment = "Strict eco-friendly standards followed throughout. Life jackets were modern and the naturalist had deep botanical and mangrove knowledge. Highly recommended.",
            createdAt = System.currentTimeMillis() - 172800000L
        ),
        Review(
            id = "rev_03",
            bookingId = "bk_demo_03",
            operatorId = "op_verified_001",
            customerId = "cust_tourist_003",
            customerName = "Sneha Mukherjee",
            rating = 4,
            comment = "Very punctual departure from Godkhali. The sunset view from Dobanki watchtower was unforgettable.",
            createdAt = System.currentTimeMillis() - 345600000L
        )
    ))

    private val bookings = MutableStateFlow<List<Booking>>(listOf(
        Booking(
            id = "SB-BK-2026-8812",
            customerId = "cust_tourist_001",
            customerName = "Priya Sharma",
            customerPhone = "+91 9820011223",
            customerEmail = "tourist@example.com",
            operatorId = "op_verified_001",
            operatorName = "Animesh Mondal (Tiger Trails Eco)",
            operatorPhone = "+91 9434056789",
            packageId = "pkg_01",
            packageTitle = "Royal Tiger & Sajnekhali 2D/1N River Safari",
            numberOfTourists = 2,
            travelDate = "2026-09-15",
            returnDate = "2026-09-16",
            pickupLocation = "Godkhali Ferry Ghat, Canning",
            specialRequirements = "Vegetarian meal preference for 1 guest, need life jackets for medium build.",
            emergencyContact = com.example.core.model.EmergencyContact(
                name = "Rohit Sharma",
                relationship = "Brother",
                phoneNumber = "+91 9820011224"
            ),
            notes = "Reaching Godkhali via Canning local train at 8:00 AM.",
            totalAmount = 9000.0,
            paidAmount = 9000.0,
            paymentMethod = PaymentMethod.ONLINE_UPI_CARD,
            paymentStatus = PaymentStatus.PAID,
            bookingStatus = BookingStatus.CONFIRMED,
            statusTimeline = listOf(
                BookingStatusHistory(
                    previousStatus = null,
                    newStatus = BookingStatus.PENDING,
                    changedByUid = "cust_tourist_001",
                    changedByName = "Priya Sharma",
                    changedByRole = UserRole.CUSTOMER,
                    timestamp = System.currentTimeMillis() - 86400000L,
                    reason = "Booking request submitted online by tourist."
                ),
                BookingStatusHistory(
                    previousStatus = BookingStatus.PENDING,
                    newStatus = BookingStatus.ACCEPTED,
                    changedByUid = "op_verified_001",
                    changedByName = "Animesh Mondal",
                    changedByRole = UserRole.OPERATOR,
                    timestamp = System.currentTimeMillis() - 82800000L,
                    reason = "Dates available on M.B. Sundarban Pride boat. Booking accepted."
                ),
                BookingStatusHistory(
                    previousStatus = BookingStatus.ACCEPTED,
                    newStatus = BookingStatus.CONFIRMED,
                    changedByUid = "cust_tourist_001",
                    changedByName = "Priya Sharma",
                    changedByRole = UserRole.CUSTOMER,
                    timestamp = System.currentTimeMillis() - 80000000L,
                    reason = "Payment of ₹9,000 received via UPI Ref UPI/SUN/20260901/8892112. Forest pass confirmed."
                )
            ),
            createdAt = System.currentTimeMillis() - 86400000L,
            updatedAt = System.currentTimeMillis() - 80000000L
        ),
        // Booking with Normal Cancellation Requested (> 5h remaining, mutual agreement pending)
        Booking(
            id = "SB-BK-2026-8813",
            customerId = "cust_tourist_001",
            customerName = "Priya Sharma",
            customerPhone = "+91 9820011223",
            customerEmail = "tourist@example.com",
            operatorId = "op_verified_001",
            operatorName = "Animesh Mondal (Tiger Trails Eco)",
            operatorPhone = "+91 9434056789",
            packageId = "pkg_02",
            packageTitle = "Pakhiralay & Sudhanyakhali Birding Expedition",
            numberOfTourists = 3,
            travelDate = "2026-09-22",
            tourStartTime = "07:30 AM",
            returnDate = "2026-09-23",
            pickupLocation = "Sonakhali Launch Ghat",
            specialRequirements = "Binoculars rental requested",
            notes = "Family vacation trip",
            totalAmount = 13500.0,
            paidAmount = 13500.0,
            paymentMethod = PaymentMethod.ONLINE_UPI_CARD,
            paymentStatus = PaymentStatus.PAID,
            bookingStatus = BookingStatus.CANCEL_REQUESTED,
            cancellationReason = "Family medical emergency requires rescheduling or cancellation.",
            activeCancellationRequest = CancellationRequest(
                requestId = "CAN_NORM_001",
                bookingId = "SB-BK-2026-8813",
                initiatedByUid = "cust_tourist_001",
                initiatedByName = "Priya Sharma",
                initiatedByRole = UserRole.CUSTOMER,
                isEmergency = false,
                hoursRemainingAtRequest = 72.0,
                reason = "Family medical emergency requires rescheduling or cancellation.",
                detailedExplanation = "Would prefer to either cancel with full refund or reschedule to mid-October if dates permit.",
                status = CancellationRequestStatus.PENDING_OTHER_PARTY,
                requestedAt = System.currentTimeMillis() - 14400000L,
                discussionMessages = listOf(
                    CancellationDiscussionMessage(
                        id = "msg_001",
                        senderUid = "cust_tourist_001",
                        senderName = "Priya Sharma",
                        senderRole = UserRole.CUSTOMER,
                        message = "Hello Animesh, really sorry about this sudden situation. My mother is scheduled for medical checkups. Can we cancel or reschedule?",
                        timestamp = System.currentTimeMillis() - 14000000L
                    ),
                    CancellationDiscussionMessage(
                        id = "msg_002",
                        senderUid = "op_verified_001",
                        senderName = "Animesh Mondal",
                        senderRole = UserRole.OPERATOR,
                        message = "Namaskar Priya ji, completely understand. We can either cancel and refund or hold credits for October. Let me know what you prefer.",
                        timestamp = System.currentTimeMillis() - 10000000L
                    )
                )
            ),
            cancellationHistory = listOf(
                CancellationRequest(
                    requestId = "CAN_NORM_001",
                    bookingId = "SB-BK-2026-8813",
                    initiatedByUid = "cust_tourist_001",
                    initiatedByName = "Priya Sharma",
                    initiatedByRole = UserRole.CUSTOMER,
                    isEmergency = false,
                    hoursRemainingAtRequest = 72.0,
                    reason = "Family medical emergency requires rescheduling or cancellation.",
                    detailedExplanation = "Would prefer to either cancel with full refund or reschedule to mid-October if dates permit.",
                    status = CancellationRequestStatus.PENDING_OTHER_PARTY,
                    requestedAt = System.currentTimeMillis() - 14400000L
                )
            ),
            statusTimeline = listOf(
                BookingStatusHistory(
                    previousStatus = null,
                    newStatus = BookingStatus.PENDING,
                    changedByUid = "cust_tourist_001",
                    changedByName = "Priya Sharma",
                    changedByRole = UserRole.CUSTOMER,
                    timestamp = System.currentTimeMillis() - 86400000L,
                    reason = "Booking submitted."
                ),
                BookingStatusHistory(
                    previousStatus = BookingStatus.PENDING,
                    newStatus = BookingStatus.CONFIRMED,
                    changedByUid = "op_verified_001",
                    changedByName = "Animesh Mondal",
                    changedByRole = UserRole.OPERATOR,
                    timestamp = System.currentTimeMillis() - 72000000L,
                    reason = "Confirmed & paid online."
                ),
                BookingStatusHistory(
                    previousStatus = BookingStatus.CONFIRMED,
                    newStatus = BookingStatus.CANCEL_REQUESTED,
                    changedByUid = "cust_tourist_001",
                    changedByName = "Priya Sharma",
                    changedByRole = UserRole.CUSTOMER,
                    timestamp = System.currentTimeMillis() - 14400000L,
                    reason = "Cancellation requested (> 5h remaining). Awaiting operator mutual agreement."
                )
            ),
            createdAt = System.currentTimeMillis() - 86400000L,
            updatedAt = System.currentTimeMillis() - 14400000L
        ),
        // Booking with Emergency Cancellation under Directorate Review (<= 5h remaining)
        Booking(
            id = "SB-BK-2026-8814",
            customerId = "cust_tourist_001",
            customerName = "Priya Sharma",
            customerPhone = "+91 9820011223",
            customerEmail = "tourist@example.com",
            operatorId = "op_verified_001",
            operatorName = "Animesh Mondal (Tiger Trails Eco)",
            operatorPhone = "+91 9434056789",
            packageId = "pkg_01",
            packageTitle = "Sundarban Mangrove Watchtower Deep Safari",
            numberOfTourists = 2,
            travelDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
            tourStartTime = "11:30 AM",
            returnDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(System.currentTimeMillis() + 86400000L)),
            pickupLocation = "Godkhali Jetty #2",
            specialRequirements = "Life jackets size L and M",
            totalAmount = 8500.0,
            paidAmount = 8500.0,
            paymentMethod = PaymentMethod.ONLINE_UPI_CARD,
            paymentStatus = PaymentStatus.PAID,
            bookingStatus = BookingStatus.EMERGENCY_REVIEW,
            cancellationReason = "Sudden mechanical propeller defect & high surge swell alert at confluence",
            activeCancellationRequest = CancellationRequest(
                requestId = "CAN_EMG_002",
                bookingId = "SB-BK-2026-8814",
                initiatedByUid = "op_verified_001",
                initiatedByName = "Animesh Mondal (Tiger Trails Eco)",
                initiatedByRole = UserRole.OPERATOR,
                isEmergency = true,
                hoursRemainingAtRequest = 2.5,
                reason = "Sudden mechanical propeller defect & high surge swell alert at confluence",
                detailedExplanation = "Forest Range Officer issued cautionary advisory due to turbulent tidal current. Launch boat M.B. Pride propeller shaft requires dry-dock inspection. Requesting Directorate review to reassign to another verified operator or authorize refund.",
                status = CancellationRequestStatus.UNDER_ADMIN_REVIEW,
                requestedAt = System.currentTimeMillis() - 3600000L,
                discussionMessages = listOf(
                    CancellationDiscussionMessage(
                        id = "msg_emg_01",
                        senderUid = "op_verified_001",
                        senderName = "Animesh Mondal",
                        senderRole = UserRole.OPERATOR,
                        message = "Propeller linkage issue detected during morning warm-up. Tourist safety is non-negotiable.",
                        timestamp = System.currentTimeMillis() - 3400000L
                    ),
                    CancellationDiscussionMessage(
                        id = "msg_emg_02",
                        senderUid = "cust_tourist_001",
                        senderName = "Priya Sharma",
                        senderRole = UserRole.CUSTOMER,
                        message = "Appreciate the safety priority. We are at Canning. Please let Directorate decide if another boat is available or issue full refund.",
                        timestamp = System.currentTimeMillis() - 3000000L
                    )
                )
            ),
            cancellationHistory = listOf(
                CancellationRequest(
                    requestId = "CAN_EMG_002",
                    bookingId = "SB-BK-2026-8814",
                    initiatedByUid = "op_verified_001",
                    initiatedByName = "Animesh Mondal",
                    initiatedByRole = UserRole.OPERATOR,
                    isEmergency = true,
                    hoursRemainingAtRequest = 2.5,
                    reason = "Sudden mechanical propeller defect & high surge swell alert at confluence",
                    detailedExplanation = "Forest Range Officer cautionary advisory. Launch boat requires inspection.",
                    status = CancellationRequestStatus.UNDER_ADMIN_REVIEW,
                    requestedAt = System.currentTimeMillis() - 3600000L
                )
            ),
            statusTimeline = listOf(
                BookingStatusHistory(
                    previousStatus = null,
                    newStatus = BookingStatus.CONFIRMED,
                    changedByUid = "op_verified_001",
                    changedByName = "Animesh Mondal",
                    changedByRole = UserRole.OPERATOR,
                    timestamp = System.currentTimeMillis() - 48000000L,
                    reason = "Booking confirmed and payment processed."
                ),
                BookingStatusHistory(
                    previousStatus = BookingStatus.CONFIRMED,
                    newStatus = BookingStatus.EMERGENCY_REVIEW,
                    changedByUid = "op_verified_001",
                    changedByName = "Animesh Mondal",
                    changedByRole = UserRole.OPERATOR,
                    timestamp = System.currentTimeMillis() - 3600000L,
                    reason = "Emergency cancellation escalated (< 5h to tour departure). Auto-routed to Directorate Admin Review."
                )
            ),
            createdAt = System.currentTimeMillis() - 48000000L,
            updatedAt = System.currentTimeMillis() - 3600000L
        )
    ))

    private val commissionConfig = MutableStateFlow(
        PlatformCommissionConfig(
            id = "COMMISSION_CONFIG_V1",
            percentageCommission = 0.5,
            fixedFeePerBooking = 0.0,
            effectiveDate = "2026-01-01",
            description = "Standard Sundarban Platform Commission for Safe Safari Permits & Verification"
        )
    )
    override val platformCommissionConfig: StateFlow<PlatformCommissionConfig> = commissionConfig.asStateFlow()

    private val transactions = MutableStateFlow<List<PaymentTransaction>>(listOf(
        PaymentTransaction(
            transactionId = "TXN_SUN_20260901_881201",
            bookingId = "SB-BK-2026-8812",
            packageId = "pkg_01",
            packageTitle = "Royal Tiger & Sajnekhali 2D/1N River Safari",
            amount = 9000.0,
            currency = "INR",
            method = PaymentGatewayMethod.UPI,
            status = TransactionStatus.SUCCESS,
            type = TransactionType.ONLINE_GATEWAY,
            payerId = "cust_tourist_001",
            payerName = "Priya Sharma",
            payerPhone = "+91 9820011223",
            payerEmail = "tourist@example.com",
            receiverId = "op_verified_001",
            receiverName = "Animesh Mondal (Tiger Trails Eco)",
            gatewayOrderId = "order_SB_20260901_8812",
            gatewayPaymentId = "pay_rzp_live_998129038",
            gatewaySignature = "sig_hmac_sha256_verified_token_8812",
            idempotencyKey = "idemp_bk_8812_full_online",
            notes = "Full online payment via UPI (Google Pay / SBI).",
            commissionRate = 0.005,
            commissionFixedFee = 0.0,
            platformCommission = 45.0,
            operatorNetEarnings = 8955.0,
            recordedByUid = "cust_tourist_001",
            recordedByName = "Priya Sharma",
            recordedByRole = UserRole.CUSTOMER,
            timestamp = System.currentTimeMillis() - 80000000L,
            formattedDate = "2026-09-01",
            formattedTime = "10:30 AM"
        )
    ))

    private val refundRecords = MutableStateFlow<List<RefundRecord>>(emptyList())
    private val payments = MutableStateFlow<List<Payment>>(emptyList())
    private val operatorPayoutDestinations = MutableStateFlow<Map<String, PayoutDestination>>(mapOf(
        "op_verified_001" to PayoutDestination(
            id = "payout_seed_01",
            operatorId = "op_verified_001",
            type = PayoutType.UPI,
            beneficiaryName = "Animesh Mondal",
            upiId = "animesh.eco@okhdfcbank",
            isVerified = true,
            verifiedAt = System.currentTimeMillis() - 86400000L,
            verificationReference = "NPCI_VPA_MATCH_001"
        )
    ))
    private val paymentRiskAlerts = MutableStateFlow<List<PaymentRiskAlert>>(listOf(
        PaymentRiskAlert(
            id = "ALERT_RISK_SEED_01",
            transactionId = "TXN_SUN_20260901_881201",
            bookingId = "SB-BK-2026-8812",
            riskScore = 15,
            severity = RiskSeverity.LOW,
            flaggedSignals = listOf("Routine Tourist Checkout: Verified Secure Gateway Authenticated"),
            isResolved = true,
            resolutionNotes = "Verified legitimate traveler booking payment.",
            timestamp = System.currentTimeMillis() - 80000000L
        )
    ))

    private val complaints = MutableStateFlow<List<Complaint>>(listOf(
        Complaint(
            id = "cmp_seed_01",
            complaintId = "CMP_20260901_8492",
            complainantId = "cust_tourist_001",
            complainantName = "Priya Sharma",
            complainantRole = UserRole.CUSTOMER,
            targetId = "op_review_001",
            targetName = "Subhasis Mondal (Delta Speed Boat)",
            targetRole = UserRole.OPERATOR,
            bookingId = "SB-BK-2026-8812",
            packageTitle = "Royal Tiger & Sajnekhali 2D/1N River Safari",
            category = ComplaintCategory.SAFETY_ISSUE,
            subject = "Defective life jackets on small creek exploration",
            description = "During the creek transfer at Gomdi, the auxiliary motor boat had worn-out life jackets without safety whistles. The guide replaced them after complaint but safety standards must be reinforced.",
            status = ComplaintStatus.OPEN,
            createdAt = System.currentTimeMillis() - 43200000L
        )
    ))

    private val disputes = MutableStateFlow<List<DisputeRecord>>(listOf(
        DisputeRecord(
            disputeId = "DSP_20260901_3321",
            bookingId = "SB-BK-2026-8812",
            packageTitle = "Royal Tiger & Sajnekhali 2D/1N River Safari",
            customerId = "cust_tourist_001",
            customerName = "Priya Sharma",
            customerPhone = "+91 9820011223",
            customerEmail = "tourist@example.com",
            operatorId = "op_verified_001",
            operatorName = "Animesh Mondal (Tiger Trails Eco)",
            operatorPhone = "+91 9434056789",
            totalBookingAmount = 9000.0,
            paidAmount = 9000.0,
            transactionIds = listOf("TXN_ONL_20260901_8812"),
            complaintId = "CMP_20260901_8492",
            disputeReason = "Requesting partial refund for unfulfilled secondary watchtower permit due to tide schedule shift.",
            evidenceUrls = emptyList(),
            messages = listOf(
                DisputeMessage(
                    id = "msg_01",
                    senderId = "cust_tourist_001",
                    senderName = "Priya Sharma",
                    senderRole = UserRole.CUSTOMER,
                    message = "We could not visit the Netidhopani watchtower as listed in the brochure due to morning high tide.",
                    timestamp = System.currentTimeMillis() - 36000000L
                ),
                DisputeMessage(
                    id = "msg_02",
                    senderId = "op_verified_001",
                    senderName = "Animesh Mondal",
                    senderRole = UserRole.OPERATOR,
                    message = "Forest department issued an advisory closing Netidhopani creek channel for 4 hours. We substituted with extended Sajnekhali bird sanctuary exploration.",
                    timestamp = System.currentTimeMillis() - 28000000L
                )
            ),
            adminNotes = "Under administrative review by Directorate. Reviewing forest permit closure logs.",
            status = DisputeStatus.UNDER_REVIEW,
            refundDecision = RefundDecisionType.NONE,
            refundAmount = 0.0,
            createdAt = System.currentTimeMillis() - 40000000L
        )
    ))

    private val auditLogs = MutableStateFlow<List<AuditLogEntry>>(listOf(
        AuditLogEntry(
            id = "AUD_INIT_001",
            adminId = "admin_master_001",
            adminName = "Sundarban Admin Directorate",
            action = AuditAction.OPERATOR_APPROVED,
            targetId = "op_verified_001",
            targetType = "OperatorProfile",
            previousValue = "PENDING_VERIFICATION",
            newValue = "VERIFIED",
            reason = "Manual verification of trade license and marine boat registration WB-CAN-2024-889.",
            timestamp = System.currentTimeMillis() - 86400000L * 5
        ),
        AuditLogEntry(
            id = "AUD_INIT_002",
            adminId = "admin_master_001",
            adminName = "Sundarban Admin Directorate",
            action = AuditAction.COMMISSION_CHANGED,
            targetId = "PLATFORM_COMMISSION",
            targetType = "PlatformConfig",
            previousValue = "5.0%",
            newValue = "0.5%",
            reason = "Admin Commission updated to 0.5% (Total Booking Amount × 0.005).",
            timestamp = System.currentTimeMillis() - 86400000L * 4
        )
    ))

    private val flaggedRiskCases = MutableStateFlow<List<FlaggedRiskCase>>(emptyList())
    private val adminAlerts = MutableStateFlow<List<AdminAlert>>(emptyList())

    private val notifications = MutableStateFlow<List<AppNotification>>(listOf(
        AppNotification(
            id = "notif_001",
            recipientUserId = "cust_tourist_001",
            title = "Booking Confirmed: Royal Tiger & Sajnekhali 2D/1N",
            message = "Your booking SB-BK-2026-8812 has been confirmed by Tiger Trails Eco. Forest entry passes are issued.",
            type = NotificationType.BOOKING_CONFIRMED,
            bookingId = "SB-BK-2026-8812",
            timestamp = System.currentTimeMillis() - 80000000L,
            isRead = false
        ),
        AppNotification(
            id = "notif_002",
            recipientUserId = "op_verified_001",
            title = "New Booking Confirmed: SB-BK-2026-8812",
            message = "Priya Sharma has confirmed safari for 2 guests on 2026-09-15. Pickup at Godkhali Ferry Ghat.",
            type = NotificationType.BOOKING_CONFIRMED,
            bookingId = "SB-BK-2026-8812",
            timestamp = System.currentTimeMillis() - 80000000L,
            isRead = false
        )
    ))

    // Packages
    override fun getPublicVerifiedPackages(): Flow<List<TourPackage>> {
        return packages.map { list ->
            list.filter {
                it.isOperatorVerified && (it.status == PackageStatus.PUBLISHED || it.status == PackageStatus.AUTO_VERIFIED)
            }
        }
    }

    override fun getPackagesForOperator(operatorId: String): Flow<List<TourPackage>> {
        return packages.map { list ->
            list.filter { it.operatorId == operatorId }
        }
    }

    override fun getAllPackagesForAdmin(): Flow<List<TourPackage>> {
        return packages.asStateFlow()
    }

    override fun getPackageById(packageId: String): TourPackage? {
        return packages.value.firstOrNull { it.id == packageId }
    }

    override suspend fun createPackage(pkg: TourPackage): Result<TourPackage> {
        val newId = "pkg_" + UUID.randomUUID().toString().take(8)
        val verification = SecurityManager.evaluateSmartPackageVerification(
            pkg = pkg,
            operator = null,
            existingPackages = packages.value
        )
        val finalStatus = if (pkg.status == PackageStatus.DRAFT) {
            PackageStatus.DRAFT
        } else {
            verification.status
        }
        val newPkg = pkg.copy(
            id = newId,
            status = finalStatus,
            isAutoVerified = verification.isAutoVerified,
            verificationStatusText = if (finalStatus == PackageStatus.PUBLISHED) "Auto-Verified" else "Review Required",
            riskScore = verification.riskScore,
            riskSignals = verification.riskSignals,
            createdAt = System.currentTimeMillis()
        )
        packages.value = listOf(newPkg) + packages.value
        return Result.success(newPkg)
    }

    override suspend fun updatePackage(pkg: TourPackage): Result<TourPackage> {
        // Operators must NOT be allowed to edit or modify an existing package after it has been published or created.
        return Result.failure(IllegalStateException("Editing existing packages is not allowed. To update package information, please delete this package and create a new package."))
    }

    override suspend fun deletePackage(packageId: String, operatorId: String): Result<Unit> {
        val target = packages.value.firstOrNull { it.id == packageId }
            ?: return Result.failure(IllegalArgumentException("Package not found with ID: $packageId"))

        // Only the package owner Operator can delete their own package
        if (target.operatorId != operatorId) {
            return Result.failure(SecurityException("Unauthorized: Only the package owner Operator ($operatorId) can delete this package."))
        }

        packages.value = packages.value.filter { it.id != packageId }
        return Result.success(Unit)
    }

    override suspend fun moderatePackageStatus(
        packageId: String,
        status: PackageStatus,
        rejectionReason: String?
    ): Result<Unit> {
        packages.value = packages.value.map {
            if (it.id == packageId) {
                val isNowPublic = status == PackageStatus.PUBLISHED || status == PackageStatus.AUTO_VERIFIED
                it.copy(
                    status = status,
                    isOperatorVerified = if (isNowPublic) true else it.isOperatorVerified,
                    verificationStatusText = status.displayName,
                    riskScore = if (isNowPublic) 0 else it.riskScore,
                    rejectionReason = rejectionReason
                )
            } else it
        }
        return Result.success(Unit)
    }

    // Operator Public Directory
    override fun getVerifiedOperators(
        searchQuery: String,
        minRating: Double,
        minExperienceYears: Int,
        operatingArea: String
    ): Flow<List<OperatorPublicProfile>> {
        val list = mutableListOf<OperatorPublicProfile>()
        val allPkgs = packages.value.filter { it.status == PackageStatus.PUBLISHED }
        val allRevs = reviews.value

        // Operator 1: Animesh Mondal
        val op1Packages = allPkgs.filter { it.operatorId == "op_verified_001" }
        val op1Reviews = allRevs.filter { it.operatorId == "op_verified_001" }
        val op1 = OperatorPublicProfile(
            operatorId = "op_verified_001",
            name = "Animesh Mondal (Tiger Trails Eco)",
            profilePhotoUrl = null,
            verifiedBadge = true,
            verificationStatus = OperatorStatus.VERIFIED,
            experienceYears = 14,
            guideExperience = "Certified West Bengal Forest Ecotourism Guide & Launch Master",
            operatingArea = "Gosaba, Sajnekhali, Sudhanyakhali, Dobanki",
            completedTrips = 142,
            rating = 4.9,
            reviewCount = 48,
            startingPrice = 2200.0,
            phoneNumber = if (_platformSettings.value.allowPublicOperatorPhone) "+91 9434056789" else null,
            isPhonePublicVisible = _platformSettings.value.allowPublicOperatorPhone,
            packages = op1Packages,
            reviews = op1Reviews
        )

        // Operator 2: Sundarban Eco Safaris (Verified)
        val op2 = OperatorPublicProfile(
            operatorId = "op_verified_002",
            name = "Manas Halder (Sundarban Green Safaris)",
            profilePhotoUrl = null,
            verifiedBadge = true,
            verificationStatus = OperatorStatus.AUTOMATICALLY_VERIFIED,
            experienceYears = 8,
            guideExperience = "Mangrove Botany and Bird Sanctuary Specialist",
            operatingArea = "Canning, Pakhiralay, Sajnekhali",
            completedTrips = 89,
            rating = 4.8,
            reviewCount = 26,
            startingPrice = 2800.0,
            phoneNumber = if (_platformSettings.value.allowPublicOperatorPhone) "+91 9831122334" else null,
            isPhonePublicVisible = _platformSettings.value.allowPublicOperatorPhone,
            packages = emptyList(),
            reviews = emptyList()
        )

        // Operator 3: Jharkhali Eco Trails (Verified)
        val op3 = OperatorPublicProfile(
            operatorId = "op_verified_003",
            name = "Prabir Das (Jharkhali Eco Expeditions)",
            profilePhotoUrl = null,
            verifiedBadge = true,
            verificationStatus = OperatorStatus.VERIFIED,
            experienceYears = 11,
            guideExperience = "Tiger Rescue Center and Mud Creek Navigation Guide",
            operatingArea = "Jharkhali, Netidhopani, Burirdabri",
            completedTrips = 115,
            rating = 4.7,
            reviewCount = 31,
            startingPrice = 3200.0,
            phoneNumber = if (_platformSettings.value.allowPublicOperatorPhone) "+91 9733099887" else null,
            isPhonePublicVisible = _platformSettings.value.allowPublicOperatorPhone,
            packages = emptyList(),
            reviews = emptyList()
        )

        list.add(op1)
        list.add(op2)
        list.add(op3)

        // Filter according to parameters
        val filtered = list.filter { op ->
            val matchesQuery = searchQuery.isBlank() ||
                    op.name.contains(searchQuery, ignoreCase = true) ||
                    op.operatingArea.contains(searchQuery, ignoreCase = true) ||
                    op.guideExperience.contains(searchQuery, ignoreCase = true)

            val matchesRating = op.rating >= minRating
            val matchesExp = op.experienceYears >= minExperienceYears
            val matchesArea = operatingArea == "All Areas" || op.operatingArea.contains(operatingArea, ignoreCase = true)

            matchesQuery && matchesRating && matchesExp && matchesArea
        }

        return MutableStateFlow(filtered).asStateFlow()
    }

    override fun getOperatorPublicProfile(operatorId: String): OperatorPublicProfile? {
        val list = mutableListOf<OperatorPublicProfile>()
        val allPkgs = packages.value.filter { it.status == PackageStatus.PUBLISHED }
        val allRevs = reviews.value

        if (operatorId == "op_verified_001") {
            return OperatorPublicProfile(
                operatorId = "op_verified_001",
                name = "Animesh Mondal (Tiger Trails Eco)",
                profilePhotoUrl = null,
                verifiedBadge = true,
                verificationStatus = OperatorStatus.VERIFIED,
                experienceYears = 14,
                guideExperience = "Certified West Bengal Forest Ecotourism Guide & Launch Master",
                operatingArea = "Gosaba, Sajnekhali, Sudhanyakhali, Dobanki",
                completedTrips = 142,
                rating = 4.9,
                reviewCount = 48,
                startingPrice = 2200.0,
                phoneNumber = if (_platformSettings.value.allowPublicOperatorPhone) "+91 9434056789" else null,
                isPhonePublicVisible = _platformSettings.value.allowPublicOperatorPhone,
                packages = allPkgs.filter { it.operatorId == "op_verified_001" },
                reviews = allRevs.filter { it.operatorId == "op_verified_001" }
            )
        } else if (operatorId == "op_verified_002") {
            return OperatorPublicProfile(
                operatorId = "op_verified_002",
                name = "Manas Halder (Sundarban Green Safaris)",
                profilePhotoUrl = null,
                verifiedBadge = true,
                verificationStatus = OperatorStatus.AUTOMATICALLY_VERIFIED,
                experienceYears = 8,
                guideExperience = "Mangrove Botany and Bird Sanctuary Specialist",
                operatingArea = "Canning, Pakhiralay, Sajnekhali",
                completedTrips = 89,
                rating = 4.8,
                reviewCount = 26,
                startingPrice = 2800.0,
                phoneNumber = if (_platformSettings.value.allowPublicOperatorPhone) "+91 9831122334" else null,
                isPhonePublicVisible = _platformSettings.value.allowPublicOperatorPhone,
                packages = emptyList(),
                reviews = emptyList()
            )
        }
        return null
    }

    // Bookings & Safety Validation Engine
    override fun getBookingsForCustomer(customerId: String): Flow<List<Booking>> {
        return MutableStateFlow(bookings.value.filter { it.customerId == customerId }).asStateFlow()
    }

    override fun getBookingsForOperator(operatorId: String): Flow<List<Booking>> {
        return MutableStateFlow(bookings.value.filter { it.operatorId == operatorId }).asStateFlow()
    }

    override fun getAllBookingsForAdmin(): Flow<List<Booking>> {
        return bookings.asStateFlow()
    }

    override fun getBookingById(bookingId: String): Booking? {
        return bookings.value.firstOrNull { it.id == bookingId }
    }

    override suspend fun validateAndCreateBooking(booking: Booking, customer: UserProfile): Result<Booking> {
        // 1. Validate Customer
        if (customer.id.isBlank() || customer.fullName.isBlank()) {
            return Result.failure(IllegalArgumentException("Invalid customer session. Please sign in."))
        }
        if (booking.numberOfTourists <= 0) {
            return Result.failure(IllegalArgumentException("Number of tourists must be at least 1."))
        }

        // 2. Validate Package Existence & Status
        val pkg = packages.value.firstOrNull { it.id == booking.packageId }
            ?: return Result.failure(IllegalArgumentException("Selected tour package does not exist or has been removed."))

        if (pkg.status != PackageStatus.PUBLISHED) {
            return Result.failure(IllegalArgumentException("This tour package is currently ${pkg.status.displayName} and not open for booking."))
        }

        // 3. Validate Travel Dates
        if (booking.travelDate.isBlank()) {
            return Result.failure(IllegalArgumentException("Please select a valid travel date."))
        }
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val todayStr = dateFormat.format(Date())
        if (booking.travelDate < todayStr) {
            return Result.failure(IllegalArgumentException("Travel date cannot be in the past."))
        }
        if (booking.returnDate.isNotBlank() && booking.returnDate < booking.travelDate) {
            return Result.failure(IllegalArgumentException("Return date cannot be earlier than travel date."))
        }

        // 4. Validate Duplicate Booking: Same customer + same package + same date
        val activeBookings = bookings.value.filter {
            it.bookingStatus != BookingStatus.CANCELLED && it.bookingStatus != BookingStatus.REJECTED
        }
        val duplicate = activeBookings.any {
            it.customerId == customer.id && it.packageId == pkg.id && it.travelDate == booking.travelDate
        }
        if (duplicate) {
            return Result.failure(IllegalArgumentException("You already have an active booking for this package on ${booking.travelDate}. Duplicate bookings are prevented."))
        }

        // 5. Validate Overbooking / Boat Capacity
        val existingGuestsForDate = activeBookings
            .filter { it.packageId == pkg.id && it.travelDate == booking.travelDate }
            .sumOf { it.numberOfTourists }

        if (existingGuestsForDate + booking.numberOfTourists > pkg.maxTourists) {
            val availableSlots = (pkg.maxTourists - existingGuestsForDate).coerceAtLeast(0)
            return Result.failure(IllegalArgumentException("Overbooking prevented: Only $availableSlots seats remaining on ${booking.travelDate} for this launch safari."))
        }

        // Generate Unique BOOKING ID (e.g. SB-BK-2026-XXXX)
        val randomSuffix = (1000 + (Math.random() * 9000).toInt()).toString()
        val year = SimpleDateFormat("yyyy", Locale.getDefault()).format(Date())
        val generatedBookingId = "SB-BK-$year-$randomSuffix"

        val initialHistory = BookingStatusHistory(
            previousStatus = null,
            newStatus = BookingStatus.PENDING,
            changedByUid = customer.id,
            changedByName = customer.fullName,
            changedByRole = customer.role,
            timestamp = System.currentTimeMillis(),
            reason = "Booking request submitted online by tourist."
        )

        val totalCost = pkg.pricePerPerson * booking.numberOfTourists

        val newBooking = booking.copy(
            id = generatedBookingId,
            customerId = customer.id,
            customerName = customer.fullName,
            customerPhone = customer.phoneNumber,
            customerEmail = customer.email,
            operatorId = pkg.operatorId,
            operatorName = pkg.operatorName,
            operatorPhone = pkg.operatorPhone,
            packageId = pkg.id,
            packageTitle = pkg.title,
            totalAmount = totalCost,
            bookingStatus = BookingStatus.PENDING,
            statusTimeline = listOf(initialHistory),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        // Atomic append
        bookings.value = listOf(newBooking) + bookings.value

        // Dispatch Notification to Operator
        val opNotification = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = pkg.operatorId,
            title = "New Booking Request: ${newBooking.id}",
            message = "${customer.fullName} has requested ${newBooking.numberOfTourists} seats for ${pkg.title} on ${newBooking.travelDate}.",
            type = NotificationType.NEW_BOOKING,
            bookingId = newBooking.id,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notifications.value = listOf(opNotification) + notifications.value

        return Result.success(newBooking)
    }

    override suspend fun createBooking(booking: Booking): Result<Booking> {
        val newBooking = if (booking.id.isBlank()) {
            val randomSuffix = (1000 + (Math.random() * 9000).toInt()).toString()
            booking.copy(id = "SB-BK-2026-$randomSuffix")
        } else booking

        bookings.value = listOf(newBooking) + bookings.value
        return Result.success(newBooking)
    }

    override suspend fun updateBookingStatus(
        bookingId: String,
        newStatus: BookingStatus,
        changedByUid: String,
        changedByName: String,
        changedByRole: UserRole,
        reason: String
    ): Result<Booking> {
        val current = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        val historyItem = BookingStatusHistory(
            previousStatus = current.bookingStatus,
            newStatus = newStatus,
            changedByUid = changedByUid,
            changedByName = changedByName,
            changedByRole = changedByRole,
            timestamp = System.currentTimeMillis(),
            reason = reason
        )

        val updated = current.copy(
            bookingStatus = newStatus,
            statusTimeline = current.statusTimeline + historyItem,
            updatedAt = System.currentTimeMillis()
        )

        bookings.value = bookings.value.map {
            if (it.id == bookingId) updated else it
        }

        // Generate corresponding notifications
        val notifType = when (newStatus) {
            BookingStatus.ACCEPTED -> NotificationType.BOOKING_ACCEPTED
            BookingStatus.REJECTED -> NotificationType.BOOKING_REJECTED
            BookingStatus.CONFIRMED -> NotificationType.BOOKING_CONFIRMED
            BookingStatus.CANCELLED -> NotificationType.BOOKING_CANCELLED
            BookingStatus.COMPLETED -> NotificationType.SYSTEM_NOTICE
            else -> NotificationType.SYSTEM_NOTICE
        }

        val notifRecipient = if (changedByRole == UserRole.OPERATOR) current.customerId else current.operatorId
        val notifTitle = when (newStatus) {
            BookingStatus.ACCEPTED -> "Booking Accepted: ${current.id}"
            BookingStatus.REJECTED -> "Booking Request Declined: ${current.id}"
            BookingStatus.CONFIRMED -> "Booking Confirmed: ${current.id}"
            BookingStatus.IN_PROGRESS -> "Safari In Progress: ${current.id}"
            BookingStatus.COMPLETED -> "Safari Completed: ${current.id}"
            BookingStatus.CANCELLED -> "Booking Cancelled: ${current.id}"
            BookingStatus.DISPUTED -> "Booking Disputed: ${current.id}"
            else -> "Status Update: ${current.id}"
        }

        val notifMessage = when (newStatus) {
            BookingStatus.ACCEPTED -> "Operator ${current.operatorName} has accepted your booking request for ${current.packageTitle}."
            BookingStatus.REJECTED -> "Operator declined request. Reason: $reason"
            BookingStatus.CONFIRMED -> "Your booking is confirmed! Forest permits and boarding tokens have been locked."
            BookingStatus.IN_PROGRESS -> "The motor launch has departed for Sundarban Tiger Reserve safari."
            BookingStatus.COMPLETED -> "Safari complete! Please take a moment to write a review of your experience."
            BookingStatus.CANCELLED -> "Booking has been cancelled. Reason: $reason"
            BookingStatus.DISPUTED -> "Dispute lodged. Sundarban Administration review is underway."
            else -> "Status changed to ${newStatus.displayName}."
        }

        val notification = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = notifRecipient,
            title = notifTitle,
            message = notifMessage,
            type = notifType,
            bookingId = current.id,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notifications.value = listOf(notification) + notifications.value

        return Result.success(updated)
    }

    override suspend fun cancelBooking(bookingId: String, customerId: String, reason: String): Result<Unit> {
        val current = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        return updateBookingStatus(
            bookingId = bookingId,
            newStatus = BookingStatus.CANCELLED,
            changedByUid = customerId,
            changedByName = current.customerName,
            changedByRole = UserRole.CUSTOMER,
            reason = reason.ifBlank { "Cancelled by tourist." }
        ).map { }
    }

    override fun calculateHoursUntilTour(booking: Booking, nowMs: Long): Double {
        return CancellationTimeHelper.calculateHoursRemaining(
            travelDate = booking.travelDate,
            tourStartTime = booking.tourStartTime,
            nowMs = nowMs
        )
    }

    override suspend fun requestBookingCancellation(
        bookingId: String,
        initiator: UserProfile,
        reason: String,
        detailedExplanation: String?
    ): Result<CancellationRequest> {
        val current = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        if (reason.isBlank()) {
            return Result.failure(IllegalArgumentException("A cancellation reason is required."))
        }

        val hoursRemaining = calculateHoursUntilTour(current)
        val isEmergency = hoursRemaining <= 5.0

        val newBookingStatus = if (isEmergency) {
            BookingStatus.EMERGENCY_REVIEW
        } else {
            BookingStatus.CANCEL_REQUESTED
        }

        val requestStatus = if (isEmergency) {
            CancellationRequestStatus.UNDER_ADMIN_REVIEW
        } else {
            CancellationRequestStatus.PENDING_OTHER_PARTY
        }

        val cancellationRequest = CancellationRequest(
            requestId = "CAN_${UUID.randomUUID().toString().take(8).uppercase()}",
            bookingId = bookingId,
            initiatedByUid = initiator.id,
            initiatedByName = initiator.fullName,
            initiatedByRole = initiator.role,
            isEmergency = isEmergency,
            hoursRemainingAtRequest = hoursRemaining,
            reason = reason.trim(),
            detailedExplanation = detailedExplanation?.trim()?.ifBlank { null },
            status = requestStatus,
            requestedAt = System.currentTimeMillis()
        )

        val updatedTimeline = current.statusTimeline + BookingStatusHistory(
            previousStatus = current.bookingStatus,
            newStatus = newBookingStatus,
            changedByUid = initiator.id,
            changedByName = initiator.fullName,
            changedByRole = initiator.role,
            reason = if (isEmergency) {
                "Emergency Cancellation escalated (${String.format(Locale.US, "%.1f", hoursRemaining)}h remaining): $reason"
            } else {
                "Cancellation requested (${String.format(Locale.US, "%.1f", hoursRemaining)}h remaining): $reason"
            }
        )

        val updated = current.copy(
            bookingStatus = newBookingStatus,
            cancellationReason = reason,
            activeCancellationRequest = cancellationRequest,
            cancellationHistory = current.cancellationHistory + cancellationRequest,
            statusTimeline = updatedTimeline,
            updatedAt = System.currentTimeMillis()
        )

        bookings.value = bookings.value.map {
            if (it.id == bookingId) updated else it
        }

        // Notifications
        if (isEmergency) {
            // Customer notification
            val notifCust = AppNotification(
                recipientUserId = current.customerId,
                title = "Emergency Review Escalated: ${current.id}",
                message = "Your emergency cancellation request for ${current.packageTitle} has been escalated to Directorate Admin Review (< 5h to safari).",
                type = NotificationType.EMERGENCY_REVIEW_SUBMITTED,
                bookingId = current.id
            )
            // Operator notification
            val notifOp = AppNotification(
                recipientUserId = current.operatorId,
                title = "Emergency Review Alert: ${current.id}",
                message = "Emergency cancellation filed for booking ${current.id} (${String.format(Locale.US, "%.1f", hoursRemaining)}h to tour). Directorate review is in progress.",
                type = NotificationType.EMERGENCY_REVIEW_SUBMITTED,
                bookingId = current.id
            )
            // Admin notification
            val notifAdmin = AppNotification(
                recipientUserId = "admin_directorate_001",
                title = "🚨 Emergency Review Required: ${current.id}",
                message = "Urgent: Emergency cancellation submitted by ${initiator.fullName} for ${current.packageTitle} with only ${String.format(Locale.US, "%.1f", hoursRemaining)}h remaining. Reason: $reason",
                type = NotificationType.EMERGENCY_REVIEW_SUBMITTED,
                bookingId = current.id
            )
            notifications.value = listOf(notifCust, notifOp, notifAdmin) + notifications.value
        } else {
            val targetRecipient = if (initiator.role == UserRole.CUSTOMER) current.operatorId else current.customerId
            val partyLabel = if (initiator.role == UserRole.CUSTOMER) "Tourist" else "Operator"
            val notifOther = AppNotification(
                recipientUserId = targetRecipient,
                title = "Cancellation Requested: ${current.id}",
                message = "$partyLabel ${initiator.fullName} has requested to cancel ${current.packageTitle}. Please discuss and accept or reject. Reason: $reason",
                type = NotificationType.CANCELLATION_REQUESTED,
                bookingId = current.id
            )
            val notifSelf = AppNotification(
                recipientUserId = initiator.id,
                title = "Cancellation Request Sent: ${current.id}",
                message = "Your cancellation request has been delivered to the other party. The tour will only cancel once both parties agree.",
                type = NotificationType.CANCELLATION_REQUESTED,
                bookingId = current.id
            )
            notifications.value = listOf(notifOther, notifSelf) + notifications.value
        }

        return Result.success(cancellationRequest)
    }

    override suspend fun respondToCancellationRequest(
        bookingId: String,
        responder: UserProfile,
        accept: Boolean,
        responseNotes: String?
    ): Result<Booking> {
        val current = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        val activeReq = current.activeCancellationRequest
            ?: return Result.failure(IllegalStateException("No active cancellation request found for booking $bookingId"))

        if (activeReq.isEmergency) {
            return Result.failure(IllegalStateException("Emergency requests are strictly adjudicated by Directorate Admins."))
        }

        val updatedRequest = activeReq.copy(
            status = if (accept) CancellationRequestStatus.ACCEPTED else CancellationRequestStatus.REJECTED,
            respondedAt = System.currentTimeMillis(),
            respondedByUid = responder.id,
            respondedByName = responder.fullName,
            responseNotes = responseNotes?.trim()?.ifBlank { null }
        )

        val newBookingStatus = if (accept) {
            BookingStatus.CANCELLED
        } else {
            BookingStatus.CONFIRMED
        }

        var updatedRefundResolution: String? = current.refundResolutionStatus
        if (accept && current.paidAmount > 0.0) {
            updatedRefundResolution = "REFUND PENDING"
            val refundRecord = RefundRecord(
                refundId = "REF_${UUID.randomUUID().toString().take(8).uppercase()}",
                bookingId = current.id,
                transactionId = "TXN_CANCEL_${current.id}",
                packageTitle = current.packageTitle,
                customerId = current.customerId,
                customerName = current.customerName,
                operatorId = current.operatorId,
                operatorName = current.operatorName,
                amount = current.paidAmount,
                reason = "Mutual Agreement Cancellation: ${activeReq.reason}",
                status = RefundStatus.PROCESSING,
                initiatedByUid = responder.id,
                initiatedByName = responder.fullName,
                initiatedByRole = responder.role
            )
            refundRecords.value = listOf(refundRecord) + refundRecords.value

            val refundTxn = PaymentTransaction(
                transactionId = "TXN_REF_${UUID.randomUUID().toString().take(8).uppercase()}",
                bookingId = current.id,
                packageId = current.packageId,
                packageTitle = current.packageTitle,
                amount = current.paidAmount,
                currency = "INR",
                method = PaymentGatewayMethod.UPI,
                status = TransactionStatus.REFUND_PENDING,
                type = TransactionType.REFUND_PAYOUT,
                payerId = current.operatorId,
                payerName = current.operatorName,
                receiverId = current.customerId,
                receiverName = current.customerName,
                notes = "Automated refund payout queued following mutual cancellation approval."
            )
            transactions.value = listOf(refundTxn) + transactions.value
        }

        val timelineEntry = BookingStatusHistory(
            previousStatus = current.bookingStatus,
            newStatus = newBookingStatus,
            changedByUid = responder.id,
            changedByName = responder.fullName,
            changedByRole = responder.role,
            reason = if (accept) {
                "Cancellation mutually agreed by both parties (${responder.fullName} accepted). Booking cancelled."
            } else {
                "Cancellation request declined by ${responder.fullName}. Reason: ${responseNotes ?: "Declined"}"
            }
        )

        val updatedHistory = current.cancellationHistory.map {
            if (it.requestId == activeReq.requestId) updatedRequest else it
        }

        val updatedBooking = current.copy(
            bookingStatus = newBookingStatus,
            activeCancellationRequest = if (accept) updatedRequest else null,
            cancellationHistory = updatedHistory,
            refundResolutionStatus = updatedRefundResolution,
            statusTimeline = current.statusTimeline + timelineEntry,
            updatedAt = System.currentTimeMillis()
        )

        bookings.value = bookings.value.map {
            if (it.id == bookingId) updatedBooking else it
        }

        // Notifications
        if (accept) {
            val notifCust = AppNotification(
                recipientUserId = current.customerId,
                title = "Booking Cancelled (Mutual Agreement): ${current.id}",
                message = "Booking ${current.id} has been cancelled by mutual agreement. Refund processing has been initiated.",
                type = NotificationType.CANCELLATION_ACCEPTED,
                bookingId = current.id
            )
            val notifOp = AppNotification(
                recipientUserId = current.operatorId,
                title = "Booking Cancelled (Mutual Agreement): ${current.id}",
                message = "Booking ${current.id} has been cancelled by mutual agreement. Boat seats have been released.",
                type = NotificationType.CANCELLATION_ACCEPTED,
                bookingId = current.id
            )
            notifications.value = listOf(notifCust, notifOp) + notifications.value
        } else {
            val notifCust = AppNotification(
                recipientUserId = current.customerId,
                title = "Cancellation Request Declined: ${current.id}",
                message = "Cancellation request was declined by ${responder.fullName}. The booking remains confirmed.",
                type = NotificationType.CANCELLATION_REJECTED,
                bookingId = current.id
            )
            val notifOp = AppNotification(
                recipientUserId = current.operatorId,
                title = "Cancellation Request Declined: ${current.id}",
                message = "Cancellation request for ${current.id} was declined. The booking remains confirmed.",
                type = NotificationType.CANCELLATION_REJECTED,
                bookingId = current.id
            )
            notifications.value = listOf(notifCust, notifOp) + notifications.value
        }

        return Result.success(updatedBooking)
    }

    override suspend fun addCancellationDiscussionMessage(
        bookingId: String,
        sender: UserProfile,
        message: String
    ): Result<CancellationDiscussionMessage> {
        val current = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        val activeReq = current.activeCancellationRequest
            ?: return Result.failure(IllegalStateException("No active cancellation request to discuss"))

        if (message.isBlank()) {
            return Result.failure(IllegalArgumentException("Message cannot be empty"))
        }

        val discussionMsg = CancellationDiscussionMessage(
            id = UUID.randomUUID().toString().take(8),
            senderUid = sender.id,
            senderName = sender.fullName,
            senderRole = sender.role,
            message = message.trim(),
            timestamp = System.currentTimeMillis()
        )

        val updatedReq = activeReq.copy(
            discussionMessages = activeReq.discussionMessages + discussionMsg
        )

        val updatedHistory = current.cancellationHistory.map {
            if (it.requestId == activeReq.requestId) updatedReq else it
        }

        val updatedBooking = current.copy(
            activeCancellationRequest = updatedReq,
            cancellationHistory = updatedHistory,
            updatedAt = System.currentTimeMillis()
        )

        bookings.value = bookings.value.map {
            if (it.id == bookingId) updatedBooking else it
        }

        val otherUid = if (sender.id == current.customerId) current.operatorId else current.customerId
        val notifMsg = AppNotification(
            recipientUserId = otherUid,
            title = "New Cancellation Message: ${current.id}",
            message = "${sender.fullName}: \"${message.take(80)}\"",
            type = NotificationType.SYSTEM_NOTICE,
            bookingId = current.id
        )
        notifications.value = listOf(notifMsg) + notifications.value

        return Result.success(discussionMsg)
    }

    override suspend fun adminResolveEmergencyCancellation(
        bookingId: String,
        admin: UserProfile,
        decisionType: AdminDecisionType,
        refundDecision: AdminRefundDecision,
        refundAmount: Double,
        rescheduledDate: String?,
        newOperatorId: String?,
        reason: String
    ): Result<Booking> {
        val current = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        val activeReq = current.activeCancellationRequest
            ?: return Result.failure(IllegalStateException("No active emergency request for booking $bookingId"))

        if (reason.isBlank()) {
            return Result.failure(IllegalArgumentException("Admin rationale and decision reason are required."))
        }

        val allOperators = authRepository?.getAllUsersForAdmin()?.firstOrNull() ?: emptyList()
        val newOp = if (!newOperatorId.isNullOrBlank()) allOperators.firstOrNull { it.id == newOperatorId } else null

        val adminDecision = AdminEmergencyDecision(
            decisionId = "ADM_DEC_${UUID.randomUUID().toString().take(8).uppercase()}",
            adminId = admin.id,
            adminName = admin.fullName,
            decisionType = decisionType,
            refundDecision = refundDecision,
            refundAmount = refundAmount,
            rescheduledDate = rescheduledDate,
            newOperatorId = newOperatorId,
            newOperatorName = newOp?.fullName,
            reason = reason.trim(),
            timestamp = System.currentTimeMillis()
        )

        val updatedReq = activeReq.copy(
            status = if (decisionType == AdminDecisionType.REQUEST_INFO) CancellationRequestStatus.UNDER_ADMIN_REVIEW else CancellationRequestStatus.RESOLVED_BY_ADMIN,
            adminDecisions = activeReq.adminDecisions + adminDecision
        )

        var newStatus = current.bookingStatus
        var updatedRefundResolution: String? = current.refundResolutionStatus
        var newTravelDate = current.travelDate
        var opId = current.operatorId
        var opName = current.operatorName
        var opPhone = current.operatorPhone

        when (decisionType) {
            AdminDecisionType.APPROVE_CANCELLATION -> {
                newStatus = BookingStatus.CANCELLED
                when (refundDecision) {
                    AdminRefundDecision.FULL_REFUND -> {
                        updatedRefundResolution = "REFUNDED"
                        val refRec = RefundRecord(
                            refundId = "REF_${UUID.randomUUID().toString().take(8).uppercase()}",
                            bookingId = current.id,
                            transactionId = "TXN_EMG_REF_${current.id}",
                            packageTitle = current.packageTitle,
                            customerId = current.customerId,
                            customerName = current.customerName,
                            operatorId = current.operatorId,
                            operatorName = current.operatorName,
                            amount = current.paidAmount,
                            reason = "Admin Emergency Adjudication (Full Refund): $reason",
                            status = RefundStatus.COMPLETED,
                            initiatedByUid = admin.id,
                            initiatedByName = admin.fullName,
                            initiatedByRole = UserRole.ADMIN,
                            completedByUid = admin.id,
                            completedByName = admin.fullName,
                            completedAt = System.currentTimeMillis()
                        )
                        refundRecords.value = listOf(refRec) + refundRecords.value
                        transactions.value = listOf(
                            PaymentTransaction(
                                transactionId = "TXN_REF_${UUID.randomUUID().toString().take(8).uppercase()}",
                                bookingId = current.id,
                                packageId = current.packageId,
                                packageTitle = current.packageTitle,
                                amount = current.paidAmount,
                                status = TransactionStatus.REFUNDED,
                                type = TransactionType.REFUND_PAYOUT,
                                payerId = current.operatorId,
                                payerName = current.operatorName,
                                receiverId = current.customerId,
                                receiverName = current.customerName,
                                notes = "Admin Emergency Order: Full refund issued. Rationale: $reason"
                            )
                        ) + transactions.value
                    }
                    AdminRefundDecision.PARTIAL_REFUND -> {
                        val amt = if (refundAmount > 0.0) refundAmount else current.paidAmount * 0.5
                        updatedRefundResolution = "PARTIALLY REFUNDED"
                        val refRec = RefundRecord(
                            refundId = "REF_${UUID.randomUUID().toString().take(8).uppercase()}",
                            bookingId = current.id,
                            transactionId = "TXN_EMG_REF_${current.id}",
                            packageTitle = current.packageTitle,
                            customerId = current.customerId,
                            customerName = current.customerName,
                            operatorId = current.operatorId,
                            operatorName = current.operatorName,
                            amount = amt,
                            reason = "Admin Emergency Adjudication (Partial Refund): $reason",
                            status = RefundStatus.COMPLETED,
                            initiatedByUid = admin.id,
                            initiatedByName = admin.fullName,
                            initiatedByRole = UserRole.ADMIN,
                            completedByUid = admin.id,
                            completedByName = admin.fullName,
                            completedAt = System.currentTimeMillis()
                        )
                        refundRecords.value = listOf(refRec) + refundRecords.value
                        transactions.value = listOf(
                            PaymentTransaction(
                                transactionId = "TXN_REF_${UUID.randomUUID().toString().take(8).uppercase()}",
                                bookingId = current.id,
                                packageId = current.packageId,
                                packageTitle = current.packageTitle,
                                amount = amt,
                                status = TransactionStatus.PARTIALLY_REFUNDED,
                                type = TransactionType.REFUND_PAYOUT,
                                payerId = current.operatorId,
                                payerName = current.operatorName,
                                receiverId = current.customerId,
                                receiverName = current.customerName,
                                notes = "Admin Emergency Order: Partial refund ₹${amt.toInt()} issued. Rationale: $reason"
                            )
                        ) + transactions.value
                    }
                    AdminRefundDecision.REJECT_REFUND -> {
                        updatedRefundResolution = "REFUND REJECTED"
                        val refRec = RefundRecord(
                            refundId = "REF_${UUID.randomUUID().toString().take(8).uppercase()}",
                            bookingId = current.id,
                            transactionId = "TXN_EMG_REF_${current.id}",
                            packageTitle = current.packageTitle,
                            customerId = current.customerId,
                            customerName = current.customerName,
                            operatorId = current.operatorId,
                            operatorName = current.operatorName,
                            amount = 0.0,
                            reason = "Admin Emergency Adjudication (Refund Declined): $reason",
                            status = RefundStatus.REJECTED,
                            initiatedByUid = admin.id,
                            initiatedByName = admin.fullName,
                            initiatedByRole = UserRole.ADMIN,
                            rejectionReason = reason
                        )
                        refundRecords.value = listOf(refRec) + refundRecords.value
                    }
                    AdminRefundDecision.NO_REFUND -> {}
                }
            }
            AdminDecisionType.REJECT_CANCELLATION -> {
                newStatus = BookingStatus.CONFIRMED
            }
            AdminDecisionType.RESCHEDULE_TOUR -> {
                newStatus = BookingStatus.RESCHEDULED
                if (!rescheduledDate.isNullOrBlank()) {
                    newTravelDate = rescheduledDate
                }
            }
            AdminDecisionType.REASSIGN_OPERATOR -> {
                newStatus = BookingStatus.CONFIRMED
                if (newOp != null) {
                    opId = newOp.id
                    opName = newOp.fullName
                    opPhone = newOp.phoneNumber
                }
            }
            AdminDecisionType.REQUEST_INFO -> {
                newStatus = BookingStatus.EMERGENCY_REVIEW
            }
        }

        val timelineEntry = BookingStatusHistory(
            previousStatus = current.bookingStatus,
            newStatus = newStatus,
            changedByUid = admin.id,
            changedByName = admin.fullName,
            changedByRole = UserRole.ADMIN,
            reason = "Directorate Emergency Adjudication: ${decisionType.displayName}. Rationale: $reason"
        )

        val updatedHistory = current.cancellationHistory.map {
            if (it.requestId == activeReq.requestId) updatedReq else it
        }

        val updatedBooking = current.copy(
            bookingStatus = newStatus,
            travelDate = newTravelDate,
            operatorId = opId,
            operatorName = opName,
            operatorPhone = opPhone,
            activeCancellationRequest = if (decisionType == AdminDecisionType.REQUEST_INFO) updatedReq else null,
            cancellationHistory = updatedHistory,
            refundResolutionStatus = updatedRefundResolution,
            statusTimeline = current.statusTimeline + timelineEntry,
            updatedAt = System.currentTimeMillis()
        )

        bookings.value = bookings.value.map {
            if (it.id == bookingId) updatedBooking else it
        }

        // Notify both Tourist and Operator
        val notifCust = AppNotification(
            recipientUserId = current.customerId,
            title = "Directorate Ruling: ${current.id}",
            message = "Sundarban Administration has issued a ruling on your emergency request: ${decisionType.displayName}. Rationale: $reason",
            type = NotificationType.ADMIN_DECISION_ISSUED,
            bookingId = current.id
        )
        val notifOp = AppNotification(
            recipientUserId = current.operatorId,
            title = "Directorate Ruling: ${current.id}",
            message = "Sundarban Administration has issued a ruling on emergency request for ${current.id}: ${decisionType.displayName}. Rationale: $reason",
            type = NotificationType.ADMIN_DECISION_ISSUED,
            bookingId = current.id
        )
        notifications.value = listOf(notifCust, notifOp) + notifications.value

        return Result.success(updatedBooking)
    }

    override suspend fun disputeBooking(bookingId: String, customerId: String, reason: String): Result<Unit> {
        val current = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        return updateBookingStatus(
            bookingId = bookingId,
            newStatus = BookingStatus.DISPUTED,
            changedByUid = customerId,
            changedByName = current.customerName,
            changedByRole = UserRole.CUSTOMER,
            reason = reason.ifBlank { "Disputed by tourist." }
        ).map { }
    }

    // Payments & Financials (Part 4)
    override fun getPayments(): Flow<List<Payment>> = payments.asStateFlow()

    override suspend fun recordPayment(payment: Payment): Result<Payment> {
        val newPayment = payment.copy(id = "pay_" + UUID.randomUUID().toString().take(8))
        payments.value = listOf(newPayment) + payments.value
        return Result.success(newPayment)
    }

    override fun getAllTransactionsForAdmin(): Flow<List<PaymentTransaction>> = transactions.asStateFlow()

    override fun getTransactionsForCustomer(customerId: String): Flow<List<PaymentTransaction>> {
        return MutableStateFlow(
            transactions.value.filter { it.payerId == customerId }
        ).asStateFlow()
    }

    override fun getTransactionsForOperator(operatorId: String): Flow<List<PaymentTransaction>> {
        return MutableStateFlow(
            transactions.value.filter { it.receiverId == operatorId }
        ).asStateFlow()
    }

    override fun getTransactionsForBooking(bookingId: String): Flow<List<PaymentTransaction>> {
        return MutableStateFlow(
            transactions.value.filter { it.bookingId == bookingId }
        ).asStateFlow()
    }

    override fun getBookingFinancialTimeline(bookingId: String): Flow<BookingFinancialTimeline?> {
        val bk = bookings.value.firstOrNull { it.id == bookingId }
        if (bk == null) return MutableStateFlow(null).asStateFlow()

        val bkTxns = transactions.value.filter { it.bookingId == bookingId && it.status != TransactionStatus.FAILED && it.status != TransactionStatus.CANCELLED }
        val bkRefunds = refundRecords.value.filter { it.bookingId == bookingId }

        val onlinePaid = bkTxns
            .filter { it.type == TransactionType.ONLINE_GATEWAY && it.status == TransactionStatus.SUCCESS }
            .sumOf { it.amount }

        val cashPaid = bkTxns
            .filter { it.type == TransactionType.OFFLINE_CASH && it.status == TransactionStatus.CASH_RECORDED }
            .sumOf { it.amount } +
            bkTxns.filter { it.type == TransactionType.CASH_ADJUSTMENT }.sumOf { it.amount }

        val refundedAmt = bkRefunds
            .filter { it.status == RefundStatus.COMPLETED }
            .sumOf { it.amount }

        val totalPaid = (onlinePaid + cashPaid).coerceAtLeast(0.0)
        val remaining = (bk.totalAmount - totalPaid + refundedAmt).coerceAtLeast(0.0)
        val finalNet = (totalPaid - refundedAmt).coerceAtLeast(0.0)

        val timeline = BookingFinancialTimeline(
            bookingId = bookingId,
            totalPackagePrice = bk.totalAmount,
            onlinePaid = onlinePaid,
            cashPaid = cashPaid,
            totalPaid = totalPaid,
            refundedAmount = refundedAmt,
            remainingAmount = remaining,
            finalNetAmount = finalNet,
            transactions = transactions.value.filter { it.bookingId == bookingId },
            refundRecords = bkRefunds
        )

        return MutableStateFlow(timeline).asStateFlow()
    }

    override fun getOperatorEarningsSummary(operatorId: String): Flow<OperatorEarningsSummary> {
        val opBookings = bookings.value.filter { it.operatorId == operatorId }
        val opTxns = transactions.value.filter { it.receiverId == operatorId }
        val opRefunds = refundRecords.value.filter { it.operatorId == operatorId }

        val grossValue = opBookings
            .filter { it.bookingStatus != BookingStatus.CANCELLED && it.bookingStatus != BookingStatus.REJECTED }
            .sumOf { it.totalAmount }

        val onlinePayments = opTxns
            .filter { it.type == TransactionType.ONLINE_GATEWAY && it.status == TransactionStatus.SUCCESS }
            .sumOf { it.amount }

        val cashPayments = opTxns
            .filter { (it.type == TransactionType.OFFLINE_CASH && it.status == TransactionStatus.CASH_RECORDED) || it.type == TransactionType.CASH_ADJUSTMENT }
            .sumOf { it.amount }

        val refundsTotal = opRefunds
            .filter { it.status == RefundStatus.COMPLETED }
            .sumOf { it.amount }

        val totalCommission = opTxns
            .filter { it.status == TransactionStatus.SUCCESS || it.status == TransactionStatus.CASH_RECORDED }
            .sumOf { it.platformCommission }

        val totalCollected = onlinePayments + cashPayments - refundsTotal
        val pending = (grossValue - totalCollected).coerceAtLeast(0.0)
        val netEarnings = (totalCollected - totalCommission).coerceAtLeast(0.0)

        val summary = OperatorEarningsSummary(
            operatorId = operatorId,
            grossBookingValue = grossValue,
            onlinePayments = onlinePayments,
            cashPayments = cashPayments,
            pendingPayments = pending,
            refunds = refundsTotal,
            totalCommission = totalCommission,
            netEarnings = netEarnings,
            totalBookingsCount = opBookings.size,
            paidBookingsCount = opBookings.count { it.paymentStatus == PaymentStatus.PAID || it.paidAmount >= it.totalAmount }
        )

        return MutableStateFlow(summary).asStateFlow()
    }

    override fun getGlobalPlatformFinancialSummary(): Flow<OperatorEarningsSummary> {
        val allBookings = bookings.value
        val allTxns = transactions.value
        val allRefunds = refundRecords.value

        val grossValue = allBookings
            .filter { it.bookingStatus != BookingStatus.CANCELLED && it.bookingStatus != BookingStatus.REJECTED }
            .sumOf { it.totalAmount }

        val online = allTxns
            .filter { it.type == TransactionType.ONLINE_GATEWAY && it.status == TransactionStatus.SUCCESS }
            .sumOf { it.amount }

        val cash = allTxns
            .filter { (it.type == TransactionType.OFFLINE_CASH && it.status == TransactionStatus.CASH_RECORDED) || it.type == TransactionType.CASH_ADJUSTMENT }
            .sumOf { it.amount }

        val refunds = allRefunds
            .filter { it.status == RefundStatus.COMPLETED }
            .sumOf { it.amount }

        val totalCommission = allTxns
            .filter { it.status == TransactionStatus.SUCCESS || it.status == TransactionStatus.CASH_RECORDED }
            .sumOf { it.platformCommission }

        val totalCollected = online + cash - refunds
        val pending = (grossValue - totalCollected).coerceAtLeast(0.0)
        val netEarnings = totalCommission // Platform net revenue

        val summary = OperatorEarningsSummary(
            operatorId = "PLATFORM_GLOBAL",
            grossBookingValue = grossValue,
            onlinePayments = online,
            cashPayments = cash,
            pendingPayments = pending,
            refunds = refunds,
            totalCommission = totalCommission,
            netEarnings = netEarnings,
            totalBookingsCount = allBookings.size,
            paidBookingsCount = allBookings.count { it.paymentStatus == PaymentStatus.PAID }
        )

        return MutableStateFlow(summary).asStateFlow()
    }

    override suspend fun updateCommissionConfig(newConfig: PlatformCommissionConfig, adminUid: String): Result<Unit> {
        val updated = newConfig.copy(
            updatedAt = System.currentTimeMillis(),
            updatedBy = adminUid
        )
        commissionConfig.value = updated

        // Log system notification
        val notif = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = "ALL",
            title = "Admin Commission Policy Updated",
            message = "Sundarban Directorate updated Admin Commission to ${updated.percentageCommission}% (Total Booking Amount × 0.005). Effective ${updated.effectiveDate}. Historical bookings remain unchanged.",
            type = NotificationType.COMMISSION_UPDATED,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notifications.value = listOf(notif) + notifications.value

        return Result.success(Unit)
    }

    override fun getRefundRecords(): Flow<List<RefundRecord>> = refundRecords.asStateFlow()

    override fun getRefundRecordsForBooking(bookingId: String): Flow<List<RefundRecord>> {
        return MutableStateFlow(refundRecords.value.filter { it.bookingId == bookingId }).asStateFlow()
    }

    override fun getRefundRecordsForCustomer(customerId: String): Flow<List<RefundRecord>> {
        return MutableStateFlow(refundRecords.value.filter { it.customerId == customerId }).asStateFlow()
    }

    override suspend fun createPaymentOrder(
        bookingId: String,
        amount: Double,
        method: PaymentGatewayMethod,
        payer: UserProfile,
        idempotencyKey: String
    ): Result<PaymentTransaction> {
        val bk = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        // Security check: Check if booking is already fully paid
        if (bk.paymentStatus == PaymentStatus.PAID && bk.paidAmount >= bk.totalAmount) {
            return Result.failure(IllegalStateException("Booking is already fully paid. No additional payment required."))
        }

        // Check idempotency: Return existing initiated txn if matching key
        val existing = transactions.value.firstOrNull { it.idempotencyKey == idempotencyKey }
        if (existing != null) {
            return Result.success(existing)
        }

        // Duplicate Check: Reuse active PENDING transaction within last 60 seconds
        val recentPending = transactions.value.firstOrNull {
            it.bookingId == bk.id && it.status == TransactionStatus.PENDING &&
                    (System.currentTimeMillis() - it.timestamp) < 60_000L && it.amount == amount
        }
        if (recentPending != null) {
            return Result.success(recentPending)
        }

        val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()

        val currentComm = commissionConfig.value
        val rate = currentComm.percentageCommission / 100.0
        val commAmt = (amount * rate) + currentComm.fixedFeePerBooking
        val operatorNet = (amount - commAmt).coerceAtLeast(0.0)

        val txnId = "TXN_SUN_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(now)}_${UUID.randomUUID().toString().take(6).uppercase()}"
        val orderId = "order_SB_${UUID.randomUUID().toString().take(10).uppercase()}"

        val txn = PaymentTransaction(
            transactionId = txnId,
            bookingId = bk.id,
            packageId = bk.packageId,
            packageTitle = bk.packageTitle,
            amount = amount,
            currency = "INR",
            method = method,
            status = TransactionStatus.PENDING,
            type = TransactionType.ONLINE_GATEWAY,
            payerId = payer.id,
            payerName = payer.fullName,
            payerPhone = payer.phoneNumber,
            payerEmail = payer.email,
            receiverId = bk.operatorId,
            receiverName = bk.operatorName,
            gatewayOrderId = orderId,
            idempotencyKey = idempotencyKey,
            commissionRate = rate,
            commissionFixedFee = currentComm.fixedFeePerBooking,
            platformCommission = commAmt,
            operatorNetEarnings = operatorNet,
            recordedByUid = payer.id,
            recordedByName = payer.fullName,
            recordedByRole = payer.role,
            timestamp = System.currentTimeMillis(),
            formattedDate = dateFmt.format(now),
            formattedTime = timeFmt.format(now)
        )

        transactions.value = listOf(txn) + transactions.value

        // Security Risk Evaluation & Fraud Signal Detection
        val isOpVerified = operatorPayoutDestinations.value[bk.operatorId]?.isVerified == true
        val riskAssess = SecurityManager.evaluatePaymentSecurityRisk(txn, transactions.value, isOpVerified)
        if (riskAssess.isSuspicious) {
            val alert = PaymentRiskAlert(
                transactionId = txn.transactionId,
                bookingId = bk.id,
                riskScore = riskAssess.riskScore,
                severity = riskAssess.severity,
                flaggedSignals = riskAssess.riskSignals
            )
            paymentRiskAlerts.value = listOf(alert) + paymentRiskAlerts.value
        }

        return Result.success(txn)
    }

    override suspend fun verifyAndProcessOnlinePayment(
        transactionId: String,
        gatewayOrderId: String,
        gatewayPaymentId: String,
        gatewaySignature: String,
        idempotencyKey: String
    ): Result<PaymentTransaction> {
        val currentTxn = transactions.value.firstOrNull { it.transactionId == transactionId }
            ?: return Result.failure(IllegalArgumentException("Transaction record not found."))

        // Server-Side Verification: Ensure payment is not processed twice
        if (currentTxn.status == TransactionStatus.SUCCESS) {
            return Result.success(currentTxn)
        }

        val bk = bookings.value.firstOrNull { it.id == currentTxn.bookingId }
            ?: return Result.failure(IllegalArgumentException("Associated booking not found."))

        // Server-Side Verification Simulation: Validate gateway payload & signature authenticity
        if (gatewayPaymentId.isBlank() || gatewaySignature.isBlank()) {
            val failedTxn = currentTxn.copy(status = TransactionStatus.FAILED)
            transactions.value = transactions.value.map { if (it.transactionId == transactionId) failedTxn else it }
            return Result.failure(SecurityException("Server-Side Payment Verification Failed: Invalid signature or missing gateway payment reference."))
        }

        val verifiedTxn = currentTxn.copy(
            status = TransactionStatus.SUCCESS,
            gatewayPaymentId = gatewayPaymentId,
            gatewaySignature = gatewaySignature,
            updatedAt = System.currentTimeMillis()
        )

        transactions.value = transactions.value.map { if (it.transactionId == transactionId) verifiedTxn else it }

        // Update Booking
        val newPaidTotal = bk.paidAmount + verifiedTxn.amount
        val isFull = newPaidTotal >= bk.totalAmount
        val newBookingStatus = if (isFull) BookingStatus.CONFIRMED else BookingStatus.PARTIALLY_PAID
        val newPaymentStatus = if (isFull) PaymentStatus.PAID else PaymentStatus.PARTIALLY_PAID

        val paymentHistory = BookingStatusHistory(
            previousStatus = bk.bookingStatus,
            newStatus = newBookingStatus,
            changedByUid = currentTxn.payerId,
            changedByName = currentTxn.payerName,
            changedByRole = UserRole.CUSTOMER,
            timestamp = System.currentTimeMillis(),
            reason = "Online payment verified: ₹${verifiedTxn.amount} received via ${verifiedTxn.method.displayName} (Txn: ${verifiedTxn.transactionId}, Gateway Ref: $gatewayPaymentId)."
        )

        val updatedBooking = bk.copy(
            paidAmount = newPaidTotal,
            bookingStatus = newBookingStatus,
            paymentStatus = newPaymentStatus,
            paymentMethod = PaymentMethod.ONLINE_UPI_CARD,
            statusTimeline = bk.statusTimeline + paymentHistory,
            updatedAt = System.currentTimeMillis()
        )

        bookings.value = bookings.value.map { if (it.id == bk.id) updatedBooking else it }

        // Notify Customer
        val custNotif = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = bk.customerId,
            title = "Payment Successful: ₹${verifiedTxn.amount}",
            message = "Your payment of ₹${verifiedTxn.amount} for ${bk.packageTitle} was successfully verified by the gateway. Booking status: ${newBookingStatus.displayName}.",
            type = NotificationType.PAYMENT_RECEIVED,
            bookingId = bk.id,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )

        // Notify Operator
        val opNotif = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = bk.operatorId,
            title = "Payment Received: ${bk.id}",
            message = "${verifiedTxn.payerName} paid ₹${verifiedTxn.amount} online for ${bk.packageTitle}. Net operator credit: ₹${verifiedTxn.operatorNetEarnings}.",
            type = NotificationType.PAYMENT_RECEIVED,
            bookingId = bk.id,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )

        notifications.value = listOf(custNotif, opNotif) + notifications.value
        return Result.success(verifiedTxn)
    }

    override suspend fun recordCashPayment(
        bookingId: String,
        amount: Double,
        notes: String,
        receiptNumber: String?,
        proofUrl: String?,
        operator: UserProfile
    ): Result<PaymentTransaction> {
        if (amount <= 0.0) {
            return Result.failure(IllegalArgumentException("Cash amount must be greater than zero."))
        }

        val bk = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking $bookingId not found."))

        val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()

        val currentComm = commissionConfig.value
        val rate = currentComm.percentageCommission / 100.0
        val commAmt = (amount * rate) + currentComm.fixedFeePerBooking
        val operatorNet = (amount - commAmt).coerceAtLeast(0.0)

        val txnId = "CASH_SUN_${SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(now)}_${UUID.randomUUID().toString().take(6).uppercase()}"

        val cashTxn = PaymentTransaction(
            transactionId = txnId,
            bookingId = bk.id,
            packageId = bk.packageId,
            packageTitle = bk.packageTitle,
            amount = amount,
            currency = "INR",
            method = PaymentGatewayMethod.CASH,
            status = TransactionStatus.CASH_RECORDED,
            type = TransactionType.OFFLINE_CASH,
            payerId = bk.customerId,
            payerName = bk.customerName,
            payerPhone = bk.customerPhone,
            payerEmail = bk.customerEmail,
            receiverId = operator.id,
            receiverName = operator.fullName,
            notes = notes.ifBlank { "Cash received at Ghat / Boarding point." },
            cashReceiptNumber = receiptNumber ?: "GHT-REC-${(1000..9999).random()}",
            cashProofUrl = proofUrl,
            commissionRate = rate,
            commissionFixedFee = currentComm.fixedFeePerBooking,
            platformCommission = commAmt,
            operatorNetEarnings = operatorNet,
            recordedByUid = operator.id,
            recordedByName = operator.fullName,
            recordedByRole = operator.role,
            timestamp = System.currentTimeMillis(),
            formattedDate = dateFmt.format(now),
            formattedTime = timeFmt.format(now)
        )

        // Append-only ledger
        transactions.value = listOf(cashTxn) + transactions.value

        // Update Booking
        val newPaidTotal = bk.paidAmount + amount
        val isFull = newPaidTotal >= bk.totalAmount
        val newBookingStatus = if (isFull) BookingStatus.CONFIRMED else BookingStatus.PARTIALLY_PAID
        val newPaymentStatus = if (isFull) PaymentStatus.PAID else PaymentStatus.PARTIALLY_PAID

        val statusHistory = BookingStatusHistory(
            previousStatus = bk.bookingStatus,
            newStatus = newBookingStatus,
            changedByUid = operator.id,
            changedByName = operator.fullName,
            changedByRole = operator.role,
            timestamp = System.currentTimeMillis(),
            reason = "Cash payment of ₹$amount recorded at Ghat by operator (Receipt: ${cashTxn.cashReceiptNumber}). Total paid: ₹$newPaidTotal."
        )

        val updatedBooking = bk.copy(
            paidAmount = newPaidTotal,
            bookingStatus = newBookingStatus,
            paymentStatus = newPaymentStatus,
            statusTimeline = bk.statusTimeline + statusHistory,
            updatedAt = System.currentTimeMillis()
        )

        bookings.value = bookings.value.map { if (it.id == bk.id) updatedBooking else it }

        // MANDATORY: Real-time notification sent to Customer when cash payment is recorded
        val custNotification = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = bk.customerId,
            title = "Cash Payment Acknowledged: ₹$amount",
            message = "Operator ${operator.fullName} has recorded receiving ₹$amount in cash at the Ghat for booking ${bk.id} (Receipt No: ${cashTxn.cashReceiptNumber}).",
            type = NotificationType.CASH_PAYMENT_RECORDED,
            bookingId = bk.id,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notifications.value = listOf(custNotification) + notifications.value

        return Result.success(cashTxn)
    }

    override suspend fun recordCashAdjustment(
        originalTxnId: String,
        adjustmentAmount: Double,
        reason: String,
        operator: UserProfile
    ): Result<PaymentTransaction> {
        if (reason.isBlank()) {
            return Result.failure(IllegalArgumentException("Audit adjustment reason is mandatory."))
        }

        val original = transactions.value.firstOrNull { it.transactionId == originalTxnId }
            ?: return Result.failure(IllegalArgumentException("Original transaction not found."))

        val bk = bookings.value.firstOrNull { it.id == original.bookingId }
            ?: return Result.failure(IllegalArgumentException("Associated booking not found."))

        val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()

        val adjTxnId = "ADJ_${SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(now)}_${UUID.randomUUID().toString().take(6).uppercase()}"

        val commRate = original.commissionRate
        val commAmt = adjustmentAmount * commRate
        val netOp = adjustmentAmount - commAmt

        val adjTxn = PaymentTransaction(
            transactionId = adjTxnId,
            bookingId = bk.id,
            packageId = bk.packageId,
            packageTitle = bk.packageTitle,
            amount = adjustmentAmount,
            currency = "INR",
            method = PaymentGatewayMethod.CASH,
            status = TransactionStatus.CASH_RECORDED,
            type = TransactionType.CASH_ADJUSTMENT,
            payerId = bk.customerId,
            payerName = bk.customerName,
            payerPhone = bk.customerPhone,
            payerEmail = bk.customerEmail,
            receiverId = operator.id,
            receiverName = operator.fullName,
            isAdjustment = true,
            adjustmentReason = reason,
            originalTransactionId = originalTxnId,
            notes = "Adjustment: $reason (Ref original: $originalTxnId)",
            commissionRate = commRate,
            platformCommission = commAmt,
            operatorNetEarnings = netOp,
            recordedByUid = operator.id,
            recordedByName = operator.fullName,
            recordedByRole = operator.role,
            timestamp = System.currentTimeMillis(),
            formattedDate = dateFmt.format(now),
            formattedTime = timeFmt.format(now)
        )

        // Append adjustment to audit ledger (Never rewrite historical transactions)
        transactions.value = listOf(adjTxn) + transactions.value

        // Update booking totals
        val newPaid = (bk.paidAmount + adjustmentAmount).coerceAtLeast(0.0)
        val isFull = newPaid >= bk.totalAmount
        val updatedBooking = bk.copy(
            paidAmount = newPaid,
            bookingStatus = if (isFull) BookingStatus.CONFIRMED else if (newPaid > 0) BookingStatus.PARTIALLY_PAID else BookingStatus.PENDING,
            paymentStatus = if (isFull) PaymentStatus.PAID else if (newPaid > 0) PaymentStatus.PARTIALLY_PAID else PaymentStatus.PENDING,
            updatedAt = System.currentTimeMillis()
        )
        bookings.value = bookings.value.map { if (it.id == bk.id) updatedBooking else it }

        // Notify customer
        val custNotif = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = bk.customerId,
            title = "Cash Ledger Adjusted: ₹$adjustmentAmount",
            message = "A cash adjustment of ₹$adjustmentAmount was recorded for booking ${bk.id}. Reason: $reason.",
            type = NotificationType.SYSTEM_NOTICE,
            bookingId = bk.id,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notifications.value = listOf(custNotif) + notifications.value

        return Result.success(adjTxn)
    }

    override suspend fun requestRefund(
        bookingId: String,
        transactionId: String,
        amount: Double,
        reason: String,
        requester: UserProfile
    ): Result<RefundRecord> {
        val bk = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        if (amount <= 0.0 || amount > bk.paidAmount) {
            return Result.failure(IllegalArgumentException("Refund amount must be between ₹1 and total paid (₹${bk.paidAmount})."))
        }

        val refundId = "REF_SUN_${UUID.randomUUID().toString().take(8).uppercase()}"

        val refund = RefundRecord(
            refundId = refundId,
            bookingId = bk.id,
            transactionId = transactionId,
            packageTitle = bk.packageTitle,
            customerId = bk.customerId,
            customerName = bk.customerName,
            operatorId = bk.operatorId,
            operatorName = bk.operatorName,
            amount = amount,
            reason = reason.ifBlank { "Customer requested safari cancellation/refund." },
            status = RefundStatus.REQUESTED,
            initiatedByUid = requester.id,
            initiatedByName = requester.fullName,
            initiatedByRole = requester.role,
            createdAt = System.currentTimeMillis()
        )

        refundRecords.value = listOf(refund) + refundRecords.value

        // Notify Admin & Operator
        val adminNotif = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = "ALL",
            title = "New Refund Request: ₹$amount ($refundId)",
            message = "${requester.fullName} requested a refund of ₹$amount for booking ${bk.id}. Reason: ${refund.reason}",
            type = NotificationType.REFUND_REQUESTED,
            bookingId = bk.id,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notifications.value = listOf(adminNotif) + notifications.value

        return Result.success(refund)
    }

    override suspend fun processRefund(
        refundId: String,
        approve: Boolean,
        admin: UserProfile,
        rejectionReason: String?
    ): Result<RefundRecord> {
        val record = refundRecords.value.firstOrNull { it.refundId == refundId }
            ?: return Result.failure(IllegalArgumentException("Refund request not found"))

        val bk = bookings.value.firstOrNull { it.id == record.bookingId }
            ?: return Result.failure(IllegalArgumentException("Associated booking not found"))

        if (approve) {
            val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
            val now = Date()

            val updatedRecord = record.copy(
                status = RefundStatus.COMPLETED,
                completedByUid = admin.id,
                completedByName = admin.fullName,
                gatewayRefundRef = "rfnd_gw_${UUID.randomUUID().toString().take(10).uppercase()}",
                completedAt = System.currentTimeMillis()
            )

            refundRecords.value = refundRecords.value.map { if (it.refundId == refundId) updatedRecord else it }

            // Create refund transaction in ledger
            val refundTxn = PaymentTransaction(
                transactionId = "TXN_REF_${SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(now)}_${UUID.randomUUID().toString().take(6).uppercase()}",
                bookingId = bk.id,
                packageId = bk.packageId,
                packageTitle = bk.packageTitle,
                amount = record.amount,
                currency = "INR",
                method = PaymentGatewayMethod.BANK_TRANSFER,
                status = TransactionStatus.REFUNDED,
                type = TransactionType.REFUND_PAYOUT,
                payerId = "SUNDARBAN_GATEWAY_ESCROW",
                payerName = "Sundarban Gateway Payout",
                payerPhone = "",
                payerEmail = "billing@sundarban.gov.in",
                receiverId = record.customerId,
                receiverName = record.customerName,
                notes = "Refund disbursed: ${record.reason} (Ref: ${updatedRecord.gatewayRefundRef})",
                recordedByUid = admin.id,
                recordedByName = admin.fullName,
                recordedByRole = admin.role,
                timestamp = System.currentTimeMillis(),
                formattedDate = dateFmt.format(now),
                formattedTime = timeFmt.format(now)
            )

            transactions.value = listOf(refundTxn) + transactions.value

            // Update booking status
            val newPaid = (bk.paidAmount - record.amount).coerceAtLeast(0.0)
            val updatedBooking = bk.copy(
                paidAmount = newPaid,
                paymentStatus = if (newPaid <= 0.0) PaymentStatus.REFUNDED else PaymentStatus.PARTIALLY_PAID,
                bookingStatus = if (newPaid <= 0.0) BookingStatus.CANCELLED else bk.bookingStatus,
                statusTimeline = bk.statusTimeline + BookingStatusHistory(
                    previousStatus = bk.bookingStatus,
                    newStatus = if (newPaid <= 0.0) BookingStatus.CANCELLED else bk.bookingStatus,
                    changedByUid = admin.id,
                    changedByName = admin.fullName,
                    changedByRole = UserRole.ADMIN,
                    timestamp = System.currentTimeMillis(),
                    reason = "Refund of ₹${record.amount} approved and disbursed to source account."
                ),
                updatedAt = System.currentTimeMillis()
            )
            bookings.value = bookings.value.map { if (it.id == bk.id) updatedBooking else it }

            // Notify customer
            val custNotif = AppNotification(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                recipientUserId = record.customerId,
                title = "Refund Processed: ₹${record.amount}",
                message = "Your refund of ₹${record.amount} for booking ${bk.id} has been disbursed to your source payment method (Ref: ${updatedRecord.gatewayRefundRef}).",
                type = NotificationType.REFUND_PROCESSED,
                bookingId = bk.id,
                timestamp = System.currentTimeMillis(),
                isRead = false
            )

            // Notify operator
            val opNotif = AppNotification(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                recipientUserId = record.operatorId,
                title = "Refund Processed: ${bk.id}",
                message = "A refund of ₹${record.amount} was processed for ${bk.packageTitle}.",
                type = NotificationType.REFUND_PROCESSED,
                bookingId = bk.id,
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
            notifications.value = listOf(custNotif, opNotif) + notifications.value

            return Result.success(updatedRecord)
        } else {
            val updatedRecord = record.copy(
                status = RefundStatus.REJECTED,
                completedByUid = admin.id,
                completedByName = admin.fullName,
                rejectionReason = rejectionReason ?: "Does not meet cancellation policy criteria.",
                completedAt = System.currentTimeMillis()
            )
            refundRecords.value = refundRecords.value.map { if (it.refundId == refundId) updatedRecord else it }

            val custNotif = AppNotification(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                recipientUserId = record.customerId,
                title = "Refund Request Declined",
                message = "Your refund request for ${bk.id} was not approved. Reason: ${updatedRecord.rejectionReason}.",
                type = NotificationType.SYSTEM_NOTICE,
                bookingId = bk.id,
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
            notifications.value = listOf(custNotif) + notifications.value

            return Result.success(updatedRecord)
        }
    }

    override fun getPayoutDestinationForOperator(operatorId: String): Flow<PayoutDestination?> {
        return operatorPayoutDestinations.map { it[operatorId] }
    }

    override suspend fun saveOperatorPayoutDestination(
        destination: PayoutDestination,
        operator: UserProfile
    ): Result<PayoutDestination> {
        if (destination.type == PayoutType.UPI) {
            if (!SecurityManager.validateUpiId(destination.upiId)) {
                return Result.failure(IllegalArgumentException("Invalid UPI ID format. Example: mobile@upi or username@bank."))
            }
        } else {
            val (valid, err) = SecurityManager.validateBankAccount(destination.accountNumberMasked, destination.ifscCode)
            if (!valid && err != null) {
                return Result.failure(IllegalArgumentException(err))
            }
        }

        val verifiedDestination = destination.copy(
            isVerified = true,
            verifiedAt = System.currentTimeMillis(),
            verificationReference = "NPCI_SYS_MATCH_${UUID.randomUUID().toString().take(6).uppercase()}"
        )

        val updatedMap = operatorPayoutDestinations.value.toMutableMap()
        updatedMap[operator.id] = verifiedDestination
        operatorPayoutDestinations.value = updatedMap

        val currentOp = operator.operatorDetails
        if (currentOp != null) {
            val updatedOp = currentOp.copy(
                bankUpiId = if (destination.type == PayoutType.UPI) destination.upiId else currentOp.bankUpiId,
                bankAccountName = destination.beneficiaryName,
                bankAccountNumberMasked = destination.accountNumberMasked,
                bankIfscCode = destination.ifscCode,
                bankName = destination.bankName,
                isPayoutDetailsVerified = true,
                payoutVerifiedAt = System.currentTimeMillis(),
                payoutVerificationMethod = "Automated Bank Account & IFSC Format Validation"
            )
            val updatedProfile = operator.copy(operatorDetails = updatedOp)
            authRepository?.updateProfile(updatedProfile)
        }

        val notif = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = operator.id,
            title = "Payout Destination Verified",
            message = "Your payout account (${verifiedDestination.displaySummary}) has been verified. You can now receive automated package disbursements.",
            type = NotificationType.SYSTEM_NOTICE,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notifications.value = listOf(notif) + notifications.value

        return Result.success(verifiedDestination)
    }

    override suspend fun verifyOperatorPayoutDestination(
        operatorId: String,
        adminUser: UserProfile
    ): Result<Unit> {
        if (adminUser.role != UserRole.ADMIN) return Result.failure(IllegalStateException("Unauthorized"))
        val current = operatorPayoutDestinations.value[operatorId]
            ?: return Result.failure(IllegalArgumentException("Payout destination not found for operator."))

        val updated = current.copy(
            isVerified = true,
            verifiedAt = System.currentTimeMillis(),
            verificationReference = "ADMIN_VERIFIED_${adminUser.id}"
        )
        val updatedMap = operatorPayoutDestinations.value.toMutableMap()
        updatedMap[operatorId] = updated
        operatorPayoutDestinations.value = updatedMap
        return Result.success(Unit)
    }

    override fun getSuspiciousPaymentAlerts(): Flow<List<PaymentRiskAlert>> = paymentRiskAlerts.asStateFlow()

    override suspend fun resolvePaymentRiskAlert(
        alertId: String,
        resolutionNotes: String,
        adminUser: UserProfile
    ): Result<Unit> {
        if (adminUser.role != UserRole.ADMIN) return Result.failure(IllegalStateException("Unauthorized"))
        paymentRiskAlerts.value = paymentRiskAlerts.value.map {
            if (it.id == alertId) it.copy(isResolved = true, resolutionNotes = resolutionNotes) else it
        }
        return Result.success(Unit)
    }

    // Reviews & Ratings (Part 5)
    override fun getReviewsForOperator(operatorId: String): Flow<List<Review>> {
        return MutableStateFlow(reviews.value.filter { it.operatorId == operatorId && !it.isModerated }).asStateFlow()
    }

    override fun getReviewsForPackage(packageId: String): Flow<List<Review>> {
        return MutableStateFlow(reviews.value.filter { it.packageId == packageId && !it.isModerated }).asStateFlow()
    }

    override fun getAllReviewsForAdmin(): Flow<List<Review>> = reviews.asStateFlow()

    override suspend fun addReview(review: Review, user: UserProfile): Result<Review> {
        // Validation: Must be completed booking
        val bk = bookings.value.firstOrNull { it.id == review.bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking record not found for this review."))

        if (bk.bookingStatus != BookingStatus.COMPLETED) {
            return Result.failure(IllegalStateException("Reviews can only be submitted after the tour is marked COMPLETED."))
        }

        if (bk.customerId != user.id) {
            return Result.failure(IllegalStateException("Only the registered tourist who completed this booking can submit a review."))
        }

        // Duplicate review prevention
        val alreadyReviewed = reviews.value.any { it.bookingId == review.bookingId }
        if (alreadyReviewed) {
            return Result.failure(IllegalStateException("A review has already been submitted for this booking."))
        }

        val clampedRating = review.rating.coerceIn(1, 5)
        val newReview = review.copy(
            id = "rev_" + UUID.randomUUID().toString().take(8),
            packageId = bk.packageId,
            packageTitle = bk.packageTitle,
            operatorId = bk.operatorId,
            customerId = user.id,
            customerName = user.fullName,
            rating = clampedRating,
            createdAt = System.currentTimeMillis()
        )
        reviews.value = listOf(newReview) + reviews.value

        // Update package rating average
        val pkgReviews = reviews.value.filter { it.packageId == bk.packageId && !it.isModerated }
        val avg = if (pkgReviews.isNotEmpty()) pkgReviews.map { it.rating }.average() else clampedRating.toDouble()
        packages.value = packages.value.map {
            if (it.id == bk.packageId) it.copy(rating = Math.round(avg * 10.0) / 10.0, reviewCount = pkgReviews.size) else it
        }

        return Result.success(newReview)
    }

    override suspend fun moderateReview(
        reviewId: String,
        isModerated: Boolean,
        reason: String?,
        adminUser: UserProfile
    ): Result<Unit> {
        if (adminUser.role != UserRole.ADMIN) {
            return Result.failure(IllegalStateException("Unauthorized: Only Admins can moderate reviews."))
        }
        val rev = reviews.value.firstOrNull { it.id == reviewId }
            ?: return Result.failure(IllegalArgumentException("Review not found"))

        reviews.value = reviews.value.map {
            if (it.id == reviewId) it.copy(isModerated = isModerated, moderationReason = reason) else it
        }

        recordAuditLog(
            AuditLogEntry(
                adminId = adminUser.id,
                adminName = adminUser.fullName,
                action = AuditAction.REVIEW_MODERATED,
                targetId = reviewId,
                targetType = "Review",
                previousValue = "isModerated=${rev.isModerated}",
                newValue = "isModerated=$isModerated",
                reason = reason ?: "Administrative review moderation"
            )
        )
        return Result.success(Unit)
    }

    // Complaints System (Part 5)
    override fun getComplaints(): Flow<List<Complaint>> = complaints.asStateFlow()

    override fun getComplaintsForUser(userId: String): Flow<List<Complaint>> {
        return MutableStateFlow(complaints.value.filter { it.complainantId == userId || it.targetId == userId }).asStateFlow()
    }

    override suspend fun fileComplaint(complaint: Complaint, complainantUser: UserProfile): Result<Complaint> {
        val dateFormat = SimpleDateFormat("yyyyMMdd", Locale.US)
        val dateStr = dateFormat.format(Date())
        val randomSuffix = (1000..9999).random().toString()
        val generatedComplaintId = "CMP_${dateStr}_$randomSuffix"

        val newComplaint = complaint.copy(
            id = "cmp_" + UUID.randomUUID().toString().take(8),
            complaintId = generatedComplaintId,
            complainantId = complainantUser.id,
            complainantName = complainantUser.fullName,
            complainantRole = complainantUser.role,
            status = ComplaintStatus.OPEN,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        complaints.value = listOf(newComplaint) + complaints.value

        // Notify Target
        if (newComplaint.targetId.isNotBlank()) {
            val targetNotif = AppNotification(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                recipientUserId = newComplaint.targetId,
                title = "Complaint Filed: ${newComplaint.complaintId}",
                message = "A complaint regarding '${newComplaint.category.displayName}' has been filed by ${complainantUser.fullName}.",
                type = NotificationType.SYSTEM_NOTICE,
                bookingId = newComplaint.bookingId,
                timestamp = System.currentTimeMillis()
            )
            notifications.value = listOf(targetNotif) + notifications.value
        }

        // Notify Admin
        val adminNotif = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = "ALL",
            title = "New ${newComplaint.category.displayName} Filed",
            message = "${complainantUser.fullName} filed complaint ${newComplaint.complaintId} against ${newComplaint.targetName}.",
            type = NotificationType.SYSTEM_NOTICE,
            bookingId = newComplaint.bookingId,
            timestamp = System.currentTimeMillis()
        )
        notifications.value = listOf(adminNotif) + notifications.value

        return Result.success(newComplaint)
    }

    override suspend fun investigateComplaint(
        complaintId: String,
        adminNotes: String,
        adminUser: UserProfile
    ): Result<Unit> {
        if (adminUser.role != UserRole.ADMIN) {
            return Result.failure(IllegalStateException("Unauthorized"))
        }
        complaints.value = complaints.value.map {
            if (it.id == complaintId || it.complaintId == complaintId) {
                it.copy(
                    status = ComplaintStatus.UNDER_REVIEW,
                    adminNotes = adminNotes,
                    updatedAt = System.currentTimeMillis()
                )
            } else it
        }

        recordAuditLog(
            AuditLogEntry(
                adminId = adminUser.id,
                adminName = adminUser.fullName,
                action = AuditAction.COMPLAINT_INVESTIGATED,
                targetId = complaintId,
                targetType = "Complaint",
                previousValue = "OPEN",
                newValue = "UNDER_REVIEW",
                reason = adminNotes
            )
        )
        return Result.success(Unit)
    }

    override suspend fun requestComplaintEvidence(
        complaintId: String,
        instructions: String,
        adminUser: UserProfile
    ): Result<Unit> {
        val cmp = complaints.value.firstOrNull { it.id == complaintId || it.complaintId == complaintId }
            ?: return Result.failure(IllegalArgumentException("Complaint not found"))

        complaints.value = complaints.value.map {
            if (it.id == cmp.id) it.copy(evidenceRequested = instructions, updatedAt = System.currentTimeMillis()) else it
        }

        // Notify complainant
        val notif = AppNotification(
            id = "notif_" + UUID.randomUUID().toString().take(8),
            recipientUserId = cmp.complainantId,
            title = "Admin Requested Evidence for ${cmp.complaintId}",
            message = "Admin Directorate has requested additional evidence: $instructions",
            type = NotificationType.SYSTEM_NOTICE,
            bookingId = cmp.bookingId,
            timestamp = System.currentTimeMillis()
        )
        notifications.value = listOf(notif) + notifications.value
        return Result.success(Unit)
    }

    override suspend fun resolveComplaint(
        complaintId: String,
        resolution: String,
        adminUser: UserProfile
    ): Result<Unit> {
        val cmp = complaints.value.firstOrNull { it.id == complaintId || it.complaintId == complaintId }
            ?: return Result.failure(IllegalArgumentException("Complaint not found"))

        complaints.value = complaints.value.map {
            if (it.id == cmp.id) {
                it.copy(
                    status = ComplaintStatus.RESOLVED,
                    resolutionNote = resolution,
                    updatedAt = System.currentTimeMillis()
                )
            } else it
        }

        recordAuditLog(
            AuditLogEntry(
                adminId = adminUser.id,
                adminName = adminUser.fullName,
                action = AuditAction.COMPLAINT_RESOLVED,
                targetId = cmp.complaintId,
                targetType = "Complaint",
                previousValue = cmp.status.name,
                newValue = "RESOLVED",
                reason = resolution
            )
        )

        // Notify Complainant & Target
        listOf(cmp.complainantId, cmp.targetId).filter { it.isNotBlank() }.forEach { uid ->
            notifications.value = listOf(
                AppNotification(
                    id = "notif_" + UUID.randomUUID().toString().take(8),
                    recipientUserId = uid,
                    title = "Complaint Resolved: ${cmp.complaintId}",
                    message = "Admin Directorate resolved this complaint: $resolution",
                    type = NotificationType.SYSTEM_NOTICE,
                    bookingId = cmp.bookingId,
                    timestamp = System.currentTimeMillis()
                )
            ) + notifications.value
        }

        return Result.success(Unit)
    }

    override suspend fun rejectComplaint(
        complaintId: String,
        rejectionReason: String,
        adminUser: UserProfile
    ): Result<Unit> {
        val cmp = complaints.value.firstOrNull { it.id == complaintId || it.complaintId == complaintId }
            ?: return Result.failure(IllegalArgumentException("Complaint not found"))

        complaints.value = complaints.value.map {
            if (it.id == cmp.id) {
                it.copy(
                    status = ComplaintStatus.REJECTED,
                    rejectionReason = rejectionReason,
                    updatedAt = System.currentTimeMillis()
                )
            } else it
        }

        recordAuditLog(
            AuditLogEntry(
                adminId = adminUser.id,
                adminName = adminUser.fullName,
                action = AuditAction.COMPLAINT_REJECTED,
                targetId = cmp.complaintId,
                targetType = "Complaint",
                previousValue = cmp.status.name,
                newValue = "REJECTED",
                reason = rejectionReason
            )
        )
        return Result.success(Unit)
    }

    // Dispute System (Part 5)
    override fun getDisputes(): Flow<List<DisputeRecord>> = disputes.asStateFlow()

    override fun getDisputesForUser(userId: String): Flow<List<DisputeRecord>> {
        return MutableStateFlow(disputes.value.filter { it.customerId == userId || it.operatorId == userId }).asStateFlow()
    }

    override fun getDisputeById(disputeId: String): DisputeRecord? {
        return disputes.value.firstOrNull { it.disputeId == disputeId }
    }

    override suspend fun openFormalDispute(
        bookingId: String,
        complaintId: String?,
        reason: String,
        evidenceUrls: List<String>,
        requester: UserProfile
    ): Result<DisputeRecord> {
        val bk = bookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalArgumentException("Booking not found"))

        val dateFormat = SimpleDateFormat("yyyyMMdd", Locale.US)
        val dateStr = dateFormat.format(Date())
        val randomSuffix = (1000..9999).random().toString()
        val generatedDisputeId = "DSP_${dateStr}_$randomSuffix"

        val initialMsg = DisputeMessage(
            id = "msg_init_" + UUID.randomUUID().toString().take(6),
            senderId = requester.id,
            senderName = requester.fullName,
            senderRole = requester.role,
            message = "Formal dispute initiated: $reason",
            timestamp = System.currentTimeMillis()
        )

        val newDispute = DisputeRecord(
            disputeId = generatedDisputeId,
            bookingId = bk.id,
            packageTitle = bk.packageTitle,
            customerId = bk.customerId,
            customerName = bk.customerName,
            customerPhone = bk.customerPhone,
            customerEmail = bk.customerEmail,
            operatorId = bk.operatorId,
            operatorName = bk.operatorName,
            operatorPhone = bk.operatorPhone,
            totalBookingAmount = bk.totalAmount,
            paidAmount = bk.paidAmount,
            transactionIds = transactions.value.filter { it.bookingId == bk.id }.map { it.transactionId },
            complaintId = complaintId,
            disputeReason = reason,
            evidenceUrls = evidenceUrls,
            messages = listOf(initialMsg),
            adminNotes = "Dispute opened by ${requester.fullName} (${requester.role.name}).",
            status = DisputeStatus.OPEN,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        disputes.value = listOf(newDispute) + disputes.value

        // Notify the counterparty and Admin
        val counterpartyId = if (requester.id == bk.customerId) bk.operatorId else bk.customerId
        notifications.value = listOf(
            AppNotification(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                recipientUserId = counterpartyId,
                title = "Formal Dispute Opened: $generatedDisputeId",
                message = "${requester.fullName} opened a formal dispute for Booking ${bk.id}.",
                type = NotificationType.SYSTEM_NOTICE,
                bookingId = bk.id,
                timestamp = System.currentTimeMillis()
            )
        ) + notifications.value

        return Result.success(newDispute)
    }

    override suspend fun addDisputeMessage(
        disputeId: String,
        message: String,
        attachmentUrl: String?,
        sender: UserProfile
    ): Result<DisputeRecord> {
        val disp = disputes.value.firstOrNull { it.disputeId == disputeId }
            ?: return Result.failure(IllegalArgumentException("Dispute not found"))

        val newMsg = DisputeMessage(
            id = "msg_" + UUID.randomUUID().toString().take(6),
            senderId = sender.id,
            senderName = sender.fullName,
            senderRole = sender.role,
            message = message,
            attachmentUrl = attachmentUrl,
            timestamp = System.currentTimeMillis()
        )

        val updated = disp.copy(
            messages = disp.messages + newMsg,
            updatedAt = System.currentTimeMillis()
        )
        disputes.value = disputes.value.map { if (it.disputeId == disputeId) updated else it }
        return Result.success(updated)
    }

    override suspend fun requestDisputeEvidence(
        disputeId: String,
        instructions: String,
        adminUser: UserProfile
    ): Result<Unit> {
        val disp = disputes.value.firstOrNull { it.disputeId == disputeId }
            ?: return Result.failure(IllegalArgumentException("Dispute not found"))

        val adminMsg = DisputeMessage(
            id = "msg_admin_" + UUID.randomUUID().toString().take(6),
            senderId = adminUser.id,
            senderName = "Admin Directorate",
            senderRole = UserRole.ADMIN,
            message = "⚠️ ADMIN EVIDENCE REQUEST: $instructions",
            timestamp = System.currentTimeMillis()
        )

        val updated = disp.copy(
            status = DisputeStatus.EVIDENCE_REQUESTED,
            requestedEvidenceDetails = instructions,
            messages = disp.messages + adminMsg,
            updatedAt = System.currentTimeMillis()
        )
        disputes.value = disputes.value.map { if (it.disputeId == disputeId) updated else it }
        return Result.success(Unit)
    }

    override suspend fun adjudicateDispute(
        disputeId: String,
        decision: DisputeStatus,
        refundDecision: RefundDecisionType,
        refundAmount: Double,
        decisionSummary: String,
        adminUser: UserProfile
    ): Result<DisputeRecord> {
        if (adminUser.role != UserRole.ADMIN) {
            return Result.failure(IllegalStateException("Unauthorized"))
        }
        val disp = disputes.value.firstOrNull { it.disputeId == disputeId }
            ?: return Result.failure(IllegalArgumentException("Dispute not found"))

        val adminMsg = DisputeMessage(
            id = "msg_dec_" + UUID.randomUUID().toString().take(6),
            senderId = adminUser.id,
            senderName = "Admin Directorate",
            senderRole = UserRole.ADMIN,
            message = "⚖️ FINAL ADJUDICATION: ${decision.displayName}. Refund Ruling: ${refundDecision.displayName} (₹$refundAmount). Summary: $decisionSummary",
            timestamp = System.currentTimeMillis()
        )

        val updated = disp.copy(
            status = decision,
            refundDecision = refundDecision,
            refundAmount = refundAmount,
            decisionSummary = decisionSummary,
            decidedByUid = adminUser.id,
            decidedByName = adminUser.fullName,
            decidedAt = System.currentTimeMillis(),
            messages = disp.messages + adminMsg,
            updatedAt = System.currentTimeMillis()
        )
        disputes.value = disputes.value.map { if (it.disputeId == disputeId) updated else it }

        // Execute financial refund if ordered
        if (refundDecision == RefundDecisionType.FULL_REFUND || refundDecision == RefundDecisionType.PARTIAL_REFUND) {
            val bk = bookings.value.firstOrNull { it.id == disp.bookingId }
            if (bk != null) {
                val effectiveRefund = if (refundDecision == RefundDecisionType.FULL_REFUND) disp.paidAmount else refundAmount
                val refundRecord = RefundRecord(
                    refundId = "REF_DSP_${UUID.randomUUID().toString().take(8).uppercase()}",
                    bookingId = bk.id,
                    packageTitle = bk.packageTitle,
                    customerId = bk.customerId,
                    customerName = bk.customerName,
                    operatorId = bk.operatorId,
                    operatorName = bk.operatorName,
                    amount = effectiveRefund,
                    reason = "Adjudicated by Admin in Dispute ${disp.disputeId}: $decisionSummary",
                    status = RefundStatus.COMPLETED,
                    initiatedByUid = adminUser.id,
                    initiatedByName = adminUser.fullName,
                    initiatedByRole = UserRole.ADMIN,
                    completedByUid = adminUser.id,
                    completedByName = adminUser.fullName,
                    completedAt = System.currentTimeMillis()
                )
                refundRecords.value = listOf(refundRecord) + refundRecords.value

                val refundTxn = PaymentTransaction(
                    transactionId = "TXN_REF_${disp.disputeId}",
                    bookingId = bk.id,
                    packageTitle = bk.packageTitle,
                    amount = effectiveRefund,
                    type = TransactionType.REFUND_PAYOUT,
                    method = PaymentGatewayMethod.UPI,
                    status = TransactionStatus.SUCCESS,
                    notes = "Adjudicated dispute refund for ${disp.disputeId}",
                    recordedByUid = adminUser.id,
                    recordedByName = adminUser.fullName,
                    recordedByRole = UserRole.ADMIN
                )
                transactions.value = listOf(refundTxn) + transactions.value
            }
        }

        recordAuditLog(
            AuditLogEntry(
                adminId = adminUser.id,
                adminName = adminUser.fullName,
                action = AuditAction.DISPUTE_DECIDED,
                targetId = disp.disputeId,
                targetType = "DisputeRecord",
                previousValue = disp.status.name,
                newValue = decision.name,
                reason = "Ruling: ${refundDecision.displayName}, Amount: ₹$refundAmount. $decisionSummary"
            )
        )

        return Result.success(updated)
    }

    // Fraud & Risk Monitoring (Part 5)
    override fun getFlaggedRiskCases(): Flow<List<FlaggedRiskCase>> {
        // Dynamically evaluate all users against live repository state
        val users = authRepository?.getAllUsersForAdmin()
        // If authRepository is injected or fallback, evaluate
        return flaggedRiskCases.asStateFlow()
    }

    override fun getAdminAlerts(): Flow<List<AdminAlert>> = adminAlerts.asStateFlow()

    override suspend fun reviewRiskCase(
        caseId: String,
        notes: String,
        adminUser: UserProfile
    ): Result<Unit> {
        flaggedRiskCases.value = flaggedRiskCases.value.map {
            if (it.caseId == caseId) it.copy(adminReviewed = true, reviewNotes = notes) else it
        }
        return Result.success(Unit)
    }

    override suspend fun acknowledgeAlert(alertId: String): Result<Unit> {
        adminAlerts.value = adminAlerts.value.map {
            if (it.id == alertId) it.copy(isAcknowledged = true) else it
        }
        return Result.success(Unit)
    }

    // Audit Log (Part 5)
    override fun getAuditLogs(): Flow<List<AuditLogEntry>> = auditLogs.asStateFlow()

    override suspend fun recordAuditLog(entry: AuditLogEntry): Result<Unit> {
        auditLogs.value = listOf(entry) + auditLogs.value
        return Result.success(Unit)
    }

    // Platform Settings
    override suspend fun updatePlatformSettings(settings: PlatformSettings): Result<Unit> {
        _platformSettings.value = settings
        return Result.success(Unit)
    }

    override suspend fun togglePublicOperatorPhone(allow: Boolean): Result<Unit> {
        _platformSettings.value = _platformSettings.value.copy(allowPublicOperatorPhone = allow)
        return Result.success(Unit)
    }

    // Notifications
    override fun getNotificationsForUser(userId: String): Flow<List<AppNotification>> {
        return MutableStateFlow(
            notifications.value.filter { it.recipientUserId == userId || it.recipientUserId == "ALL" }
        ).asStateFlow()
    }

    override suspend fun markNotificationAsRead(notificationId: String): Result<Unit> {
        notifications.value = notifications.value.map {
            if (it.id == notificationId) it.copy(isRead = true) else it
        }
        return Result.success(Unit)
    }

    override suspend fun markAllNotificationsAsRead(userId: String): Result<Unit> {
        notifications.value = notifications.value.map {
            if (it.recipientUserId == userId || it.recipientUserId == "ALL") it.copy(isRead = true) else it
        }
        return Result.success(Unit)
    }

    override suspend fun sendNotification(notification: AppNotification): Result<AppNotification> {
        val newNotif = notification.copy(id = "notif_" + UUID.randomUUID().toString().take(8))
        notifications.value = listOf(newNotif) + notifications.value
        return Result.success(newNotif)
    }
}
