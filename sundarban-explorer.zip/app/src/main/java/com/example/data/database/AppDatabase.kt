package com.example.data.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cached_users")
data class CachedUserEntity(
    @PrimaryKey val id: String,
    val email: String,
    val fullName: String,
    val phoneNumber: String,
    val role: String,
    val address: String,
    val isVerified: Boolean,
    val profilePhotoUrl: String?,
    val emergencyContactName: String,
    val emergencyContactPhone: String,
    val emergencyContactRelation: String,
    val operatingArea: String = "",
    val yearsOfExperience: Int = 0,
    val guideExperience: String = "",
    val govIdType: String = "",
    val govIdNumber: String = "",
    val licenseNumber: String = "",
    val boatRegistrationNumber: String = "",
    val bankUpiId: String = "",
    val verificationStatus: String = "PENDING_VERIFICATION",
    val preferredLanguage: String = "en",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_packages")
data class CachedPackageEntity(
    @PrimaryKey val id: String,
    val operatorId: String,
    val operatorName: String,
    val operatorPhone: String = "",
    val isOperatorVerified: Boolean,
    val title: String,
    val description: String,
    val durationText: String = "",
    val startingLocation: String = "",
    val route: String = "",
    val destination: String = "",
    val durationDays: Int,
    val durationNights: Int,
    val maxTourists: Int = 15,
    val price: Double,
    val pricePerPerson: Double,
    val boatDetails: String = "",
    val foodDetails: String = "",
    val accommodationDetails: String = "",
    val guideDetails: String = "",
    val permitInfo: String = "",
    val pickupInfo: String = "",
    val cancellationPolicy: String = "",
    val importantInstructions: String = "",
    val status: String = "PUBLISHED",
    val rating: Double,
    val reviewCount: Int,
    val imageUrl: String?,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_bookings")
data class CachedBookingEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val customerName: String,
    val customerPhone: String,
    val customerEmail: String = "",
    val operatorId: String,
    val operatorName: String,
    val operatorPhone: String = "",
    val packageId: String,
    val packageTitle: String,
    val numberOfTourists: Int,
    val travelDate: String,
    val returnDate: String = "",
    val pickupLocation: String = "",
    val specialRequirements: String = "",
    val emergencyContactName: String,
    val emergencyContactPhone: String,
    val emergencyContactRelation: String = "",
    val notes: String = "",
    val totalAmount: Double,
    val paidAmount: Double = 0.0,
    val paymentMethod: String,
    val paymentStatus: String,
    val bookingStatus: String,
    val cancellationReason: String? = null,
    val disputeReason: String? = null,
    val createdAt: Long,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_notifications")
data class CachedNotificationEntity(
    @PrimaryKey val id: String,
    val recipientUserId: String,
    val title: String,
    val message: String,
    val type: String,
    val bookingId: String?,
    val timestamp: Long,
    val isRead: Boolean
)

@Dao
interface UserDao {
    @Query("SELECT * FROM cached_users WHERE id = :userId LIMIT 1")
    fun getUserById(userId: String): Flow<CachedUserEntity?>

    @Query("SELECT * FROM cached_users WHERE role = :role")
    fun getUsersByRole(role: String): Flow<List<CachedUserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: CachedUserEntity)

    @Query("DELETE FROM cached_users WHERE id = :userId")
    suspend fun deleteUser(userId: String)

    @Query("DELETE FROM cached_users")
    suspend fun clearUsers()
}

@Dao
interface PackageDao {
    @Query("SELECT * FROM cached_packages")
    fun getAllPackages(): Flow<List<CachedPackageEntity>>

    @Query("SELECT * FROM cached_packages WHERE id = :packageId")
    fun getPackageById(packageId: String): Flow<CachedPackageEntity?>

    @Query("SELECT * FROM cached_packages WHERE operatorId = :operatorId")
    fun getPackagesByOperator(operatorId: String): Flow<List<CachedPackageEntity>>

    @Query("SELECT * FROM cached_packages WHERE status = :status")
    fun getPackagesByStatus(status: String): Flow<List<CachedPackageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackages(packages: List<CachedPackageEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackage(pkg: CachedPackageEntity)

    @Query("DELETE FROM cached_packages WHERE id = :packageId")
    suspend fun deletePackage(packageId: String)
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM cached_bookings WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getBookingsForCustomer(customerId: String): Flow<List<CachedBookingEntity>>

    @Query("SELECT * FROM cached_bookings WHERE operatorId = :operatorId ORDER BY createdAt DESC")
    fun getBookingsForOperator(operatorId: String): Flow<List<CachedBookingEntity>>

    @Query("SELECT * FROM cached_bookings ORDER BY createdAt DESC")
    fun getAllBookings(): Flow<List<CachedBookingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: CachedBookingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookings(bookings: List<CachedBookingEntity>)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM cached_notifications WHERE recipientUserId = :userId ORDER BY timestamp DESC")
    fun getNotificationsForUser(userId: String): Flow<List<CachedNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: CachedNotificationEntity)

    @Query("UPDATE cached_notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE cached_notifications SET isRead = 1 WHERE recipientUserId = :userId")
    suspend fun markAllAsRead(userId: String)
}

@Database(
    entities = [
        CachedUserEntity::class,
        CachedPackageEntity::class,
        CachedBookingEntity::class,
        CachedNotificationEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun packageDao(): PackageDao
    abstract fun bookingDao(): BookingDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sundarban_explorer.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
