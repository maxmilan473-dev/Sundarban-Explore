package com.example.data.repositories

import com.example.core.model.EmergencyContact
import com.example.core.model.OperatorDetails
import com.example.core.model.OperatorStatus
import com.example.core.model.UserProfile
import com.example.core.model.UserRole
import com.example.core.model.VerificationDocument
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

sealed class AuthResult<out T> {
    data class Success<out T>(val data: T) : AuthResult<T>()
    data class Error(val message: String, val cause: Throwable? = null) : AuthResult<Nothing>()
    object Loading : AuthResult<Nothing>()
}

interface AuthRepository {
    val currentUser: StateFlow<UserProfile?>
    val isUserLoggedIn: Boolean

    suspend fun signIn(email: String, password: String, role: UserRole): AuthResult<UserProfile>
    
    suspend fun signUpCustomer(
        fullName: String,
        email: String,
        phoneNumber: String,
        password: String,
        address: String,
        profilePhotoUrl: String?,
        emergencyContact: EmergencyContact,
        phoneVerified: Boolean = false
    ): AuthResult<UserProfile>

    suspend fun signUpOperator(
        fullName: String,
        email: String,
        phoneNumber: String,
        password: String,
        address: String,
        profilePhotoUrl: String? = null,
        dateOfBirth: String = "",
        gender: String = "Male",
        state: String = "West Bengal",
        district: String = "South 24 Parganas",
        operatorBusinessName: String = "",
        serviceType: String = "Boat Safari & Guided Eco-Tour",
        yearsOfExperience: Int = 1,
        areasCovered: String = "Gosaba, Sajnekhali, Dobanki",
        languagesSpoken: String = "Bengali, English, Hindi",
        maxTourists: Int = 15,
        shortDescription: String = "",
        tourPackageTitle: String = "",
        tourDuration: String = "",
        tourPrice: Double = 0.0,
        tourMaxCapacity: Int = 12,
        tourAvailableDates: String = "",
        onlinePaymentAvailable: Boolean = true,
        cashPaymentAvailable: Boolean = true,
        phoneVerified: Boolean = false,
        operatingArea: String = "",
        guideExperience: String = "",
        emergencyContact: EmergencyContact = EmergencyContact(),
        govIdType: String = "Government ID",
        govIdNumber: String = "",
        licenseNumber: String = "",
        boatRegistrationNumber: String = "",
        bankUpiId: String = "",
        emailVerified: Boolean = false,
        documents: List<VerificationDocument> = emptyList()
    ): AuthResult<UserProfile>

    suspend fun sendPhoneOtp(phoneNumber: String): AuthResult<String> // Returns 6-digit OTP code for testing/entry
    suspend fun verifyPhoneOtp(phoneNumber: String, otpCode: String): AuthResult<Boolean>

    suspend fun sendEmailVerification(email: String): AuthResult<String> // Returns verification token/code
    suspend fun verifyEmailCode(email: String, code: String): AuthResult<Boolean>

    suspend fun sendPasswordResetEmail(email: String): AuthResult<Unit>
    
    // Multi-factor Password Recovery (Email or Mobile OTP)
    suspend fun checkAccountExistsForRecovery(identifier: String): AuthResult<UserRole>
    suspend fun sendPasswordResetOtp(identifier: String): AuthResult<String>
    suspend fun verifyPasswordResetOtp(identifier: String, otpCode: String): AuthResult<Boolean>
    suspend fun resetPasswordWithOtp(identifier: String, otpCode: String, newPassword: String): AuthResult<Unit>

    suspend fun changePassword(oldPassword: String, newPassword: String): AuthResult<Unit>
    suspend fun updateProfile(updatedProfile: UserProfile): AuthResult<UserProfile>
    suspend fun logout()
    suspend fun refreshCurrentUser(): UserProfile?

    fun getAllUsersForAdmin(): Flow<List<UserProfile>>
    suspend fun updateOperatorVerificationStatus(
        operatorId: String,
        status: OperatorStatus,
        adminNotes: String? = null,
        rejectionReason: String? = null,
        infoRequiredNote: String? = null
    ): AuthResult<Unit>

    suspend fun submitAdditionalInfo(
        operatorId: String,
        updatedDetails: OperatorDetails
    ): AuthResult<UserProfile>

    // Account Suspension & Moderation (Part 5)
    suspend fun warnUser(userId: String, reason: String, adminUser: UserProfile): AuthResult<UserProfile>
    suspend fun restrictUser(userId: String, reason: String, adminUser: UserProfile): AuthResult<UserProfile>
    suspend fun suspendUser(userId: String, durationDays: Int, reason: String, adminUser: UserProfile): AuthResult<UserProfile>
    suspend fun banUser(userId: String, reason: String, adminUser: UserProfile): AuthResult<UserProfile>
    suspend fun unbanUser(userId: String, reason: String, adminUser: UserProfile): AuthResult<UserProfile>
    suspend fun getUnmaskedVerificationDocuments(operatorId: String, adminUser: UserProfile): AuthResult<List<VerificationDocument>>

    // Admin ID Creation (Super Admin Only)
    suspend fun createAdminUser(
        creatorUser: UserProfile,
        fullName: String,
        email: String,
        phoneNumber: String,
        password: String,
        designation: String,
        isSuperAdmin: Boolean = false
    ): AuthResult<UserProfile>
}
