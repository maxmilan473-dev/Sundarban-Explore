package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.core.di.AppContainer
import com.example.core.di.AppContainerImpl
import com.example.navigation.AppNavigation
import com.example.ui.theme.SundarbanTheme

class MainActivity : ComponentActivity() {

    private lateinit var appContainer: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        appContainer = AppContainerImpl(applicationContext)

        setContent {
            SundarbanTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavigation(appContainer = appContainer)
                }
            }
        }
    }
}
