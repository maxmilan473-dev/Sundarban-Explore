package com.example.core.localization

enum class AppLanguage(val code: String, val nativeName: String, val englishName: String) {
    ENGLISH("en", "English", "English"),
    BENGALI("bn", "বাংলা", "Bengali"),
    HINDI("hi", "हिन्दी", "Hindi");

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: ENGLISH
        }
    }
}
