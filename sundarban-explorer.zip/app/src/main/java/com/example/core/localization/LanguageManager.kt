package com.example.core.localization

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LanguageManager private constructor(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("app_language_prefs", Context.MODE_PRIVATE)

    private val _currentLanguage = MutableStateFlow(loadInitialLanguage())
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _currentStrings = MutableStateFlow(getStringsForLanguage(_currentLanguage.value))
    val currentStrings: StateFlow<LocalizedStrings> = _currentStrings.asStateFlow()

    private fun loadInitialLanguage(): AppLanguage {
        val code = prefs.getString("selected_language_code", "en") ?: "en"
        return AppLanguage.fromCode(code)
    }

    fun setLanguage(language: AppLanguage) {
        prefs.edit().putString("selected_language_code", language.code).apply()
        _currentLanguage.value = language
        _currentStrings.value = getStringsForLanguage(language)
    }

    companion object {
        @Volatile
        private var instance: LanguageManager? = null

        fun getInstance(context: Context): LanguageManager {
            return instance ?: synchronized(this) {
                instance ?: LanguageManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
