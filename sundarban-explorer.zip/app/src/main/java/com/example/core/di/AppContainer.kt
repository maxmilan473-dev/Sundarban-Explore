package com.example.core.di

import android.content.Context
import com.example.core.analytics.AnalyticsTracker
import com.example.core.analytics.DefaultAnalyticsTracker
import com.example.core.localization.LanguageManager
import com.example.data.database.AppDatabase
import com.example.data.repositories.AuthRepository
import com.example.data.repositories.AuthRepositoryImpl
import com.example.data.repositories.ContentRepository
import com.example.data.repositories.ContentRepositoryImpl
import com.example.data.repositories.TourRepository
import com.example.data.repositories.TourRepositoryImpl

interface AppContainer {
    val authRepository: AuthRepository
    val tourRepository: TourRepository
    val contentRepository: ContentRepository
    val languageManager: LanguageManager
    val analyticsTracker: AnalyticsTracker
}

class AppContainerImpl(private val context: Context) : AppContainer {
    private val database: AppDatabase by lazy {
        AppDatabase.getDatabase(context)
    }

    override val authRepository: AuthRepository by lazy {
        AuthRepositoryImpl(context, database)
    }

    override val tourRepository: TourRepository by lazy {
        TourRepositoryImpl()
    }

    override val contentRepository: ContentRepository by lazy {
        ContentRepositoryImpl()
    }

    override val languageManager: LanguageManager by lazy {
        LanguageManager.getInstance(context)
    }

    override val analyticsTracker: AnalyticsTracker by lazy {
        DefaultAnalyticsTracker()
    }
}
