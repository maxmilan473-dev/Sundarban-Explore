package com.example.core.model

import java.util.UUID

enum class PackageStatus(val displayName: String, val isPublicVisible: Boolean = false) {
    DRAFT("Draft", false),
    PENDING_APPROVAL("Pending Approval", false),
    PUBLISHED("Published", true),
    AUTO_VERIFIED("Auto-Verified", true),
    REQUIRES_ADMIN_REVIEW("Review Required", false),
    REJECTED("Rejected", false),
    HIDDEN("Hidden", false),
    ARCHIVED("Archived", false)
}

enum class BookingStatus(val displayName: String) {
    // Core Booking Status Flow:
    PROCESSING("Processing"),
    CONFIRMED("Confirmed"),
    UPCOMING("Upcoming"),
    TOUR_IN_PROGRESS("Tour In Progress"),
    COMPLETED("Completed"),

    // Additional Statuses:
    CANCEL_REQUESTED("Cancel Requested"),
    CANCELLED("Cancelled"),
    RESCHEDULE_REQUESTED("Reschedule Requested"),
    RESCHEDULED("Rescheduled"),
    EMERGENCY_REVIEW("Emergency Review"),
    REJECTED("Rejected"),

    // Compatibility aliases
    PENDING("Processing"),
    ACCEPTED("Accepted by Operator"),
    PARTIALLY_PAID("Partially Paid"),
    PAID("Paid in Full"),
    IN_PROGRESS("Tour In Progress"),
    DISPUTED("Disputed")
}

enum class CancellationRequestStatus(val displayName: String) {
    PENDING_OTHER_PARTY("Awaiting Mutual Agreement"),
    ACCEPTED("Accepted by Both Parties"),
    REJECTED("Rejected by Other Party"),
    UNDER_ADMIN_REVIEW("Emergency Directorate Review"),
    RESOLVED_BY_ADMIN("Decided by Admin"),
    CANCELLED("Cancelled")
}

data class CancellationDiscussionMessage(
    val id: String = UUID.randomUUID().toString().take(8),
    val senderUid: String = "",
    val senderName: String = "",
    val senderRole: UserRole = UserRole.CUSTOMER,
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

enum class AdminDecisionType(val displayName: String) {
    APPROVE_CANCELLATION("Approve Cancellation"),
    REJECT_CANCELLATION("Reject Cancellation"),
    RESCHEDULE_TOUR("Reschedule Tour"),
    REASSIGN_OPERATOR("Reassign / Change Operator"),
    REQUEST_INFO("Request Additional Information")
}

enum class AdminRefundDecision(val displayName: String) {
    FULL_REFUND("Approve Full Refund"),
    PARTIAL_REFUND("Approve Partial Refund"),
    REJECT_REFUND("Reject Refund"),
    NO_REFUND("No Refund / Keep Existing")
}

data class AdminEmergencyDecision(
    val decisionId: String = "ADM_DEC_${UUID.randomUUID().toString().take(8).uppercase()}",
    val adminId: String = "",
    val adminName: String = "",
    val decisionType: AdminDecisionType = AdminDecisionType.APPROVE_CANCELLATION,
    val refundDecision: AdminRefundDecision = AdminRefundDecision.FULL_REFUND,
    val refundAmount: Double = 0.0,
    val rescheduledDate: String? = null,
    val newOperatorId: String? = null,
    val newOperatorName: String? = null,
    val reason: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class CancellationRequest(
    val requestId: String = "CAN_${UUID.randomUUID().toString().take(8).uppercase()}",
    val bookingId: String = "",
    val initiatedByUid: String = "",
    val initiatedByName: String = "",
    val initiatedByRole: UserRole = UserRole.CUSTOMER,
    val isEmergency: Boolean = false,
    val hoursRemainingAtRequest: Double = 0.0,
    val reason: String = "",
    val detailedExplanation: String? = null,
    val status: CancellationRequestStatus = CancellationRequestStatus.PENDING_OTHER_PARTY,
    val requestedAt: Long = System.currentTimeMillis(),
    val respondedAt: Long? = null,
    val respondedByUid: String? = null,
    val respondedByName: String? = null,
    val responseNotes: String? = null,
    val discussionMessages: List<CancellationDiscussionMessage> = emptyList(),
    val adminDecisions: List<AdminEmergencyDecision> = emptyList()
)

enum class PaymentStatus(val displayName: String) {
    PENDING("Pending"),
    PARTIALLY_PAID("Partially Paid"),
    PAID("Paid Online"),
    CASH_ON_ARRIVAL("Cash on Arrival"),
    REFUNDED("Refunded"),
    FAILED("Failed")
}

enum class PaymentMethod(val displayName: String) {
    ONLINE_UPI_CARD("Online (UPI / Card)"),
    CASH_ON_ARRIVAL("Cash on Arrival"),
    BANK_TRANSFER("Direct Bank Transfer")
}

data class BookingStatusHistory(
    val id: String = UUID.randomUUID().toString().take(8),
    val previousStatus: BookingStatus?,
    val newStatus: BookingStatus,
    val changedByUid: String,
    val changedByName: String,
    val changedByRole: UserRole,
    val timestamp: Long = System.currentTimeMillis(),
    val reason: String = ""
)

data class TourPackage(
    val id: String = "",
    val operatorId: String = "",
    val operatorName: String = "",
    val operatorPhone: String = "",
    val isOperatorVerified: Boolean = false,
    val title: String = "",
    val description: String = "",
    val photos: List<String> = emptyList(),
    val durationText: String = "2 Days / 1 Night",
    val startingLocation: String = "Godkhali Ferry Ghat, Canning",
    val route: String = "Godkhali -> Gosaba -> Sajnekhali -> Sudhanyakhali -> Dobanki -> Godkhali",
    val destination: String = "Sundarban Tiger Reserve & Core Mangroves",
    val destinations: List<String> = listOf("Sajnekhali", "Sudhanyakhali", "Dobanki Canopy Walk"),
    val durationDays: Int = 2,
    val durationNights: Int = 1,
    val maxTourists: Int = 15,
    val price: Double = 4500.0,
    val pricePerPerson: Double = 4500.0,
    val includedServices: List<String> = listOf(
        "Govt Forest Entry Permits",
        "Certified Naturalist Guide",
        "Traditional Bengali Meals on Boat",
        "Life Jackets & Safety Gear",
        "Twin-sharing Eco-Resort Stay"
    ),
    val excludedServices: List<String> = listOf(
        "Personal Snacks / Mineral Water",
        "Camera video fees at forest post",
        "Train / Flight fare to Canning/Godkhali"
    ),
    val boatDetails: String = "M.B. Sundarban Pride - 42ft Twin-Diesel Deluxe Motor Boat with upper viewing deck, clean western washroom, and GPS navigation",
    val foodDetails: String = "Day 1: Breakfast (Luchi/Cholar Dal), Lunch (Rice, Bhetki Fish Curry, Dal, Bhaja), Dinner (Chicken Curry/Paneer). Day 2: Morning Tea, Heavy Breakfast & Special Crab/Fish Lunch",
    val accommodationDetails: String = "Air-conditioned Eco Cottages at Pakhiralay / Dayapur with attached bath, 24-hr electricity, and river view balcony",
    val guideDetails: String = "Certified West Bengal Forest Ecotourism Naturalist and experienced Sundarban boat pilot",
    val permitInfo: String = "All mandatory National Park permits and biometric registration handled prior to launch departure",
    val pickupInfo: String = "Godkhali Ghat Meeting Point (8:30 AM) or optional Canning Station pickup (+Rs 200/person)",
    val cancellationPolicy: String = "100% refund up to 72 hours before departure. 50% refund between 24-72 hours. Non-refundable within 24 hours.",
    val availableDates: List<String> = listOf("2026-09-10", "2026-09-15", "2026-09-20", "2026-09-25", "2026-10-02", "2026-10-10"),
    val importantInstructions: String = "1. Carry original Govt ID card (mandatory for forest checkposts).\n2. Single-use plastic is strictly prohibited inside the Reserve.\n3. High-decibel audio is banned by Forest Directorate.\n4. Wear muted forest-friendly colors (khaki, green, beige).",
    val status: PackageStatus = PackageStatus.PUBLISHED,
    val isAutoVerified: Boolean = true,
    val verificationStatusText: String = "Auto-Verified",
    val riskScore: Int = 0,
    val riskSignals: List<String> = emptyList(),
    val rejectionReason: String? = null,
    val rating: Double = 4.8,
    val reviewCount: Int = 38,
    val imageUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    // Helper property for backward compatibility
    val maxGuests: Int get() = maxTourists
    val departurePoint: String get() = startingLocation
    val inclusions: List<String> get() = includedServices
    val highlights: List<String> get() = listOf(
        "Spot Royal Bengal Tigers at Sudhanyakhali",
        "360-degree mangrove views on Dobanki Canopy Walk",
        "Sunset boat safari on Panchamukhani confluence"
    )
}

data class Booking(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val customerEmail: String = "",
    val operatorId: String = "",
    val operatorName: String = "",
    val operatorPhone: String = "",
    val packageId: String = "",
    val packageTitle: String = "",
    val numberOfTourists: Int = 1,
    val travelDate: String = "",
    val returnDate: String = "",
    val pickupLocation: String = "Godkhali Ghat, Canning",
    val specialRequirements: String = "",
    val emergencyContact: EmergencyContact = EmergencyContact(),
    val notes: String = "",
    val totalAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val paymentMethod: PaymentMethod = PaymentMethod.ONLINE_UPI_CARD,
    val paymentStatus: PaymentStatus = PaymentStatus.PENDING,
    val bookingStatus: BookingStatus = BookingStatus.PENDING,
    val statusTimeline: List<BookingStatusHistory> = emptyList(),
    val cancellationReason: String? = null,
    val disputeReason: String? = null,
    val tourStartTime: String = "08:00 AM",
    val activeCancellationRequest: CancellationRequest? = null,
    val cancellationHistory: List<CancellationRequest> = emptyList(),
    val refundResolutionStatus: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    // Backward compat aliases
    val guestCount: Int get() = numberOfTourists
    val numberOfGuests: Int get() = numberOfTourists
    val tourDate: String get() = travelDate
    val specialNotes: String get() = specialRequirements
}

data class Payment(
    val id: String = "",
    val bookingId: String = "",
    val customerId: String = "",
    val operatorId: String = "",
    val amount: Double = 0.0,
    val paymentMethod: PaymentMethod = PaymentMethod.ONLINE_UPI_CARD,
    val paymentStatus: PaymentStatus = PaymentStatus.PAID,
    val transactionRef: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

enum class TransactionStatus(val displayName: String) {
    INITIATED("Initiated"),
    PENDING("Pending Gateway"),
    SUCCESS("Payment Successful"),
    PAYMENT_SUCCESSFUL("Payment Successful"),
    FAILED("Payment Failed"),
    CANCELLED("Cancelled"),
    REFUND_PENDING("Refund Pending"),
    REFUNDED("Refunded"),
    PARTIALLY_REFUNDED("Partially Refunded"),
    REFUND_REJECTED("Refund Rejected"),
    CASH_RECORDED("Cash Recorded at Ghat"),
    DISPUTED("Payment Disputed")
}

enum class TransactionType(val displayName: String) {
    ONLINE_GATEWAY("Online Gateway"),
    OFFLINE_CASH("Cash on Arrival"),
    CASH_ADJUSTMENT("Cash Adjustment (Audit)"),
    REFUND_PAYOUT("Customer Refund"),
    COMMISSION_DEDUCTION("Platform Commission")
}

enum class PaymentGatewayMethod(val displayName: String) {
    UPI("UPI (GPay / PhonePe / Paytm)"),
    CREDIT_CARD("Credit Card (Visa / Mastercard)"),
    DEBIT_CARD("Debit Card / RuPay"),
    NET_BANKING("Net Banking (SBI / HDFC / ICICI)"),
    CASH("Cash on Arrival at Ghat"),
    BANK_TRANSFER("Direct NEFT / IMPS")
}

data class PaymentTransaction(
    val transactionId: String = "TXN_${UUID.randomUUID().toString().take(10).uppercase()}",
    val bookingId: String = "",
    val packageId: String = "",
    val packageTitle: String = "",
    val amount: Double = 0.0,
    val currency: String = "INR",
    val method: PaymentGatewayMethod = PaymentGatewayMethod.UPI,
    val status: TransactionStatusDAN = TransactionStatus.SUCCESS,
    val type: TransactionType = TransactionType.ONLINE_GATEWAY,
    val payerId: String = "",
    val payerName: String = "",
    val payerPhone: String = "",
    val payerEmail: String = "",
    val receiverId: String = "",
    val receiverName: String = "",
    val gatewayOrderId: String? = null,
    val gatewayPaymentId: String? = null,
    val gatewaySignature: String? = null,
    val idempotencyKey: String = UUID.randomUUID().toString(),
    val notes: String = "",
    val cashProofUrl: String? = null,
    val cashReceiptNumber: String? = null,
    val isAdjustment: Boolean = false,
    val adjustmentReason: String? = null,
    val originalTransactionId: String? = null,
    val commissionRate: Double = 0.005,
    val commissionFixedFee: Double = 0.0,
    val platformCommission: Double = 0.0,
    val operatorNetEarnings: Double = 0.0,
    val recordedByUid: String = "",
    val recordedByName: String = "",
    val recordedByRole: UserRole = UserRole.CUSTOMER,
    val timestamp: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val formattedDate: String = "",
    val formattedTime: String = ""
)

typealias TransactionStatusDAN = TransactionStatus

data class PlatformCommissionConfig(
    val id: String = "COMMISSION_CONFIG_V1",
    val percentageCommission: Double = 0.5, // 0.5%
    val fixedFeePerBooking: Double = 0.0, // 0 INR
    val effectiveDate: String = "2026-01-01",
    val updatedAt: Long = System.currentTimeMillis(),
    val updatedBy: String = "Sundarban Admin Directorate",
    val description: String = "Standard Eco-Safari Admin Commission for Operator Directory & Safety Permitting"
)

enum class RefundStatus(val displayName: String) {
    REQUESTED("Refund Requested"),
    PROCESSING("Processing Gateway Refund"),
    COMPLETED("Refund Completed"),
    FAILED("Refund Failed"),
    REJECTED("Refund Declined")
}

data class RefundRecord(
    val refundId: String = "REF_${UUID.randomUUID().toString().take(8).uppercase()}",
    val bookingId: String = "",
    val transactionId: String = "",
    val packageTitle: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val operatorId: String = "",
    val operatorName: String = "",
    val amount: Double = 0.0,
    val reason: String = "",
    val status: RefundStatus = RefundStatus.REQUESTED,
    val initiatedByUid: String = "",
    val initiatedByName: String = "",
    val initiatedByRole: UserRole = UserRole.CUSTOMER,
    val completedByUid: String? = null,
    val completedByName: String? = null,
    val rejectionReason: String? = null,
    val gatewayRefundRef: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

data class BookingFinancialTimeline(
    val bookingId: String = "",
    val totalPackagePrice: Double = 0.0,
    val onlinePaid: Double = 0.0,
    val cashPaid: Double = 0.0,
    val totalPaid: Double = 0.0,
    val refundedAmount: Double = 0.0,
    val remainingAmount: Double = 0.0,
    val finalNetAmount: Double = 0.0,
    val transactions: List<PaymentTransaction> = emptyList(),
    val refundRecords: List<RefundRecord> = emptyList()
)

data class OperatorEarningsSummary(
    val operatorId: String = "",
    val grossBookingValue: Double = 0.0,
    val onlinePayments: Double = 0.0,
    val cashPayments: Double = 0.0,
    val pendingPayments: Double = 0.0,
    val refunds: Double = 0.0,
    val totalCommission: Double = 0.0,
    val netEarnings: Double = 0.0,
    val totalBookingsCount: Int = 0,
    val paidBookingsCount: Int = 0
)

enum class PayoutType(val displayName: String) {
    UPI("UPI ID / Virtual Payment Address"),
    BANK_ACCOUNT("Bank Account (NEFT / IMPS / RTGS)")
}

data class PayoutDestination(
    val id: String = "payout_" + UUID.randomUUID().toString().take(8),
    val operatorId: String = "",
    val type: PayoutType = PayoutType.UPI,
    val beneficiaryName: String = "",
    val upiId: String = "",
    val bankName: String = "",
    val accountNumberMasked: String = "",
    val ifscCode: String = "",
    val isVerified: Boolean = false,
    val verifiedAt: Long? = null,
    val verificationReference: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val displaySummary: String
        get() = when (type) {
            PayoutType.UPI -> "UPI: $upiId"
            PayoutType.BANK_ACCOUNT -> "$bankName • $accountNumberMasked (IFSC: $ifscCode)"
        }
}

enum class RiskSeverity(val displayName: String) {
    LOW("Low Risk"),
    MEDIUM("Medium Risk"),
    HIGH("High Risk"),
    CRITICAL("Critical Risk")
}

data class PaymentRiskAlert(
    val id: String = "ALERT_RISK_" + UUID.randomUUID().toString().take(8).uppercase(),
    val transactionId: String = "",
    val bookingId: String = "",
    val riskScore: Int = 0,
    val severity: RiskSeverity = RiskSeverity.MEDIUM,
    val flaggedSignals: List<String> = emptyList(),
    val isResolved: Boolean = false,
    val resolutionNotes: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

enum class NotificationType(val title: String) {
    NEW_BOOKING("New Booking Request"),
    BOOKING_ACCEPTED("Booking Accepted"),
    BOOKING_REJECTED("Booking Request Declined"),
    BOOKING_CONFIRMED("Booking Confirmed"),
    BOOKING_CANCELLED("Booking Cancelled"),
    CANCELLATION_REQUESTED("Cancellation Request Submitted"),
    CANCELLATION_ACCEPTED("Cancellation Accepted"),
    CANCELLATION_REJECTED("Cancellation Rejected"),
    EMERGENCY_REVIEW_SUBMITTED("Emergency Cancellation Review"),
    ADMIN_DECISION_ISSUED("Admin Emergency Decision"),
    BOOKING_RESCHEDULED("Booking Rescheduled"),
    OPERATOR_REASSIGNED("Operator Reassigned"),
    PAYMENT_RECEIVED("Payment Received"),
    CASH_PAYMENT_RECORDED("Cash Payment Recorded at Ghat"),
    REFUND_REQUESTED("Refund Request Submitted"),
    REFUND_PROCESSED("Refund Processed"),
    COMMISSION_UPDATED("Commission Settings Updated"),
    OPERATOR_VERIFIED("Operator Verification Approved"),
    TRIP_REMINDER("Upcoming Safari Reminder"),
    SYSTEM_NOTICE("Sundarban Forest Notice")
}

data class AppNotification(
    val id: String = UUID.randomUUID().toString().take(8),
    val recipientUserId: String = "",
    val title: String = "",
    val message: String = "",
    val type: NotificationType = NotificationType.SYSTEM_NOTICE,
    val bookingId: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

data class PlatformSettings(
    val allowPublicOperatorPhone: Boolean = true,
    val autoApprovePackages: Boolean = false,
    val platformNotice: String = "Peak Season Eco-Guidelines are active across Sundarban Tiger Reserve."
)

object SundarbanCategories {
    val ALL_CATEGORIES = listOf(
        "About Sundarbans",
        "History",
        "Geography",
        "Mangrove Forest",
        "Rivers",
        "Islands",
        "Royal Bengal Tiger",
        "Wildlife",
        "Birds",
        "Fish",
        "Reptiles",
        "Plants",
        "Tourist Destinations",
        "Best Time to Visit",
        "Travel Preparation",
        "Safety",
        "Forest Rules",
        "Tourist Responsibilities",
        "FAQs"
    )

    val OPERATING_AREAS = listOf(
        "All Areas",
        "Gosaba",
        "Canning",
        "Pakhiralay",
        "Dayapur",
        "Jharkhali",
        "Satjelia Island",
        "Sajnekhali",
        "Sonakhali Ghat"
    )

    val DESTINATIONS = listOf(
        "All Destinations",
        "Sajnekhali Watch Tower",
        "Sudhanyakhali Tiger Camp",
        "Dobanki Canopy Walk",
        "Netidhopani Historical Tower",
        "Burirdabri Mud Walk",
        "Jharkhali Tiger Rescue Centre",
        "Panchamukhani Confluence",
        "Pakhiralay Village"
    )

    val VIDEO_CATEGORIES = listOf(
        "Sundarban Introduction",
        "Travel Guide",
        "Wildlife",
        "Tourist Destinations",
        "Safety",
        "Educational",
        "Local Culture"
    )

    val BOOK_CATEGORIES = listOf(
        "Ecological Studies",
        "Wildlife & Tiger Field Guides",
        "Botanical & Mangrove Surveys",
        "History & Delta Geography",
        "Forest Governance & Laws",
        "Travel Handbooks"
    )
}

data class SundarbanArticle(
    val id: String = "",
    val titleEn: String = "",
    val titleBn: String = "",
    val titleHi: String = "",
    val category: String = "Wildlife",
    val summaryEn: String = "",
    val summaryBn: String = "",
    val summaryHi: String = "",
    val contentEn: String = "",
    val contentBn: String = "",
    val contentHi: String = "",
    val imageUrl: String? = null,
    val readTimeMinutes: Int = 4,
    val author: String = "Sundarban Forest Dept. & Eco-Conservation Team",
    val isPublished: Boolean = true,
    val isArchived: Boolean = false,
    val tags: List<String> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun getLocalizedTitle(langCode: String): String = when (langCode) {
        "bn" -> titleBn.ifBlank { titleEn }
        "hi" -> titleHi.ifBlank { titleEn }
        else -> titleEn
    }

    fun getLocalizedSummary(langCode: String): String = when (langCode) {
        "bn" -> summaryBn.ifBlank { summaryEn }
        "hi" -> summaryHi.ifBlank { summaryEn }
        else -> summaryEn
    }

    fun getLocalizedContent(langCode: String): String = when (langCode) {
        "bn" -> contentBn.ifBlank { contentEn }
        "hi" -> contentHi.ifBlank { contentEn }
        else -> contentEn
    }

    val title: String get() = titleEn
    val summary: String get() = summaryEn
    val content: String get() = contentEn
}

data class VideoResource(
    val id: String = "",
    val titleEn: String = "",
    val titleBn: String = "",
    val titleHi: String = "",
    val descriptionEn: String = "",
    val descriptionBn: String = "",
    val descriptionHi: String = "",
    val durationText: String = "12:45",
    val videoUrl: String = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    val thumbnailUrl: String = "",
    val channel: String = "Sundarban Eco Wildlife Foundation",
    val category: String = "Sundarban Introduction",
    val language: String = "English / Bengali / Hindi",
    val isPublished: Boolean = true,
    val transcript: String = "Educational documentary covering Sundarban tidal ecology, wildlife conservation, and forest safety."
) {
    fun getLocalizedTitle(langCode: String): String = when (langCode) {
        "bn" -> titleBn.ifBlank { titleEn }
        "hi" -> titleHi.ifBlank { titleEn }
        else -> titleEn
    }

    fun getLocalizedDescription(langCode: String): String = when (langCode) {
        "bn" -> descriptionBn.ifBlank { descriptionEn }
        "hi" -> descriptionHi.ifBlank { descriptionEn }
        else -> descriptionEn
    }

    val title: String get() = titleEn
    val description: String get() = descriptionEn
}

data class BookChapter(
    val id: String = "",
    val chapterNumber: Int = 1,
    val title: String = "",
    val content: String = ""
)

data class BookResource(
    val id: String = "",
    val titleEn: String = "",
    val titleBn: String = "",
    val titleHi: String = "",
    val author: String = "",
    val descriptionEn: String = "",
    val descriptionBn: String = "",
    val descriptionHi: String = "",
    val pageCount: Int = 120,
    val language: String = "English / Bengali / Hindi",
    val category: String = "Wildlife & Tiger Field Guides",
    val downloadUrl: String = "",
    val format: String = "PDF / Article",
    val chapters: List<BookChapter> = emptyList(),
    val readingProgressPercent: Int = 0,
    val bookmarks: List<Int> = emptyList(),
    val isPublished: Boolean = true
) {
    fun getLocalizedTitle(langCode: String): String = when (langCode) {
        "bn" -> titleBn.ifBlank { titleEn }
        "hi" -> titleHi.ifBlank { titleEn }
        else -> titleEn
    }

    fun getLocalizedDescription(langCode: String): String = when (langCode) {
        "bn" -> descriptionBn.ifBlank { descriptionEn }
        "hi" -> descriptionHi.ifBlank { descriptionEn }
        else -> descriptionEn
    }

    val title: String get() = titleEn
    val description: String get() = descriptionEn
}

data class Review(
    val id: String = "",
    val bookingId: String = "",
    val packageId: String = "",
    val packageTitle: String = "",
    val operatorId: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val rating: Int = 5, // 1 to 5 stars
    val comment: String = "",
    val photoUrl: String? = null,
    val isModerated: Boolean = false,
    val moderationReason: String? = null,
    val isFlagged: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

enum class ComplaintCategory(val displayName: String) {
    PAYMENT_PROBLEM("Payment Problem"),
    BOOKING_PROBLEM("Booking Problem"),
    OPERATOR_PROBLEM("Operator Problem"),
    TOURIST_PROBLEM("Tourist Problem"),
    OVERCHARGING("Overcharging"),
    FALSE_INFORMATION("False Information"),
    MISBEHAVIOR("Misbehavior"),
    SAFETY_ISSUE("Safety Issue"),
    REFUND_PROBLEM("Refund Problem"),
    CANCELLATION_PROBLEM("Cancellation Problem"),
    OTHER("Other")
}

enum class ComplaintStatus(val displayName: String) {
    OPEN("Open"),
    UNDER_REVIEW("Under Review"),
    RESOLVED("Resolved"),
    REJECTED("Rejected")
}

data class Complaint(
    val id: String = "",
    val complaintId: String = "CMP_${UUID.randomUUID().toString().take(8).uppercase()}",
    val complainantId: String = "",
    val complainantName: String = "",
    val complainantRole: UserRole = UserRole.CUSTOMER,
    val targetId: String = "",
    val targetName: String = "",
    val targetRole: UserRole? = null,
    val bookingId: String? = null,
    val packageTitle: String? = null,
    val category: ComplaintCategory = ComplaintCategory.OTHER,
    val subject: String = "",
    val description: String = "",
    val evidenceUrls: List<String> = emptyList(),
    val status: ComplaintStatus = ComplaintStatus.OPEN,
    val adminNotes: String? = null,
    val evidenceRequested: String? = null,
    val resolutionNote: String? = null,
    val rejectionReason: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

enum class DisputeStatus(val displayName: String) {
    OPEN("Open Dispute"),
    UNDER_REVIEW("Under Investigation"),
    EVIDENCE_REQUESTED("Evidence Requested"),
    RESOLVED_REFUND_CUSTOMER("Resolved - Refund Customer"),
    RESOLVED_RELEASE_OPERATOR("Resolved - Payout to Operator"),
    RESOLVED_SPLIT("Resolved - Split Settlement"),
    DISMISSED("Dispute Dismissed")
}

enum class RefundDecisionType(val displayName: String) {
    NONE("No Refund"),
    FULL_REFUND("Full Refund to Customer"),
    PARTIAL_REFUND("Partial Refund to Customer"),
    OPERATOR_RELEASE("Full Release to Operator")
}

data class DisputeMessage(
    val id: String = UUID.randomUUID().toString().take(8),
    val senderId: String = "",
    val senderName: String = "",
    val senderRole: UserRole = UserRole.CUSTOMER,
    val message: String = "",
    val attachmentUrl: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class DisputeRecord(
    val disputeId: String = "DSP_${UUID.randomUUID().toString().take(8).uppercase()}",
    val bookingId: String = "",
    val packageTitle: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val customerEmail: String = "",
    val operatorId: String = "",
    val operatorName: String = "",
    val operatorPhone: String = "",
    val totalBookingAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val transactionIds: List<String> = emptyList(),
    val complaintId: String? = null,
    val disputeReason: String = "",
    val evidenceUrls: List<String> = emptyList(),
    val messages: List<DisputeMessage> = emptyList(),
    val adminNotes: String = "",
    val requestedEvidenceDetails: String? = null,
    val status: DisputeStatus = DisputeStatus.OPEN,
    val refundDecision: RefundDecisionType = RefundDecisionType.NONE,
    val refundAmount: Double = 0.0,
    val decisionSummary: String? = null,
    val decidedByUid: String? = null,
    val decidedByName: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val decidedAt: Long? = null
) {
    val claimedAmount: Double get() = paidAmount
}

enum class RiskLevel(val displayName: String) {
    LOW("Low Risk"),
    MEDIUM("Moderate Risk"),
    HIGH("Elevated Risk"),
    CRITICAL("High Risk / Immediate Review")
}

enum class RiskSignalType(val displayName: String) {
    REPEATED_FAILED_PAYMENTS("Repeated Failed Payments"),
    SUSPICIOUS_DUPLICATE_ACCOUNTS("Suspicious Duplicate Accounts"),
    REPEATED_CANCELLATIONS("Repeated Safari Cancellations"),
    UNUSUAL_BOOKING_ACTIVITY("Unusual Spike in Booking Activity"),
    SUSPICIOUS_PAYMENT_ADJUSTMENTS("Suspicious Cash Adjustment Frequency"),
    REPEATED_COMPLAINTS("Multiple Active Complaints Filed"),
    VERIFICATION_INCONSISTENCIES("Identity / Document Inconsistencies"),
    UNUSUAL_REFUND_ACTIVITY("High Velocity Refund Requests")
}

data class RiskSignal(
    val signalType: RiskSignalType,
    val description: String,
    val severity: RiskLevel = RiskLevel.MEDIUM,
    val detectedAt: Long = System.currentTimeMillis()
)

data class FlaggedRiskCase(
    val caseId: String = "RISK_${UUID.randomUUID().toString().take(8).uppercase()}",
    val targetId: String = "",
    val targetName: String = "",
    val targetRole: UserRole = UserRole.OPERATOR,
    val riskScore: Int = 0, // 0 to 100
    val riskLevel: RiskLevel = RiskLevel.LOW,
    val signals: List<RiskSignal> = emptyList(),
    val isFlaggedForReview: Boolean = true,
    val adminReviewed: Boolean = false,
    val reviewNotes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastActivityAt: Long = System.currentTimeMillis()
)

enum class AdminAlertType(val displayName: String) {
    SUSPICIOUS_OPERATOR("Suspicious Operator Flagged"),
    SERIOUS_COMPLAINT("Serious Complaint Filed"),
    PAYMENT_DISPUTE("Payment Dispute Opened"),
    SUSPICIOUS_TRANSACTION("High Risk Transaction"),
    REPEATED_REPORTS("Multiple User Reports Detected")
}

data class AdminAlert(
    val id: String = "ALT_${UUID.randomUUID().toString().take(8).uppercase()}",
    val type: AdminAlertType,
    val title: String,
    val targetId: String,
    val targetName: String,
    val reason: String,
    val riskIndicators: List<String> = emptyList(),
    val recommendedInvestigation: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isAcknowledged: Boolean = false
)

enum class AuditAction(val displayName: String) {
    OPERATOR_APPROVED("Operator Approved & Verified"),
    OPERATOR_REJECTED("Operator Verification Rejected"),
    OPERATOR_INFO_REQUESTED("Operator Info Requested"),
    USER_WARNED("User Account Warned"),
    USER_RESTRICTED("User Account Restricted"),
    USER_SUSPENDED("User Account Suspended"),
    USER_BANNED("User Account Banned"),
    USER_UNBANNED("User Account Restored / Unbanned"),
    PACKAGE_APPROVED("Tour Package Approved & Published"),
    PACKAGE_REJECTED("Tour Package Rejected"),
    PACKAGE_MODERATED("Tour Package Moderated / Hidden"),
    BOOKING_MODIFIED("Booking Status Modified"),
    PAYMENT_ADJUSTMENT("Cash Ledger Adjusted"),
    REFUND_ISSUED("Refund Authorized & Processed"),
    COMPLAINT_INVESTIGATED("Complaint Marked Under Review"),
    COMPLAINT_RESOLVED("Complaint Resolved"),
    COMPLAINT_REJECTED("Complaint Rejected"),
    DISPUTE_DECIDED("Formal Dispute Adjudicated"),
    COMMISSION_CHANGED("Platform Commission Rate Modified"),
    REVIEW_MODERATED("Customer Review Moderated"),
    SENSITIVE_DOCS_VIEWED("Admin Unmasked Sensitive Verification ID"),
    ADMIN_PROVISIONED("Admin Account Provisioned by Super Admin")
}

data class AuditLogEntry(
    val id: String = "AUD_${UUID.randomUUID().toString().take(10).uppercase()}",
    val adminId: String = "",
    val adminName: String = "",
    val action: AuditAction,
    val targetId: String = "",
    val targetType: String = "",
    val previousValue: String = "",
    val newValue: String = "",
    val reason: String = "",
    val ipOrDevice: String = "Sundarban Admin Terminal (Web/App)",
    val timestamp: Long = System.currentTimeMillis()
)

data class SmartVerificationResult(
    val status: OperatorStatus,
    val isAutoVerified: Boolean,
    val riskScore: Int,
    val riskSignals: List<String>,
    val explanation: String
)

data class OperatorPublicProfile(
    val operatorId: String,
    val name: String,
    val profilePhotoUrl: String?,
    val verifiedBadge: Boolean,
    val verificationStatus: OperatorStatus,
    val experienceYears: Int,
    val guideExperience: String,
    val operatingArea: String,
    val completedTrips: Int,
    val rating: Double,
    val reviewCount: Int,
    val startingPrice: Double,
    val phoneNumber: String?,
    val isPhonePublicVisible: Boolean,
    val packages: List<TourPackage> = emptyList(),
    val reviews: List<Review> = emptyList()
)

data class SundarbanDestination(
    val id: String = "dest_${UUID.randomUUID().toString().take(6)}",
    val nameEn: String = "",
    val nameBn: String = "",
    val category: String = "Watchtower", // Watchtower, Tiger Reserve, Island, Historical, Beach
    val description: String = "",
    val permitRequired: Boolean = true,
    val highlights: List<String> = emptyList(),
    val coordinates: String = "21.9497° N, 88.9004° E",
    val bestTimeToVisit: String = "October to March",
    val imageUrl: String? = null,
    val isFeatured: Boolean = true
)

data class SafetyAdvisory(
    val id: String = "safe_${UUID.randomUUID().toString().take(6)}",
    val title: String = "",
    val category: String = "Wildlife", // Wildlife, Tidal, Cyclone, Boat Safety, Health
    val severity: String = "Advisory", // Advisory, Warning, Emergency
    val details: String = "",
    val guidelineSteps: List<String> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class EmergencyContactItem(
    val id: String = "emg_${UUID.randomUUID().toString().take(6)}",
    val agencyName: String = "",
    val designation: String = "",
    val phoneNumber: String = "",
    val secondaryPhone: String = "",
    val location: String = "Canning / Gosaba / Sajnekhali",
    val is24x7: Boolean = true,
    val type: String = "Forest Department" // Forest Department, Coastal Police, Boat Ambulance, Search & Rescue
)

data class PlatformBroadcastNotification(
    val id: String = "ntf_${UUID.randomUUID().toString().take(6)}",
    val title: String = "",
    val message: String = "",
    val recipientRole: String = "ALL", // ALL, CUSTOMER, OPERATOR
    val priority: String = "NORMAL", // NORMAL, HIGH, URGENT_CYCLONE
    val sentAt: Long = System.currentTimeMillis(),
    val sentByAdmin: String = "Sundarban Admin Directorate"
)

data class LanguageSetting(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val isDefault: Boolean = false,
    val translationProgress: Int = 100
)
