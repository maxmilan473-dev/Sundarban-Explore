package com.example.core.model

enum class UserRole(val displayName: String) {
    CUSTOMER("Tourist / Customer"),
    OPERATOR("Tour Operator"),
    ADMIN("Administrator")
}

enum class AccountStatus(val displayName: String) {
    ACTIVE("Active"),
    WARNED("Warned"),
    RESTRICTED("Restricted"),
    SUSPENDED("Suspended"),
    BANNED("Banned")
}

enum class OperatorStatus(val displayName: String, val publicVisible: Boolean = false) {
    PENDING_REVIEW("Review Required", false),
    APPROVED("Approved", true),
    REJECTED("Rejected", false),
    CHANGES_REQUESTED("Changes Requested", false),
    SUSPENDED("Suspended", false),

    // Backward-compatibility aliases and new system statuses
    PENDING_VERIFICATION("Review Required", false),
    AUTOMATICALLY_VERIFIED("Auto-Verified", true),
    VERIFIED("Verified", true),
    REQUIRES_ADMIN_REVIEW("Review Required", false),
    INFORMATION_REQUIRED("Info Required", false),
    DRAFT("Draft", false),
    BANNED("Banned", false)
}

data class EmergencyContact(
    val name: String = "",
    val relationship: String = "",
    val phoneNumber: String = ""
)

data class VerificationDocument(
    val id: String = "",
    val docType: String = "Government ID",
    val title: String = "",
    val documentNumberMasked: String = "",
    val rawDocumentNumber: String = "",
    val fileUrl: String = "",
    val uploadedAt: Long = System.currentTimeMillis(),
    val isVerified: Boolean = false
)

data class OperatorDetails(
    val operatingArea: String = "",
    val yearsOfExperience: Int = 0,
    val guideExperience: String = "",
    val serviceType: String = "Boat Safari & Guided Eco-Tour",
    val languagesSpoken: String = "Bengali, English, Hindi",
    val maxTourists: Int = 15,
    val operatorBusinessName: String = "",
    val dateOfBirth: String = "",
    val gender: String = "Male",
    val state: String = "West Bengal",
    val district: String = "South 24 Parganas",
    val onlinePaymentEnabled: Boolean = true,
    val cashPaymentEnabled: Boolean = true,
    val tourPackageTitle: String = "Sundarban 2D/1N Royal Mangrove Safari",
    val tourDuration: String = "2 Days / 1 Night",
    val tourPrice: Double = 4500.0,
    val tourMaxCapacity: Int = 12,
    val tourAvailableDates: String = "Daily Departures / Weekends",
    val govIdType: String = "Government ID",
    val govIdNumber: String = "", // Masked for public safety
    val licenseNumber: String = "",
    val boatRegistrationNumber: String = "",
    val bankUpiId: String = "",
    val bankAccountName: String = "",
    val bankAccountNumberMasked: String = "",
    val bankIfscCode: String = "",
    val bankName: String = "",
    val isPayoutDetailsVerified: Boolean = false,
    val payoutVerifiedAt: Long? = null,
    val payoutVerificationMethod: String = "",
    val verificationStatus: OperatorStatus = OperatorStatus.PENDING_REVIEW,
    val phoneVerified: Boolean = false,
    val emailVerified: Boolean = false,
    val documents: List<VerificationDocument> = emptyList(),
    val riskScore: Int = 0, // 0 (lowest risk / clean) to 100 (high risk)
    val riskSignals: List<String> = emptyList(),
    val autoVerificationPassed: Boolean = false,
    val adminNotes: String? = null,
    val rejectionReason: String? = null,
    val infoRequiredNote: String? = null,
    val accountHistory: List<String> = emptyList(),
    val verificationSubmittedAt: Long = System.currentTimeMillis()
) {
    val maskedGovId: String
        get() {
            if (govIdNumber.isBlank()) return "Not Provided"
            val clean = govIdNumber.trim()
            return if (clean.length > 4) {
                "XXXX-XXXX-" + clean.takeLast(4)
            } else {
                "XXXX-" + clean
            }
        }

    val maskedBankUpi: String
        get() {
            if (bankUpiId.isBlank()) return "Not Set"
            val parts = bankUpiId.split("@")
            return if (parts.size == 2) {
                parts[0].take(3) + "****@" + parts[1]
            } else {
                "****" + bankUpiId.takeLast(4)
            }
        }

    val maskedBankAccount: String
        get() {
            if (bankAccountNumberMasked.isBlank()) return "Not Set"
            return bankAccountNumberMasked
        }

    val verifiedPayoutDisplay: String
        get() {
            return when {
                !isPayoutDetailsVerified && bankUpiId.isBlank() && bankAccountNumberMasked.isBlank() -> "No Payout Account Configured"
                !isPayoutDetailsVerified -> "Pending Verification (${if (bankUpiId.isNotBlank()) "UPI" else "Bank Account"})"
                bankUpiId.isNotBlank() -> "Verified UPI: $maskedBankUpi"
                bankAccountNumberMasked.isNotBlank() -> "Verified Bank: $bankName ($maskedBankAccount, IFSC: $bankIfscCode)"
                else -> "Not Set"
            }
        }
}

data class UserProfile(
    val id: String = "",
    val email: String = "",
    val fullName: String = "",
    val phoneNumber: String = "",
    val phoneVerified: Boolean = false,
    val role: UserRole = UserRole.CUSTOMER,
    val profilePhotoUrl: String? = null,
    val address: String = "",
    val emergencyContact: EmergencyContact = EmergencyContact(),
    val isVerified: Boolean = false,
    val accountStatus: AccountStatus = AccountStatus.ACTIVE,
    val statusReason: String = "",
    val warningCount: Int = 0,
    val warningMessages: List<String> = emptyList(),
    val suspendedUntil: Long? = null,
    val operatorDetails: OperatorDetails? = null,
    val isSuperAdmin: Boolean = false,
    val designation: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val preferredLanguage: String = "en"
) {
    val uid: String get() = id

    val isAccountActive: Boolean
        get() = accountStatus == AccountStatus.ACTIVE || accountStatus == AccountStatus.WARNED

    val isPublicVerifiedOperator: Boolean
        get() = role == UserRole.OPERATOR &&
                isAccountActive &&
                (operatorDetails?.verificationStatus == OperatorStatus.APPROVED ||
                 operatorDetails?.verificationStatus == OperatorStatus.VERIFIED ||
                 operatorDetails?.verificationStatus == OperatorStatus.AUTOMATICALLY_VERIFIED)
}
