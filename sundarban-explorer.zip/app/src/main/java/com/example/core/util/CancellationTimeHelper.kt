package com.example.core.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object CancellationTimeHelper {

    /**
     * Exact difference in hours between current time and scheduled tour start date & time.
     * If more than 5.0 hours remain: Normal Cancellation Flow.
     * If 5.0 hours or less remain: Emergency Cancellation Flow (Directorate Admin Review).
     */
    fun calculateHoursRemaining(
        travelDate: String,
        tourStartTime: String = "08:00 AM",
        nowMs: Long = System.currentTimeMillis()
    ): Double {
        val startEpoch = getScheduledStartEpoch(travelDate, tourStartTime)
        val diffMs = startEpoch - nowMs
        return diffMs / (1000.0 * 60.0 * 60.0)
    }

    fun isEmergencyCancellation(
        travelDate: String,
        tourStartTime: String = "08:00 AM",
        nowMs: Long = System.currentTimeMillis()
    ): Boolean {
        return calculateHoursRemaining(travelDate, tourStartTime, nowMs) <= 5.0
    }

    fun getScheduledStartEpoch(travelDate: String, tourStartTime: String = "08:00 AM"): Long {
        val cleanDate = travelDate.trim()
        val cleanTime = tourStartTime.trim().ifBlank { "08:00 AM" }

        val formatCombos = listOf(
            SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.US),
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US),
            SimpleDateFormat("yyyy-MM-dd h:mm a", Locale.US),
            SimpleDateFormat("yyyy-MM-dd", Locale.US)
        )

        for (fmt in formatCombos) {
            try {
                val input = if (fmt.toPattern().contains(" ")) "$cleanDate $cleanTime" else cleanDate
                val parsed = fmt.parse(input)
                if (parsed != null) {
                    return if (fmt.toPattern().contains(" ")) {
                        parsed.time
                    } else {
                        // Default to 8:00 AM if pattern had only date
                        val cal = Calendar.getInstance().apply {
                            time = parsed
                            set(Calendar.HOUR_OF_DAY, 8)
                            set(Calendar.MINUTE, 0)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        cal.timeInMillis
                    }
                }
            } catch (_: Exception) {
                // try next format
            }
        }

        // Fallback: parse date or fallback to now + 24h
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdf.parse(cleanDate) ?: Date(System.currentTimeMillis() + 86400000L)
            val cal = Calendar.getInstance().apply {
                time = date
                set(Calendar.HOUR_OF_DAY, 8)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            cal.timeInMillis
        } catch (_: Exception) {
            System.currentTimeMillis() + 86400000L
        }
    }

    fun formatHoursRemaining(hours: Double): String {
        return when {
            hours < 0.0 -> "Tour departed ${String.format(Locale.US, "%.1f", -hours)} hrs ago"
            hours < 1.0 -> "${(hours * 60).toInt().coerceAtLeast(1)} mins remaining"
            hours < 24.0 -> "${String.format(Locale.US, "%.1f", hours)} hrs remaining"
            else -> {
                val days = (hours / 24).toInt()
                val remHours = (hours % 24).toInt()
                "$days d $remHours hrs remaining"
            }
        }
    }
}
