package com.example.core.analytics

import android.util.Log

interface AnalyticsTracker {
    fun logEvent(name: String, params: Map<String, Any> = emptyMap())
    fun logScreenView(screenName: String)
    fun setUserProperty(name: String, value: String)
}

class DefaultAnalyticsTracker : AnalyticsTracker {
    override fun logEvent(name: String, params: Map<String, Any>) {
        Log.d("SundarbanAnalytics", "Event: $name | Params: $params")
    }

    override fun logScreenView(screenName: String) {
        Log.d("SundarbanAnalytics", "ScreenView: $screenName")
    }

    override fun setUserProperty(name: String, value: String) {
        Log.d("SundarbanAnalytics", "UserProperty: $name = $value")
    }
}
