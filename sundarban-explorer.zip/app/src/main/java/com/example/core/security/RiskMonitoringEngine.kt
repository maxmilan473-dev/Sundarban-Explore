package com.example.core.security

import com.example.core.model.AdminAlert
import com.example.core.model.AdminAlertType
import com.example.core.model.Booking
import com.example.core.model.BookingStatus
import com.example.core.model.Complaint
import com.example.core.model.FlaggedRiskCase
import com.example.core.model.PaymentTransaction
import com.example.core.model.RefundRecord
import com.example.core.model.RiskLevel
import com.example.core.model.RiskSignal
import com.example.core.model.RiskSignalType
import com.example.core.model.TransactionStatus
import com.example.core.model.UserProfile
import com.example.core.model.UserRole
import java.util.UUID

object RiskMonitoringEngine {

    /**
     * Scans user activity across bookings, transactions, complaints, refunds, and verifications
     * to identify potential risk indicators.
     *
     * IMPORTANT SAFETY PRINCIPLE:
     * Flagged cases are marked for human Admin review only.
     * The system NEVER automatically labels a user as a fraudster or automatically bans accounts.
     */
    fun evaluateUserRisk(
        user: UserProfile,
        userBookings: List<Booking>,
        userTransactions: List<PaymentTransaction>,
        userComplaints: List<Complaint>,
        userRefunds: List<RefundRecord>,
        allUsers: List<UserProfile>
    ): FlaggedRiskCase? {
        val signals = mutableListOf<RiskSignal>()
        var totalScore = 0

        // 1. Repeated Failed Payments Signal
        val failedTxns = userTransactions.count { it.status == TransactionStatus.FAILED }
        if (failedTxns >= 3) {
            signals.add(
                RiskSignal(
                    signalType = RiskSignalType.REPEATED_FAILED_PAYMENTS,
                    description = "Detected $failedTxns failed payment transactions in the financial ledger.",
                    severity = if (failedTxns > 5) RiskLevel.HIGH else RiskLevel.MEDIUM
                )
            )
            totalScore += (failedTxns * 10).coerceAtMost(30)
        }

        // 2. Suspicious Duplicate Accounts (shared phone or normalized name)
        val duplicatePhoneCount = allUsers.count { 
            it.id != user.id && it.phoneNumber.isNotBlank() && it.phoneNumber == user.phoneNumber 
        }
        if (duplicatePhoneCount > 0) {
            signals.add(
                RiskSignal(
                    signalType = RiskSignalType.SUSPICIOUS_DUPLICATE_ACCOUNTS,
                    description = "Phone number ${user.phoneNumber} is associated with $duplicatePhoneCount other registered profile(s).",
                    severity = RiskLevel.HIGH
                )
            )
            totalScore += 35
        }

        // 3. Repeated Cancellations
        val cancelledBookings = userBookings.count { it.bookingStatus == BookingStatus.CANCELLED }
        if (cancelledBookings >= 3 && userBookings.isNotEmpty()) {
            val cancelRatio = cancelledBookings.toDouble() / userBookings.size
            if (cancelRatio > 0.5) {
                signals.add(
                    RiskSignal(
                        signalType = RiskSignalType.REPEATED_CANCELLATIONS,
                        description = "High cancellation frequency: $cancelledBookings of ${userBookings.size} bookings cancelled (${(cancelRatio * 100).toInt()}%).",
                        severity = RiskLevel.MEDIUM
                    )
                )
                totalScore += 20
            }
        }

        // 4. Unusual Booking Activity (Sudden high volume in a 24-hour window)
        val recent24hBookings = userBookings.count {
            System.currentTimeMillis() - it.createdAt < 24 * 60 * 60 * 1000L
        }
        if (recent24hBookings >= 6) {
            signals.add(
                RiskSignal(
                    signalType = RiskSignalType.UNUSUAL_BOOKING_ACTIVITY,
                    description = "Unusual surge of $recent24hBookings safari bookings created within a 24-hour window.",
                    severity = RiskLevel.MEDIUM
                )
            )
            totalScore += 25
        }

        // 5. Suspicious Payment Adjustments (For Operators)
        if (user.role == UserRole.OPERATOR) {
            val adjustmentsCount = userTransactions.count { it.isAdjustment }
            if (adjustmentsCount >= 2) {
                signals.add(
                    RiskSignal(
                        signalType = RiskSignalType.SUSPICIOUS_PAYMENT_ADJUSTMENTS,
                        description = "Operator logged $adjustmentsCount retrospective cash adjustments requiring administrative ledger review.",
                        severity = RiskLevel.HIGH
                    )
                )
                totalScore += 30
            }
        }

        // 6. Repeated Complaints Against User
        val complaintsAgainstUser = userComplaints.filter { it.targetId == user.id }
        if (complaintsAgainstUser.size >= 2) {
            signals.add(
                RiskSignal(
                    signalType = RiskSignalType.REPEATED_COMPLAINTS,
                    description = "${complaintsAgainstUser.size} active complaint(s) filed by tourists/operators regarding service delivery.",
                    severity = if (complaintsAgainstUser.size >= 3) RiskLevel.CRITICAL else RiskLevel.HIGH
                )
            )
            totalScore += (complaintsAgainstUser.size * 20).coerceAtMost(40)
        }

        // 7. Verification Inconsistencies (For Operators)
        if (user.role == UserRole.OPERATOR) {
            val details = user.operatorDetails
            if (details != null && details.riskScore > 20) {
                signals.add(
                    RiskSignal(
                        signalType = RiskSignalType.VERIFICATION_INCONSISTENCIES,
                        description = "Operator credentials have ${details.riskSignals.size} automated verification flag(s).",
                        severity = if (details.riskScore > 50) RiskLevel.HIGH else RiskLevel.MEDIUM
                    )
                )
                totalScore += details.riskScore / 2
            }
        }

        // 8. Unusual Refund Activity
        val refundCount = userRefunds.size
        if (refundCount >= 2) {
            signals.add(
                RiskSignal(
                    signalType = RiskSignalType.UNUSUAL_REFUND_ACTIVITY,
                    description = "$refundCount refund claims processed or requested for this account.",
                    severity = RiskLevel.MEDIUM
                )
            )
            totalScore += 15
        }

        if (signals.isEmpty() && totalScore < 20) {
            return null
        }

        val riskLevel = when {
            totalScore >= 70 -> RiskLevel.CRITICAL
            totalScore >= 45 -> RiskLevel.HIGH
            totalScore >= 25 -> RiskLevel.MEDIUM
            else -> RiskLevel.LOW
        }

        return FlaggedRiskCase(
            caseId = "RISK_${user.id.takeLast(6).uppercase()}_${UUID.randomUUID().toString().take(4).uppercase()}",
            targetId = user.id,
            targetName = user.fullName,
            targetRole = user.role,
            riskScore = totalScore.coerceIn(0, 100),
            riskLevel = riskLevel,
            signals = signals,
            isFlaggedForReview = true,
            createdAt = System.currentTimeMillis(),
            lastActivityAt = System.currentTimeMillis()
        )
    }

    /**
     * Converts high-severity risk cases and serious complaints into actionable Admin Alerts.
     */
    fun generateAdminAlerts(
        riskCases: List<FlaggedRiskCase>,
        complaints: List<Complaint>
    ): List<AdminAlert> {
        val alerts = mutableListOf<AdminAlert>()

        // 1. High & Critical Risk Cases
        riskCases.filter { it.riskLevel == RiskLevel.HIGH || it.riskLevel == RiskLevel.CRITICAL }
            .forEach { riskCase ->
                alerts.add(
                    AdminAlert(
                        id = "ALT_RISK_${riskCase.caseId}",
                        type = if (riskCase.targetRole == UserRole.OPERATOR) AdminAlertType.SUSPICIOUS_OPERATOR else AdminAlertType.SUSPICIOUS_TRANSACTION,
                        title = "${riskCase.riskLevel.displayName}: ${riskCase.targetName} (${riskCase.targetRole.displayName})",
                        targetId = riskCase.targetId,
                        targetName = riskCase.targetName,
                        reason = "Risk score ${riskCase.riskScore}/100 detected across ${riskCase.signals.size} telemetry signals.",
                        riskIndicators = riskCase.signals.map { "${it.signalType.displayName}: ${it.description}" },
                        recommendedInvestigation = "Inspect submitted identity credentials, review linked booking payment receipts, and contact the party directly before taking administrative action.",
                        timestamp = riskCase.createdAt
                    )
                )
            }

        // 2. Serious Complaints (Overcharging, Misbehavior, Safety Issue)
        complaints.filter {
            it.status == com.example.core.model.ComplaintStatus.OPEN &&
                    (it.category == com.example.core.model.ComplaintCategory.SAFETY_ISSUE ||
                            it.category == com.example.core.model.ComplaintCategory.OVERCHARGING ||
                            it.category == com.example.core.model.ComplaintCategory.MISBEHAVIOR)
        }.forEach { cmp ->
            alerts.add(
                AdminAlert(
                    id = "ALT_CMP_${cmp.id}",
                    type = AdminAlertType.SERIOUS_COMPLAINT,
                    title = "Urgent: ${cmp.category.displayName} Filed",
                    targetId = cmp.targetId,
                    targetName = cmp.targetName,
                    reason = "Complainant ${cmp.complainantName} reported: ${cmp.subject}",
                    riskIndicators = listOf("Category: ${cmp.category.displayName}", "Complainant: ${cmp.complainantName} (${cmp.complainantRole.name})"),
                    recommendedInvestigation = "Review booking details, check GPS logs/checkpost records, and initiate formal dispute mediation.",
                    timestamp = cmp.createdAt
                )
            )
        }

        return alerts.sortedByDescending { it.timestamp }
    }
}
